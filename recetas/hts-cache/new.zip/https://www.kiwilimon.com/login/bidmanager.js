
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <title>Recetas de cocina</title>
    <meta name="description" content="Cocina una gran variedad de recetas de cocina con reseñas, fotos y calificaciones.  Aprende y mejora tus habilidades culinarias con las mejores recetas de cocina. Sube tus propias recetas de cocina, reseñas y fotos para formar parte de la comunidad Kiwilimón." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <meta name="author" content="Kiwilimon®, Copyright © 2010-2022" />
    <meta name="generator" content="Kiwilimon - Xamboo GO Framework - v7 - site7" />
    <meta name="rating" content="General" />
    <meta name="designer" content="Kiwilimon.com" />

    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png?v=7.0.1" />
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png?v=7.0.1" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png?v=7.0.1" />
    <link rel="manifest" href="/manifest.json?v=7.0.1" crossorigin="use-credentials" />
    <link rel="mask-icon" href="/safari-pinned-tab.svg?v=7.0.1" color="#5bbad5" />
    <link rel="shortcut icon" href="/favicon.ico?v=7.0.1" />
    <meta name="msapplication-TileColor" content="#da532c" />
    <meta name="theme-color" content="#8CC63E" />
    

    <meta name="robots" content="index,follow" />
    <meta name="revisit-after" content="2 days" />
    <link rel="canonical" href="https://www.kiwilimon.com/login/bidmanager.js">
    <link rel="amphtml" href="https://www.kiwilimon.com/amp/login/bidmanager.js">

    <link rel="image_src" href="" />
    <meta property="og:image" content="" />
    <meta property="og:title" content="" />
    <meta property="og:url" content="" />
    <meta property="og:description" content="" />
    <meta property="og:type" content="website" />

    <meta property="fb:pages" content="162885097834" />
    <meta property="fb:app_id" content="250305718425857" />
    <meta name="google-signin-scope" content="profile email" />
    <meta name="google-signin-client_id" content="283529264243-vvdq0isu1kiu6ic5rob68ngf2imok0j7.apps.googleusercontent.com" />
    <meta name="google-site-verification" content="8MdIdUMhzL3gBZ-meCWDkQ6m0iDyONNgqmBIMF9Es2Y" />
    <meta name="googlebot" content="index,follow" />
    <meta content='app-id=680885433' name='apple-itunes-app' />
    <meta name="format-detection" content="telephone=no" />
    <link rel="preconnect" href="https://cdn7.kiwilimon.com" />
    <link rel="preconnect" href="https://browser-update.org" />
    <link rel="preconnect" href="https://www.google-analytics.com" />
    <link rel="preconnect" href="https://certify-js.alexametrics.com" />
    <link rel="preconnect" href="https://certify.alexametrics.com" />
    <link rel="preconnect" href="https://sb.scorecardresearch.com" />
    <link rel="preconnect" href="https://connect.facebook.net" />
    <link rel="preconnect" href="https://stats.g.doubleclock.net" />
    <link rel="preconnect" href="https://www.google.com" />
    <link rel="preconnect" href="https://www.facebook.com" />
    <link rel="preconnect" href="https://consent.cookiebot.com" />
    <link rel="preload" href="/fonts/icomoon.woff2" as="font" crossorigin="anonymous" />
    <link rel="preload" href="/fonts/source-sans-pro-200.woff2" as="font" type="font/woff2" crossorigin="anonymous" />
    <link rel="preload" href="/fonts/source-sans-pro-400.woff2" as="font" type="font/woff2" crossorigin="anonymous" />
    <link rel="preload" href="/fonts/source-sans-pro-700.woff2" as="font" type="font/woff2" crossorigin="anonymous" />




<script type="text/javascript">
/*
    core.js, WAJAF, the WebAbility(r) Javascript Application Framework
    Simplified version for Templates Subset for kiwilimon
    Contains multi purpose functions, browser and WA objects
    (c) 2008-2020 Philippe Thomassigny

    This file is part of WAJAF

    WAJAF is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    WAJAF is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with WAJAF.  If not, see <http://www.gnu.org/licenses/>.
*/

var WA = { version: '4.0.0' };
WA.Managers = {};

WA.isString = function(val)
{
  return typeof val === 'string' || Object.prototype.toString.apply(val) === '[object String]';
}

WA.isDOM = function(o)
{
  // be carefull: window is NOT a Node !
  return (o === window || (typeof Node === 'object' ? o instanceof Node : o !== null && typeof o === 'object' && typeof o.nodeType === 'number' && typeof o.nodeName === 'string' ));
}


WA.isArray = function(val)
{
  return Object.prototype.toString.apply(val) === '[object Array]';
}

WA.isObject = function(val)
{
  return typeof val == 'object';
}

WA.isFunction = function(val)
{
  return Object.prototype.toString.apply(val) === '[object Function]';
}

WA.getDomNode = function(domID)
{
  if (arguments.length > 1)
  {
    var elements = [];
    for (var i = 0, l = arguments.length; i < l; i++)
      elements.push(WA.toDOM(arguments[i]));
    return elements;
  }
  if (WA.isString(domID))
    return document.getElementById(domID);
  return null;
}

WA.toDOM = function(n)
{
  if (WA.isDOM(n))
    return n;
  else if (WA.isString(n))
    return WA.getDomNode(n);
  return null;
}


WA.get = function(n)
{
  var self = this;
  var _nodes = [];
  // if multi is a string => search for NODE ID, or NODE CLASS or NODE ?
  if (WA.isString(n))
  {
    switch(n[0])
    {
      case '#': _nodes = [WA.getDomNode(n.substr(1))]; break;
      case '.':
        if (document.getElementsByClassName)
          _nodes = document.getElementsByClassName(n.substr(1));
        else
        {
          theclass = new RegExp('\\b'+n.substr(1)+'\\b');
          allnodes = this.getElementsByTagName('*');
          for (var i = 0, l = allnodes.length; i < l; i++)
            if (theclass.test(allnodes[i].className)) _nodes.push(allnodes[i]);
        }
        break;
      case '!': _nodes = Array.prototype.slice.call(document.getElementsByName(n.substr(1))); break;
      // anything else (start with a letter ?)
      default: _nodes = Array.prototype.slice.call(document.getElementsByTagName(n)); break;
    }
  }
  else if (WA.isDOM(n))
    _nodes = [n];

  // fast access to the first
  this.node = function () { return _nodes[0]; }

  // fast access to the nodes
  this.nodes = function() { return _nodes; }

  // content of the nodes
  this.text = function(t)
  {
    t = t.replace(/\&/g,"&amp;").replace(/\'/g,"&#39;").replace(/\"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    for (var i = 0, l = _nodes.length; i < l; i++) _nodes[i].innerHTML = t; return self;
  }
  this.html = function(t) { for (var i = 0, l = _nodes.length; i < l; i++) _nodes[i].innerHTML = t; return self; }
  this.append = function(t) { for (var i = 0, l = _nodes.length; i < l; i++) _nodes[i].innerHTML += t; return self; }

  // generic css
  this.css = function(p, v)
  {
    if (v === undefined)
      return _nodes[0]?_nodes[0].style[p]:undefined;
    for (var i = 0, l = _nodes.length; i < l; i++)
      _nodes[i].style[p] = v;
    return self;
  }

  // some most common CSS
  this.CSSwidth = function(v) { return self.css('width', v); }
  this.CSSheight = function(v) { return self.css('height', v); }
  this.CSSleft = function(v) { return self.css('left', v); }
  this.CSStop = function(v) { return self.css('top', v); }
  this.CSSmargin = function(v) { return self.css('margin', v); }
  this.CSSpadding = function(v) { return self.css('padding', v); }
  this.CSSborder = function(v) { return self.css('border', v); }
  this.CSScolor = function(v) { return self.css('color', v); }
  this.CSSbgcolor = function(v) { return self.css('backgroundColor', v); }
  this.CSSbg = function(v) { return self.css('background', v); }
  this.CSSfont = function(v) { return self.css('font', v); }
  this.CSSdisplay = function(v) { return self.css('display', v); }
  this.CSSopacity = function(v) { self.css('opacity', v/100); return self.css('filter', 'alpha(opacity: '+v+')'); }

  // some metrics
  this.width = function(v) { if (v === undefined) return _nodes[0]?WA.browser.getNodeWidth(_nodes[0]):null; else return self.css('width', WA.isNumber(v)?v+'px':v); }
  this.height = function(v) { if (v === undefined) return _nodes[0]?WA.browser.getNodeHeight(_nodes[0]):null; else return self.css('height', WA.isNumber(v)?v+'px':v); }
  this.left = function(v, n) { if (v === undefined) return _nodes[0]?(n===undefined?WA.browser.getNodeDocumentLeft(_nodes[0]):WA.browser.getNodeNodeLeft(_nodes[0], n)):null; else return self.css('left', WA.isNumber(v)?v+'px':v); }
  this.top = function(v, n) { if (v === undefined) return _nodes[0]?(n===undefined?WA.browser.getNodeDocumentTop(_nodes[0]):WA.browser.getNodeNodeTop(_nodes[0], n)):null; else return self.css('top', WA.isNumber(v)?v+'px':v); }

  // generic animation
  this.anim = function(s, f) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.createSprite(_nodes[i], s, f); return self; }

  // some basic animations
  this.fadeIn = function(s, f) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.fadeIn(_nodes[i], s, f); return self; }
  this.fadeOut = function(s, f) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.fadeOut(_nodes[i], s, f); return self; }
  this.openV = function(s, f, h) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.openV(_nodes[i], s, h, f); return self; }
  this.closeV = function(s, f, h) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.closeV(_nodes[i], s, h, f); return self; }
  this.openH = function(s, f, w) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.openH(_nodes[i], s, w, f); return self; }
  this.closeH = function(s, f, w) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.closeH(_nodes[i], s, w, f); return self; }
  this.open = function(s, f, w, h) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.open(_nodes[i], s, w, h, f); return self; }
  this.close = function(s, f, w, h) { if (!WA.Managers.anim) return null; for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.anim.close(_nodes[i], s, w, h, f); return self; }
  this.move = function(s, x, y, f, l, t) { if (!WA.Managers.anim) return null; for (var i = 0, lx = _nodes.length; i < lx; i++) WA.Managers.anim.move(_nodes[i], s, l, t, x, y, f); return self; }

  // generic mouse event binder
  this.on = function(e, f) { for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.event.on(e, _nodes[i], f, true); return self; }
  this.off = function(e, f) { for (var i = 0, l = _nodes.length; i < l; i++) WA.Managers.event.off(e, _nodes[i], f, true); return self; }

  // some most common events
  this.click = function(f) { return self.on('click', f); }
  this.dblclick = function(f) { return self.on('dblclick', f); }
  this.mouseover = function(f) { return self.on('mouseover', f); }
  this.mouseout = function(f) { return self.on('mouseout', f); }
  this.mousemove = function(f) { return self.on('mousemove', f); }
  this.mousedown = function(f) { return self.on('mousedown', f); }
  this.mouseup = function(f) { return self.on('mouseup', f); }
  this.keydown = function(f) { return self.on('keydown', f); }
  this.keyup = function(f) { return self.on('keyup', f); }

  return this;
}


// Messages and internationalization
WA.i18n = function() {}
WA.i18n.defaulti18n = {
  'json.error': 'The JSON code has been parsed with error, it cannot be built.\n',
  'json.unknown': 'The JSON core do not know what to do with this unknown type: '
};
WA.i18n.i18n = {};

WA.i18n.setEntry = function(id, message)
{
  WA.i18n.defaulti18n[id] = message;
}

WA.i18n.loadMessages = function(messages)
{
  for (var i in messages)
  {
    if (!WA.isString(messages[i]))     // we are only interested by strings
      continue;
    WA.i18n.i18n[i] = messages[i];
  }
}

WA.i18n.getMessage  = function(id)
{
  return WA.i18n.i18n[id] || WA.i18n.defaulti18n[id] || id;
}

WA.createDomNode = function(type, id, classname)
{
  var domnode = document.createElement(type);
  if (id)
    domnode.id = id;
  if (classname !== null && classname != undefined)
    domnode.className = classname;
  return domnode;
}


WA.extend = function(collector, source)
{
  var f = function() {};
  f.prototype = source.prototype;
  collector.prototype = new f();
  collector.prototype.constructor = collector;
  collector.sourceconstructor = source;
  collector.source = source.prototype;
  return collector;
}

WA.clone = function(obj)
{
  var cloned = {};
  for (var i in obj)
  {
    if (!obj.hasOwnProperty(i))
      continue;
    if (typeof obj[i] == 'object' && !WA.isDOM(obj[i]))
      cloned[i] = WA.clone(obj[i]);
    else
      cloned[i] = obj[i];
  }
  return cloned;
}

//  
// 

// Date basic functions
WA.Date = {};
WA.Date.setNames = function(days, shortdays, months, shortmonths)
{
  WA.Date.days = days;
  WA.Date.shortdays = shortdays;
  WA.Date.months = months;
  WA.Date.shortmonths = shortmonths;
}

// english by default
WA.Date.setNames(
  ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
);

WA.Date.basicdays = [31,28,31,30,31,30,31,31,30,31,30,31];

WA.Date.isDate = function(year, month, day)
{
  var numdays = WA.Date.basicdays[month-1];
  return day>0 && !!numdays && (day<=numdays || day==29 && year%4==0 && (year%100!=0 || year%400==0) );
}

WA.Date.isTime = function(hour, min, sec)
{
  return hour>=0 && hour<=23 && min>=0 && min<=59 && sec>=0 && sec<=59;
}

WA.Date.isValid = function(year, month, day, hour, min, sec, ms)
{
  hour = hour || 0;
  min = min || 0;
  sec = sec || 0;
  ms = ms || 0;
  // no need to apply(this) for isDate and isTime, they are static funcions
  return WA.Date.isDate(year, month, day) && WA.Date.isTime(hour, min, sec) && ms >= 0 && ms <= 999;
}

WA.Date.isLeapYear = function(d)
{
  var year = d.getFullYear();
  return (year%4==0 && (year%100!=0 || year%400==0));
}

WA.Date.getOrdinalSuffix = function()
{
  switch (this.getDate())
  {
    case 1: case 21: case 31: return 'st';
    case 2: case 22:          return 'nd';
    case 3: case 23:          return 'rd';
    default:                  return 'th';
  }
}

WA.Date.getMaxMonthDays = function(d)
{
  var numdays = WA.Date.basicdays[d.getMonth()];
  if (numdays == 28 && WA.Date.isLeapYear(d))
  {
    numdays++;
  }
  return numdays;
}

WA.Date.getDayOfYear = function()
{
  var day = this.getDate();
  for (var i = 0; i <= this.getMonth()-1; i++)
    day += WA.Date.basicdays[i] + (i==1&&WA.Date.isLeapYear(this)?1:0);
  return day;
}

// adapted from http://www.merlyn.demon.co.uk/weekcalc.htm
WA.Date.getWeekOfYear = function()
{
  var ms1d = 86400000;
  var ms7d = 604800000;
  var DC3 = Date.UTC(this.getFullYear(), this.getMonth(), this.getDate() + 3) / ms1d;
  var AWN = Math.floor(DC3 / 7);
  var Wyr = (new Date(AWN * ms7d)).getUTCFullYear();
  return AWN - Math.floor(Date.UTC(Wyr, 0, 7) / ms7d) + 1;
}

WA.Date.getGMTOffset = function(colon)
{
  return (this.getTimezoneOffset() > 0 ? '-' : '+')
      + String.padding(2, '0', Math.floor(Math.abs(this.getTimezoneOffset()) / 60))
      + (colon ? ':' : '')
      + String.padding(2, '0', Math.abs(this.getTimezoneOffset() % 60));
}

// by extJS
WA.Date.getTimezone = function()
{
  return this.toString().replace(/^.* (?:\((.*)\)|([A-Z]{1,4})(?:[\-+][0-9]{4})?(?: -?\d+)?)$/, '$1$2').replace(/[^A-Z]/g, '');
}

// original idea of structure/pattern by extJS
WA.Date.grabformats = {
  j: "this.getDate()",                                           // day of the month, no leading 0
  d: "WA.String.padding(2, '0', this.getDate())",                // day of the month, leading 0, no need to call()
  D: "WA.Date.shortdays[this.getDay()]",                         // short name of day
  l: "WA.Date.days[this.getDay()]",                              // full name of day

  w: "this.getDay()",                                            // day of the week, 0 = sunday
  N: "(this.getDay()==0?7:this.getDay())",                       // ISO day of the week, 1 = monday
  S: "WA.Date.getOrdinalSuffix.call(this)",                      // english day of the week suffix

  z: "WA.Date.getDayOfYear.call(this)",                          // day of the year, 0 to 365

  W: "WA.String.padding(2, '0', WA.Date.getWeekOfYear.call(this))",  // ISO week of the year, leading 0, no need to call()

  n: "(this.getMonth() + 1)",                                    // number of month, 1 to 12, no leading 0
  m: "WA.String.padding(2, '0', this.getMonth() + 1)",           // number of month, 01 to 12, leading 0, no need to call()
  M: "WA.Date.shortmonths[this.getMonth()]",                     // short name of month
  F: "WA.Date.months[this.getMonth()]",                          // full name of month
  t: "WA.Date.getMaxMonthDays.call(this)",                       // number of days into the month

  L: "(WA.Date.isLeapYear(this) ? 1 : 0)",
  o: "(this.getFullYear() + (WA.Date.getWeekOfYear.call(this) == 1 && this.getMonth() > 0 ? +1 : (WA.Date.getWeekOfYear.call(this) >= 52 && this.getMonth() < 11 ? -1 : 0)))",
  Y: "this.getFullYear()",
  y: "('' + this.getFullYear()).substring(2, 4)",

  a: "(this.getHours() < 12 ? 'am' : 'pm')",
  A: "(this.getHours() < 12 ? 'AM' : 'PM')",
  g: "((this.getHours() % 12) ? this.getHours() % 12 : 12)",
  G: "this.getHours()",
  h: "WA.String.padding(2, '0', (this.getHours() % 12) ? this.getHours() % 12 : 12)",
  H: "WA.String.padding(2, '0', this.getHours())",

  i: "WA.String.padding(2, '0', this.getMinutes())",
  s: "WA.String.padding(2, '0', this.getSeconds())",
  u: "WA.String.padding(3, '0', this.getMilliseconds())",

  O: "WA.String.getGMTOffset.call(this)",
  P: "WA.String.getGMTOffset.call(this, true)",
  T: "WA.String.getTimezone.call(this)",
  Z: "(this.getTimezoneOffset() * -60)",
  c: "this.getUTCFullYear() + '-' + WA.String.padding(2, '0', this.getUTCMonth() + 1) + '-' + WA.String.padding(2, '0', this.getUTCDate()) + 'T' + "
        + "WA.String.padding(2, '0', this.getUTCHours()) + ':' + WA.String.padding(2, '0', this.getUTCMinutes()) + ':' + "
        + "WA.String.padding(2, '0', this.getUTCSeconds()) + WA.Date.getGMTOffset.call(this, true)",
  U: "Math.round(this.getTime() / 1000)"
};

WA.Date.format = function(d, str)
{
  var code = [];
  for (var i = 0, l = str.length; i < l; i++)
  {
    var c = str.charAt(i);
    if (c == '\\')
    {
      i++;
      // no need to call String.escape with an apply since we pass the caracter as parameter
      code.push("'" + WA.String.escape(str.charAt(i)) + "'");
    }
    else
    {
      WA.Date.grabformats[c]!=undefined?code.push(WA.Date.grabformats[c]):code.push("'" + WA.String.escape(c) + "'");
    }
  }

  var f = new Function('return ' + code.join('+') + ';');
  return f.call(d);
}

// String prototypes
WA.String = {};
WA.String.sprintf = function()
{
  if (WA.isObject(arguments[0]))
  {
    var args = arguments[0];
    return this.replace(/\{([A-Za-z0-9\-_\.]+)\}/g, function(p0, p1){ return args[p1]; });
  }
  else
  {
    var args = arguments;
    return this.replace(/\{(\d+)\}/g, function(p0, p1){ return args[p1]; });
  }
}

WA.String.escape = function(value)
{
  var newstr = (value != undefined && value != null) ? value : this;
  return newstr.replace(/("|'|\\)/g, "\\$1");
}

WA.String.padding = function(size, pad, value)
{
  if (!pad) pad = ' ';
  var newstr = new String((value != undefined && value != null) ? value : this);
  while (newstr.length < size)
  {
    newstr = pad + newstr;
  }
  return newstr;
}

WA.String.trim = function(value)
{
  var newstr = (value != undefined && value != null) ? value : this;
  return newstr.replace(/^(\s|&nbsp;)*|(\s|&nbsp;)*$/g, '');
};

// json
WA.JSON = function() {}
WA.JSON.withalert = false;

WA.JSON.decode = function(json, execerror)
{
  var code = null;
  try
  {
    // 1. We parse the json code
    code = eval('(' + json + ')');
  }
  catch (e)
  {
    if (WA.JSON.withalert)
      alert(WA.i18n.getMessage('json.error') + e.message + '\n' + json);
    throw e;
  }
  /*
  if (code.debug)
  {
    WA.debug.explain(code.system, 3);
    code = code.code;
  }
  if (execerror && code.error && !code.login)
  {
    WA.debug.explain(code.messages, 3);
    code = null;
  }
  */
  return code;
}

WA.JSON.encode = function(data)
{
  var json = '';
  if (WA.isArray(data))
  {
    json += '[';
    var item = 0;
    for (var i = 0, l = data.length; i < l; i++)
    {
      json += (item++?',':'') + WA.JSON.encode(data[i]);
    }
    json += ']';
  }
  else if (data === null)
  {
    json += 'null';
  }
  else if (!WA.isDefined(data))
  {
    json += 'undefined';
  }
  else if (WA.isNumber(data))
  {
    json += data;
  }
  else if (WA.isString(data))
  {
    json += '"' + (data.replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\n/g, "\\n")) + '"';
  }
  else if (WA.isObject(data))
  {
    json += '{';
    var item=0;
    for (var i in data)
    {
      if (WA.isFunction(data[i]))   // we are not interested by functions
        continue;
      json += (item++?',':'')+'"'+i+'":'+WA.JSON.encode(data[i]);
    }
    json += '}';
  }
  else if (WA.isBool(data))
  {
    json += data?'true':'false';
  }
  else
  {
    if (WA.JSON.withalert)
      alert(WA.i18n.getMessage('json.unknown') + typeof data);
  }
  return json;
}

WA.browser = function()
{
  var agent = navigator.userAgent.toUpperCase();
  WA.browser.isCompat = (document.compatMode == 'CSS1Compat');
  WA.browser.isOpera = agent.indexOf('OPERA') > -1;
  WA.browser.isChrome = agent.indexOf('CHROME') > -1;
  WA.browser.isFirefox = agent.indexOf('FIREFOX') > -1;
  WA.browser.isFirebug = (WA.isDefined(window.console) && WA.isDefined(window.console.firebug));
  WA.browser.isSafari = !WA.browser.isChrome && agent.indexOf('SAFARI') > -1;
  WA.browser.isSafari2 = WA.browser.isSafari && agent.indexOf('APPLEWEBKIT/4') > -1;
  WA.browser.isSafari3 = WA.browser.isSafari && agent.indexOf('VERSION/3') > -1;
  WA.browser.isSafari4 = WA.browser.isSafari && agent.indexOf('VERSION/4') > -1;
  WA.browser.isMSIE = !WA.browser.isOpera && agent.indexOf('MSIE') > -1;
  WA.browser.isMSIE7 = WA.browser.isMSIE && agent.indexOf('MSIE 7') > -1;
  WA.browser.isMSIE8 = WA.browser.isMSIE && agent.indexOf('MSIE 8') > -1;
  WA.browser.isMSIE9 = WA.browser.isMSIE && agent.indexOf('MSIE 9') > -1;
  WA.browser.isMSIE6 = WA.browser.isMSIE && !WA.browser.isMSIE7 && !WA.browser.isMSIE8 && !WA.browser.isMSIE9;
  WA.browser.isWebKit = agent.indexOf('WEBKIT') > -1;
  WA.browser.isGecko = !WA.browser.isWebKit && agent.indexOf('GECKO') > -1;
  WA.browser.isGecko2 = WA.browser.isGecko && agent.indexOf('RV:1.8') > -1;
  WA.browser.isGecko3 = WA.browser.isGecko && agent.indexOf('RV:1.9') > -1;
  WA.browser.isLinux = agent.indexOf('LINUX') > -1;
  WA.browser.isWindows = !!agent.match(/WINDOWS|WIN32/);
  WA.browser.isMac = !!agent.match(/MACINTOSH|MAC OS X/);
  WA.browser.isAir = agent.indexOf('ADOBEAIR') > -1;
  WA.browser.isDom = document.getElementById && document.childNodes && document.createElement;
  WA.browser.isBoxModel = WA.browser.isMSIE && !WA.browser.isCompat;
  WA.browser.isSecure = (window.location.href.toUpperCase().indexOf('HTTPS') == 0);
  // DO WE NEED isFlash and isJava ?

  WA.browser.normalizedMouseButton = WA.browser.isMSIE ? {1:0, 2:2, 4:1} : (WA.browser.isSafari2 ? {1:0, 2:1, 3:2} : {0:0, 1:1, 2:2});

  // remove css image flicker
  if (WA.browser.isMSIE6)
    try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
}

WA.browser.isWebpSupport = function()
{
  var agent = navigator.userAgent.toUpperCase();
  var brw = agent.match(/(opera|chrome|firefox(?=\/))\/?\s*(\d+)/i) || [];

  if (brw[1] == 'OPERA' && brw[2] >= 19)
      return true;

  if (brw[1] == 'CHROME' && brw[2] >= 32)
      return true;

  if (brw[1] == 'FIREFOX' && brw[2] >= 65)
      return true;

  return false;
}

// ===================================
  // METRICS FUNCTIONS

  // get the size of the document. The document is the full usable html area
WA.browser.getDocumentWidth = function()
{
  if (WA.browser.isMSIE6)
    return document.body.scrollWidth;
  return document.documentElement.scrollWidth;
}

WA.browser.getDocumentHeight = function()
{
  if (WA.browser.isMSIE6)
    return document.body.scrollHeight;
  return document.documentElement.scrollHeight;
}

  // get the size of the window. The window is the browser visible area
WA.browser.getWindowWidth = function()
{
  if (!WA.browser.isMSIE)
    return window.innerWidth;

  if (document.documentElement && document.documentElement.clientWidth)
    return document.documentElement.clientWidth;

  if (document.body && document.body.clientWidth)
    return document.body.clientWidth;

  return 0;
}

WA.browser.getWindowHeight = function()
{
  if (!WA.browser.isMSIE)
    return window.innerHeight;

  if( document.documentElement && document.documentElement.clientHeight)
    return document.documentElement.clientHeight;

  if( document.body && document.body.clientHeight)
    return document.body.clientHeight;

  return 0;
}

  // get the size of the OS/screen
WA.browser.getScreenWidth = function()
{
  return screen.width;
}

WA.browser.getScreenHeight = function()
{
  return screen.height;
}

  // get the scroll of the window if the document is bigger than the window
WA.browser.getScrollLeft = function()
{
  if (WA.browser.isDom) // && (WA.browser.isMSIE7Sup || !WA.browser.isMSIE))
    return document.documentElement.scrollLeft;

  // ie6 and before
  if (document.body && document.body.scrollLeft)
    return document.body.scrollLeft;

  // others without dom
  if (typeof window.pageXOffset == 'number')
    return window.pageXOffset;

  return 0;
}

WA.browser.getScrollTop = function()
{
  // others without dom
  if (typeof window.pageYOffset == 'number')
    return window.pageYOffset;

  if (typeof window.scrollY == 'number')
    return window.scrollY;

  // should be supported by all browsers
  if (document.body && document.body.scrollTop)
    return document.body.scrollTop;

  // ie6 and before use BAD the documentelement on dom!
  if (WA.browser.isDom) // && (WA.browser.isMSIE7 || !WA.browser.isMSIE))
    return document.body.scrollTop;

  // ie6 and before


  return 0;
}

WA.browser.getScrollNodeTop = function(node)
{
  return node.scrollTop;
}

// get the maximum scroll available
WA.browser.getScrollWidth = function()
{
  return WA.browser.getDocumentWidth();
}

WA.browser.getScrollHeight = function()
{
  return WA.browser.getDocumentHeight();
}

  // get the left of a DOM element into the document
WA.browser.getNodeDocumentLeft = function(node)
{
  if (!node)
    return null;
  var l = node.offsetLeft;
  if (node.offsetParent != null)
    l += WA.browser.getNodeDocumentLeft(node.offsetParent) + WA.browser.getNodeBorderLeftWidth(node.offsetParent) + WA.browser.getNodeMarginLeftWidth(node.offsetParent);
  return l;
}

  // get the top of a DOM element into the document
WA.browser.getNodeDocumentTop = function(node)
{
  if (!node)
    return null;
  var t = node.offsetTop;
  if (node.offsetParent != null)
    t += WA.browser.getNodeDocumentTop(node.offsetParent) + WA.browser.getNodeBorderTopHeight(node.offsetParent) + WA.browser.getNodeMarginTopHeight(node.offsetParent);
  return t;
}

  // get the left of a DOM element into the referenced node. If referenced node is NOT into the fathers, then it will give the left in the document
WA.browser.getNodeNodeLeft = function(node, refnode)
{
  if (!node)
    return null;
  var l = node.offsetLeft;
  if (node.offsetParent != null && node.offsetParent != refnode)
    l += WA.browser.getNodeBorderLeftWidth(node.offsetParent) + WA.browser.getNodeNodeLeft(node.offsetParent, refnode);
  return l;
}

  // get the top of a DOM element into the referenced node. If referenced node is NOT into the fathers, then it will give the top in the document
WA.browser.getNodeNodeTop = function(node, refnode)
{
  if (!node)
    return null;
  var t = node.offsetTop;
  if (node.offsetParent != null && node.offsetParent != refnode)
    t += WA.browser.getNodeBorderTopHeight(node.offsetParent) + WA.browser.getNodeNodeTop(node.offsetParent, refnode);
  return t;
}

  // get the scroll of the node if the content is bigger than the node
WA.browser.getNodeScrollLeft = function(node)
{
  if (!node)
    return null;
  if (WA.browser.isDom) // && (WA.browser.isMSIE7 || !WA.browser.isMSIE))
    return node.scrollLeft;

  // others without dom
  if (typeof node.pageXOffset == 'number')
    return node.pageXOffset;

  return 0;
}

WA.browser.getNodeScrollTop = function(node)
{
  if (!node)
    return null;
  if (WA.browser.isDom) // && (WA.browser.isMSIE7 || !WA.browser.isMSIE))
    return node.scrollTop;

  // others without dom
  if (typeof node.pageYOffset == 'number')
    return node.pageYOffset;

  return 0;
}

// get the maximum scroll available
WA.browser.getNodeScrollWidth = function(node)
{
  return WA.browser.getDocumentWidth();
}

WA.browser.getNodeScrollHeight = function(node)
{
  return WA.browser.getDocumentHeight();
}

/*
  About size and functions to get sizes:

     | margin | border | padding | content | padding | border | margin |
     |-------- extrawidth -------|- width -|
     |- externalwidth -|-------- innerwidth ---------|
              |----------------- offsetwidth -----------------|
     |--------------------------- outerwidth --------------------------|

  The external is the sum of left and right external
  The extra is the sum of left and right extra

  Same applies with height
*/

WA.browser.getNodeMarginLeftWidth = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.marginLeft, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('margin-left')) || 0;
}

WA.browser.getNodeMarginRightWidth = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.marginRight, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('margin-right')) || 0;
}

WA.browser.getNodeMarginWidth = function(node)
{
  return WA.browser.getNodeMarginLeftWidth(node) + WA.browser.getNodeMarginRightWidth(node);
}

WA.browser.getNodeMarginTopHeight = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.marginTop, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('margin-top')) || 0;
}

WA.browser.getNodeMarginBottomHeight = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.marginBottom, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('margin-bottom')) || 0;
}

WA.browser.getNodeMarginHeight = function(node)
{
  return WA.browser.getNodeMarginTopHeight(node) + WA.browser.getNodeMarginBottomHeight(node);
}

WA.browser.getNodeBorderLeftWidth = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.borderLeftWidth, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('border-left-width')) || 0;
}

WA.browser.getNodeBorderRightWidth = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.borderRightWidth, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('border-right-width')) || 0;
}

WA.browser.getNodeBorderWidth = function(node)
{
  return WA.browser.getNodeBorderLeftWidth(node) + WA.browser.getNodeBorderRightWidth(node);
}

WA.browser.getNodeBorderTopHeight = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.borderTopWidth, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('border-top-width')) || 0;
}

WA.browser.getNodeBorderBottomHeight = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.borderBottomWidth, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('border-bottom-width')) || 0;
}

WA.browser.getNodeBorderHeight = function(node)
{
  return WA.browser.getNodeBorderTopHeight(node) + WA.browser.getNodeBorderBottomHeight(node);
}

WA.browser.getNodePaddingLeftWidth = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.paddingLeft, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('padding-left')) || 0;
}

WA.browser.getNodePaddingRightWidth = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.paddingRight, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('padding-right')) || 0;
}

WA.browser.getNodePaddingWidth = function(node)
{
  return WA.browser.getNodePaddingLeftWidth(node) + WA.browser.getNodePaddingRightWidth(node);
}

WA.browser.getNodePaddingTopHeight = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.paddingTop, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('padding-top')) || 0;
}

WA.browser.getNodePaddingBottomHeight = function(node)
{
  return WA.browser.isMSIE?parseInt(node.currentStyle.paddingBottom, 10) || 0:parseInt(window.getComputedStyle(node, null).getPropertyValue('padding-bottom')) || 0;
}

WA.browser.getNodePaddingHeight = function(node)
{
  return WA.browser.getNodePaddingTopHeight(node) + WA.browser.getNodePaddingBottomHeight(node);
}

WA.browser.getNodeExternalLeftWidth = function(node)
{
  return WA.browser.getNodeMarginLeftWidth(node) + WA.browser.getNodeBorderLeftWidth(node);
}

WA.browser.getNodeExternalRightWidth = function(node)
{
  return WA.browser.getNodeMarginRightWidth(node) + WA.browser.getNodeBorderRightWidth(node);
}

WA.browser.getNodeExternalWidth = function(node)
{
  return WA.browser.getNodeExternalLeftWidth(node) + WA.browser.getNodeExternalRightWidth(node);
}

WA.browser.getNodeExternalTopHeight = function(node)
{
  return WA.browser.getNodeMarginTopHeight(node) + WA.browser.getNodeBorderTopHeight(node);
}

WA.browser.getNodeExternalBottomHeight = function(node)
{
  return WA.browser.getNodeMarginBottomHeight(node) + WA.browser.getNodeBorderBottomHeight(node);
}

WA.browser.getNodeExternalHeight = function(node)
{
  return WA.browser.getNodeExternalTopHeight(node) + WA.browser.getNodeExternalBottomHeight(node);
}

WA.browser.getNodeExtraLeftWidth = function(node)
{
  return WA.browser.getNodeMarginLeftWidth(node) + WA.browser.getNodeBorderLeftWidth(node) + WA.browser.getNodePaddingLeftWidth(node);
}

WA.browser.getNodeExtraRightWidth = function(node)
{
  return WA.browser.getNodeMarginRightWidth(node) + WA.browser.getNodeBorderRightWidth(node) + WA.browser.getNodePaddingRightWidth(node);
}

WA.browser.getNodeExtraWidth = function(node)
{
  return WA.browser.getNodeExtraLeftWidth(node) + WA.browser.getNodeExtraRightWidth(node);
}

WA.browser.getNodeExtraTopHeight = function(node)
{
  return WA.browser.getNodeMarginTopHeight(node) + WA.browser.getNodeBorderTopHeight(node) + WA.browser.getNodePaddingTopHeight(node);
}

WA.browser.getNodeExtraBottomHeight = function(node)
{
  return WA.browser.getNodeMarginBottomHeight(node) + WA.browser.getNodeBorderBottomHeight(node) + WA.browser.getNodePaddingBottomHeight(node);
}

WA.browser.getNodeExtraHeight = function(node)
{
  return WA.browser.getNodeExtraTopHeight(node) + WA.browser.getNodeExtraBottomHeight(node);
}

  // get the real size of a DOM element
WA.browser.getNodeWidth = function(node)
{
  return WA.browser.getNodeOffsetWidth(node) - WA.browser.getNodePaddingWidth(node) - WA.browser.getNodeBorderWidth(node);
}

WA.browser.getNodeHeight = function(node)
{
  return WA.browser.getNodeOffsetHeight(node) - WA.browser.getNodePaddingHeight(node) - WA.browser.getNodeBorderHeight(node);
}

WA.browser.getNodeInnerWidth = function(node)
{
  return WA.browser.getNodeOffsetWidth(node) - WA.browser.getNodeBorderWidth(node);
}

WA.browser.getNodeInnerHeight = function(node)
{
  return WA.browser.getNodeOffsetHeight(node) - WA.browser.getNodeBorderHeight(node);
}

WA.browser.getNodeOffsetWidth = function(node)
{
  return parseInt(node.offsetWidth, 10) || 0;
}

WA.browser.getNodeOffsetHeight = function(node)
{
  return parseInt(node.offsetHeight, 10) || 0;
}

WA.browser.getNodeOuterWidth = function(node)
{
  return WA.browser.getNodeOffsetWidth(node) + WA.browser.getNodeMarginWidth(node);
}

WA.browser.getNodeOuterHeight = function(node)
{
  return WA.browser.getNodeOffsetHeight(node) + WA.browser.getNodeMarginHeight(node);
}

// ===================================
// MOUSE FUNCTIONS

/*
  The mouse is not standard on all navigators.
  ie and safari does not map same clicks keys (left, center, right), we need corresponding table

  NOTE Than both mouse and keyboard events are mixed in the same event
*/

  // getCursorNode will return the DOM node in which the event happened
WA.browser.getCursorNode = function(e)
{
  var ev = e || window.event;
  if (ev.target) return ev.target;
  if (ev.srcElement) return ev.srcElement;
  return null;
}

  // returns the absolute position of the event in the document
WA.browser.getCursorDocumentX = function(e)
{
  var ev = e || window.event;
  return ev.pageX - (document.documentElement.clientLeft || 0);  // MSIE 7 has a weird 2 pixels offset for mouse coords !
}

  // returns the absolute position of the event in the document
WA.browser.getCursorDocumentY = function(e)
{
  var ev = e || window.event;
  return ev.pageY - (document.documentElement.clientTop || 0);  // MSIE 7 has a weird 2 pixels offset for mouse coords !
}

  // returns the absolute position of the event in the document
WA.browser.getTouchDocumentX = function(e)
{
  var ev = e || window.event;
  var touchobj = ev.changedTouches[0];
  return touchobj.pageX;
}

  // returns the absolute position of the event in the document
WA.browser.getTouchDocumentY = function(e)
{
  var ev = e || window.event;
  var touchobj = ev.changedTouches[0];
  return touchobj.pageY;
}

  // returns the absolute position of the event in the browserwindow
WA.browser.getCursorWindowX = function(e)
{
  var ev = e || window.event;
  return ev.clientX - (document.documentElement.clientLeft || 0);  // MSIE 7 has a weird 2 pixels offset for mouse coords !;
}

  // returns the absolute position of the event in the browserwindow
WA.browser.getCursorWindowY = function(e)
{
  var ev = e || window.event;
  return ev.clientY - (document.documentElement.clientLeft || 0);  // MSIE 7 has a weird 2 pixels offset for mouse coords !;
}

  // returns the absolute position of the event in the container based on the OFFSET metrix (i.e. with border included)
  // IF the function does not work on FIREFOX: DO NOT MODIFY the code,
  //     but add a position: relative to the container !
  // (note: FF and Safari, gets natural origin with border, IE and opera, without border :S)
WA.browser.getCursorOffsetX = function(e)
{
  var offset = 0;
  if (WA.browser.isMSIE || WA.browser.isOpera)
    offset = WA.browser.getNodeBorderLeftWidth(WA.browser.getCursorNode(e));

  var ev = e || window.event;
  if(typeof(ev.offsetX) == 'number')
    return ev.offsetX + offset;
  if(typeof(ev.layerX) == 'number')
    return ev.layerX + offset;
  return 0;
}

// returns the absolute position of the event in the container based on the OFFSET metrix (i.e. with border included)
// IF the function does not work on FIREFOX: DO NOT MODIFY the code,
//     but add a position: relative to the container !
WA.browser.getCursorOffsetY = function(e)
{
  var offset = 0;
  if (WA.browser.isMSIE || WA.browser.isOpera)
    offset = WA.browser.getNodeBorderTopHeight(WA.browser.getCursorNode(e));

  var ev = e || window.event;
  if(typeof(ev.offsetY) == 'number')
    return ev.offsetY + offset;
  if(typeof(ev.layerY) == 'number')
    return ev.layerY + offset;
  return 0;
}

// returns the absolute position of the event in the container based on the INNER metrix (i.e. without border included)
// IF the function does not work on FIREFOX: DO NOT MODIFY the code,
//     but add a position: relative to the container !
WA.browser.getCursorInnerX = function(e)
{
  var offset = 0;
  if (!WA.browser.isMSIE && !WA.browser.isOpera)
    offset = WA.browser.getNodeBorderLeftWidth(WA.browser.getCursorNode(e));

  var ev = e || window.event;
  if(typeof(ev.offsetX) == 'number')
    return ev.offsetX - offset;
  if(typeof(ev.layerX) == 'number')
    return ev.layerX - offset;
  return 0;
}

// returns the absolute position of the event in the container based on the INNER metrix (i.e. without border included)
// IF the function does not work on FIREFOX: DO NOT MODIFY the code,
//     but add a position: relative to the container !
WA.browser.getCursorInnerY = function(e)
{
  var offset = 0;
  if (!WA.browser.isMSIE && !WA.browser.isOpera)
    offset = WA.browser.getNodeBorderTopHeight(WA.browser.getCursorNode(e));

  var ev = e || window.event;
  if(typeof(ev.offsetY) == 'number')
    return ev.offsetY - offset;
  if(typeof(ev.layerY) == 'number')
    return ev.layerY - offset;
  return 0;
}

// click functions
WA.browser.getButtonClick = function(e)
{
  var ev = e || window.event;
  if (ev.type != 'click' && ev.type != 'dblclick')
    return false;
  var button = ev.button ? WA.browser.normalizedMouseButton[ev.button] : (ev.which ? ev.which-1 : 0);
  return button;
}

// click functions
WA.browser.getButtonPressed = function(e)
{
  var ev = e || window.event;
  if (ev.type != 'mousedown' && ev.type != 'mouseup')
    return false;
  var button = ev.button ? WA.browser.normalizedMouseButton[ev.button] : (ev.which ? ev.which-1 : false);
  return button;
}

WA.browser.getWheel = function(e)
{
  var ev = e || window.event;
  if (ev.type != 'DOMMouseScroll' && ev.type != 'mousewheel')
    return false;
  var delta = 0;
  if(ev.wheelDelta)
  {
    delta = ev.wheelDelta / 120;
  }
  else if (ev.detail)
  {
    delta = -ev.detail / 3;
  }
  return delta;
}

WA.browser.cancelEvent = function(e)
{
  var ev = e || window.event;
  if (!ev)
    return false;
  if (ev.stopPropagation)
    ev.stopPropagation();
  if (ev.preventDefault)
    ev.preventDefault();
  if (ev.stopEvent)
    ev.stopEvent();
  if (WA.browser.isMSIE) window.event.keyCode = 0;
  ev.cancel = true;
  ev.cancelBubble = true;
  ev.returnValue = false;
  return false;
}

// ===================================
// KEYBOARD FUNCTIONS

/*
  The keyboard is not standard on all navigators.
  known properties: shift, control, alt, keycode, charcode, navigation key
  navigation keys are: arrows, page up/down, insert, home, end, enter, tab escape

  NOTE Than both mouse and keyboard events are mixed in the same event
*/

// key functions
WA.browser.getKey = function(e)
{
  var ev = e || window.event;
  if (ev.type != 'keydown' && ev.type != 'keyup')
    return false;
  return ev.keyCode || ev.which;
}

WA.browser.getChar = function(e)
{
  var ev = e || window.event;
  if (ev.type != 'keypress')
    return false;
  return String.fromCharCode(ev.charCode ? ev.charCode : ev.keyCode);
}

WA.browser.ifShift = function(e)
{
  var ev = e || window.event;
  return ev.shiftKey;
}

WA.browser.ifCtrl = function(e)
{
  var ev = e || window.event;
  return ev.ctrlKey || ev.metaKey;
}

WA.browser.ifAlt = function(e)
{
  var ev = e || window.event;
  return ev.altKey;
}

  // any shift, control, alt
WA.browser.ifModifier = function(e)
{
  var ev = e || window.event;
  return (ev.altKey || ev.ctrlKey || ev.metaKey || ev.shiftKey) ? true : false;
}

  // any navigation keys: arrows, page up/down, home/end, escape, enter, tab
WA.browser.ifNavigation = function(e)
{
  var c = WA.browser.getKey(e);
  return ((c >= 33 && c <= 40) || c == 9 || c == 13 || c == 27) ? true : false;
}

  // f1 to f12
WA.browser.ifFunction = function(e)
{
  var c = WA.browser.getKey(e);
  return (c >= 112 && c <= 123) ? true : false;
}

// ===================================
// SELECTION FUNCTIONS

// select something in the document
WA.browser.getSelectionRange = function(node, selectionStart, selectionEnd)
{
  if (node.setSelectionRange)
  {
    node.focus();
    node.setSelectionRange(selectionStart, selectionEnd);
  }
  else if (node.createTextRange)
  {
    var range = node.createTextRange();
    range.collapse(true);
    range.moveEnd('character', selectionEnd);
    range.moveStart('character', selectionStart);
    range.select();
  }
}

// ===================================
// FILL FUNCTIONS

// fill an innerHTML
WA.browser.setInnerHTML = function(node, content)
{
  if (WA.browser.isGecko)
  {
    var rng = document.createRange();
    rng.setStartBefore(node);
    var htmlFrag = rng.createContextualFragment(content);
    while (node.hasChildNodes())
      node.removeChild(node.lastChild);
    node.appendChild(htmlFrag);
  }
  else
  {
    node.innerHTML = content;
  }
}

WA.templates = {};
WA.templatesstrings = {};
WA.codes = {};

WA.templater = function(strings, ...keys)
{
  function searchdata(data, key)
  {
    if ((pos = key.indexOf(">")) != -1)
    {
      first = key.substr(0, pos);
      val = data[first];
      if (WA.isArray(val) || WA.isObject(val) || WA.isFunction(val))
        return searchdata(val, key.substr(pos+1))
      return undefined;
    }
    if (data)
      return data[key];
    return null;
  }
  function searchdatapile(datapile, key)
  {
    if (!key)
      return '';
    for (var i = datapile.length-1; i >= 0; i--)
    {
      var val = searchdata(datapile[i], key);
      if (val !== undefined)
        return val;
    }
    return '';
  }
  function loop(templates, datapile, data, template)
  {
    if (!templates)
      templates = WA.templates;
    if (!data || !WA.isArray(data) || data.length == 0)
    {
      if (templates[template + ".none"])
        return templates[template + ".none"](datapile, templates);
      return "<!-- Template " + template + ".none not found for loop -->";
    }
    txt = "";
    for (var i = 0; i < data.length; i++)
    {
      datapile.push(data[i]);
      if (templates[template + ".key." + i])
        txt += templates[template + ".key." + i](datapile, templates);
      else if (i==0 && templates[template + ".first"])
        txt += templates[template + ".first"](datapile, templates);
      else if (i==data.length-1 && templates[template + ".last"])
        txt += templates[template + ".last"](datapile, templates);
      else if (i%2==0 && templates[template + ".even"])
        txt += templates[template + ".even"](datapile, templates);
      else if (templates[template])
        txt += templates[template](datapile, templates);
      else
        txt += "<!-- Template " + template + " not found for loop -->";
      datapile.pop();
    }
    return txt;
  }
  function cond(templates, field, template, datapile)
  {
    if (!templates)
      templates = WA.templates;

    val = searchdatapile(datapile, field);
    var pushed = false;
    if (val != null && (WA.isArray(val) || WA.isObject(val) || WA.isFunction(val)))
    {
      pushed = true;
      datapile.push(val);
    }
    if (!val && templates[template + ".none"])
      text = templates[template + ".none"](datapile, templates);
    else if (val && templates[template + "." + val])
      text = templates[template + "." + val](datapile, templates);
    else if (templates[template])
      text = templates[template](datapile, templates);
    else
      text = "<!-- Template " + template + " not found for cond -->";
    if (pushed)
      datapile.pop();

    return text;
  }
  function call(templates, template, data)
  {
    if (!templates)
      templates = WA.templates;
    if (templates[template])
      return templates[template](data, templates);
    return "<!-- Template " + template + " not found for call -->";
  }

  return function(data, templates)
  {
    let temp = strings.slice();
    let datapile = data
    if (!WA.isArray(data))
      datapile = [data];
    keys.forEach((key, i) =>
      {
        if (Array.isArray(key))
        {
          switch (key[0])
          {
            case "eval":
              temp[i] = temp[i] + eval(key[1]);
              break;
            case "loop":
              val = searchdatapile(datapile, key[1]);
              if (!WA.isArray(val))
                val = undefined;
              temp[i] = temp[i] + loop(templates, datapile, val, key[2]?key[2]:key[1]);
              break;
            case "cond":
              temp[i] = temp[i] + cond(templates, key[1], key[2], datapile);
              break;
            case "call":
              if (key[3])
              {
                template = key[3] + searchdatapile(datapile, key[2]);
                temp[i] = temp[i] + call(templates, template, datapile);
              }
              else
              {
                val = searchdatapile(datapile, key[2]);
                var pushed = false;
                if (WA.isArray(val) || WA.isObject(val) || WA.isFunction(val))
                {
                  pushed = true;
                  datapile.push(val);
                }
                temp[i] = temp[i] + call(templates, key[1], datapile);
                if (pushed)
                  datapile.pop();
              }
              break;
            default:
              temp[i] = temp[i] + "<!-- Parameter not recognized " + key[0] + " -->";
          }
        }
        else
        {
          temp[i] = temp[i] + searchdatapile(datapile, key);
        }
      });
    return temp.join('');
  }
};

WA.XTemplate = function(temps) {

  var templates = temps

  return function run(data) {
    return templates.main(data, templates);
  }
}

/*
    eventManager.js, WAJAF, the WebAbility(r) Javascript Application Framework
    Contains the Manager singleton to manage browser Events
    (c) 2008-2010 Philippe Thomassigny

    This file is part of WAJAF

    WAJAF is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    WAJAF is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with WAJAF.  If not, see <http://www.gnu.org/licenses/>.
*/

WA.Managers.event = new function()
{
  // All the attributes are PRIVATE.
  var self = this;
  listenerid = 1;
  functionid = 1;
  events = {};
  beforeflushs = [];
  flushs = [];
  keys = [];
  this.keys = keys;
  specialkeys =
  {
    'esc': 27, 'escape': 27,
    'tab': 9, 'space': 32,
    'return': 13, 'enter': 13,
    'scrolllock': 145, 'capslock': 20, 'numlock': 144,
    'pause': 19, 'break': 19,
    'insert': 45, 'delete': 46, 'backspace': 8,
    'home': 36, 'end': 35, 'pageup': 33, 'pagedown': 34,
    'left': 37, 'up': 38, 'right': 39, 'down': 40,
    'f1': 112, 'f2': 113, 'f3': 114, 'f4': 115, 'f5': 116, 'f6': 117, 'f7': 118, 'f8': 119, 'f9': 120, 'f10': 121, 'f11': 122, 'f12': 123,
    '(shift)': 16, '(control)': 17, '(alt)': 18
    };

  // eventname: one of: mousedown, mouseup, click, dblclick, mousemove,
  // mouseover, mouseout, mousewheel,
  // keydown, keyup, keypress, load, unload, scroll,
  // focus, blur, change, submit, abort, error, reset, resize
  // eventnode: the id or the node itself
  // eventfunction: pointer to the function to execute when the event happens
  // eventcapture: true/false to notify if this event is greedy
  this.addListener = this.on = this.add = this.start = this.listen = this.attachEvent = this.registerEvent = addListener;
  function addListener(eventname, eventnode, eventfunction, eventcapture)
  {
    eventnode = WA.toDOM(eventnode);
    if (!eventnode) // no node found ?
      return false;
//    WA.debug.explain('eventManager.addListener('+eventname+', '+eventnode.id+')');

    // link the UID to the node
    if (eventnode.listeneruid == undefined)
      eventnode.listeneruid = listenerid++;
    if (eventfunction.functionuid == undefined)
      eventfunction.functionuid = functionid++;

    if (events[eventnode.listeneruid] == undefined)
      events[eventnode.listeneruid] = {};
    if (events[eventnode.listeneruid][eventname] == undefined)
      events[eventnode.listeneruid][eventname] = {};

    // get the context from the ID of the node if any
    eventnode.context = WA.context;

    thefunction = function()
    {
      // support for 4GL
      if (WA.context != undefined)
      {
        var xid = oldcontext = null;
        if (this.id && this.id.indexOf('|') != -1)
        {
          xid = WA.parseID(this.id);
          oldcontext = WA.context = xid[0] + '|' + xid[1] + '|';
        }
      }
      var ret = eventfunction.apply(this, arguments);
      if (WA.context != undefined)
      {
        if (xid)
          WA.context = oldcontext;
      }
      return ret;
    }

    if (eventnode != window && eventname == 'load' && WA.browser.isMSIE) // special incompatible IE not firing onload event on images
    {
      thefunction = function(e)
      {
        if (this.readyState != 'complete' && this.readyState != 'loaded')
          return null;
        var xid = oldcontext = null;
        if (this.id && this.id.indexOf('|') != -1)
        {
          xid = WA.parseID(this.id);
          oldcontext = WA.context = xid[0] + '|' + xid[1] + '|';
        }
        var ret = eventfunction.apply(this, arguments);
        if (xid)
          WA.context = oldcontext;
        return ret;
      };
      eventnode.onreadystatechange = thefunction;
    }
    else if (eventnode.addEventListener)
    {
      if (eventname == 'mousewheel') // special incompatible mousewheel
      {
        eventnode.addEventListener('DOMMouseScroll', thefunction, eventcapture);
      }
      eventnode.addEventListener(eventname, thefunction, eventcapture);
    }
    else if (eventnode.attachEvent)
    {
      eventnode.attachEvent('on' + eventname, thefunction);
    }
    else
    {
      eventnode['on' + eventname] = thefunction;
    }
    events[eventnode.listeneruid][eventname][eventfunction.functionuid] = [eventnode, thefunction, eventcapture];
    return true;
  }

  // must be the SAME PARAMETERS as addListener
  this.removeListener = this.off = this.remove = this.stop = this.detachEvent = removeListener;
  function removeListener(eventname, eventnode, eventfunction, eventcapture)
  {
    eventnode = WA.toDOM(eventnode);
    if (!eventnode) // no node found ?
      return;
//    WA.debug.explain('eventManager.removeListener('+eventname+', '+eventnode.id+')');
    if (eventnode.listeneruid == undefined) // node not registered here
      return;
    if (eventfunction.functionuid == undefined) // function not registered here
      return;
    if (events[eventnode.listeneruid] == undefined) // already unregistered ?
      return;
    if (events[eventnode.listeneruid][eventname] == undefined) // already unregistered ?
      return;
    if (events[eventnode.listeneruid][eventname][eventfunction.functionuid] == undefined) // already unregistered ?
      return;

    if (eventname == 'load' && WA.browser.isMSIE) // special incompatible IE not firing onload event
    {
      eventnode.onreadystatechange = WA.nothing;
    }
    else if (eventnode.removeEventListener)
    {
      if (eventname == 'mousewheel')
      {
        eventnode.removeEventListener('DOMMouseScroll', events[eventnode.listeneruid][eventname][eventfunction.functionuid], eventcapture);
      }
      eventnode.removeEventListener(eventname, events[eventnode.listeneruid][eventname][eventfunction.functionuid], eventcapture);
    }
    else if (eventnode.detachEvent)
    {
      eventnode.detachEvent('on' + eventname, events[eventnode.listeneruid][eventname][eventfunction.functionuid]);
    }
    else
    {
      eventnode['on' + eventname] = null;
    }
    delete events[eventnode.listeneruid][eventname][eventfunction.functionuid];
    // *********************************************
    // do we clean the 3 levels of the array ?
  }

  // key is 'modif[+modif]+key'
  // modif is 'shift', 'alt', 'control' or 'ctrl'
  // key is 0-9, a-z, !@#$%^&*()_-+=}{]["';?><,./`~
  // can be also: special keys, arrows, functions etc. see the array in the
  // function.

  this.addKey = this.key = addKey;
  function addKey(key, callback)
  {
//    WA.debug.explain('eventManager.addKey('+key+')');
    var xkey = key.toLowerCase().split("+");
    for (var i = 0, l = xkey.length; i < l; i++)
    {
      if (xkey[i] == 'shift' || xkey[i] == 'control' || xkey[i] == 'ctrl' || xkey[i] == 'alt')
        continue;
      if (specialkeys[xkey[i]] != undefined)
        continue;
      // should be normal char, we take the 1rst one to be sure
      xkey[i] = xkey[i].charAt(0);
    }

    var data =
    {
      skey: key,
      key: xkey,
      callback: callback
    };
    keys.push(data);
  }

  this.removeKey = removeKey;
  function removeKey(key)
  {
//    WA.debug.explain('eventManager.removeKey('+key+')');
    for (var i = 0, l=keys.length; i<l; i++)
      if (keys[i].skey == key)
        keys.splice(i, 1);
  }

  /* private method */
  function keycallbackdown(e)
  {
    keycallback(e,'down');
  }

  function keycallbackup(e)
  {
    keycallback(e,'up');
  }

  function keycallback(e,type)
  {
    var code = WA.browser.getKey(e);
    var c = String.fromCharCode(code).toLowerCase();
    var shift = WA.browser.ifShift(e);
    var ctrl = WA.browser.ifCtrl(e);
    var alt = WA.browser.ifAlt(e);
    for ( var i = 0, l=keys.length; i < l; i++)
    {
      // check any keys combination if ok
      var isok = 0;
      for (var j = 0, m=keys[i]['key'].length; j < m; j++)
      {
        if (keys[i]['key'][j] == 'shift' && shift)
          isok++;
        else if (keys[i]['key'][j] == 'alt' && alt)
          isok++;
        else if (keys[i]['key'][j] == 'control' && ctrl)
          isok++;
        else if (specialkeys[keys[i]['key'][j]] == code)
          isok++;
        else if (keys[i]['key'][j] === c)
          isok++;
      }
      if (isok == keys[i]['key'].length)
      {
        keys[i]['callback'](e, keys[i]['skey'], type);
      }
    }
  }

  this.registerBeforeFlush = registerBeforeFlush;
  function registerBeforeFlush(functionflush)
  {
    beforeflushs.push(functionflush);
  }

  this.registerFlush = registerFlush;
  function registerFlush(functionflush)
  {
    flushs.push(functionflush);
  }

  this.unregisterBeforeFlush = unregisterBeforeFlush;
  function unregisterBeforeFlush(functionflush)
  {
    beforeflushs.remove(functionflush);
  }

  this.unregisterFlush = unregisterFlush;
  function unregisterFlush(functionflush)
  {
    flushs.remove(functionflush);
  }

  /* private method */
  function _beforeflush(e)
  {
    // then call all flush for other managers
    var result = '';
    for ( var i = 0, l = beforeflushs.length; i < l; i++)
    {
      result += beforeflushs[i](e);
    }
    if (result != '')
    {
      WA.browser.cancelEvent(e);   // for ie, ff, chrome, safari
      e.returnValue = result;      // for ie, ff
      return result;               // for ie
    }
  }

  function _flush(e)
  {
    // then call all flush for other managers
    for ( var i = 0, l = flushs.length; i < l; i++)
    {
      flushs[i](e);
      flushs[i] = null;
    }

    // no way to block unload on other browsers, se we destroy
    for (i in events)
    {
      for (j in events[i])
      {
        for (k in events[i][j])
        {
          if (events[i][j][k][0])
          {
            if (j == 'mousewheel')
            {
              events[i][j][k][0].removeEventListener('DOMMouseScroll', events[i][j][k][1], events[i][j][k][2]);
            }
            events[i][j][k][0].removeEventListener(j, events[i][j][k][1], events[i][j][k][2]);
          }
          else if (events[i][j][k][0].detachEvent)
          {
            events[i][j][k][0].detachEvent('on' + j, events[i][j][k][1]);
          }
          else
          {
            events[i][j][k][0]['on' + j] = null;
          }
        }
      }
    }

    // we stop listening unload and keypress
    delete events;
    delete beforeflushs;
    delete flushs;
    delete keys;
    self = null;
  }

  // we take control of unload. blocks unload only works on
  // IE, FF, CHROME and SAFARI with beforeunload / should check version of those
  this.addListener('beforeunload', window, _beforeflush, false);
  this.addListener('unload', window, _flush, false);
  // we listen the key binder
  this.addListener('keydown', document, keycallbackdown, false);
  this.addListener('keyup', document, keycallbackup, false);
}();

/*
    ajaxManager.js, WAJAF, the WebAbility(r) Javascript Application Framework
    Contains the Manager singleton to manage ajax requests
    (c) 2008-2010 Philippe Thomassigny

    This file is part of WAJAF

    WAJAF is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    WAJAF is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with WAJAF.  If not, see <http://www.gnu.org/licenses/>.
*/

WA.Managers.ajax = new function()
{
  var self = this;
  this.requests = [];
  this.listener = null;
  this.stateFeedBack = null; // no feedback by default
  this.timeoutabort = 0;     // automatic browser ajax control

  this.setListener = setListener;
  function setListener(listener)
  {
    self.listener = listener;
  }

  this.addStateFeedback = addStateFeedback;
  function addStateFeedback(statefeedback, timeoutabort)
  {
    self.statefeedback = statefeedback;
    if (timeoutabort)
      self.timeoutabort = timeoutabort;
  }

  this.setTimeout = setTimeout;
  function setTimeout(timeoutabort)
  {
    self.timeoutabort = timeoutabort;
  }

  function callNotify(event)
  {
    if (self.listener)
    {
      self.listener(event);
    }
  }

  this.createRequest = createRequest;
  function createRequest(url, method, data, feedback, dosend)
  {
    callNotify('create');
    var r = new WA.Managers.ajax.Request(url, method, data, feedback, dosend, self.listener, self.statefeedback, self.timeoutabort);
    if (r)
    {
      self.requests.push(r);
    }
    return r;
  }

  // data is { url:, method:, data:, }
  this.createPromiseRequest = createPromiseRequest;
  function createPromiseRequest(data)
  {
    var prom = new Promise(function(resolve, reject)
    {
      try
      {
        callNotify('create');
        var r = new WA.Managers.ajax.PromiseRequest(data, self.listener, self.timeoutabort);
        resolve(r);
      }
      catch (e)
      {
        callNotify('error-create');
        reject(-1, e);
      }
    });
    return prom;
  }

  this.createPeriodicRequest = createPeriodicRequest;
  function createPeriodicRequest(period, times, url, method, data, feedback, dosend)
  {
    callNotify('create');
    var r = new WA.Managers.ajax.Request(url, method, data, feedback, dosend, self.listener, self.statefeedback, self.timeoutabort);
    if (r)
    {
      self.requests.push(r);
      r.setPeriodic(period, times);
    }
    return r;
  }

  this.destroyRequest = destroyRequest;
  function destroyRequest(r)
  {
    for (var i=0, l=self.requests.length; i < l; i++)
    {
      if (self.requests[i] == r)
      {
        self.requests[i].destroy();
        self.requests.splice(i, 1);
        callNotify('destroy');
        break;
      }
    }
  }

  function destroy()
  {
    for (var i=0, l=self.requests.length; i < l; i++)
      self.requests[i].destroy();
    self.listener = null;
    delete self.requests;
    self = null;
  }

  WA.Managers.event.registerFlush(destroy);
}();

WA.Managers.ajax.Request = function(url, method, data, feedback, autosend, listener, statefeedback, timeoutabort)
{
  var self = this;
  // parameters
  this.url = url;
  this.method = method.toUpperCase();
  this.data = data;
  this.feedback = feedback;
  this.autosend = autosend;
  // special parameters
  this.period = 0;
  this.times = 0;
  this.statefeedback = statefeedback;    // consider waiting, error and abort feedbacks
  this.timeoutabort = timeoutabort;      // time out to abort, no default, let it to the ajax autocontrol.
  // working attributes
  this.request = null;
  this.parameters = null;
  this.putdata = null;
  this.timer = null;
  this.timerabort = null;
  this.state = 0;               // 0 = nothing, 1 = sent and waiting, 2 = finished, 3 = error
  this.listener = listener;

  try { this.request = new XMLHttpRequest(); }
  catch(e)
  { try { this.request = new ActiveXObject('Msxml2.XMLHTTP.3.0'); }
    catch(e)
    { try { this.request = new ActiveXObject('Msxml2.XMLHTTP'); }
      catch(e)
      { try { this.request = new ActiveXObject('Microsoft.XMLHTTP'); }
        catch(e)
        { alert(WA.i18n.getMessage('ajax.notsupported')); }
      }
    }
  }

  function callNotify(event, data)
  {
    if (self.listener)
    {
      self.listener(event, data);
    }
  }

  // Special parameters
  this.setPeriodic = setPeriodic;
  function setPeriodic(period, times)
  {
    self.period = period;
    self.times = times;
  }

  this.addStateFeedback = addStateFeedback;
  function addStateFeedback(statefeedback, timeoutabort)
  {
    self.statefeedback = statefeedback;
    if (timeoutabort != undefined && timeoutabort != null)
      self.timeoutabort = timeoutabort;
  }

  this.setTimeoutAbort = setTimeoutAbort;
  function setTimeoutAbort(timeoutabort)
  {
    self.timeoutabort = timeoutabort;
  }

  // Parameters for POST/GET send
  this.addParameter = addParameter;
  function addParameter(id, value)
  {
    if (self.parameters === null)
      self.parameters = {};
    self.parameters[id] = value;
  }

  // Parameters for POST/GET send
  this.addPutData = addPutData;
  function addPutData(data)
  {
    self.putdata = data;
  }

  this.getParameters = getParameters;
  function getParameters()
  {
    return self.parameters;
  }

  this.clearParameters = clearParameters;
  function clearParameters()
  {
    self.parameters = null;
  }

  function buildParametersPost()
  {
    var data = self.data || '';
    for (i in self.parameters)
      data += (data.length > 0?'&':'') + encodeURIComponent(i) + '=' + encodeURIComponent(self.parameters[i]);
    return data;
  }

  function buildParameters()
  {
    var data = self.data || '';
    for (i in self.parameters)
      data += (data.length > 0?'&':'') + escape(i) + '=' + escape(self.parameters[i]);
    return data;
  }

  // Ajax control
  function headers()
  {
    self.request.setRequestHeader('X-Requested-With', 'WAJAF::Ajax - WebAbility(r) v5');
    if (self.method == 'POST' || self.method == 'PUT')
    {
      self.request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    }
//    self.request.setRequestHeader('Method', self.method + ' ' + self.url + ' HTTP/1.1');
  }

  this.send = send;
  function send(form)
  {
    if (self.timer)
      self.timer = null;
    if (self.request.readyState != 0 && self.request.readyState != 4) // still doing something
      return;

    self.request.onreadystatechange = process;
    if (self.timeoutabort)
      self.timerabort = setTimeout( function() { timeabort(); }, self.timeoutabort );
    try
    {
      var url = self.url;
      if (self.method == 'GET')
      {
        var parameters = buildParameters();
        if (parameters.length > 0)
          url += (url.match(/\?/) ? '&' : '?') + parameters;
      }
      self.request.open(self.method, url, true);
      self.request.withCredentials = true;
      if (!form)
        headers();
      callNotify('start');
      if (self.method == 'POST')
      {
        if (!!form)
          self.request.send(form);
        else
        {
          var parameters = buildParametersPost();
          self.request.send(parameters);
        }
      }
      else if (self.method == 'PUT')
      {
        if (self.putdata)
          self.request.send(self.putdata);
        else
          self.request.send(JSON.stringify(self.parameters));
      }
      else
        self.request.send(null);
      self.state = 1;
//      WA.debug.explain(WA.i18n.getMessage('ajax.send')+url, 2);
    }
    catch (e)
    {
//      WA.debug.explain(WA.i18n.getMessage('ajax.errorcreation')+url, 2);
      self.state = 3;
      processError(1, e);
    }
  }

  function process()
  {
    try
    {
      if (self.request.readyState == 4)
      {
        if (self.request.status == 200)
        {
//          WA.debug.explain(WA.i18n.getMessage('ajax.received')+self.url, 2);
          if (self.timerabort)
          {
            clearTimeout(self.timerabort);
            self.timerabort = null;
          }
          callNotify('stop');
          if (self.feedback)
          {
            self.feedback(self.request);
          }
          self.state = 2;
        }
        else
        {
//          WA.debug.explain(WA.i18n.getMessage('ajax.errorreception')+self.url, 2);
          self.state = 3;
          // we call error feedback, or alert
          processError(3, WA.i18n.getMessage('ajax.error')+self.request.status+':\n' + self.request.statusText, self.request);
        }
        self.request.onreadystatechange = WA.nothing;  // IE6 CANNOT assign null !!!
        var state = checkPeriod();
        if (!state)
          setTimeout( function() { WA.Managers.ajax.destroyRequest(self); }, 1);
      }
      else
      {
        waiting();
      }
    }
    catch(e)
    {
//      WA.debug.explain(WA.i18n.getMessage('ajax.fatalerror')+self.url+' '+e, 2);
      self.state = 3;
      processError(2, e);
    }
  }

  function checkPeriod()
  {
    if (self.period)
    {
      if (--self.times > 0)
      {
        self.timer = setTimeout( function() { self.send(); }, self.period);
        return true;
      }
    }
    return false;
  }

  function waiting()
  {
    // dispatcher for user events like "loading...", "making request", "sending information" based on readyState , etc ?
    // could also use a setInterval to periodically call this function to know how is going the call
    if (self.statefeedback)
      self.statefeedback('wait', self.request.readyState, '');
  }

  // any error
  // type = 1: error sending, 2: error during process, 3: error state != 200, 4: timeout forced
  function processError(type, error, request)
  {
    console.log('ERROR:');
    console.log(type);
    console.log(error);
    console.log(request);

    callNotify('error', type);
    if (typeof error == 'object')
      error = error.message;
    // abort and call feedback error
    if (self.statefeedback)
      self.statefeedback('error', type, error, request);
    // Default behaviour is to be silent on error
//    else
//      alert('Error: '+type+', '+error);
  }

  // we abort after a given timeout
  function doabort()
  {
    if (self.timer)
    {
      clearTimeout(self.timer);
      self.timer = null;
    }
    self.request.abort();
    self.request.onreadystatechange = WA.nothing;
    if (!checkPeriod())
      setTimeout( function() { WA.Managers.ajax.destroyRequest(self); }, 1);
  }

  // timeout abort
  function timeabort()
  {
    self.timerabort = null;
    callNotify('abortbytimeout');
    doabort();
  }

  // Manual abort
  this.abort = abort;
  function abort()
  {
    if (self.timerabort)
    {
      clearTimeout(self.timerabort);
      self.timerabort = null;
    }
    callNotify('abortbyuser');
    doabort();
  }

  this.destroy = destroy;
  function destroy()
  {
    self.period = 0;
    self.times = 0;
    if (self.timerabort)
    {
      clearTimeout(self.timerabort);
      self.timerabort = null;
    }
    if (self.timer)
    {
      clearTimeout(self.timer);
      self.timer = null;
    }
    if (self.state == 1 || self.state == 3)
    {
      doabort();
    }
    self.request.onreadystatechange = WA.nothing;
    self.clearParameters();
    delete self.request;
    self.statefeedback = null;
    self.feedback = null;
    self = null;
  }

  if (autosend)
    this.send();
}

WA.i18n.setEntry('ajax.notsupported', 'XMLHttpRequest is not supported. AJAX will not be available.');
WA.i18n.setEntry('ajax.send', 'Sending AJAX request to: ');
WA.i18n.setEntry('ajax.errorcreation', 'Error creating AJAX request to: ');
WA.i18n.setEntry('ajax.received', 'AJAX answer received from: ');
WA.i18n.setEntry('ajax.errorreception', 'Error during AJAX reception from: ');
WA.i18n.setEntry('ajax.fatalerror', 'Fatal error during AJAX reception from: ');
WA.i18n.setEntry('ajax.error', 'Error: ');



WA.Managers.ajax.PromiseRequest = function(data, listener, timeoutabort)
{
  var self = this;
  // parameters
  this.url = data.url;
  this.method = data.method.toUpperCase();
  this.data = data.data;
  this.feedback = data.feedback;
  this.autosend = data.send;
  // special parameters
  this.period = 0;
  this.times = 0;
  this.statefeedback = listener;    // consider waiting, error and abort feedbacks
  this.timeoutabort = timeoutabort;      // time out to abort, no default, let it to the ajax autocontrol.
  // working attributes
  this.request = null;
  this.parameters = null;
  this.timer = null;
  this.timerabort = null;
  this.state = 0;               // 0 = nothing, 1 = sent and waiting, 2 = finished, 3 = error
  this.listener = listener;
  this.putdata = null;
  // events
  //this.onprogress = null;
  this.onuploadprogress = null;
  this.onloadstart = null;
  this.onloadend = null;

  try { this.request = new XMLHttpRequest(); }
  catch(e)
  { try { this.request = new ActiveXObject('Msxml2.XMLHTTP.3.0'); }
    catch(e)
    { try { this.request = new ActiveXObject('Msxml2.XMLHTTP'); }
      catch(e)
      { try { this.request = new ActiveXObject('Microsoft.XMLHTTP'); }
        catch(e)
        { alert(WA.i18n.getMessage('ajax.notsupported')); }
      }
    }
  }

  function callNotify(event, data)
  {
    if (self.listener)
    {
      self.listener(event, data);
    }
  }

  // Special parameters
  this.setPeriodic = setPeriodic;
  function setPeriodic(period, times)
  {
    self.period = period;
    self.times = times;
  }

  this.addStateFeedback = addStateFeedback;
  function addStateFeedback(statefeedback, timeoutabort)
  {
    self.statefeedback = statefeedback;
    if (timeoutabort != undefined && timeoutabort != null)
      self.timeoutabort = timeoutabort;
  }

  this.setTimeoutAbort = setTimeoutAbort;
  function setTimeoutAbort(timeoutabort)
  {
    self.timeoutabort = timeoutabort;
  }

  // Parameters for POST/GET send
  this.addPutData = addPutData;
  function addPutData(data)
  {
    self.putdata = data;
  }

  this.addParameter = addParameter;
  function addParameter(id, value)
  {
    if (self.parameters === null)
      self.parameters = {};
    self.parameters[id] = value;
  }

  this.getParameters = getParameters;
  function getParameters()
  {
    return self.parameters;
  }

  this.clearParameters = clearParameters;
  function clearParameters()
  {
    self.parameters = null;
  }

  function buildParametersPost()
  {
    var data = self.data || '';
    for (i in self.parameters)
      data += (data.length > 0?'&':'') + encodeURIComponent(i) + '=' + encodeURIComponent(self.parameters[i]);
    return data;
  }

  function buildParameters()
  {
    var data = self.data || '';
    for (i in self.parameters)
      data += (data.length > 0?'&':'') + escape(i) + '=' + escape(self.parameters[i]);
    return data;
  }

  // Ajax control
  function headers()
  {
    self.request.setRequestHeader('X-Requested-With', 'WAJAF::Ajax - WebAbility(r) v5');
    if (self.method == 'POST' || self.method == 'PUT')
    {
      self.request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    }
/*
      if (self.request.overrideMimeType)
        self.request.setRequestHeader('Connection', 'close');
*/
//    self.request.setRequestHeader('Method', self.method + ' ' + self.url + ' HTTP/1.1');
  }

  this.send = send;
  function send(form)
  {
    prom = new Promise(function(resolve, reject) {
      if (self.timer)
        self.timer = null;
      if (self.request.readyState != 0 && self.request.readyState != 4) // still doing something
      {
        reject(1, "NO READY STATE, STILL DOING SOMETHING");
        return;
      }

      self.request.onreadystatechange = process;
      if (self.timeoutabort)
        self.timerabort = setTimeout( function() { timeabort(); }, self.timeoutabort );
      try
      {
        var url = self.url;
        if (self.method == 'GET')
        {
          var parameters = buildParameters();
          if (parameters.length > 0)
            url += (url.match(/\?/) ? '&' : '?') + parameters;
        }
        self.request.open(self.method, url, true);
        self.request.withCredentials = true;
        // events
        self.request.onloadstart = ((self.onloadstart && (typeof(self.onloadstart) === 'function')) ? self.onloadstart: null);
        var onuploadprogress = ((self.onuploadprogress && (typeof(self.onuploadprogress) === 'function')) ? self.onuploadprogress: null);
        self.request.upload.addEventListener('progress', onuploadprogress); //progress de post
        // self.request.onprogress //GET progress
        self.request.onloadend = ((self.onloadend && (typeof(self.onloadend) === 'function')) ? self.onloadend: null);
        // events -- /
        if (!form)
          headers();
        callNotify('start');
        if (self.method == 'POST')
        {
          if (!!form)
            self.request.send(form);
          else
          {
            var parameters = buildParametersPost();
            self.request.send(parameters);
          }
        }
        else if (self.method == 'PUT')
        {
          if (self.putdata)
            self.request.send(self.putdata);
          else
            self.request.send(JSON.stringify(self.parameters));
        }
        else
          self.request.send(null);
        self.state = 1;
      }
      catch (e)
      {
        self.state = 3;
        console.log("error", e)
        reject(-1, e);
      }

      function process()
      {
        try
        {
          if (self.request.readyState == 4)
          {
            if (self.request.status == 200)
            {
              if (self.timerabort)
              {
                clearTimeout(self.timerabort);
                self.timerabort = null;
              }
              callNotify('stop');
              resolve(self.request.responseText);
              self.state = 2;
            }
            else
            {
    //          WA.debug.explain(WA.i18n.getMessage('ajax.errorreception')+self.url, 2);
              self.state = 3;
              // we call error feedback, or alert
              reject(self.request.status, self.request.statusText);
            }
            self.request.onreadystatechange = WA.nothing;  // IE6 CANNOT assign null !!!
            var state = checkPeriod();
            if (!state)
              setTimeout( function() { WA.Managers.ajax.destroyRequest(self); }, 1);
          }
          else
          {
            waiting();
          }
        }
        catch(e)
        {
          self.state = 3;
          reject(-2, e);
        }
      }
    });
    return prom;
  }

  function checkPeriod()
  {
    if (self.period)
    {
      if (--self.times > 0)
      {
        self.timer = setTimeout( function() { self.send(); }, self.period);
        return true;
      }
    }
    return false;
  }

  function waiting()
  {
    // dispatcher for user events like "loading...", "making request", "sending information" based on readyState , etc ?
    // could also use a setInterval to periodically call this function to know how is going the call
    if (self.statefeedback)
      self.statefeedback('wait', self.request.readyState, '');
  }

  // we abort after a given timeout
  function doabort()
  {
    if (self.timer)
    {
      clearTimeout(self.timer);
      self.timer = null;
    }
    self.request.abort();
    self.request.onreadystatechange = WA.nothing;
    if (!checkPeriod())
      setTimeout( function() { WA.Managers.ajax.destroyRequest(self); }, 1);
  }

  // timeout abort
  function timeabort()
  {
    self.timerabort = null;
    callNotify('abortbytimeout');
    doabort();
  }

  // Manual abort
  this.abort = abort;
  function abort()
  {
    if (self.timerabort)
    {
      clearTimeout(self.timerabort);
      self.timerabort = null;
    }
    callNotify('abortbyuser');
    doabort();
  }

  this.destroy = destroy;
  function destroy()
  {
    self.period = 0;
    self.times = 0;
    if (self.timerabort)
    {
      clearTimeout(self.timerabort);
      self.timerabort = null;
    }
    if (self.timer)
    {
      clearTimeout(self.timer);
      self.timer = null;
    }
    if (self.state == 1 || self.state == 3)
    {
      doabort();
    }
    self.request.onreadystatechange = WA.nothing;
    self.clearParameters();
    delete self.request;
    self.statefeedback = null;
    self.feedback = null;
    self = null;
  }

  /*if (data.send)
    return this.send();*/
  if (self.autosend)
    this.send();
  return this;
}
WA.Managers.externloader = new function()
{
  var self = this;
  var requestedJs = [];
  var requestedCss = [];

  /* ================================================================================ */
  /* Códigos externos */
  /* ================================================================================ */
  this.loadexterncode = loadexterncode;
  function loadexterncode(src, text, listener, cfasync)
  {
    if (requestedJs.indexOf(src) > -1) // este recurso ya fue cargado
      return;
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = src;
    if (text) s.text = text;
    if (cfasync != undefined)
      s.setAttribute("data-cfasync", cfasync);
    if (listener)
    {
      s.onload = listener;
      s.onreadystatechange = function() { if (this.readyState == 'complete') { listener(); } };
    }
    document.getElementsByTagName('head')[0].appendChild(s);
    requestedJs.push(src);
    return s;
  }

  /* ================================================================================ */
  /* CSS externos */
  /* ================================================================================ */

  this.loadexterncss = loadexterncss;
  function loadexterncss(src, listener, cfasync)
  {
    if (requestedCss.indexOf(src) > -1) //el css ya fue cargado
      return;
    var s = document.createElement('link');
    s.setAttribute('rel', 'stylesheet');
    s.setAttribute('type','text/css');
    s.setAttribute('href', src);
    document.getElementsByTagName('head')[0].appendChild(s);
    requestedCss.push(src);
  }
}
WA.Managers.validator =
{
  version: '1.1.0'
}

WA.Managers.validator.base = function(listener)
{
  var self = this;

  this.status = false;
  this.blurred = false;
  this.listener = listener;
}

WA.Managers.validator.textfield = function(id, params, checkimage, listener)
{
  var self = this;
  WA.Managers.validator.textfield.sourceconstructor.call(this, listener);

  this.Node = WA.toDOM(id);
  this.NodeCheckImage = WA.toDOM(checkimage);
  this.id = this.Node.id;
  this.visibility = params.visibility?params.visibility:false,

  this.checks = {
    minlength: params.minlength?params.minlength:null,
    maxlength: params.maxlength?params.maxlength:null,
    minwords: params.minwords?params.minwords:null,
    maxwords: params.maxwords?params.maxwords:null,
    notempty: params.notempty?params.notempty:null,
    format: params.format?new RegExp(params.format):null,
    extra: params.checkextra?params.checkextra:null
  };

  this.errors = {
    minlength: false,
    maxlength: false,
    minwords: false,
    maxwords: false,
    notempty: false,
    format: false,
    extra: false
  };

  this.errormessages = {
    minlength: 'Error: tiene que capturar mínimo ' + this.minlength + ' carácteres',
    maxlength: 'Error: tiene que capturar máximo ' + this.maxlength + ' carácteres',
    minwords: 'Error: tiene que capturar mínimo ' + this.minwords + ' palabras',
    maxwords: 'Error: tiene que capturar mínimo ' + this.maxwords + ' palabras',
    notempty: 'Error: tiene que capturar mínimo 1 caracter',
    format: 'Error: el campo no tiene un formato válido',
    extra: 'Error: verifique el valor del campo'
  };

  WA.Managers.event.on('focus', this.Node, focus, true);
  WA.Managers.event.on('blur', this.Node, blur, true);
  WA.Managers.event.on('keyup', this.Node, keyup, true);
  WA.Managers.event.on('paste', this.Node, keyup, true);
  WA.Managers.event.on('change', this.Node, keyup, true);

  function focus(e)
  {
    var n = WA.toDOM(self.id + '_tooltip');
    if (n)
      n.style.display = '';
  }

  function blur(e)
  {
    var n = WA.toDOM(self.id + '_tooltip');
    if (n)
      n.style.display = 'none';
    self.blurred = true;
  }

  function keyup(e)
  {
    var t = setTimeout(validar, 0);
  }

  this.validar = validar;
  function validar()
  {
    for (var i in self.errors)
      self.errors[i] = false;

    var value = self.Node.value;

    self.status = true;

    if (self.checks.notempty && value == '')
    {
      self.status = false;
      self.errors.notempty = true;
    }
    if (self.checks.minlength && value.length < self.checks.minlength)
    {
      self.status = false;
      self.errors.minlength = true;
    }
    if (self.checks.maxlength && value.length > self.checks.maxlength)
    {
      self.status = false;
      self.errors.maxlength = true;
    }
    if (self.checks.maxwords || self.checks.minwords)
    {
      var text = value;
      text = text.replace(/^[ ]+/, "");
      text = text.replace(/[ ]+$/, "");
      text = text.replace(/[ ]+/g, " ");
      text = text.replace(/[\n]+/g, " ");
      var numpalabras = (text.length>0?text.split(" ").length:0);
      if (numpalabras < self.checks.minwords)
      {
        self.status = false;
        self.errors.minwords = true;
      }
      if (numpalabras > self.checks.maxwords)
      {
        self.status = false;
        self.errors.maxwords = true;
      }
    }
    if (self.checks.format && value.match(self.checks.format) == null)
    {
      self.status = false;
      self.errors.format = true;
    }
    if (self.checks.extra)
    {
      var result = self.checks.extra(value);
      if (result)
      {
        self.status = false;
        self.errors.extra = true;
      }
    }
    if (self.visibility)
      self.NodeCheckImage.style.visibility = self.status?'visible':'hidden';
    else
      self.NodeCheckImage.style.display = self.status?'':'none';

    if (self.listener)
      self.listener(self);
  }

  this.forceerror = forceerror;
  function forceerror()
  {
    self.status = false;
    self.errors.extra = true;
    if (self.visibility)
      self.NodeCheckImage.style.visibility = self.status?'visible':'hidden';
    else
      self.NodeCheckImage.style.display = self.status?'':'none';
    if (self.listener)
      self.listener(self);
  }

  validar();
}

// Add basic element code
WA.extend(WA.Managers.validator.textfield, WA.Managers.validator.base);


WA.Managers.validator.checkboxfield = function(id, params, checkimage, listener)
{
  var self = this;
  WA.Managers.validator.checkboxfield.sourceconstructor.call(this, listener);

  this.Node = WA.toDOM(id);
  this.NodeCheckImage = WA.toDOM(checkimage);
  this.id = this.Node.id;

  this.checks = {
    notempty: params.notempty?params.notempty:null,
    extra: params.checkextra?params.checkextra:null
  };

  this.errors = {
    notempty: false,
    extra: false
  };

  this.errormessages = {
    notempty: 'Error: tiene que poner una palemita en este campo',
    extra: 'Error: verifique el valor del campo'
  };

  WA.Managers.event.on('focus', this.Node, focus, true);
  WA.Managers.event.on('blur', this.Node, blur, true);
  WA.Managers.event.on('mouseover', this.Node, focus, true);
  WA.Managers.event.on('mouseout', this.Node, blur, true);
  WA.Managers.event.on('click', this.Node, keyup, true);
  WA.Managers.event.on('change', this.Node, keyup, true);

  function focus(e)
  {
    var n = WA.toDOM(self.id + '_tooltip');
    if (n)
      n.style.display = '';
  }

  function blur(e)
  {
    var n = WA.toDOM(self.id + '_tooltip');
    if (n)
      n.style.display = 'none';
  }

  function keyup(e)
  {
    var t = setTimeout(validar, 0);
  }

  function validar()
  {
    for (var i in self.errors)
      self.errors[i] = false;

    var checked = self.Node.checked;

    self.status = true;

    if (self.checks.notempty && !checked)
    {
      self.status = false;
      self.errors.notempty = true;
    }
    if (self.checks.extra)
    {
      var result = self.checks.extra(checked);
      if (result)
      {
        self.status = false;
        self.errors.extra = true;
      }
    }

    if (self.listener)
      self.listener(self);
  }

  validar();
}

// Add basic element code
WA.extend(WA.Managers.validator.checkboxfield, WA.Managers.validator.base);
function ajaximage(formid, nodeid)
{
  var self = this;
  this.formid = formid;
  this.form = WA.toDOM(formid);
  this.nodeid = nodeid;                         // field with name of image
  this.downloadnode = WA.toDOM(nodeid+'_download');    // field with upload button
  this.imagenode = WA.toDOM(nodeid+'_image');          // image
  this.filenode = WA.toDOM(nodeid+'_file');            // temporary file name

  this.loading = false;
  this.loadingimage = KL.cdn7domains + '/kiwi5/static/loading.gif';
  this.action = '/doeditor?orden=foto';
  this.page = null;
  this.container = null;
  this.check = null;

  this.setLoadingImage = setLoadingImage;
  function setLoadingImage(img)
  {
    self.loadingimage = img;
  }

  this.setAction = setAction;
  function setAction(action)
  {
    self.action = action;
  }

  this.setPage = setPage;
  function setPage(page)
  {
    self.page = page;
  }

  this.changeImage = changeImage;
  function changeImage()
  {
    var oldtarget = self.form.target;
    var oldaction = self.form.action;
    var oldpage = null;
    
    if (self.form.elements["orden"] && self.page)
    {
      oldpage = self.form.elements["orden"].value;
      self.form.elements["orden"].value = self.page;
    }
    
    self.form.action = KL.graphdomains + self.action; // set the URL 
    self.form.target = self.nodeid + '_hiddeniframe';
    self.loading = true;
    if (self.check)
      self.check('change');
    if (WA.toDOM("barratiempo_subeimg")) //hay progressbar ?  
      self.imagenode.src = self.loadingimage;
    
    var imageFile = (self.downloadnode.files.length > 0 ? self.downloadnode.files[0]: false);
    if (!imageFile)
      { alert('No image file'); return; }
    
    self.imagenode.src = KL.cdn7domains + '/kiwi5/static/loading.gif';
    self.imagenode.style.display = "block";

    var auxForm = new FormData();
    auxForm.append(self.nodeid + '_download', imageFile);
    WA.Managers.ajax.createPromiseRequest({ url: self.form.action, method: 'POST', send: false})
      .then(function(request) {
              request.onloadstart = () => {showProgressBar();};
              request.onuploadprogress = function (e) {
                if (e.lengthComputable)
                {
                  var progress = Math.round((e.loaded / e.total) * 100); // 0 - 100 %
                  setProgressToProgresBar(progress);
                }
              };
              //request.onloadend = () => {console.log('wb-loadend');};//hideProgressBar();};
              return request.send(auxForm);
            })
      .then(function(response) {
              processResponseScript(response);
            })
      .catch(function(code, err) {
              hideProgressBar();
              KL.Modules.modal.alerta(WA.i18n.getMessage("errorcargaimagen"));
            } )
    
    self.form.target = oldtarget;
    self.form.action = oldaction;
    if (oldpage)
      self.form.elements["orden"].value = oldpage;
  }
  
  // /--- PROGRESSBAR FUNCTIONS ---\
  
  //progress (0 - 100) int
  function setProgressToProgresBar(progress)
  {
    if (isNaN(progress))
      return;
    
    progress = parseInt(progress);
    if (progress < 0)
      progress = 0;
    if (progress > 100)
      progress = 100;
    
    var progressNode = WA.toDOM("barratiempo_indiceimg");
    if (progressNode)
      progressNode.style.width = progress + '%';
  }
  
  function showProgressBar()
  {
    var progressBarNode = WA.toDOM("barratiempo_subeimg");
    if (progressBarNode && (progressBarNode.style.display === 'none'))
      { setProgressToProgresBar(0); progressBarNode.style.display = 'block'; }
  }
  
  function hideProgressBar()
  {
    var progressBarNode = WA.toDOM("barratiempo_subeimg");
    if (progressBarNode && (progressBarNode.style.display === 'block'))
      progressBarNode.style.display = 'none';
  }
  
  // \--- PROGRESSBAR FUNCTIONS ---/
  
  function processResponseScript(response)
  {
    var code = JSON.parse(response);
    if (code.status == 'OK')
    {
      self.imagenode.src = "";
      self.imagenode.style.display = "none";
      setImage(code.path, code.name);
    }
    else
    {
      self.imagenode.style.display = "none";
      KL.Modules.modal.hidepopup();
      KL.Modules.modal.alerta(code.message);
    }
  }

  this.setImage = setImage;
  function setImage(path, name)
  {
    self.imagenode.src = path+name; //WA.toDOM('IMAGEN_image').src = '';
    self.imagenode.style.width = '120px'; //WA.toDOM('IMAGEN_image').style.width = '0px';
    self.imagenode.style.margin = '0 auto'; //WA.toDOM('IMAGEN_image').style.width = '0px';
    self.filenode.value = name;
    self.loading = false;
    self.imagenode.style.display = "block";
    if (self.check)
      self.check('set');
    
    WA.toDOM("upload-image-validaImagen").disable = false;
  }
  
  this.setCheck = setCheck;
  function setCheck(check)
  {
    self.check = check;
  }

  this.downloadnode.onchange = this.changeImage;

  return this;
}
KL = {};
KL.version = "7.0.1";
KL.webdomains = 'https://www.kiwilimon.com';
KL.cdndomains = 'https://cdn.kiwilimon.com';
KL.cdn7domains = 'https://cdn7.kiwilimon.com';
KL.graphdomains = 'https://gr.kiwilimon.com';
KL.identitydomains = 'https://im.kiwilimon.com';
KL.pgraphdomains = 'https://graph.kiwilimon.com';
KL.officialname = "Kiwilimon";
KL.urllogo = KL.cdn7domains + "/img/static/logo-kiwilimon-verde.png";
KL.logowidth = "384";
KL.logoheight = "80";

KL.cookiedomain = 'kiwilimon.com';
KL.videodomains = 'https://video.kiwilimon.com'
KL.ssl = (document.location.protocol == "https:");
KL.rootsite = "kiwi";
KL.skin = 'kiwi-pc';
KL.devel = false;
KL.fbid = '250305718425857';
KL.alexaid = "Cq4Hj1aotV008f";
KL.alexadomain = "kiwilimon.com";
KL.comscoreid = "7750805";
KL.device = ""; // Set after full code loading
KL.language = ""; // Set after full code loading
KL.KR = true;   // kontent room yes

KL.pagedata = {};

KL.appleredirecturl = "https://www.kiwilimon.com/login";
KL.appleclientid = "com.kiwilimon.kiwilimon";

KL.googleclientauth = '283529264243-vvdq0isu1kiu6ic5rob68ngf2imok0j7.apps.googleusercontent.com';

KL.firebase = '283529264243-vvdq0isu1kiu6ic5rob68ngf2imok0j7.apps.googleusercontent.com';
KL.firebaseauthdomain = "kiwilimon-app.firebaseapp.com";
KL.firebaseurl = "https://kiwilimon-app.firebaseio.com";
KL.firebasestoreagebucket = "kiwilimon-app.appspot.com";
KL.firebasemessagingsender = "283529264243";

KL.huaweiclient = "100355327"; 
KL.huaweiredirecturl = "https://www.kiwilimon.com/login/social";
KL.huaweiscope = "openid+profile";

KL.openpayID = "meq8emxd1wpyyq6rs5ya";
KL.openpayKey = "pk_22ad8b73303542bd89a904d66118a570";
KL.openpaySandboxMode = false;

// KL.openpayID = "mlzjtvf9aqak1gd1yiwe";
// KL.openpayKey = "pk_3e8a3eaf459e41c9bb7694757966e4f4";
// KL.openpaySandboxMode = true;

KL.currenttemplate = null;
KL.currentcore = null;

KL.Modules = {};
KL.LoadedModules = [];

KL.onLoad=function(){
  KL.loader.Start();
};

KL.paint=function(){
  KL.Modules.images.analyze();

  if (!KL.Modules.client || !KL.Modules.client.clientpro)
    KL.Modules.ads.analyze();
};
KL.mydomains = 'https://www.kiwilimon.com';
KL.fblocale = 'es_LA';
KL.i18n = {
  "tools_favoritos_ok1": "Favoritos:",
  "tools_favoritos_ok2": "Se ha agregado este elemento a tus favoritos.",
  "tools_collections_ok1": "Colecciones:",
  "tools_collections_ok2": "Se ha agregado este elemento a tu colección.",
  "tools_listasuper_ok1": "Lista del súper:",
  "tools_listasuper_ok2": "La receta se ha agregado a la lista del súper."
}
KL.manageError = function(e)
{
  var r = WA.Managers.ajax.createRequest(KL.graphdomains + '/v6/bitacora', 'POST', null, null, false);
  r.addParameter('data', '' + e + '\n' + e.stack );
  r.addParameter('device', KL.device );
  r.addParameter('language', KL.language );
  r.send();
}

KL.fixedEncodeURIComponent = function(str)
{
  return encodeURIComponent(str).replace(/[!'()]/g, escape).replace(/\*/g, "%2A");
}

KL.loader = new function()
{
  var self = this;

  var started = false;        // true when code is already started
  var nodeload = null;
  var loader = 0;
  var scriptloaded = true;    // true at first load: anything comes with the page
  var codeloaded = true;

  var recon_time = 30000;     // hit news every 30 segunds at start
  var recon_timeinc = 5000;   // wait 5 seconds more each loop
  var recon_timemax = 120000; // max 2 minutes to search news

  var hooksstart = {};        // llamar al onload del codigo JS en general (primera vez solamente que se carga la app)
  var hooksload = {};         // llamar despues de que se carga por PRIMERA VEZ la pagina
  var hookspostload = {};     // llamar despues de que se carga algo dentro del bodycontainer, puede ser llamado MUCHAS VECES en cualquier cambio de contenido de la misma pagina
  var hooksunload = {};       // llamar antes de que se descarga algo del bodycontainer
  var hooksrecon = {};        // llamar cada X segundos para conocer nuevas cosas del servidor (noticias x ej.)
  this.hookspostload = hookspostload;
  this.waitload = 10000;   // wait X seconds before loading not visible data if needed

  var pleaseload = null;
  /* ================================================================================ */
  /* Main start function                                                              */
  /* ================================================================================ */
  function addLoad(n)
  {
    if (loader == 0)
    {
      loader = 0;
      nodeload.style.top = "0px";
      nodeload.className = "anim";
    }
    loader += n;
    nodeload.style.width = loader + "%";
    if (loader == 100)
    {
      setTimeout(function() { endload(); }, 1000);
    }
  }

  function endload()
  {
    loader = 0;
    nodeload.style.top = "-2px";
    nodeload.className = "";
    if (pleaseload != null)
    {
      loadPage(pleaseload[0], pleaseload[1], pleaseload[2])
      pleaseload = null;
    }
  }

  this.Start = Start;
  function Start()
  {
    if (started) // doble protección: si el onstart de esta funcion pasa justo despues del onload de KL, pudiera ser llamado también
      return;
    started = true;
    nodeload = WA.toDOM("header-loading");
    loader = 75; // only have to paint the page

    callHooksStart();

    // apply template on crosslink
    template = WA.templater`${['loop', 'crosslink','feed_payload']}`;
    text = template(KL.pagedata.page);
    WA.toDOM('footer-crosslink').innerHTML = text;
    delete(WA.toDOM('footer-crosslink').dataset.scanned);

    buildPage(); // build the page
    KL.Modules.ads.analyze() // for first ads, data is already here

    // carga todos los scripts de terceras partes asyncronamente lazy load despues de 2 segundos para proteger el speed insight y la interactividad con el usuario
    postload();

    // Call news in 5 seconds
    setTimeout(recon, 10000);  // recon after 5 sec: call news and notifs
    loadKR();
  }

  this.buildPage = buildPage;
  function buildPage()
  {
    KL.Modules.modal.hidepopup();
    KL.Modules.menu.switchoff();
    KL.Modules.language.switchoff();
    KL.Modules.search.switchoff();
    KL.Modules.client.switchoff();
    window.scrollTo(0,0);
    WA.toDOM("page_container").innerHTML = KL.currenttemplate(KL.currentcode);
    // call los Loads de los modulos varios
    addLoad(25);
    callHooksLoad();
  }

  function changePage()
  {
    addLoad(25); // called twice
    if (!scriptloaded || !codeloaded)
      return; // we wait both loaded
    callHooksUnload();

    fc = WA.toDOM('footer-crosslink');
    if (fc)
    {
      template = WA.templater`${['loop', 'crosslink','feed_payload']}`;
//      console.log(KL.pagedata.page)
      text = template(KL.pagedata.page);
      fc.innerHTML = text;
      delete(WA.toDOM('footer-crosslink').dataset.scanned);
    }

    buildPage();
    callHooksPostLoad();

    // console.log("change page");
    // analytics metrics
    KL.Modules.stat.registerPage();
    /* ALEXA METRICS */
    as.parentNode.removeChild( as );
    window._atrk_fired = 0;
    (function() { as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "//certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
  }

  this.loadPage = loadPage;
  function loadPage(url, hash, donotpush)
  {
    // only one page load at the same time !!
    if (loader != 0)
    {
      pleaseload = [url,hash,donotpush];
      return;
    }

    scriptloaded = false;
    codeloaded = false;
    addLoad(25);

    var s = document.createElement('script');
    s.src = url + (url.indexOf("?")==-1?"?":"&") + "data=page&loaded=" + JSON.stringify(KL.LoadedModules);
    s.onload = function() { getpagecode(s); };
    s.onerror = function(d) { console.log("ERROR LOADING PAGE", url, d); };
    document.getElementsByTagName('head')[0].appendChild(s);

    // ask for page data too
    var request = WA.Managers.ajax.createRequest(KL.graphdomains + '/v6/page', 'POST', "device="+KL.device+"&language="+KL.language+"&path="+url, getpagedata, true);

    KL.loadingpage = true;
    if (!donotpush)
      window.history.pushState('', 'Kiwilimon ' + url, url + (hash?hash:''));
  }

  function getpagecode(s)
  {
//    console.log("CODE SOURCE:", s.src);
    scriptloaded = true;
    changePage();
  }

  function getpagedata(request)
  {
    // pagedata contains 2 parts:
    // - Ads data
    // - Crosslink data
    KL.pagedata.page = JSON.parse(request.responseText)
    codeloaded = true;
    changePage();
  }

  function historystate(event)
  {
    loadPage(document.location.pathname, null, true);
  }

  this.callPage = callPage;
  function callPage(event)
  {
    WA.browser.cancelEvent(event);
    var url = this.pathname + this.search;
    var hash = this.hash;
    loadPage(url, hash);
    return false;
  }

  /* ================================================================================ */
  /* Hooks START ANYTHING                                                             */
  /* ================================================================================ */

  this.addHookStart = addHookStart;
  function addHookStart(id, hook)
  {
    hooksstart[id] = hook;
    // If already started, call it immediatly
    if (started)
      hook();
  }

  function callHooksStart()
  {
    for (var i in hooksstart)
    {
      hooksstart[i]();
    }
  }

  /* ================================================================================ */
  /* Hooks LOAD A PAGE                                                                */
  /* ================================================================================ */

  this.addHookLoad = addHookLoad;
  function addHookLoad(id, hook)
  {
    hooksload[id] = hook;
//    if (started)
//      hook();
  }

  this.callHooksLoad = callHooksLoad;
  function callHooksLoad()
  {
    for (var i in hooksload)
    {
      hooksload[i]();
    }
    KL.Modules.links.analyze();
    KL.Modules.images.analyze();
    KL.Modules.ads.onload();
  }

  /* ================================================================================ */
  /* Hooks LOAD A PART OF A PAGE                                                      */
  /* ================================================================================ */

  this.addHookPostLoad = addHookPostLoad;
  function addHookPostLoad(id, hook)
  {
    hookspostload[id] = hook;
  }

  this.callHooksPostLoad = callHooksPostLoad;
  function callHooksPostLoad()
  {
    for (var i in hookspostload)
    {
      hookspostload[i]();
    }
    KL.Modules.links.analyze();
    KL.Modules.images.analyze();
    KL.Modules.ads.refresh();
    KL.Modules.ads.analyze();
  }

  /* ================================================================================ */
  /* Hooks RECON (cada 30 sec + lazy post time)                                       */
  /* ================================================================================ */

  this.addHookRecon = addHookRecon;
  function addHookRecon(id, hook)
  {
    hooksrecon[id] = hook;
  }

  this.callHooksRecon = callHooksRecon;
  function callHooksRecon()
  {
    for (var i in hooksrecon)
    {
      hooksrecon[i]();
    }
  }

  /* ================================================================================ */
  /* Hooks UNLOAD A PAGE                                                              */
  /* ================================================================================ */

  this.addHookUnload = addHookUnload;
  function addHookUnload(id, hook)
  {
    hooksunload[id] = hook;
  }

  this.callHooksUnload = callHooksUnload;
  function callHooksUnload()
  {
    for (var i in hooksunload)
    {
      hooksunload[i]();
    }
  }

  function postload() {

    /* DFP */
    WA.Managers.externloader.loadexterncode("//www.googletagservices.com/tag/js/gpt.js");

    /* FACEBOOK PIXEL */
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/'+KL.fblocale+'/fbevents.js');
    fbq('init', KL.fbid);
    fbq('track', 'PageView');

    /* BROWSER UPDATE */
    window.$buoop = {required:{e:12,f:-5,o:-5,s:-2,c:71},noclose:true,insecure:true,unsupported:true,style:"corner",api:2020.03 };
    WA.Managers.externloader.loadexterncode("//browser-update.org/update.min.js");

    /* COMSCORE */
    window._comscore = window._comscore || [];
    window._comscore.push({ c1: "2", c2: KL.comscoreid });
    WA.Managers.externloader.loadexterncode("//sb.scorecardresearch.com/beacon.js");

    setTimeout(function() { KL.Modules.video.LoadPlayer(); }, 20000)

    /* Amazon APS */
    //load the apstag.js library
    !function(a9,a,p,s,t,A,g){if(a[a9])return;function q(c,r){a[a9]._Q.push([c,r])}a[a9]={init:function(){q("i",arguments)},fetchBids:function(){q("f",arguments)},setDisplayBids:function(){},targetingKeys:function(){return[]},_Q:[]};A=p.createElement(s);A.async=!0;A.src=t;g=p.getElementsByTagName(s)[0];g.parentNode.insertBefore(A,g)}("apstag",window,document,"script","//c.amazon-adsystem.com/aax2/apstag.js");

    /* Google FIREBASE */
    //    WA.Managers.externloader.loadexterncode("https://www.gstatic.com/firebasejs/3.6.5/firebase.js",'',firebasedone);
  }

/*
  function firebasedone()
  {
    // Initialize Firebase
    var config = {
      client_id: '283529264243-vvdq0isu1kiu6ic5rob68ngf2imok0j7.apps.googleusercontent.com',
//      apiKey: "AIzaSyB_3sU0fUuzO67ipiXBjy_fydFyCUlAaXU",
      authDomain: "kiwilimon-app.firebaseapp.com",
      databaseURL: "https://kiwilimon-app.firebaseio.com",
      storageBucket: "kiwilimon-app.appspot.com",
      messagingSenderId: "283529264243"
    };
    firebase.initializeApp(config);
  }
*/

  function recon()
  {

  }

  // Kontent room loader
  function loadKR()
  {
    // Load only if country = US
    if (KL.KR && KL.Modules.client.getCountry() == "US")
      WA.Managers.externloader.loadexterncode("//s.ntv.io/serve/load.js");
  }

  this.createCSS = createCSS;
  function createCSS(data)
  {
    var s = document.createElement('style');
    s.innerHTML = data;
    document.getElementsByTagName('head')[0].appendChild(s);
  }

  // escucha popstate para saber si hay un cambio de pagina
  WA.Managers.event.on('popstate', window, historystate, true);
}
/*
  Funciones para manejar una popup modal
  Escrito por: Phil
  Fecha: Agosto 2016

  Control de cambios:
  07/10/2021: Rodolfo, en la función para cerrar la modal al WA.toDOM del body se colocó una posición relative,
              ya que en la lading de club kiwipro, diseño solicitó que cuando apareciera la modal la parte que queda abajo de la sombra
              se quedara fijo (fixed)
  21/07/2017: Rodolfo, Puse un div extra dentro de las notificaciones de kiwi (popup-notif),
              esto para darle espacio entre los botones de accion y los mensajes ya que se encimaban
              cuando el mensaje es largo
  16/08/2016: Phil, Creacion
*/

KL.Modules.modal = new function()
{
  var self = this;

  var hook = null;
  var current = null;

  /* ================================================================================ */
  /* DO NOT MOVE THE PAGE WHILE POPUP                                                             */
  /* ================================================================================ */
  var fixedpage = 0;

  this.fixpage = fixpage;
  function fixpage()
  {
    fixedpage = WA.browser.getScrollTop();

    WA.toDOM('pagecontainer').style.position = 'fixed';
    if (fixedpage == 0)
      WA.toDOM('pagecontainer').style.top = '0px'; // 80 = menu-header
    else
      WA.toDOM('pagecontainer').style.top = (-fixedpage-80) + 'px'; // 80 = menu-header
  }

  this.unfixpage = unfixpage;
  function unfixpage()
  {
    console.log("UNFIX TO: ", fixedpage)
    if (KL.origin.url !== "" && KL.origin.top_offset === 0)
      KL.origin.top_offset = fixedpage;
    WA.toDOM('pagecontainer').style.top = '0px';
    WA.toDOM('pagecontainer').style.position = '';
    window.scrollTo(0,fixedpage);
    var unfix = WA.browser.getScrollTop();
    console.log("UNFIXED TO: ", unfix)
  }

  /* ================================================================================ */
  /* POPUPS                                                                           */
  /* ================================================================================ */
  var backgroundpopup = null;
  var popup = null;
  var popupstatus = false;
  var popupparams = null;

  this.buildpopup = buildpopup;
  function buildpopup(data)
  {
    if (!popup)
    {
      popup = WA.toDOM("popup");
      backgroundpopup = WA.toDOM("backgroundpopup");
    }
    popup.innerHTML = data;
  }

  this.showpopup = showpopup;
  function showpopup(params)
  {
    if (!popup)
      return;

    popupparams = params;
    backgroundpopup.onclick = actionpopup;
    backgroundpopup.style.display = "block";
    popup.style.display = "block";
    if (popupparams && popupparams.closeable)
    {
      // activate CLOSE button
    }
    popupstatus = true;
  }

  this.actionpopup = actionpopup;
  function actionpopup(event)
  {
    if (!popup || !popupstatus)
      return;
    hidepopup();
  }

  this.hidepopup = hidepopup;
  function hidepopup()
  {
    if (!popup)
      return;
    popupstatus = false;
    backgroundpopup.style.display = "none";
    popup.style.display = "none";
    WA.toDOM('body').style.position = 'relative';
  }

  this.cleanpopup = cleanpopup;
  function cleanpopup()
  {
    if (!popup)
      return;

  }

  /* ================================================================================ */
  /* Modals under menu bar, MESSAGES queue                                            */
  /* ================================================================================ */
  var pilamensajes = [];
  var mensajesabierto = false;
  var listenerabierto = null;
  var iconomensaje = null;
  var titulomensaje = null;
  var tiempo = 3000;

  this.notifica = notifica;
  function notifica(mensaje)
  {
    //console.log('Notficar: ' + mensaje);
    pilamensajes.push([1, mensaje]);
    siguientemensaje();
  }

  this.alerta = alerta;
  function alerta(mensaje, boton, listener)
  {
    if (!boton)
      boton = 'OK';
    pilamensajes.push([2, mensaje, boton, listener]);
    siguientemensaje();
  }

  this.confirma = confirma;
  function confirma(mensaje, boton1, boton2, listener)
  {
    if (!boton1)
      boton1 = 'SI';

    if (!boton2)
      boton2 = 'NO';
    
    pilamensajes.push([3, mensaje, boton1, boton2, listener]);
    siguientemensaje();
  }

  function siguientemensaje()
  {
    if (mensajesabierto)
      return;
    if (pilamensajes.length == 0)
      return;

    var data = pilamensajes.shift();
    // enseña mensaje

    var node = WA.toDOM('header-modal');
    node.className = 'anim modal-' + data[0]
    texto = "";
    texto += data[1];
    if (data[0] == 2)
      texto += '<div class="modal-buttonok" onclick="KL.Modules.modal.cerrarmensaje();">'+data[2]+'</div>';

    if (data[0] == 3)
      texto += '<div class="modal-buttonconfirma" onclick="KL.Modules.modal.cerrarmensaje(1);">'+data[2]+'</div> <div class="modal-buttonconfirma" onclick="KL.Modules.modal.cerrarmensaje(2);">'+data[3]+'</div>';

    node.innerHTML = texto;

//    node.innerHTML = '<div class="area-txt-notificacion"><div class="area-txt-infonotificacion"><div class="circulo-ok-popup icon-k5-paloma-ok-popup"></div>' + data[1] + '</div></div>' +
    /* <div class="area-txt-notificacion"><div class="area-txt-infonotificacion"><div class="circulo-ok-popup icon-k5-paloma-ok-popup"></div>' + data[1] + '</div><div class="btn-confirmacion-popup">OK</div></div>' + */
    /* <div class="area-txt-notificacion"><div class="icon-k5-paloma-ok" style="background-position: -732px 2px; display: inline-block; width: 16px; vertical-align: top; height: 16px; margin-right: 5px;"></div>' + data[1] + '</div>' + */
      /* (data[0] == 2?'<div class="pop-tipo-2-confirma" onclick="KL.Modules.modal.cerrarmensaje();"><div class="icon-k5-paloma-ok" style="background-position: 2px -480px; width: 20px; height: 20px;"></div></div>':'') + */
//      (data[0] == 2?'<div class="pop-tipo-2-confirma" onclick="KL.Modules.modal.cerrarmensaje();"></div>':'') +
//      (data[0] == 3?'<div class="pop-tipo-3-cancela" onclick="KL.Modules.modal.cerrarmensaje(2);">'+data[3]+'</div><div class="pop-tipo-3-confirma" onclick="KL.Modules.modal.cerrarmensaje(1);">'+data[2]+'</div>':'');

    /* codigo original notificacion popup
    WA.toDOM('popup-notif').innerHTML = '<div class="bgicon" style="background-position: -732px 2px; display: inline-block; width: 16px; vertical-align: top; height: 16px; margin-right: 5px;"></div>' + data[1] +
      (data[0] == 2?'<div style="background-color: #8CC63E; width: 40px; height: 40px; padding-left: 10px; padding-top: 10px; border-radius: 20px; position: absolute; right: 5px; top: -20px; border: 1px solid white;" onclick="KL.Modules.modal.cerrarmensaje();"><div class="bgicon" style="background-position: 2px -480px; width: 20px; height: 20px;"></div></div>':'') +
      (data[0] == 3?'<div style="background-color: #8CC63E; min-width: 40px; height: 40px; padding: 10px; border-radius: 20px; position: absolute; left: 5px; top: -20px; border: 1px solid white; text-align: center;" onclick="KL.Modules.modal.cerrarmensaje(1);">'+data[2]+'</div><div style="background-color: #8CC63E; min-width: 40px; height: 40px; padding: 10px; border-radius: 20px; position: absolute; right: 5px; top: -20px; border: 1px solid white; text-align: center;" onclick="KL.Modules.modal.cerrarmensaje(2);">'+data[3]+'</div>':'');
    */

    if (data[0] == 3)
    {
      //showbg(true);
      // WA.toDOM('popup-notif').className = 'anim confirma';
//      node.className = 'confirma';
      if (data[4])
        listenerabierto = data[4];
    }
    else if (data[0] == 2)
    {
//      showbg();
      // WA.toDOM('popup-notif').className = 'anim error';
//      node.className = 'error';
      if (data[3])
        listenerabierto = data[3];
    }
    else
    {
//      node.className = 'activa-notif';
      //WA.toDOM('popup-notif').className = 'anim';
    }

    // WA.toDOM('popup-notif').style.bottom = '0';
    if (KL.device=="mobile")
    {
      node.style.top = '46px';
    }
    else
    {
      node.style.top = '60px';
    }

    if (data[0] == 1)
    {
      setTimeout(cerrarmensajes, tiempo);
      //hidebg();
    }
    mensajesabierto = true;
  }

  this.cerrarmensaje = cerrarmensaje;
  function cerrarmensaje(id)
  {
    // console.log('mensaje: ' + id);
    cerrarmensajes();
//    hidebg();
    if (listenerabierto)
    {
      listenerabierto(id);
      listenerabierto = null;
    }
  }

  function cerrarmensajes()
  {
    // WA.toDOM('popup-notif').style.bottom = '-200px';
    if (KL.device=="mobile")
    {
      WA.toDOM('header-modal').style.top = '-20px';
    }
    else
    {
      WA.toDOM('header-modal').style.top = '-10px';
    }
    mensajesabierto = false;
    setTimeout(siguientemensaje, 500);
//    hidebg();
  }









  /* ================================================================================ */
  /* Tutoriales                                                                       */
  /* ================================================================================ */

  this.cerrartutorialmenus = cerrartutorialmenus;
   function cerrartutorialmenus()
  {
    if(WA.toDOM('bgtutorialmenus'))
      WA.toDOM('bgtutorialmenus').style.display = 'none';
    if(WA.toDOM('tutorialmenus'))
      WA.toDOM('tutorialmenus').style.display = 'none';
  }

  this.abrirtutorialmenus = abrirtutorialmenus;
  function abrirtutorialmenus(request)
  {
    if (request==1)
    {
      var prueba30dias = WA.toDOM('galeria-tour-dpm4');
      if (prueba30dias)
        prueba30dias.parentNode.removeChild(prueba30dias);

      var bullet = WA.toDOM('bullet_4');
      if (bullet)
        bullet.parentNode.removeChild(bullet);
    }
    WA.toDOM('bgtutorialmenus').style.display = 'block';
    WA.toDOM('tutorialmenus').style.display = 'block';
  }
  //tutorial_planeadormenu
  
}
KL.Modules.links = new function()
{
  var self = this;

  /* ================================================================================ */
  /* Códigos externos */
  /* ================================================================================ */
  this.analyze = analyze;
  function analyze()
  {
    //Obtenemos, los nodos A que cumplen para agregar el onclick
    var aNodes = document.getElementsByTagName('A');
    var urlvar = window.location.href;
    if (aNodes)
    {
      for (var id = 0; id < aNodes.length; id++)
      {
        // ya escaneado
        if (aNodes[id].scanned)
          continue;
        aNodes[id].scanned = true;

        // no tocar links externos
        if (aNodes[id].href.substr(0, 7) == 'http://' || aNodes[id].href.substr(0, KL.mydomains.length) != KL.mydomains)
          continue;
        // no tocar los redirects
        if (aNodes[id].pathname.substr(0, 10) == '/redirect/')
          continue;
        aNodes[id].onclick = KL.loader.callPage;
      }
    }
  }

//  KL.loader.addHookLoad('links', analyze);
//  KL.loader.addHookPostLoad('links', analyze);
}
KL.Modules.images = new function()
{
  var self = this;
  var analyzeclass = "analyzethis";
  var webp = canUseWebP();

  function canUseWebP()
  {
    var elem = document.createElement('canvas');

    if (!!(elem.getContext && elem.getContext('2d'))) {
      // was able or not to get WebP representation
      if (elem.toDataURL('image/webp').indexOf('data:image/webp') == 0)
        return true;
    }

    // very old browser like IE 8, canvas not supported
    if (WA.browser.isWebpSupport())
      return true;
    return false;
  }

  /* ================================================================================ */
  /* Códigos externos */
  /* ================================================================================ */
  this.analyze = analyze;
  function analyze()
  {
    var maxheight = WA.browser.getWindowHeight();
    var maxwidth  = WA.browser.getWindowWidth();
    var scrolltop = WA.browser.getScrollTop();
    var scrollleft = WA.browser.getScrollLeft();

    //Obtenemos, los nodos que tienen esta clase y les ponemos al .src, el atributo especifico
    var imgNode = document.getElementsByClassName(analyzeclass);

    // Create new IntersectionObserver
    var io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {

            entry.target.scanned = true;

            var haswebp = entry.target.dataset.webp;
            var w = entry.target.dataset.width;
            var h = entry.target.dataset.height;

            var src = entry.target.dataset.src;
            if (src)
            {
              if (src.substr(0, 4) != "http")
              {
                // Rebuild as cdn7/.../WxH/...webp
                // Only if OUR CDN
                xpath = src.split("/");
                img = xpath[xpath.length-1];
                xpath[xpath.length-1] = w + "x" + h;
                if (webp&&haswebp)
                {
                  xpath.push(img + ".webp");
                }
                else
                {
                  xpath.push(img + ".jpg");
                }
                src = KL.cdn7domains + xpath.join("/");
              }
              entry.target.src = src;
            }
    
          }
        })
      },
      {
        root: null,
        rootMargin: '110px',
        threshold: 0.1
      }
    );


    if (imgNode)
    {
      for (var id = 0; id < imgNode.length; id++)
      {
        if (imgNode[id].scanned)
          continue;

        io.observe(imgNode[id]);
        /*
        // verificar si es parte de pantalla visible y flag visible
        var top = WA.get(imgNode[id]).top();
        var left = WA.get(imgNode[id]).left();
        var width = WA.get(imgNode[id]).width();
        var height = WA.get(imgNode[id]).height();
        var displaynone = isDisplayNone(imgNode[id]);

        var desplegar = ((maxheight + scrolltop) * 100) / top;


        
        //if (top + height < scrolltop || top > scrolltop + maxheight || left + width < scrollleft || left > scrollleft + maxwidth || displaynone)
        if(top > maxheight && (Math.round(parseInt(desplegar)) < 91 || Math.round(parseInt(desplegar)) > 163) || left + width < scrollleft || left > scrollleft + maxwidth || displaynone){
          continue;
        }

        imgNode[id].scanned = true;

        var haswebp = imgNode[id].dataset.webp;
        var w = imgNode[id].dataset.width;
        var h = imgNode[id].dataset.height;
        //var srcset = imgNode[id].dataset.set;
        //if (srcset)
          //{
          // if (webp&&haswebp) srcset = srcset.replace(".jpg", ".jpg.webp").replace(".png", ".png.webp");
            // imgNode[id].srcset = srcset
         //}
        var src = imgNode[id].dataset.src;
        if (src)
        {
          if (src.substr(0, 4) != "http")
          {
            // Rebuild as cdn7/.../WxH/...webp
            // Only if OUR CDN
            xpath = src.split("/");
            img = xpath[xpath.length-1];
            xpath[xpath.length-1] = w + "x" + h;
            if (webp&&haswebp)
            {
              xpath.push(img + ".webp");
            }
            else
            {
              xpath.push(img + ".jpg");
            }
            src = KL.cdn7domains + xpath.join("/");
          }
          imgNode[id].src = src;
        }
        */
      }
    }
  }

  function isDisplayNone(node)
  {
    if (node.parentNode == null || node.parentNode == window || node.parentNode == window.document)
      return false
    if (node.style.display == "none")
      return true;
    return isDisplayNone(node.parentNode);
  }

  this.missingImage = missingImage;
  function missingImage(node)
  {
    // send error to server
    var r = WA.Managers.ajax.createRequest(KL.imdomains + '/missingimage', 'POST', null, null, false);
    r.addParameter('user', node.dataset.client);
    r.addParameter('device', KL.device );
    r.addParameter('language', KL.language );
    r.send();

    // replace image by user logo
    node.src = KL.cdn7domains + "/kiwilimon/static/icono-usuario.svg";
  }

//  KL.loader.addHookLoad('images', analyze);
//  KL.loader.addHookPostLoad('images', analyze);
}

// Vamos a cargar videokiwi.js a los 10 segundos excepto si hay una solicitud antes

/* PLAYER VIDEO KIWI */
//  WA.Managers.externloader.loadexterncode(KL.cdn7domains + "/js/video/v1/kvideo.js");

KL.Modules.video = new function() {
  var self = this;

  var loaded = false;

  var players = {};
  var currentowner = null;      // id of division owning the video
  var currentplayer = null;     // id of the player
  var currentvideo = null;      // id of the video playing in the player
  var floatingplayer = false;   // true when the video player is floating around
  var floatingvisible = false;  // flag to indicate if the floating can happen. set to false if the user close or swipe the floatingplayer (stop play and hide),
                                // the player comes back to its container and does not move untill this flag is set to true again. always true when playing
  var swipe = 0;                // 1 when to user start to swipe
  var swipestartx = 0;          // touch finger starts here
  var swipestarty = 0;          // touch finger starts here
  var swipeplayerx = 0;         // fixed position left of player when start
  var isAdPlaying = false;      // true when IMA ad playing

  var interval;
  var timeSend = 5;
  var buttonClickTouch = false;
  var buttonClickNode = false;
  var isCloseVideo = false;
  var videoPlay = false;
  var adMode = false;

  this.crear = crear;
  function crear(playerid, force) {
    var node = WA.toDOM('player_' + playerid);

    if (node && !force)
      return node;
    if (!node) { // creates the node
      // crea el node
      node = WA.createDomNode('div', 'player_' + playerid, 'anim');
      WA.Managers.event.on('touchstart', node, touchstart, true);
      WA.Managers.event.on('touchmove', node, touchmove, true);
      WA.Managers.event.on('touchend', node, touchend, true);
    }

    // agrega el node al DOM
    // NODE BC:
//    node.innerHTML = '<video-js id="video_'+playerid+'" data-account="4832064755001" data-player="'+playerid+'" data-embed="default" data-video-id="" class="video-js" controls style="width: 100%; height: 100%;"></video-js>';
    // NODE KIWI:
    var iOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);

    node.innerHTML = '<video '+(iOS ? '': 'controls')+' id="video_'+playerid+'" style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;" \
      class="video-js player-divcontenedor-video" preload="auto" origin="'+KL.device+'"></video>';

    // crea el close (aparece solo en chico)
    nodeclose = WA.createDomNode('div', 'playerclose_' + playerid, 'icon-k7-closevideo');
    nodeclose.style = "display: none;";
    node.appendChild(nodeclose);

    players[playerid] = node;
    return node;
  }

  function clickTouch() {

    if (!buttonClickNode) {
      buttonClickTouch = true;

   //   isCloseVideo = closeVideo();
      console.log("DAG isCloseVideo:", isCloseVideo);
      if (isCloseVideo) {
        if (videoPlay)
          stopVideo();
      } else {
        if (videoPlay) {
          stopVideo();
        } else {
          playVideo();
        }
      }
    }
  }

  function playPause() {
    if (myPlayer.paused()) {
      videoPlay = false;
    } else {
      videoPlay = true;
    }
  }

  function clickNode() {
    if (!buttonClickTouch) {
      buttonClickNode = true;

      isCloseVideo = closeVideo();

      if (isCloseVideo) {
        if (videoPlay)
          stopVideo();
       } else {
        if (videoPlay) {
            stopVideo();
        } else {
          playVideo();
        }
      }
    }
  }

  function stopVideo() {
    try { adMode = myPlayer.ads.isInAdMode(); } catch (err) { adMode = false }

    if (adMode) {
      myPlayer.ima.pauseAd();
      videoPlay = false;
    } else {
      myPlayer.pause();
      videoPlay = false;
    }
  }

  function playVideo() {
    try { adMode = myPlayer.ads.isInAdMode(); } catch (err) { adMode = false }

    if (adMode) {
      if (!videoPlay) {
        myPlayer.ima.resumeAd();
        floatingvisible = true;
        videoPlay = true;
      }
    } else {
      if (!videoPlay) {
        myPlayer.play();
        floatingvisible = true;
        videoPlay = true;
      }
    }
  }

  function closeVideo() {
    if (event.target.id == 'playerclose_' + playerid) { // si da click en cerrar
      setTimeout(cerrar, 0);
      return true;
    }
    return false;
  }

  this.LoadPlayer = LoadPlayer;
  function LoadPlayer() {
    if (loaded) {
      return;
    }
    /* KIWI video */
    WA.Managers.externloader.loadexterncode(KL.cdndomains + "/js/video/v2/kvideo.js?v=" + KL.version);
    loaded = true;
  }


  // v1 es horizontal o unico, v2 cuadrado, v3 vertical
  this.abrir = abrir;
  function abrir(event, containerid, videoid) {

    LoadPlayer();

    console.log("EVENTO:", event, containerid, videoid);
    event.preventDefault();
    event.stopPropagation();

    if (!containerid)
      containerid = this.dataset.containerid;

    containerClose = containerid;

    if (!videoid)
      videoid = this.dataset.videoid;

    playerid = "kiwi";

    if (window.videojs) {
      var newone = false;

      var node = null;
      if (!currentvideo || currentvideo != videoid) { // there MUST be a player live

        if (currentplayer) {
          // unload the old one first (to avoid "watch" the old one for a little time into new place)
          videojs.getPlayer('video_' + currentplayer).dispose();
          currentplayer = null;
          currentvideo = null;
        }

        if (KL.devel)
          console.log("CREAR PLAYER", currentvideo, videoid)

        node = crear(playerid, true);
        WA.toDOM(containerid).appendChild(node);
        newone = true;
      } else {
        if (KL.device === 'pc')
          clickNode();

      }

      if (newone) {
        currentowner = containerid;
        currentplayer = playerid;
        currentvideo = videoid;
        floatingplayer = false;

        myPlayer = videojs('video_' + playerid, {
          /*controlBar: {
            playToogle: {
              replay: false
            }
          },*/
          autoplay: true,
          controls: true
        });

        myPlayer = videojs('video_' + playerid);
        myPlayer.src({type: 'application/x-mpegURL', src: 'https://video.kiwilimon.com:1935/kiwilimon/smil:'+videoid+'.smil/playlist.m3u8'});
        KLVideo.Loader.Link('video_' + playerid);
        node.style = "display: block;";

        playVideo();
        timeSend = 5;
        interval = setInterval(timeStatistic, 5000);
        isCloseVideo = false;

      }
    } else {
      // esperar que las librerias cargan
      setTimeout(function() {KL.Modules.video.abrir(event, containerid, videoid); }, 50 );
    }
    //return false;
    return;
  }

  // Funcion timer para mandar algo cada cierto tiempo
  function timeStatistic() {
    let vecesSend = 0;

//console.log("DAG en intervalo", timeSend, " tiempo actual:", Math.round(myPlayer.currentTime()), "Duraci�n:", myPlayer.duration())
    try {
        // No se tiene que tomar en cuenta el tiempo del Ad
        if (!myPlayer.ads.isInAdMode() && !myPlayer.paused()) {

          if (myPlayer.currentTime() > timeSend) {
            //  console.log("DAG se cumplieron 5 segundos");
            timeSend += 5;
            vecesSend++;
          }

        }

        if (myPlayer.duration() == myPlayer.currentTime()) {
          // console.log("DAG detiene el intervalo")
          clearInterval(interval);
        }
    } catch(error) {
      clearInterval(interval);
    }
  }

  // v1 es horizontal o unico, v2 cuadrado, v3 vertical
  this.cerrar = cerrar;
  function cerrar(swipe) {
    // console.log("DAG entra a cerrar");
    if (!currentplayer)
      return;

    if (swipe !== true)
      ga('send', 'event', 'video', 'vid/playermobile', 'vid/pla/close', null);

    // 1. hide
    playernode = WA.toDOM("player_" + currentplayer);
    hide(playernode, nodeclose);
  }

  function embed(node, nodeclose)
  {
    floatingplayer = false;
    floatingvisible = true;
    //node.style = "position: absolute; left: 0; width: 100%; top: 0; bottom: 0; z-index: 10;";
    node.className = "player-divcontenedor-noscroll";
    nodeclose.style = "display: none;";
  }

  function hide(node, nodeclose)
  {
    floatingplayer = false;
    floatingvisible = false;
    node.className = "player-divcontenedor-noscroll";
    nodeclose.style = "display: none;";
  }

  const nodeCloseStyle = (direction) => {
    return "display: block; position: absolute; width: 30px; height: 30px; left: -30px; " + direction + ": 0px; background-color: black; padding: 6px; border-top-left-radius: 50%; border-bottom-left-radius: 50%; color: white; font-size: 1.5em; box-sizing: border-box;";
  }

  function float(node, pos, nodeclose)
  {
    floatingplayer = true;
    floatingvisible = true;

    if (pos == 'up')
    {
      //node.style = "position: fixed; left: 50%; width: 50%; top: 44px; height: 200px; z-index: 1000;";
      node.className = "player-divcontenedor-scroll-up";
      nodeclose.style = nodeCloseStyle("top");
    }
    else
    {
      //node.style = "position: fixed; left: 50%; width: 50%; bottom: 0px; height: 200px; z-index: 1000;";
      node.className = "player-divcontenedor-scroll-down";
      nodeclose.style = nodeCloseStyle("bottom");
    }
  }

  function touchstart(e) {
    swipe = 1;
    swipestartx = WA.browser.getTouchDocumentX(e);
    swipestarty = WA.browser.getTouchDocumentY(e);
    playernode = WA.toDOM("player_" + currentplayer);
    swipeplayerx = WA.browser.getNodeDocumentLeft(playernode);
  }

  function touchmove(e) {
    if (!swipe)
      return;
    var x = WA.browser.getTouchDocumentX(e);
    var y = WA.browser.getTouchDocumentY(e);
    playernode = WA.toDOM("player_" + currentplayer);
    //playernode.style.left = (x-swipestartx+swipeplayerx)+'px';
  }

  function touchend(e) {
    x = WA.browser.getTouchDocumentX(e);
    y = WA.browser.getTouchDocumentY(e);
    swipe = 0;

    // swipe candidate ?
    if (Math.abs(x-swipestartx) > 50 && Math.abs(y-swipestarty) < 30)
    {
      // PAUSAR EL VIDEO
      stopVideo();
      cerrar(true);
      ga('send', 'event', 'video', 'vid/playermobile', 'vid/pla/swipe', null);
    }
    else // back to its place
    {
      playernode = WA.toDOM("player_" + currentplayer);
      isCloseVideo = closeVideo();
      buttonClickTouch = true;
      setTimeout(clickTouch, 100);
     // playernode.style.left = swipeplayerx + 'px';
    }
  }

  function scroll(event) {
    if (!currentplayer)
      return;
    if (!floatingvisible)
      return;

    containernode = WA.toDOM(currentowner);
    playernode = WA.toDOM("player_" + currentplayer);
    nodeclose = WA.toDOM('playerclose_'+ currentplayer);

    var headerheight = 80;
    var screenheight = WA.browser.getScreenHeight();
    var pagetop = WA.browser.getScrollTop();
    var top = WA.browser.getNodeDocumentTop(containernode);
    var height = WA.browser.getNodeHeight(containernode);

    if (top + height/3 < pagetop + headerheight)
    {
      // pasamos a que sea una miniventana fixed top
      if (!floatingplayer)
      {
        float(playernode, "up", nodeclose);
        ga('send', 'event', 'video', 'vid/playermobile', 'vid/pla/up', null);
      }
    }
    else if (top + 2*height/3 > pagetop + screenheight)
    {
      // pasamos a que sea una miniventana fixed bottom
      if (!floatingplayer)
      {
        float(playernode, "down", nodeclose);
        ga('send', 'event', 'video', 'vid/playermobile', 'vid/pla/down', null);
      }
    }
    else
    {
      if (floatingplayer)
      {
        embed(playernode, nodeclose);
        ga('send', 'event', 'video', 'vid/playermobile', 'vid/pla/embed', null);
      }
    }
  }

  function unload()
  {
    if (!currentplayer)
      return;

    ga('send', 'event', 'video', 'vid/playermobile', 'vid/pla/unload', null);

    videojs.getPlayer('video_' + currentplayer).dispose();
    currentplayer = null;
    currentvideo = null;

    for (var i in players)
    {
      if (players[i].parentNode != document.body)
      {
        players[i].style.display = "none";
        WA.toDOM(document.body).appendChild(players[i]);
      }
    }
  }

  function load()
  {
    var videoNodes = document.getElementsByClassName('video');
    if (videoNodes)
    {
      for (var i = 0; i < videoNodes.length; i++)
      {
        if (KL.devel)
          console.log(videoNodes[i]);
        videoNodes[i].onclick = abrir;
      }
    }
  }

  // scroll para poner video en chiquito
  WA.Managers.event.on('scroll', window, scroll, true);
  KL.loader.addHookLoad('video', load);
  KL.loader.addHookPostLoad('video', load);
  KL.loader.addHookUnload('video', unload);
}

// Based on the code structure, inject LDJson of page objects and breadcrumbs

KL.Modules.ldjson = new function()
{
  var self = this;
  var scripts = {};

  this.analyze = analyze;
  function analyze()
  {
    if (KL.currentcode.recipefamilydata)
      return buildrecipefamily(KL.currentcode);
    if (KL.currentcode.recipeclassificationdata)
      return buildrecipeclassification(KL.currentcode);
    if (KL.currentcode.recipe)
      return buildrecipe(KL.currentcode);
      if (KL.currentcode.tip)
      return buildtip(KL.currentcode);
  }

  function setbc(data)
  {
    if (!scripts.bc)
    {
      scripts.bc = document.createElement('script');
      scripts.bc.setAttribute('type', 'application/ld+json');
      scripts.bc.id = "breadcrumbs";
      document.head.appendChild(scripts.bc);
    }
    scripts.bc.textContent = data;
  }

  function setmain(data)
  {
    if (!scripts.main)
    {
      scripts.main = document.createElement('script');
      scripts.main.setAttribute('type', 'application/ld+json');
      scripts.main.id = "data";
      document.head.appendChild(scripts.main);
    }
    scripts.main.textContent = data;
  }

  function setmainextra(data)
  {
    if (!scripts.mainextra)
    {
      scripts.mainextra = document.createElement('script');
      scripts.mainextra.setAttribute('type', 'application/ld+json');
      scripts.mainextra.id = "dataextra";
      document.head.appendChild(scripts.mainextra);
    }
    scripts.mainextra.textContent = data;
  }

  function buildbc(data)
  {
    if (!data)
      return "";
    jsondata = {"@context": "https://schema.org","@type": "BreadcrumbList","itemListElement": []};
    for (var i = 0, l = data.length; i < l; i++)
    {
      element = {"@type": "ListItem", "position": i+1, "name": data[i].n, "item": KL.mydomains + data[i].p};
      jsondata.itemListElement.push(element);
    }
    return JSON.stringify(jsondata);
  }

  function builditemlist(data)
  {
    if (!data)
      return "";
    jsondata = {"@context": "https://schema.org","@type": "ItemList","itemListElement": []};
    for (var i = 0, l = data.length; i < l; i++)
    {
      var path = data[i].pa;
      if (!path) path = data[i].path;
      if (!path) continue;
      element = {"@type": "ListItem", "position": i+1, "url": KL.mydomains + path };
      jsondata.itemListElement.push(element);
    }
    return JSON.stringify(jsondata);
  }

  function buildrecipefamily(data)
  {
    // 1. breadcrumbs
    setbc(buildbc(data.recipefamilydata.bc));

    // 2. main data
    setmain(builditemlist(data.top10.payload));
  }

  function buildrecipeclassification(data)
  {
    // 1. breadcrumbs
    setbc(buildbc(data.recipeclassificationdata.bc));
    // 2. main data
    setmain(builditemlist(data.top10.payload));
  }

  function buildrecipe(data)
  {
    // 1. breadcrumbs
    setbc(buildbc(data.recipe.bc));
    // 2. recipe news
    setmainextra(buildnewsrecipe(data));
    // 3. main data
    jsondata = {"@context": "https://schema.org","@type": "Recipe",
      "author": {
        "@type": "Person",
        "name": data.recipe.clientdata.firstname + " " + data.recipe.clientdata.lastname,
        "url": KL.webdomains + data.recipe.clientdata.path
      },
      "name": data.recipe.name,
      "cookTime": "PT" + data.recipe.cooktime + "M",
      "prepTime": "PT" + data.recipe.totaltime + "M",
      "datePublished": data.recipe.published,
      "keywords": data.recipe.name,
      "recipeYield": data.recipe.portions,
      "description": data.recipe.description,
      "recipeCategory": data.recipe.classificationname,
      "recipeCuisine": data.recipe.cuisinename,
      "recipeIngredient": [],
      "recipeInstructions": [],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": data.recipe.rating,
        "ratingCount": data.recipe.view
      }
    };

    if (data.recipe.nutrients && data.recipe.nutrients[0]) {
      jsondata.nutrition = {
        "@type": "NutritionInformation",
        "calories": data.recipe.nutrients[0].quantity100 + " " + data.recipe.nutrients[0].metric
      }
    }

    if (data.recipe.video) {
      jsondata.video = {
        "@type": "VideoObject",
        "name": data.recipe.name,
        "description": data.recipe.description,
        "thumbnailUrl": [
          KL.cdndomains + "/recetaimagen/" + data.recipe.key + "/" + data.recipe.video.thumb
         ],
        "contentUrl": KL.videodomains + "/" + data.recipe.video.videoid + "/" + data.recipe.video.videoid + "-300.mp4",
        "embedUrl": KL.graphdomains + "/player?video=" + data.recipe.video.videoid,
        "uploadDate": data.recipe.published,
        "duration": data.recipe.video.duration==0?"PT120S":"PT" + data.recipe.video.duration + "S",
        "interactionStatistic": {
          "@type": "InteractionCounter",
          "interactionType": { "@type": "http://schema.org/WatchAction" },
          "userInteractionCount": data.recipe.view
        }
      }
    }

    for (var i = 0, l = data.recipe.ingredients.length; i < l; i++)
    {
      jsondata.recipeIngredient.push(data.recipe.ingredients[i].text);
    }

    for (var i = 0, l = data.recipe.steps.length; i < l; i++)
    {
      element = {
        "@type": "HowToStep",
        // Falta campo name, url y se debe especificar image o video (opcionales todos)
        "text": data.recipe.steps[i].text
      };
      jsondata.recipeInstructions.push(element);
    }

    if (data.recipe.images && data.recipe.images.length > 0)
    {
      jsondata.image = [];
      for (var i = 0, l = data.recipe.images.length; i < l; i++)
      {
        jsondata.image.push(KL.cdndomains + "/recetaimagen/" + data.recipe.key + "/th5-640x640-" + data.recipe.images[i].image);
      }
    } else {
      jsondata.image = [
        KL.cdndomains + "/kiwi5/static/k5-o-640x640.png"
      ];
    }

    setmain(JSON.stringify(jsondata));
  }

  /* Enlaza JSON con lsjson */
  function buildnewsrecipe(data) {
    // 1. main data
    jsondata = {"@context": "https://schema.org","@type": "NewsArticle",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": document.URL
      },
      "headline": data.recipe.name,
      "datePublished": data.recipe.published,
      "dateModified": data.recipe.published,
      "author": {
        "@type": "Person",
        "name": data.recipe.clientdata.firstname + " " + data.recipe.clientdata.lastname,
        "url": KL.webdomains + data.recipe.clientdata.path
      },
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo,  
          "width": "384",
          "height": "80"
        }
      },
      "articleSection": "Noticias",
      "description": data.recipe.description,
      "keywords": data.recipe.name,
    }

    if (data.recipe.images && data.recipe.images.length > 0)
    {
      jsondata.image = [];
      c = 0;
      for (var i = 0, l = data.recipe.images.length; i < l; i++)
      {
        jsondata.image.push(KL.cdndomains + "/recetaimagen/" + data.recipe.key + "/th5-640x640-" + data.recipe.images[i].image);
        c++;
        if (c >= 3) break;
      }
    } else {
      jsondata.image = [
        KL.cdndomains + "/kiwi5/static/k5-o-640x640.png"
      ];
    }

    return JSON.stringify(jsondata);
  }

  function buildtip(data)
  {
    // 1. breadcrumbs
    setbc(buildbc(data.tip.bc));
    // 2. news tip
    setmainextra(buildnewstip(data));
    // 2. main data
    jsondata = {"@context": "https://schema.org","@type": "Article",
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo,  
          "width": "384",
          "height": "80"
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": KL.cookiedomain
      },
       "author": {
        "@type": "Person",
        "name": data.tip.clientdata.firstname + " " + data.tip.clientdata.lastname,
        "url": KL.webdomains + data.tip.clientdata.path
      },
      "articleSection": "Noticias",
      "name": data.tip.name,
      "headline": data.tip.name,
      "description": data.tip.description,
      "datePublished": data.tip.published,
      "dateModified": data.tip.published,
      "mainEntityOfPage": KL.mydomains,
    };

    if (data.tip.video) {
      jsondata.video = {
        "@type": "VideoObject",
        "name": data.tip.name,
        "description": data.tip.description,
        "thumbnailUrl": [
          KL.cdndomains + "/ss_secreto/" + data.tip.key + "/" + data.tip.video.thumb
         ],
        "contentUrl": KL.videodomains + "/" + data.tip.video.videoid + "/" + data.tip.video.videoid + "-300.mp4",
        "embedUrl": KL.graphdomains + "/player?video=" + data.tip.video.videoid,
        "uploadDate": data.tip.published,
        "duration": data.tip.video.duration==0?"PT120S":"PT" + data.tip.video.duration + "S",
        "interactionStatistic": {
          "@type": "InteractionCounter",
          "interactionType": { "@type": "http://schema.org/WatchAction" },
          "userInteractionCount": data.tip.view
        }
      }
    }

    if (data.tip.image)
    {
      jsondata.image = [
        KL.cdndomains + "/ss_secreto/" + data.tip.key + "/th5-640x640-" + data.tip.image
      ];

      if (data.tip.steps){
        jsondata.articleBody = [];

        for (var i = 0, l = data.tip.steps.length; i < l; i++)
        {
          jsondata.image.push(KL.cdndomains + "/ss_secreto/" + data.tip.key + "/th5-640x640-" + data.tip.steps[i].imagen);

          jsondata.articleBody.push("Paso " + data.tip.steps[i].orden + ": " + data.tip.steps[i].descripcion);
        }
      }
    } else {
      jsondata.image = [
        KL.cdndomains + "/kiwi5/static/k5-o-640x640.png"
      ];
    }

    setmain(JSON.stringify(jsondata));
  }

  function buildnewstip(data)
  {
    // 2. main data
    jsondata = {"@context": "https://schema.org","@type": "NewsArticle",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": document.URL
      },
      "headline": "¿Tienes una bolsita de té? Úsala para cultivar manzanilla en tu huerto casero",
      "datePublished": data.tip.published,
      "dateModified": data.tip.published,
      "author": {
        "@type": "Person",
        "name": data.tip.clientdata.firstname + " " + data.tip.clientdata.lastname,
        "url": KL.webdomains + data.tip.clientdata.path
      },
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo,  
          "width": KL.logowidth,
          "height": KL.logoheight
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": KL.cookiedomain
      },
      "articleSection": "Noticias"
    }

    if (data.tip.image)
    {
      jsondata.image = [
        KL.cdndomains + "/ss_secreto/" + data.tip.key + "/th5-640x640-" + data.tip.image
      ];

      if (data.tip.steps){
        c = 0;
        for (var i = 0, l = data.tip.steps.length; i < l; i++)
        {
          jsondata.image.push(KL.cdndomains + "/ss_secreto/" + data.tip.key + "/th5-640x640-" + data.tip.steps[i].imagen);
          c++;
          if (c >= 2) break;
        }
      }
    } else {
      jsondata.image = [
        KL.cdndomains + "/kiwi5/static/k5-o-640x640.png"
      ];
    }
    return JSON.stringify(jsondata);
  }

  function buildproduct()
  {
    // recetarios son productos tambien
    // 1. breadcrumbs
    setbc(buildbc(data.tip.bc));
    // 2. main data
    jsondata = {"@context": "https://schema.org","@type": "Product",
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": KL.cookiedomain
      },
      "author": {
        "@type": "Person",
        "name": ""//data.tip.clientdata.firstname + " " + data.tip.clientdata.lastname
      }
    };

    return JSON.stringify(jsondata);
  }

  function buildbook()
  {
    // recetarios son libros tambien
    // 1. breadcrumbs
    setbc(buildbc(data.tip.bc));
    // 2. main data
    jsondata = {"@context": "https://schema.org","@type": "Book",
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": KL.cookiedomain
      },
      "author": {
        "@type": "Person",
        "name": ""//data.tip.clientdata.firstname + " " + data.tip.clientdata.lastname
      },
      "bookFormatiType": "AudioBook, EBook, GraphicNovel, Hardcover, Paperback", // ejemplos de tipos formato
      "numberOfPages": "100" // Ejemplo
    };

    return JSON.stringify(jsondata);
  }

  function buildapp()
  {
    // 1. breadcrumbs
    setbc(buildbc(data.tip.bc));
    // 2. main data
    jsondata = {"@context": "https://schema.org","@type": "SoftwareApplication",
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": KL.cookiedomain
      },
      "author": {
        "@type": "Person",
        "name": ""//data.tip.clientdata.firstname + " " + data.tip.clientdata.lastname
       },
       "operatingSystem": "Android 1.6",
       "license": "url" // Si es que hay una url de licencia
    };
    return JSON.stringify(jsondata);

    /*
    {
       "@context": "https://schema.org",
       "@type": "SoftwareApplication",
       "name": "Angry Birds",
       "operatingSystem": "ANDROID",
       "applicationCategory": "GameApplication",
       "aggregateRating": {
         "@type": "AggregateRating",
         "ratingValue": "4.6",
         "ratingCount": "8864"
       },
       "offers": {
         "@type": "Offer",
         "price": "1.00",
         "priceCurrency": "USD"
       }
     }
     */
  }

  function getlistproduct()
  {
    // 1. breadcrumbs
    setbc(buildbc(data.tip.bc));
    // 2. main data
    jsondata = {"@context": "https://schema.org","@type": "Collection",
      "publisher": {
        "@type": "Organization",
        "name": KL.officialname,
        "logo": {
          "@type": "ImageObject",
          "url": KL.urllogo
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": KL.cookiedomain
      },
      "author": {
        "@type": "Person",
        "name": ""//data.tip.clientdata.firstname + " " + data.tip.clientdata.lastname
      },
      "isFamilyFriendly": "true"
    };
    return JSON.stringify(jsondata);
/*
{
  "@context": "https://schema.org/",
  "@type": "Product",
  "name": "Executive Anvil",
  "image": [
    "https://example.com/photos/1x1/photo.jpg",
    "https://example.com/photos/4x3/photo.jpg",
    "https://example.com/photos/16x9/photo.jpg"
   ],
  "description": "Sleeker than ACME's Classic Anvil, the Executive Anvil is perfect for the business traveler looking for something to drop from a height.",
  "sku": "0446310786",
  "mpn": "925872",
  "brand": {
    "@type": "Brand",
    "name": "ACME"
  },
  "review": {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": "4",
      "bestRating": "5"
    },
    "author": {
      "@type": "Person",
      "name": "Fred Benson"
    }
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.4",
    "reviewCount": "89"
  },
  "offers": {
    "@type": "AggregateOffer",
    "offerCount": "5",
    "lowPrice": "119.99",
    "highPrice": "199.99",
    "priceCurrency": "USD"
  }
}
*/

  }

  function clean()
  {
    // clean all scripts
    for (var i in scripts)
    {
      document.head.removeChild(scripts[i]);
    }
    scripts = {};
  }

  KL.loader.addHookLoad('ldjson', analyze);
  KL.loader.addHookUnload('ldjson', clean);
}

/* stats, register events into analytics, FB, kiwi stat */

KL.Modules.stat = new function()
{
  var self = this;

  // Register normal page
  this.registerPage = registerPage;
  function registerPage()
  {
    if (window.gtag != undefined) {
      gtag('event', 'page_view', { page_location: location.href, page_path: location.pathname + location.search } );
    } else {
      ga('send', 'pageview', location.pathname + location.search);
    }
  }

  // Simple event
  this.registerEvent = registerEvent;
  function registerEvent(categoria, etiqueta, amount)
  {
    if (!amount)
      amount = null;
    if (window.gtag != undefined) {
      gtag('event', categoria, categoria+"/"+KL.device+"/"+KL.language, etiqueta, amount);
    } else {
      ga('send', 'event', categoria, categoria+"/"+KL.device+"/"+KL.language, etiqueta, amount);
    }
  }

  // ecommerce event
  this.registerSubscription = registerSubscription;
  function registerSubscription(orderid, productid, amount)
  {
    if (window.gtag != undefined) {
      gtag('event', 'sale');
    } else {
      registerEvent('sale', 'sale/subscription/'+productid, amount);
      ga('ecommerce:addTransaction', {'id': orderid, 'affiliation': 'InSite', 'revenue': amount, 'shipping': '0', 'tax': '0', 'currency': 'MXN' });
      ga('ecommerce:addItem', {'id': orderid, 'name': 'Subscription PRO', 'sku': productid, 'category': 'subscription', 'price': amount, 'quantity': 1, 'currency': 'MXN' });
      ga('ecommerce:send');
    }
  }
}

KL.Modules.ads = new function()
{
  var self = this;
  var analyzeclass = "buildad";
  var globalcounter = 1;
  var timerall = null;
  var apstagSet = false;

  this.setApstag = setApstag;
  function setApstag() {
    if (apstagSet)
      return;

    apstag.init({
      pubID: '972b50b3-6527-47e8-baae-88f9430414db',
      adServer: 'googletag'
   });
   apstagSet = true;
  }

  function getsize(id)
  {
    switch(id)
    {
      case '1x1': return [[1,1]];
      case 'billboard': return [[1200,250],[970,250],[970,90],[728,90]];
      case 'cinta': return [[957,56]];
      case '300x250':
        if (KL.device == "pc")
          return [[300,250]];
        else
          return [[300,250],[336,280]];
      case 'halfpage': return [[300,600],[300,250],[160,600],[120,600]];
      case 'fcarpet': return [[300,600]];
      case 'middle': return [[728,90]];
      case 'footer': return [[728,90],[970,90]];
      case 'mbillboard': return [[320,50]];
      case '320x50': return [[320,50]];
      case 'mfooter': return [[320,100],[320,50],[300,250]];
      case 'quiz': return [[320,50]]; // iguales que mbillboard mobile
      case 'sticky_web':
        if (KL.device == "pc")
          return [[728,90]];
        else
          return [[300,100],[320,50],[320,100]];
    }
    return [];
  }

  this.buildAd = buildAd;
  function buildAd(N)
  {
    if (N.built)
      return;
    N.built = true;

    /* original
    if (KL.Modules.client && KL.Modules.client.clientpro)
      return;
    */

    if (KL.Modules.client && KL.Modules.client.clientpro){
      if(KL.device === 'pc'){
        WA.toDOM('footer-adbannersticky').style.display = 'none';
        WA.toDOM('footer-adbanner').style.display = 'none';
        WA.toDOM('adbottom').style.display = 'none';
        WA.toDOM('footer-div-crosslink').style.width = '100%';
      }

      if(KL.device === 'mobile'){
        WA.toDOM('footer-adbannersticky').style.display = 'none';
        WA.toDOM('footer-adbanner').style.display = 'none';
      }

      return;
    }

    // special rules to apply.
    if (KL.pagedata.page.load)
      return;

    var oop = N.dataset.oop;
    var id = N.dataset.id;

    // filtrar sticky ad, no poner en US
    if (id == "sticky_web" && KL.Modules.client && KL.Modules.client.getCountry() == "US")
      return;

    // si la página está en una receta sin video no presenta sticky
    if (WA.toDOM('ad-rec-sticky-web') && id == "sticky_web"){
      removeStickyStyle();
      if (id == "sticky_web")
        return;
    }
    else{
      llamaSticky();
    }

    var adunit = KL.pagedata.page.adprefix + id;
    var nodeid = 'div'+globalcounter+'_' + adunit;
    globalcounter++;
    N.id = nodeid;

    var size = getsize(id)
    var position = N.dataset.position;
    var placementid = N.dataset.placementid;
    var gaplacementid = N.dataset.gaplacementid;
    var ixplacementid = N.dataset.ixplacementid;
    var formatid = N.dataset.ixplacementid;

    // 1. TARGETING
    if (position)
      var position = '.setTargeting("position", "'+position+'")';
    else
      var position = (KL.device=="mobile"&&id=='300x250')?'.setTargeting("position", "mobile")':'';

    var strkeywords = KL.pagedata.page.keywords?'.setTargeting("keywords", '+JSON.stringify(KL.pagedata.page.keywords)+')':'';

    if (KL.pagedata.page.type)
      strkeywords += '.setTargeting("type", "'+KL.pagedata.page.type+'")';

    if (id == 'oop')
    {
      var codegoogle = 'googletag.cmd.push(function() { var slot = googletag.defineOutOfPageSlot("/3879499/'+adunit+'","'+nodeid+'")'+strkeywords+'.addService(googletag.pubads()); googletag.pubads().refresh([slot]); }); '
       + 'googletag.cmd.push(function() { googletag.display("'+nodeid+'"); });';

      if (KL.devel)
      {
         console.log('** Evaluando google code para ' + nodeid);
         console.log(codegoogle);
         console.log(N);
      }
      setTimeout(function() { tryeval(codegoogle); }, 1);
      return;
    }
    if (id == '1x1')
    {
      var codegoogle = 'googletag.cmd.push(function() { var slot = googletag.defineSlot("/3879499/'+adunit+'",'+JSON.stringify(size)+',"'+nodeid+'")'+strkeywords+'.addService(googletag.pubads()); googletag.pubads().refresh([slot]);  });';
      // googletag.display("'+nodeid+'");
      // console.log(codegoogle);
      setTimeout(function() { tryeval(codegoogle); }, 1);
      return;
    }

    // tenemos que pasar los IDs naturales parte del string o da un error porque el payload[i] ya no es accesible
    var codegoogle = '';
    bidders = buildbidders(id, size);
    jsonbidders = JSON.stringify(bidders);
    // prebid
    codegoogle += 'googletag.cmd.push(function() { var slot = googletag.defineSlot("/3879499/'+adunit+'",'+JSON.stringify(size)+',"'+nodeid+'")'+position+strkeywords+'.setCollapseEmptyDiv(true).addService(googletag.pubads());';
    codegoogle += '  googletag.display("'+nodeid+'"); ';
    codegoogle += 'KL.Modules.ads.setApstag();';
    codegoogle += '  apstag.fetchBids({slots: [{slotID: "'+nodeid+'", slotName: "/3879499/'+adunit+'", sizes: '+JSON.stringify(size)+'}]}); ';
    codegoogle += 'apstag.setDisplayBids();';
    codegoogle += 'var adUnits = [{ code: "'+nodeid+'", mediaTypes: { banner: { sizes: '+JSON.stringify(size)+'}}, bids: '+jsonbidders+'}]; ';
    codegoogle += 'pbjs.que.push(function() { pbjs.addAdUnits(adUnits); pbjs.requestBids({ timeout: PREBID_TIMEOUT, adUnitCodes: ["'+nodeid+'"], bidsBackHandler: function() { pbjs.setTargetingForGPTAsync(["'+nodeid+'"]); googletag.pubads().refresh([slot]); } }); });';
    codegoogle += '});';

    if (KL.devel)
    {
      console.log('** Evaluando google code para ' + nodeid);
      console.log(codegoogle);
      console.log(N);
    }

    setTimeout(function() { tryeval(codegoogle); }, 1);
  }

  function buildbidders(id, size)
  {
    code = [];
    for (i in KL.Modules.ads.bidders)
    {
      var subcode = KL.Modules.ads.bidders[i].getCode(id, size);
      if (!subcode)
        continue;
      if (Array.isArray(subcode))
      {
        for (var j = 0, l = subcode.length; j<l; j++)
          code.push(subcode[j]);
      }
      else
      {
        code.push(subcode);
      }
    }
    return code
  }

  function tryeval(codegoogle)
  {
    // TODO(phil) try catch ?
    eval(codegoogle);
  }

  this.refresh = refresh;
  function refresh()
  {
    googletag.pubads().refresh();
  }

  /* ================================================================================ */
  /* Analyze the page to show visible ads, or all (=true)
  /* ================================================================================ */
  this.analyze = analyze;
  function analyze(all)
  {
    if(KL.Modules.client.clientready)
    {
      timerall = null;
      var maxheight = WA.browser.getWindowHeight();
      var maxwidth  = WA.browser.getWindowWidth();
      var scrolltop = WA.browser.getScrollTop();
      var scrollleft = WA.browser.getScrollLeft();

      // Obtenemos, los nodos ads que cumplen
      var adNodes = document.getElementsByClassName(analyzeclass);

      if (adNodes)
      {
        for (var id = 0; id < adNodes.length; id++)
        {
          if (adNodes[id].scanned && !adNodes[id].refresh) // must be in refresh mode to be scanned and updated
            continue;

          if (!all) {
            // verificar si es parte de pantalla visible y flag visible
            var top = WA.get(adNodes[id]).top();
            var left = WA.get(adNodes[id]).left();
            var width = WA.get(adNodes[id]).width();
            var height = WA.get(adNodes[id]).height();
            var displaynone = isDisplayNone(adNodes[id]);

            if (top + height < scrolltop || top > scrolltop + maxheight || left + width < scrollleft || left > scrollleft + maxwidth || displaynone)
              continue;
          }
          // build only the ads visible. Others will be refreshed on +5 sec
          adNodes[id].scanned = true;
          adNodes[id].refresh = false;
          buildAd(adNodes[id]);
        }
      }
      if (!all) {
        // wait 5 seconds to build all ads
        timerall = setTimeout( function() { analyze(true); }, KL.loader.waitload );
      }
    }
  }

  function isDisplayNone(node)
  {
    if (node.parentNode == null || node.parentNode == window || node.parentNode == window.document)
      return false
    if (node.style.display == "none")
      return true;
    return isDisplayNone(node.parentNode);
  }

  this.onload = onload;
  function onload()
  {
    // Obtenemos, los nodos ads que cumplen
    var adNodes = document.getElementsByClassName(analyzeclass);
    if (adNodes)
    {
      for (var id = 0; id < adNodes.length; id++)
      {
        adNodes[id].scanned = true;
        adNodes[id].refresh = true;
      }
    }

    // KL.Modules.ads.seedtag.onload();
    if (!KL.Modules.client || !KL.Modules.client.clientpro){
      KL.Modules.ads.truvid.onload();
      KL.Modules.ads.insurads.onload();
      // KL.Modules.ads.lunamedia.onload();
      KL.Modules.ads.amazon.onload();
      KL.Modules.ads.walmart.onload();
    }
  }

  function onunload()
  {
    if (timerall != null)
      clearTimeout(timerall);
    timerall = null;

    // KL.Modules.ads.seedtag.onunload();
    if (!KL.Modules.client || !KL.Modules.client.clientpro){
      KL.Modules.ads.truvid.onload();
      KL.Modules.ads.insurads.onload();
      // KL.Modules.ads.lunamedia.onload();
      //KL.Modules.ads.walmart.onunload();
    }
  }

  // Funcion para esconder el footer-adbannersticky
  this.removeStickyStyle = removeStickyStyle;
  function removeStickyStyle()
  {
    // console.log('entra para remover estilo sticky al banner de footer');

    // var rutapagina = document.location.pathname;
    // console.log('ruta ok: ' + rutapagina);

    if (WA.toDOM('footer-adbannersticky'))
    {
      // console.log('sigue aqui para remover sticky');
      WA.toDOM('footer-adbannersticky').style.display = 'none';
      WA.toDOM('footer-remueve-sticky').style.display = 'none';
    }
  }

  // Funcion para reiniciar el display del footer-adbannersticky y que este banner vuelva a mostrar
  function sticky()
  {
    if (WA.toDOM('footer-adbannersticky'))
    {
      // console.log('reinicio el valor del sticky');
      if (KL.Modules.client && KL.Modules.client.clientpro){
        // console.log('entra a if client-clientpro en sticky');
        WA.toDOM('footer-adbannersticky').style.display = 'none';
        WA.toDOM('footer-remueve-sticky').style.display = 'none';
      }else{
        WA.toDOM('footer-adbannersticky').style.display = 'flex';
        WA.toDOM('footer-remueve-sticky').style.display = 'block';
      }
    }
  }


  function calculaPosicionSticky(){
    if (WA.toDOM('footer-adbannersticky')){

      pagina = WA.toDOM('body');
      footerbanner = WA.toDOM('footer-adbanner');
      sticky = WA.toDOM('footer-adbannersticky');
      footer = WA.toDOM('footer-divfooter');

      // altura visible en pantalla
      areavisiblecliente = document.documentElement.clientHeight;
      // console.log('area visible cliente: ' + areavisiblecliente);

      alturafooterbanner = footerbanner.scrollHeight;
      // console.log('altura footer banner: ' + alturafooterbanner);

      alturasticky = sticky.scrollHeight;
      // console.log('altura sticky: ' + alturasticky);

      alturafooter = footer.scrollHeight;
      // console.log('altura footer: ' + alturafooter);

      totaldivs =  alturafooterbanner + alturasticky + alturafooter;

      if(KL.device == 'pc')
        totaldivs = totaldivs + 40;
      else if(KL.device == 'mobile')
        totaldivs = totaldivs + 30;

      // console.log('sumatoria divs: ' + totaldivs);

      // area de interaccion en pantalla respecto al scroll
      areainteraccion = areavisiblecliente + totaldivs;
      // console.log('area interaccion: ' + areainteraccion);

      // Calcula posicion de div footer respecto al scrolltop
      posicionfooterbanner = footer.offsetTop;
      // console.log('posicion de footer banner: ' + posicionfooterbanner);

      // posicion en la que se esconder� sticky
      escondesticky = posicionfooterbanner - areainteraccion;
      // console.log('posicion en la que se esconder� sticky: ' + escondesticky);

      // posicion de scroll
      posicionscroll = window.scrollY;
      // console.log('posicion de scroll: ' + posicionscroll);

      posisionescondesticky = escondesticky + alturafooter;
      // console.log('posicion real donde se va a esconder sticky: ' + posisionescondesticky);

      if( posicionscroll > posisionescondesticky){
        // console.log('a partir de aqui se esconde sticky');
        sticky.style.display = 'none';
        WA.toDOM('footer-remueve-sticky').style.display = 'none';
      }
    }
  }

  function llamaSticky(){
    if (WA.toDOM('footer-adbannersticky'))
    {
      WA.toDOM('footer-adbannersticky').style.display = 'flex';
      WA.toDOM('footer-remueve-sticky').style.display = 'block';

    }
  }

  window.addEventListener('scroll', calculaPosicionSticky);


  // onload: put all the ads on refresh state
  // KL.loader.addHookLoad('ads', onload);
  KL.loader.addHookPostLoad('ads', sticky);
  KL.loader.addHookUnload('ads', onunload);

}

/*
KL.Modules.ads.seedtag = new function()
{
  var self = this;
  this.node = null;

  this.onload = onload;
  function onload()
  {
    // only tips and recipes
    if ((!KL.currentcode.tip) && (!KL.currentcode.recipe))
      return;

    // si encuentra el div ad-seedtag entonces ejecuta el seedtag
    if ( WA.toDOM('ad-seedtag') )
    {
      window._seedtagq = window._seedtagq || [];
      window._seedtagq.push(['_setId', '2725-3907-01']);
      window._seedtagq.push(['iframe_mode']);
      self.node = WA.Managers.externloader.loadexterncode("//config.seedtag.com/loader.js?v=" + Math.random());
      //  console.log("seedtag loaded");
    }
  }

  this.onunload = onunload;
  function onunload()
  {
    if (self.node) {
      self.node.parentNode.removeChild(self.node);
      self.node = null;
//      console.log("seedtag unload");
    }
  }
}
*/

KL.Modules.ads.truvid = new function()
{
  var self = this;
  this.node = null;

  this.onload = onload;
  function onload()
  {
    // only receta en prueba
    //console.log(document.location.pathname);
    /*
    if (document.location.pathname != '/receta/platos-fuertes/mexicanos/jalapenos-rellenos-de-frijol-con-chorizo')
      return;
    */

    /* solo recetas con video */
    if (!WA.toDOM('ad-rec-truvid'))
      return;

    // self.node = WA.Managers.externloader.loadexterncode("//cnt.trvdp.com/js/1252/5477.js?v=" + Math.random());
    // console.log("truvid loaded");
  }

  this.onunload = onunload;
  function onunload()
  {
    if (self.node) {
      self.node.parentNode.removeChild(self.node);
      self.node = null;
      // console.log("truvid unload");
    }
  }
}


KL.Modules.ads.insurads = new function()
{
  var self = this;
  this.node = null;

  this.onload = onload;
  function onload()
  {
    self.node = WA.Managers.externloader.loadexterncode("//cdn.insurads.com/bootstrap/CKVE5KE3.js?v=" + Math.random());
    // console.log("insurads loaded");
  }

  this.onunload = onunload;
  function onunload()
  {
    if (self.node) {
      self.node.parentNode.removeChild(self.node);
      self.node = null;
      // console.log("insurads unload");
    }
  }
}



KL.Modules.ads.bidders = {};

KL.Modules.ads.bidders.gourmetads = new function()
{
  var self = this;

  function getPlacement(id)
  {
    switch(id)
    {
      case 'billboard': return '21719610';
      case '300x250':
         if (KL.device == 'mobile')
           return '21719628';
         return '21719802';
      case 'halfpage': return '21719611';
      case 'middle': return '21719616';
      case 'footer': return '21719607';

      case '320x50': return '21719639';

      case 'mbillboard': return '21719639';
      case 'fcarpet': return '21719639';
      case 'mfooter': return '21719790';
      case 'quiz': return '21719639'; // igual que mbillboard
      case 'sticky_web':
         if (KL.device == 'mobile')
           return '21719790';
         return '21719607';
    }
    return null;
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;
    return {bidder:"gourmetads",params:{placementId:placement, usePaymentRule:true}};
  }
}

KL.Modules.ads.bidders.ix = new function()
{
  var self = this;

  function getPlacement(id)
  {
    switch(id)
    {
      case 'oop': return '355871';
//      case '1x1': return '355871';

      case 'billboard': return '358387';
      case '300x250':
         if (KL.device == 'mobile')
           return '358394';
         return '358388';
      case 'halfpage': return '358390';
      case 'middle': return '358391';
      case 'footer': return '358391';

      case '320x50': return '358393';

      case 'mbillboard': return '358393';
      case 'fcarpet': return '358393';
      case 'mfooter': return '358395';
      case 'quiz': return '358393'; // igual que mbillboard
      case 'sticky_web':
         if (KL.device == 'mobile')
           return '358395';
         return '358391';
    }
    return null;
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    data = [];
    for (var j = 0; j < size.length; j++)
    {
      data.push({ bidder: "ix", params: { siteId: placement, size: size[j] } });
    }
    return data;
  }
}


KL.Modules.ads.bidders.richaudience = new function()
{
  var self = this;

  function getPlacement(id)
  {
    switch(id)
    {
      case 'billboard': return '1VlIIAsEqW';
      case '300x250':
         if (KL.device == 'mobile')
           return 'OSzTr4APXc';
         return 'Al6AgBcRIj';
      case 'halfpage': return 'ofN46OLDGE';
      //case 'middle': return 'Al6AgBcRIj';
      case 'middle': return 'iQesaEsuiz';
      case 'footer': return 'iQesaEsuiz';

      case '320x50': return '0Pt5mL4bJw';

      case 'mbillboard': return '0Pt5mL4bJw';
      case 'mfooter': return 'OSzTr4APXc';
      case 'quiz': return '0Pt5mL4bJw'; // igual que mbillboard
      case 'sticky_web':
         if (KL.device == 'mobile')
           return '0Pt5mL4bJw';
         return 'iQesaEsuiz';
    }
    return null;
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"richaudience",params:{pid:placement, supplyType: 'site'}};
  }
}


KL.Modules.ads.bidders.appnexus = new function()
{
  var self = this;

  function getPlacement(id)
  {
    switch(id)
    {
      case 'oop': return '13085447';
//      case '1x1': return '13085447';

      case 'billboard': return '13078565';
      case '300x250':
         if (KL.device == 'mobile')
           return '13081605';
         return '13081595';
      case 'halfpage': return '13081600';
      case 'middle': return '13081601';
      case 'footer': return '13081603';

      case '320x50': return '13081604';

      case 'mbillboard': return '13081604';
      case 'fcarpet': return '13081604';
      case 'mfooter': return '13081606';
      case 'quiz': return '13081604'; // igual que mbillboard<
      case 'sticky_web':
         if (KL.device == 'mobile')
           return '13081606';
         return '13081603';
    }
    return null;
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"appnexus",params:{placementId: placement}};
  }

}

/*
KL.Modules.ads.bidders.brightcom = new function()
{
  var self = this;

  function getPlacement(id)
  {
    if (id == '1x1')
      return null;
    return '20284';
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"brightcom",params:{publisherId: placement}};
  }

}
*/


/*
KL.Modules.ads.bidders.rubicon = new function()
{
  var self = this;

  function getPlacement(id)
  {
    return {
      accountid: 21224,
      siteid: 272988,
      zoneid: 2206276
    };
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"rubicon",params:{accountId: placement.accountid, siteId: placement.siteid, zoneId: placement.zoneid }};
  }

}
*/

KL.Modules.ads.bidders.rubicon = new function()
{
  var self = this;

  function getPlacement(id)
  {
    switch(id)
    {
      case 'oop':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

//      case '1x1': return '13085447';

      case 'billboard':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2206276
        };

      case '300x250':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2206276
        };

      case 'halfpage':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case 'middle':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case 'footer':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case '320x50':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case 'mbillboard':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case 'fcarpet':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case 'mfooter':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };

      case 'quiz':
        return {
          accountid: 21224,
          siteid: 272988,
          zoneid: 2152992
        };
      case 'sticky_web':
        if (KL.device == 'mobile') {
          return {
            accountid: 21224,
            siteid: 272988,
            zoneid: 2152992
          };
        } else {
          return {
            accountid: 21224,
            siteid: 272988,
            zoneid: 2152992
          };
        }
    }
    return null;
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"rubicon",params:{accountId: placement.accountid, siteId: placement.siteid, zoneId: placement.zoneid }};
  }

}

/*
KL.Modules.ads.bidders.rhythmone = new function()
{
  var self = this;

  function getPlacement(id)
  {
    return '213806';
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"rhythmone",params:{placementId: placement}};
  }

}
*/


/*
KL.Modules.ads.bidders.oftmedia = new function()
{
  var self = this;

  function getPlacement(id)
  {
    // if pc
    if (KL.device == "pc")
      return '22267936';

    // else if mobile
    return '22267941';
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"oftmedia",params:{placementId: placement}};
  }
}
*/

KL.Modules.ads.bidders.triplelift = new function()
{
  var self = this;

  function getPlacement(id)
  {
    switch(id)
    {
      case 'oop': return '';
      case '1x1': return '';

      case 'billboard': return 'Kiwilimon_SHA_Prebid_Desktop_970x250';
      case '300x250':
         if (KL.device == 'mobile')
           return 'Kiwilimon_SHA_Prebid_Mobile_300x250';
         return 'Kiwilimon_SHA_Prebid_Desktop_300x250';
      case 'halfpage': return 'Kiwilimon_SHA_Prebid_Desktop_300x250';
      case 'middle': return 'Kiwilimon_SHA_Prebid_Desktop_728x90';
      case 'footer': return 'Kiwilimon_SHA_Prebid_Desktop_728x90';

      case '320x50': return 'Kiwilimon_SHA_Prebid_Desktop_300x250';

      case 'mbillboard': return 'Kiwilimon_SHA_Prebid_Mobile_320x50';
      case 'fcarpet': return 'Kiwilimon_SHA_Prebid_Mobile_320x50';
      case 'mfooter': return 'Kiwilimon_SHA_Prebid_Mobile_300x250';
      case 'quiz': return 'Kiwilimon_SHA_Prebid_Mobile_320x50'; // igual que mbillboard
      case 'sticky_web':
         if (KL.device == 'mobile')
           return 'Kiwilimon_SHA_Prebid_Mobile_300x250';
         return 'Kiwilimon_SHA_Prebid_Desktop_728x90';
    }
    return null;
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"triplelift",params:{inventoryCode: placement}};
  }

}


/*
KL.Modules.ads.bidders.tappx = new function()
{
  var self = this;

  function getPlacement(id)
  {
    // pc
    valortappxkey = 'pub-64140-desktop-9218';

    if (KL.device == 'mobile')
      valortappxkey = 'pub-64141-mweb-9239';

    return {
      endpoint: 'zz38863kl',
      host: 'zz38863kl.pub.tappx.com/rtb/',
      tappxkey: valortappxkey,
    };
  }

  this.getCode = getCode;
  function getCode(id, size)
  {
    placement = getPlacement(id);
    if (!placement)
      return null;

    return {bidder:"tappx",params:{endpoint: placement.endpoint, host: placement.host, tappxkey: placement.tappxkey }};
  }
}
*/


/*
KL.Modules.ads.lunamedia = new function()
{
  var self = this;
  this.node = null;

  this.onload = onload;
  function onload()
  {
    self.node = WA.Managers.externloader.loadexterncode("//d2q2a5sepkhvug.cloudfront.net/player.js?source=683273");
    //console.log("lunamedia loaded");
  }

  this.onunload = onunload;
  function onunload()
  {
    if (self.node) {
      self.node.parentNode.removeChild(self.node);
      self.node = null;
      // console.log("lunamedia unload");
    }
  }
}
*/


// DAG 19/Sep/2022
KL.Modules.ads.amazon = new function()
{
  this.onload = onload;
  function onload()
  {
    if(window.apstag)
      return;

    var lkn = document.createElement("LINK");
    lkn.setAttribute("rel", "dns-prefetch");
    lkn.setAttribute("href", "https://c.amazon-adsystem.com");
    document.head.appendChild(lkn);

    var lnk = document.createElement("LINK");
    lnk.setAttribute("rel", "preconnect");
    lnk.setAttribute("href", "https://c.amazon-adsystem.com");
    lnk.setAttribute("crossorigin", "");
    document.head.appendChild(lnk);

    var scriptjs = document.createElement('script');
    scriptjs.type = 'text/javascript';
    scriptjs.async = true;
    scriptjs.src = "https://c.amazon-adsystem.com/aax2/apstag.js";
    document.head.appendChild(scriptjs);

    // Agrega la function del script
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.innerHTML = '!(function (a9, a, p, s, t, A, g) {' + 
                    'if (a[a9]) return; ' +
                      'function q(c, r) {' +
                        'a[a9]._Q.push([c, r]);' +
                      '}' +
                    'a[a9] = {' +
                    'init: function () {' +
                      'q("i", arguments);' +
                    '},' +
                    'fetchBids: function () {' +
                      'q("f", arguments);' +
                    '},' +
                    'setDisplayBids: function () {},' +
                    'targetingKeys: function () {' +
                      'return [];' +
                    '},' +
                    'dpa: function () {' +
                      'q("di", arguments);' +
                    '},' +
                    'rpa: function () {' +
                      'q("ri", arguments);' + 
                    '},' +
                    'upa: function () {' +
                      'q("ui", arguments);' +
                    '},' +
                    '_Q: [],' +
                    '};' +
                  '})("apstag", window);';

    document.head.appendChild(s);
  }
}

// DAG borrar 11/05/2022
KL.Modules.ads.walmart = new function()
{
  var self = this;
  this.node = null;

  this.onload = onload;
  function onload()
  {
    if(!WA.toDOM('fira-container'))
      return

    onunload()
      .then(response => {
        window.firaImplemented = false;

        /* WALMART publicidad prueba DAG 12/05/2022 */
        (function () {
          script = document.createElement('script');
          script.type = 'text/javascript';
          script.async = true;
          script.src = "//firalivepro.blob.core.windows.net/scripts/fira-script.js";
          script.setAttribute('data-firakey', '621ce2e1c1765b47744ee50a');
          var scrpt = document.getElementsByTagName('script')[0];
          scrpt.parentNode.insertBefore(script, scrpt);
        })();
      })
      .catch(error => {console.log('Error:', error)});

      /*
      self.node = WA.Managers.externloader.loadexterncode("//firalivepro.blob.core.windows.net/scripts/fira-script.js?v=");
      self.node.setAttribute('data-firakey', '621ce2e1c1765b47744ee50a');
      */
  }

  this.onunload = onunload;
  function onunload()
  {
    return new Promise(resolve => {
      if (self.node) {
        self.node.parentNode.removeChild(self.node);
        self.node = null;
        var nodo = document.getElementById('fira-styles');
        nodo.parentNode.removeChild(nodo);
        // console.log("walmart unload");
      }
      resolve();
    })
  }

}
/* prebid.js v7.12.0
Updated: 2022-08-30
Modules: fpdModule, appnexusBidAdapter, appnexusBidAdapter, ixBidAdapter, richaudienceBidAdapter, rubiconBidAdapter, tripleliftBidAdapter, consentManagement, consentManagementUsp, enrichmentFpdModule, gdprEnforcement, gptPreAuction */
if(window.pbjs&&window.pbjs.libLoaded)try{window.pbjs.getConfig("debug")&&console.warn("Attempted to load a copy of Prebid.js that clashes with the existing 'pbjs' instance. Load aborted.")}catch(e){}else (function(){
!function(){var e,n={35706:function(e,n,t){t.d(n,{Pd:function(){return s},Th:function(){return c},_U:function(){return d}});var r=t(55730),i=t(64358),o=t(20265),a=t(34614),u="outstream";function c(e){var n=this,t=e.url,o=e.config,a=e.id,c=e.callback,s=e.loaded,d=e.adUnitCode,l=e.renderNow;this.url=t,this.config=o,this.handlers={},this.id=a,this.loaded=s,this.cmd=[],this.push=function(e){"function"==typeof e?n.loaded?e.call():n.cmd.push(e):(0,i.logError)("Commands given to Renderer.push must be wrapped in a function")},this.callback=c||function(){n.loaded=!0,n.process()},this.render=function(){var e=this,n=arguments,o=function(){e._render?e._render.apply(e,n):(0,i.logWarn)("No render function was provided, please use .setRender on the renderer")};f(d)?((0,i.logWarn)("External Js not loaded by Renderer since renderer url and callback is already defined on adUnit ".concat(d)),o()):l?o():(this.cmd.unshift(o),(0,r.B)(t,u,this.callback,this.documentContext))}.bind(this)}function s(e){return!(!e||!e.url)}function d(e,n,t){var r=null;e.config&&e.config.documentResolver&&(r=e.config.documentResolver(n,document,t)),r||(r=document),e.documentContext=r,e.render(n,e.documentContext)}function f(e){var n=pbjs.adUnits,t=(0,a.sE)(n,(function(n){return n.code===e}));if(!t)return!1;var r=(0,o.Z)(t,"renderer"),i=!!(r&&r.url&&r.render),u=(0,o.Z)(t,"mediaTypes.video.renderer"),c=!!(u&&u.url&&u.render);return!!(i&&!0!==r.backupOnly||c&&!0!==u.backupOnly)}c.install=function(e){return new c({url:e.url,config:e.config,id:e.id,callback:e.callback,loaded:e.loaded,adUnitCode:e.adUnitCode,renderNow:e.renderNow})},c.prototype.getConfig=function(){return this.config},c.prototype.setRender=function(e){this._render=e},c.prototype.setEventHandlers=function(e){this.handlers=e},c.prototype.handleVideoEvent=function(e){var n=e.id,t=e.eventName;"function"==typeof this.handlers[t]&&this.handlers[t](),(0,i.logMessage)("Prebid Renderer event for id ".concat(n," type ").concat(t))},c.prototype.process=function(){for(;this.cmd.length>0;)try{this.cmd.shift().call()}catch(e){(0,i.logError)("Error processing Renderer command: ",e)}}},875:function(e,n,t){t.d(n,{f:function(){return a}});var r=t(20265),i={};function o(e,n,t){var r=function(e,n){var t=i[e]=i[e]||{bidders:{}};return n?t.bidders[n]=t.bidders[n]||{}:t}(e,t);return r[n]=(r[n]||0)+1,r[n]}var a={incrementRequestsCounter:function(e){return o(e,"requestsCounter")},incrementBidderRequestsCounter:function(e,n){return o(e,"requestsCounter",n)},incrementBidderWinsCounter:function(e,n){return o(e,"winsCounter",n)},getRequestsCounter:function(e){return(0,r.Z)(i,"".concat(e,".requestsCounter"))||0},getBidderRequestsCounter:function(e,n){return(0,r.Z)(i,"".concat(e,".bidders.").concat(n,".requestsCounter"))||0},getBidderWinsCounter:function(e,n){return(0,r.Z)(i,"".concat(e,".bidders.").concat(n,".winsCounter"))||0}}},48525:function(e,n,t){function r(e){var n=e;return{callBids:function(){},setBidderCode:function(e){n=e},getBidderCode:function(){return n}}}t.d(n,{Z:function(){return r}})},9528:function(e,n,t){t.d(n,{qJ:function(){return F},VP:function(){return $},ZP:function(){return ie},JO:function(){return V},rp:function(){return Y},uV:function(){return ne},Ct:function(){return te},nX:function(){return X}});var r=t(93324),i=t(4942),o=t(64358),a=t(20265),u=t(74247),c=t(70059),s=t(14699),d=t(48928),f=t(3193),l=t(92797),g=t(34614),p=t(875),v=t(25102),h=t(60136),m=t(82963),b=t(61120),y=t(15671),E=t(43144),w=t(18916),C=t(42793),A=t(68792);function I(e){var n=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(e){return!1}}();return function(){var t,r=(0,b.Z)(e);if(n){var i=(0,b.Z)(this).constructor;t=Reflect.construct(r,arguments,i)}else t=r.apply(this,arguments);return(0,m.Z)(this,t)}}function T(e,n,t){O(e,n),n.set(e,t)}function O(e,n){if(n.has(e))throw new TypeError("Cannot initialize the same private elements twice on an object")}function S(e,n,t){if(!n.has(e))throw new TypeError("attempted to get private field on non-instance");return t}var B=new WeakMap,k=new WeakMap,j=new WeakMap,U=new WeakMap,_=new WeakSet,R=function(){function e(){var n,t;(0,y.Z)(this,e),O(n=this,t=_),t.add(n),T(this,B,{writable:!0,value:void 0}),T(this,k,{writable:!0,value:void 0}),T(this,j,{writable:!0,value:void 0}),T(this,U,{writable:!0,value:void 0}),(0,i.Z)(this,"generatedTime",void 0),this.reset()}return(0,E.Z)(e,[{key:"reset",value:function(){(0,C.Z)(this,j,(0,A.P)()),(0,C.Z)(this,B,!1),(0,C.Z)(this,k,null),(0,C.Z)(this,U,!1),this.generatedTime=null}},{key:"enable",value:function(){(0,C.Z)(this,B,!0)}},{key:"enabled",get:function(){return(0,w.Z)(this,B)}},{key:"ready",get:function(){return(0,w.Z)(this,U)}},{key:"promise",get:function(){return(0,w.Z)(this,U)?A.Z.resolve((0,w.Z)(this,k)):((0,w.Z)(this,B)||S(this,_,P).call(this,null),(0,w.Z)(this,j).promise)}},{key:"setConsentData",value:function(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:(0,o.timestamp)();this.generatedTime=n,S(this,_,P).call(this,e)}},{key:"getConsentData",value:function(){return(0,w.Z)(this,k)}}]),e}();function P(e){(0,C.Z)(this,U,!0),(0,C.Z)(this,k,e),(0,w.Z)(this,j).resolve(e)}var q=function(e){(0,h.Z)(t,e);var n=I(t);function t(){return(0,y.Z)(this,t),n.apply(this,arguments)}return(0,E.Z)(t,[{key:"getConsentMeta",value:function(){var e=this.getConsentData();if(e&&this.generatedTime)return{usp:e,generatedAt:this.generatedTime}}}]),t}(R),D=function(e){(0,h.Z)(t,e);var n=I(t);function t(){return(0,y.Z)(this,t),n.apply(this,arguments)}return(0,E.Z)(t,[{key:"getConsentMeta",value:function(){var e=this.getConsentData();if(e&&e.vendorData&&this.generatedTime)return{gdprApplies:e.gdprApplies,consentStringSize:(0,o.isStr)(e.vendorData.tcString)?e.vendorData.tcString.length:0,generatedAt:this.generatedTime,apiVersion:e.apiVersion}}}]),t}(R),Z=t(52021),x=t(5644);function N(e,n){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n&&(r=r.filter((function(n){return Object.getOwnPropertyDescriptor(e,n).enumerable}))),t.push.apply(t,r)}return t}function M(e){for(var n=1;n<arguments.length;n++){var t=null!=arguments[n]?arguments[n]:{};n%2?N(Object(t),!0).forEach((function(n){(0,i.Z)(e,n,t[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):N(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}))}return e}var F={CLIENT:"client",SERVER:"server"},W={},z=W.bidderRegistry={},K=W.aliasRegistry={},L=[];f.vc.getConfig("s2sConfig",(function(e){e&&e.s2sConfig&&(L=(0,o.isArray)(e.s2sConfig)?e.s2sConfig:[e.s2sConfig])}));var H={};var G=(0,l.z3)("sync",(function(e){var n=e.bidderCode,t=e.auctionId,r=e.bidderRequestId,i=e.adUnits,u=e.src;return i.reduce((function(e,i){return e.push(i.bids.filter((function(e){return e.bidder===n})).reduce((function(e,n){var c=null==(n=Object.assign({},n,(0,o.getDefinedParams)(i,["nativeParams","nativeOrtbRequest","ortb2Imp","mediaType","renderer"]))).mediaTypes?i.mediaTypes:n.mediaTypes;return(0,o.isValidMediaTypes)(c)?n=Object.assign({},n,{mediaTypes:c}):(0,o.logError)("mediaTypes is not correctly configured for adunit ".concat(i.code)),e.push(Object.assign({},n,{adUnitCode:i.code,transactionId:i.transactionId,sizes:(0,a.Z)(c,"banner.sizes")||(0,a.Z)(c,"video.playerSize")||[],bidId:n.bid_id||(0,o.getUniqueIdentifierStr)(),bidderRequestId:r,auctionId:t,src:u,bidRequestsCount:p.f.getRequestsCounter(i.code),bidderRequestsCount:p.f.getBidderRequestsCounter(i.code,n.bidder),bidderWinsCount:p.f.getBidderWinsCounter(i.code,n.bidder)})),e}),[])),e}),[]).reduce(o.flatten,[]).filter((function(e){return""!==e}))}),"getBids");var V=(0,l.z3)("sync",(function(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=t.getS2SBidders,i=void 0===r?ne:r;if(null==n)return e;var o=i(n);return e.filter((function(e){return o.has(e.bidder)}))}),"filterBidsForAdUnit");function Q(e,n){var t=(0,o.deepClone)(e);return t.forEach((function(e){e.bids=V(e.bids,n).map((function(e){return e.bid_id=(0,o.getUniqueIdentifierStr)(),e}))})),t=t.filter((function(e){return 0!==e.bids.length}))}function J(e){var n=(0,o.deepClone)(e);return n.forEach((function(e){e.bids=V(e.bids,null)})),n=n.filter((function(e){return 0!==e.bids.length}))}var Y=new D,X=new q,$={getCoppa:function(){return!!f.vc.getConfig("coppa")}},ee=(0,l.z3)("sync",(function(e,n){return(0,u.UB)(e,n)}),"setupAdUnitMediaTypes");function ne(e){(0,o.isArray)(e)||(e=[e]);var n=new Set([null]);return e.filter((function(e){return e&&e.enabled})).flatMap((function(e){return e.bidders})).forEach((function(e){return n.add(e)})),n}var te=(0,l.z3)("sync",(function(e,n){var t,r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},a=r.getS2SBidders,u=void 0===a?ne:a,c=u(n);return(0,o.getBidderCodes)(e).reduce((function(e,n){return e[c.has(n)?F.SERVER:F.CLIENT].push(n),e}),(t={},(0,i.Z)(t,F.CLIENT,[]),(0,i.Z)(t,F.SERVER,[]),t))}),"partitionBidders");function re(e,n,t){try{var r=z[e].getSpec();r&&r[n]&&"function"==typeof r[n]&&((0,o.logInfo)("Invoking ".concat(e,".").concat(n)),f.vc.runWithBidder(e,o.bind.call(r[n],r,t)))}catch(t){(0,o.logWarn)("Error calling ".concat(n," of ").concat(e))}}W.makeBidRequests=(0,l.z3)("sync",(function(e,n,t,r,i){var a=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};Z.j8(x.FP.BEFORE_REQUEST_BIDS,e),(0,c.Fb)(e),e=ee(e,i);var u=te(e,L),s=u[F.CLIENT],d=u[F.SERVER];f.vc.getConfig("bidderSequence")===f.FD&&(s=(0,o.shuffle)(s));var l=(0,v.nH)(),p=[],h=a.global||{},m=a.bidder||{};function b(e){var n=Object.freeze((0,o.mergeDeep)({},h,m[e.bidderCode]));return e.ortb2=n,e.bids.forEach((function(e){return e.ortb2=n})),e}L.forEach((function(r){if(r&&r.enabled){var i=Q(e,r),a=(0,o.generateUUID)();d.forEach((function(e){var u=(0,o.getUniqueIdentifierStr)(),c=b({bidderCode:e,auctionId:t,bidderRequestId:u,uniquePbsTid:a,bids:G({bidderCode:e,auctionId:t,bidderRequestId:u,adUnits:(0,o.deepClone)(i),src:x.os.YZ}),auctionStart:n,timeout:r.timeout,src:x.os.YZ,refererInfo:l});0!==c.bids.length&&p.push(c)})),i.forEach((function(e){var n=e.bids.filter((function(e){return(0,g.sE)(p,(function(n){return(0,g.sE)(n.bids,(function(n){return n.bidId===e.bid_id}))}))}));e.bids=n})),p.forEach((function(e){void 0===e.adUnitsS2SCopy&&(e.adUnitsS2SCopy=i.filter((function(e){return e.bids.length>0})))}))}}));var y=J(e);return s.forEach((function(e){var a=(0,o.getUniqueIdentifierStr)(),u=b({bidderCode:e,auctionId:t,bidderRequestId:a,bids:G({bidderCode:e,auctionId:t,bidderRequestId:a,adUnits:(0,o.deepClone)(y),labels:i,src:"client"}),auctionStart:n,timeout:r,refererInfo:l}),c=z[e];c||(0,o.logError)("Trying to make a request for bidder that does not exist: ".concat(e)),c&&u.bids&&0!==u.bids.length&&p.push(u)})),Y.getConsentData()&&p.forEach((function(e){e.gdprConsent=Y.getConsentData()})),X.getConsentData()&&p.forEach((function(e){e.uspConsent=X.getConsentData()})),p}),"makeBidRequests"),W.callBids=function(e,n,t,i,a,u,c){var s=arguments.length>7&&void 0!==arguments[7]?arguments[7]:{};if(n.length){var l=n.reduce((function(e,n){return e[Number(void 0!==n.src&&n.src===x.os.YZ)].push(n),e}),[[],[]]),g=(0,r.Z)(l,2),p=g[0],v=g[1],h=[];v.forEach((function(e){for(var n=-1,t=0;t<h.length;++t)if(e.uniquePbsTid===h[t].uniquePbsTid){n=t;break}n<=-1&&h.push(e)}));var m=0,b=(0,o.generateUUID)();L.forEach((function(e){if(e&&h[m]&&ne(e).has(h[m].bidderCode)){var n=(0,d.O)(u,a?{request:a.request.bind(null,"s2s"),done:a.done}:void 0),r=e.bidders,c=z[e.adapter],f=h[m].uniquePbsTid,l=h[m].adUnitsS2SCopy,g=v.filter((function(e){return e.uniquePbsTid===f}));if(c){var p={tid:b,ad_units:l,s2sConfig:e,ortb2Fragments:s};if(p.ad_units.length){var y=g.map((function(e){return e.start=(0,o.timestamp)(),i.bind(e)})),E=(0,o.getBidderCodes)(p.ad_units).filter((function(e){return r.includes(e)}));(0,o.logMessage)("CALLING S2S HEADER BIDDERS ==== ".concat(E.length>0?E.join(", "):'No bidder specified, using "ortb2Imp" definition(s) only')),g.forEach((function(e){Z.j8(x.FP.BID_REQUESTED,M(M({},e),{},{tid:b}))})),c.callBids(p,v,t,(function(){return y.forEach((function(e){return e()}))}),n)}}else(0,o.logError)("missing "+e.adapter);m++}})),p.forEach((function(e){e.start=(0,o.timestamp)();var n=z[e.bidderCode];f.vc.runWithBidder(e.bidderCode,(function(){(0,o.logMessage)("CALLING BIDDER"),Z.j8(x.FP.BID_REQUESTED,e)}));var r=(0,d.O)(u,a?{request:a.request.bind(null,e.bidderCode),done:a.done}:void 0),s=i.bind(e);try{f.vc.runWithBidder(e.bidderCode,o.bind.call(n.callBids,n,e,t,s,r,c,f.vc.callbackWithBidder(e.bidderCode)))}catch(n){(0,o.logError)("".concat(e.bidderCode," Bid Adapter emitted an uncaught error when parsing their bidRequest"),{e:n,bidRequest:e}),s()}}))}else(0,o.logWarn)("callBids executed with no bidRequests.  Were they filtered by labels or sizing?")},W.videoAdapters=[],W.registerBidAdapter=function(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=t.supportedMediaTypes,i=void 0===r?[]:r;e&&n?"function"==typeof e.callBids?(z[n]=e,(0,g.q9)(i,"video")&&W.videoAdapters.push(n),(0,g.q9)(i,"native")&&c.Sg.push(n)):(0,o.logError)("Bidder adaptor error for bidder code: "+n+"bidder must implement a callBids() function"):(0,o.logError)("bidAdapter or bidderCode not specified")},W.aliasBidAdapter=function(e,n,t){if(void 0===z[n]){var r=z[e];if(void 0===r){var i=[];L.forEach((function(t){if(t.bidders&&t.bidders.length){var r=t&&t.bidders;t&&(0,g.q9)(r,n)?K[n]=e:i.push(e)}})),i.forEach((function(e){(0,o.logError)('bidderCode "'+e+'" is not an existing bidder.',"adapterManager.aliasBidAdapter")}))}else try{var a,u=function(e){var n=[];return(0,g.q9)(W.videoAdapters,e)&&n.push("video"),(0,g.q9)(c.Sg,e)&&n.push("native"),n}(e);if(r.constructor.prototype!=Object.prototype)(a=new r.constructor).setBidderCode(n);else{var d=r.getSpec(),f=t&&t.gvlid,l=t&&t.skipPbsAliasing;a=(0,s.PZ)(Object.assign({},d,{code:n,gvlid:f,skipPbsAliasing:l})),K[n]=e}W.registerBidAdapter(a,n,{supportedMediaTypes:u})}catch(n){(0,o.logError)(e+" bidder does not currently support aliasing.","adapterManager.aliasBidAdapter")}}else(0,o.logMessage)('alias name "'+n+'" has been already specified.')},W.registerAnalyticsAdapter=function(e){var n=e.adapter,t=e.code,r=e.gvlid;n&&t?"function"==typeof n.enableAnalytics?(n.code=t,H[t]={adapter:n,gvlid:r}):(0,o.logError)('Prebid Error: Analytics adaptor error for analytics "'.concat(t,'"\n        analytics adapter must implement an enableAnalytics() function')):(0,o.logError)("Prebid Error: analyticsAdapter or analyticsCode not specified")},W.enableAnalytics=function(e){(0,o.isArray)(e)||(e=[e]),(0,o._each)(e,(function(e){var n=H[e.provider];n&&n.adapter?n.adapter.enableAnalytics(e):(0,o.logError)("Prebid Error: no analytics adapter found in registry for '".concat(e.provider,"'."))}))},W.getBidAdapter=function(e){return z[e]},W.getAnalyticsAdapter=function(e){return H[e]},W.callTimedOutBidders=function(e,n,t){n=n.map((function(n){return n.params=(0,o.getUserConfiguredParams)(e,n.adUnitCode,n.bidder),n.timeout=t,n})),n=(0,o.groupBy)(n,"bidder"),Object.keys(n).forEach((function(e){re(e,"onTimeout",n[e])}))},W.callBidWonBidder=function(e,n,t){n.params=(0,o.getUserConfiguredParams)(t,n.adUnitCode,n.bidder),p.f.incrementBidderWinsCounter(n.adUnitCode,n.bidder),re(e,"onBidWon",n)},W.callSetTargetingBidder=function(e,n){re(e,"onSetTargeting",n)},W.callBidViewableBidder=function(e,n){re(e,"onBidViewable",n)},W.callBidderError=function(e,n,t){re(e,"onBidderError",{error:n,bidderRequest:t})};var ie=W},14699:function(e,n,t){t.d(n,{JY:function(){return U},Ks:function(){return B},PZ:function(){return O},Q1:function(){return k},dX:function(){return T}});var r=t(93324),i=t(71002),o=t(48525),a=t(9528),u=t(3193),c=t(69626),s=t(11974),d=t(70059),f=t(90154),l=t(5644),g=t(52021),p=t(34614),v=t(48928),h=t(64358),m=t(20265),b=t(24679),y=t(92797),E=t(15164),w=t(78653),C=t(55975),A=(0,E.eA)("bidderFactory"),I=["cpm","ttl","creativeId","netRevenue","currency"];function T(e){var n=Array.isArray(e.supportedMediaTypes)?{supportedMediaTypes:e.supportedMediaTypes}:void 0;function t(e){var t=O(e);a.ZP.registerBidAdapter(t,e.code,n)}t(e),Array.isArray(e.aliases)&&e.aliases.forEach((function(n){var r,i,o=n;(0,h.isPlainObject)(n)&&(o=n.code,r=n.gvlid,i=n.skipPbsAliasing),a.ZP.aliasRegistry[o]=e.code,t(Object.assign({},e,{code:o,gvlid:r,skipPbsAliasing:i}))}))}function O(e){return Object.assign(new o.Z(e.code),{getSpec:function(){return Object.freeze(e)},registerSyncs:n,callBids:function(r,i,o,s,d,f){if(Array.isArray(r.bids)){var p={},v=[],m=r.bids.filter(t);if(0!==m.length){var b={};m.forEach((function(e){b[e.bidId]=e,e.adUnitCode||(e.adUnitCode=e.placementCode)})),S(e,m,r,s,f,{onRequest:function(e){return g.j8(l.FP.BEFORE_BIDDER_HTTP,r,e)},onResponse:function(n){d(e.code),v.push(n)},onError:function(n,t){d(e.code),a.ZP.callBidderError(e.code,t,r),g.j8(l.FP.BIDDER_ERROR,{error:t,bidderRequest:r}),(0,h.logError)("Server call for ".concat(e.code," failed: ").concat(n," ").concat(t.status,". Continuing without bids."))},onBid:function(n){var t=b[n.requestId];if(t){if(n.adapterCode=t.bidder,function(e,n){var t=C.S.get(n,"allowAlternateBidderCodes")||!1,r=C.S.get(n,"allowedAlternateBidderCodes");if(e&&n&&n!==e&&(r=(0,h.isArray)(r)?r.map((function(e){return e.trim().toLowerCase()})).filter((function(e){return!!e})).filter(h.uniques):r,!t||(0,h.isArray)(r)&&"*"!==r[0]&&!r.includes(e)))return!0;return!1}(n.bidderCode,t.bidder))return void(0,h.logWarn)("".concat(n.bidderCode," is not a registered partner or known bidder of ").concat(t.bidder,", hence continuing without bid. If you wish to support this bidder, please mark allowAlternateBidderCodes as true in bidderSettings."));n.originalCpm=n.cpm,n.originalCurrency=n.currency,n.meta=n.meta||Object.assign({},n[t.bidder]);var r=Object.assign((0,c.m)(l.Q_.GOOD,t),n);!function(e,n){p[e]=!0,U(e,n)&&i(e,n)}(t.adUnitCode,r)}else(0,h.logWarn)("Bidder ".concat(e.code," made bid for unknown request ID: ").concat(n.requestId,". Ignoring."))},onCompletion:y})}else y()}function y(){o(),u.vc.runWithBidder(e.code,(function(){g.j8(l.FP.BIDDER_DONE,r),n(v,r.gdprConsent,r.uspConsent)}))}}});function n(n,t,r){B(e,n,t,r)}function t(n){return!!e.isBidRequestValid(n)||((0,h.logWarn)("Invalid bid sent to bidder ".concat(e.code,": ").concat(JSON.stringify(n))),!1)}}var S=(0,y.z3)("sync",(function(e,n,t,r,o,a){var u=a.onRequest,c=a.onResponse,s=a.onError,d=a.onBid,f=a.onCompletion,l=e.buildRequests(n,t);if(l&&0!==l.length){Array.isArray(l)||(l=[l]);var g=(0,h.delayExecution)(f,l.length);l.forEach((function(n){var t=o((function(t,r){try{t=JSON.parse(t)}catch(e){}var i;t={body:t,headers:{get:r.getResponseHeader.bind(r)}},c(t);try{i=e.interpretResponse(t,n)}catch(n){return(0,h.logError)("Bidder ".concat(e.code," failed to interpret the server's response. Continuing without bids"),null,n),void g()}i&&((0,h.isArray)(i)?i.forEach(d):d(i)),g()})),a=o((function(e,n){s(e,n),g()}));switch(u(n),n.method){case"GET":r("".concat(n.url).concat(function(e){if(e)return"?".concat("object"===(0,i.Z)(e)?(0,h.parseQueryStringParameters)(e):e);return""}(n.data)),{success:t,error:a},void 0,Object.assign({method:"GET",withCredentials:!0},n.options));break;case"POST":r(n.url,{success:t,error:a},"string"==typeof n.data?n.data:JSON.stringify(n.data),Object.assign({method:"POST",contentType:"text/plain",withCredentials:!0},n.options));break;default:(0,h.logWarn)("Skipping invalid request from ".concat(e.code,". Request type ").concat(n.type," must be GET or POST")),g()}}))}else f()}),"processBidderRequests"),B=(0,y.z3)("async",(function(e,n,t,r){var i=u.vc.getConfig("userSync.aliasSyncEnabled");if(e.getUserSyncs&&(i||!a.ZP.aliasRegistry[e.code])){var o=u.vc.getConfig("userSync.filterSettings"),c=e.getUserSyncs({iframeEnabled:!(!o||!o.iframe&&!o.all),pixelEnabled:!(!o||!o.image&&!o.all)},n,t,r);c&&(Array.isArray(c)||(c=[c]),c.forEach((function(n){s.k_.registerSync(n.type,e.code,n.url)})))}}),"registerSyncs");function k(e,n){var t=a.ZP.getBidAdapter(e);if(t.getSpec().getMappingFileInfo){var r=t.getSpec().getMappingFileInfo(),i=r.localStorageKey?r.localStorageKey:t.getBidderCode(),o=A.getDataFromLocalStorage(i);if(o){try{o=JSON.parse(o)}catch(n){(0,h.logError)("Failed to parse ".concat(e," mapping data stored in local storage"))}return o.mapping[n]?o.mapping[n]:null}}}function j(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},i=t.index,o=void 0===i?w.K.index:i;if((n.width||0===parseInt(n.width,10))&&(n.height||0===parseInt(n.height,10)))return n.width=parseInt(n.width,10),n.height=parseInt(n.height,10),!0;var a=o.getBidRequest(n),u=o.getMediaTypes(n),c=a&&a.sizes||u&&u.banner&&u.banner.sizes,s=(0,h.parseSizesInput)(c);if(1===s.length){var d=s[0].split("x"),f=(0,r.Z)(d,2),l=f[0],g=f[1];return n.width=parseInt(l,10),n.height=parseInt(g,10),!0}return!1}function U(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=t.index,i=void 0===r?w.K.index:r;function o(){var e=Object.keys(n);return I.every((function(t){return(0,p.q9)(e,t)&&!(0,p.q9)([void 0,null],n[t])}))}function a(e){return"Invalid bid from ".concat(n.bidderCode,". Ignoring bid: ").concat(e)}return e?n?o()?"native"!==n.mediaType||(0,d.r4)(n,{index:i})?"video"!==n.mediaType||(0,f.Dn)(n,{index:i})?!("banner"===n.mediaType&&!j(e,n,{index:i}))||((0,h.logError)(a("Banner bids require a width and height")),!1):((0,h.logError)(a("Video bid does not have required vastUrl or renderer property")),!1):((0,h.logError)(a("Native bid missing some required properties.")),!1):((0,h.logError)(a("Bidder ".concat(n.bidderCode," is missing required params. Check http://prebid.org/dev-docs/bidder-adapter-1.html for list of params."))),!1):((0,h.logWarn)("Some adapter tried to add an undefined bid for ".concat(e,".")),!1):((0,h.logWarn)("No adUnitCode was supplied to addBidResponse."),!1)}(0,y.v5)("checkAdUnitSetup").before((function(e,n){if(!u.vc.getConfig("adpod.brandCategoryExclusion"))return e.call(this,n);n.filter((function(e){return(0,m.Z)(e,"mediaTypes.video.context")===b.Oh})).map((function(e){return e.bids.map((function(e){return e.bidder}))})).reduce(h.flatten,[]).filter(h.uniques).forEach((function(e){var n=a.ZP.getBidAdapter(e);if(n.getSpec().getMappingFileInfo){var t=n.getSpec().getMappingFileInfo(),r=t.refreshInDays?t.refreshInDays:1,i=t.localStorageKey?t.localStorageKey:n.getSpec().code,o=A.getDataFromLocalStorage(i);try{(!(o=o?JSON.parse(o):void 0)||(0,h.timestamp)()>o.lastUpdated+24*r*60*60*1e3)&&(0,v.h)(t.url,{success:function(n){try{n=JSON.parse(n);var t={lastUpdated:(0,h.timestamp)(),mapping:n.mapping};A.setDataInLocalStorage(i,JSON.stringify(t))}catch(n){(0,h.logError)("Failed to parse ".concat(e," bidder translation mapping file"))}},error:function(){(0,h.logError)("Failed to load ".concat(e," bidder translation file"))}})}catch(n){(0,h.logError)("Failed to parse ".concat(e," bidder translation mapping file"))}}})),e.call(this,n)}))},55730:function(e,n,t){t.d(n,{B:function(){return u}});var r=t(34614),i=t(64358),o=new WeakMap,a=["debugging","adloox","criteo","outstream","adagio","spotx","browsi","brandmetrics","justtag","tncId","akamaidap","ftrackId","inskin","hadron","medianet","improvedigital"];function u(e,n,t,u,c){if(n&&e){if((0,r.q9)(a,n)){u||(u=document);var s=l(u,e);if(s)return t&&"function"==typeof t&&(s.loaded?t():s.callbacks.push(t)),s.tag;var d=o.get(u)||{},f={loaded:!1,tag:null,callbacks:[]};return d[e]=f,o.set(u,d),t&&"function"==typeof t&&f.callbacks.push(t),(0,i.logWarn)("module ".concat(n," is loading external JavaScript")),function(n,t,r,o){r||(r=document);var a=r.createElement("script");a.type="text/javascript",a.async=!0;var u=l(r,e);u&&(u.tag=a);a.readyState?a.onreadystatechange=function(){"loaded"!==a.readyState&&"complete"!==a.readyState||(a.onreadystatechange=null,t())}:a.onload=function(){t()};a.src=n,o&&(0,i.setScriptAttributes)(a,o);return(0,i.insertElement)(a,r),a}(e,(function(){f.loaded=!0;try{for(var e=0;e<f.callbacks.length;e++)f.callbacks[e]()}catch(e){(0,i.logError)("Error executing callback","adloader.js:loadExternalScript",e)}}),u,c)}(0,i.logError)("".concat(n," not whitelisted for loading external JavaScript"))}else(0,i.logError)("cannot load external script without url and moduleCode");function l(e,n){var t=o.get(e);return t&&t[n]?t[n]:null}}},48928:function(e,n,t){t.d(n,{O:function(){return u},h:function(){return a}});var r=t(71002),i=t(3193),o=t(64358),a=u();function u(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:3e3,n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.request,a=n.done;return function(n,u,c){var s=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{};try{var d,f=s.method||(c?"POST":"GET"),l=document.createElement("a");l.href=n;var g="object"===(0,r.Z)(u)&&null!==u?u:{success:function(){(0,o.logMessage)("xhr success")},error:function(e){(0,o.logError)("xhr error",null,e)}};if("function"==typeof u&&(g.success=u),(d=new window.XMLHttpRequest).onreadystatechange=function(){if(4===d.readyState){"function"==typeof a&&a(l.origin);var e=d.status;e>=200&&e<300||304===e?g.success(d.responseText,d):g.error(d.statusText,d)}},i.vc.getConfig("disableAjaxTimeout")||(d.ontimeout=function(){(0,o.logError)("  xhr timeout after ",d.timeout,"ms")}),"GET"===f&&c){var p=(0,o.parseUrl)(n,s);Object.assign(p.search,c),n=(0,o.buildUrl)(p)}d.open(f,n,!0),i.vc.getConfig("disableAjaxTimeout")||(d.timeout=e),s.withCredentials&&(d.withCredentials=!0),(0,o._each)(s.customHeaders,(function(e,n){d.setRequestHeader(n,e)})),s.preflight&&d.setRequestHeader("X-Requested-With","XMLHttpRequest"),d.setRequestHeader("Content-Type",s.contentType||"text/plain"),"function"==typeof t&&t(l.origin),"POST"===f&&c?d.send(c):d.send()}catch(e){(0,o.logError)("xhr construction",e),"object"===(0,r.Z)(u)&&null!==u&&u.error(e)}}}},25686:function(e,n,t){t.d(n,{D$:function(){return N},LX:function(){return L},RH:function(){return W},Yt:function(){return k},Yw:function(){return A},dg:function(){return z},e0:function(){return j},lU:function(){return R},mv:function(){return I},sq:function(){return _},vO:function(){return B}});var r=t(71002),i=t(64358),o=t(20265),a=t(56463),u=t(70059),c=t(79885),s=t(35706),d=t(3193),f=t(11974),l=t(92797),g=t(34614),p=t(90154),v=t(24679),h=t(78653),m=t(55975),b=t(52021),y=t(9528),E=t(5644),w=t(68792),C=f.k_.syncUsers,A="inProgress",I="completed";b.on(E.FP.BID_ADJUSTMENT,(function(e){!function(e){var n=e.bidderCode,t=e.cpm,r=m.S.get(n||null,"bidCpmAdjustment");if(r&&"function"==typeof r)try{t=r(e.cpm,Object.assign({},e))}catch(e){(0,i.logError)("Error during bid adjustment","bidmanager.js",e)}t>=0&&(e.cpm=t)}(e)}));var T={},O={},S=[];function B(e){var n,t,r,o,a=e.adUnits,u=e.adUnitCodes,c=e.callback,s=e.cbTimeout,f=e.labels,l=e.auctionId,p=e.ortb2Fragments,v=a,m=f,B=u,_=[],q=[],D=[],Z=l||(0,i.generateUUID)(),x=c,N=s,F=[],W=new Set;function z(){return{auctionId:Z,timestamp:n,auctionEnd:t,auctionStatus:r,adUnits:v,adUnitCodes:B,labels:m,bidderRequests:_,noBids:D,bidsReceived:q,winningBids:F,timeout:N}}function K(e,n){if(n&&clearTimeout(o),void 0===t){var u=[];e&&((0,i.logMessage)("Auction ".concat(Z," timedOut")),c=W,(u=_.map((function(e){return(e.bids||[]).filter((function(e){return!c.has(e.bidder)}))})).reduce(i.flatten,[])).length&&b.j8(E.FP.BID_TIMEOUT,u)),r=I,t=Date.now(),b.j8(E.FP.AUCTION_END,z()),U(v,(function(){try{if(null!=x){var n=B,t=q.filter(i.bind.call(i.adUnitsFilter,this,n)).reduce(G,{});x.apply(pbjs,[t,e,Z]),x=null}}catch(e){(0,i.logError)("Error executing bidsBackHandler",null,e)}finally{u.length&&y.ZP.callTimedOutBidders(a,u,N);var r=d.vc.getConfig("userSync")||{};r.enableOverride||C(r.syncDelay)}}))}var c}function L(){d.vc.resetBidder(),(0,i.logInfo)("Bids Received for Auction with id: ".concat(Z),q),r=I,K(!1,!0)}function H(e){W.add(e)}function V(e){var n=this;e.forEach((function(e){var n;n=e,_=_.concat(n)}));var t={},a={bidRequests:e,run:function(){var a,s;a=K.bind(null,!0),s=setTimeout(a,N),o=s,r=A,b.j8(E.FP.AUCTION_INIT,z());var f=function(e,n){var t=(arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}).index,r=void 0===t?h.K.index:t,o=0,a=!1,u=new Set,c={},s={};function f(e,n){null==s[e]&&(s[e]=w.Z.resolve()),s[e]=s[e].then((function(){return w.Z.resolve(n).catch((function(){}))}))}function l(e,t){var r=e.timeout;(null==r||r>n.getTimeout())&&(r=n.getTimeout());var i=n.getAuctionStart()+r-Date.now(),o=s[e.bidderRequestId],a=s[""];(null!=o||null!=a)&&i>0?w.Z.race([w.Z.timeout(i),w.Z.resolve(a).then((function(){return o}))]).then(t):t()}function p(){o--,a&&0===o&&e()}function v(e,t){c[t.requestId]=!0,o++;var r=M({adUnitCode:e,bid:t,auctionId:n.getAuctionId()});"video"===r.mediaType?P(n,r,p):(R(n,r),p())}function m(){var t=this,r=n.getBidRequests(),s=d.vc.getConfig("auctionOptions");if(u.add(t),s&&!(0,i.isEmpty)(s)){var f=s.secondaryBidders;f&&!r.every((function(e){return(0,g.q9)(f,e.bidderCode)}))&&(r=r.filter((function(e){return!(0,g.q9)(f,e.bidderCode)})))}a=r.every((function(e){return u.has(e)})),t.bids.forEach((function(e){c[e.bidId]||(n.addNoBid(e),b.j8(E.FP.NO_BID,e))})),a&&0===o&&e()}return{addBidResponse:function(e,n){var t=r.getBidderRequest(n);f(t&&t.bidderRequestId||"",k.call({dispatch:v},e,n))},adapterDone:function(){l(this,m.bind(this))}}}(L,n);y.ZP.callBids(v,e,f.addBidResponse,f.adapterDone,{request:function(e,n){c(T,n),c(t,e),O[e]||(O[e]={SRA:!0,origin:n}),t[e]>1&&(O[e].SRA=!1)},done:function(e){T[e]--,S[0]&&u(S[0])&&S.shift()}},N,H,p)}};function u(e){var n=!0,t=d.vc.getConfig("maxRequestsPerOrigin")||4;return e.bidRequests.some((function(e){var r=1,i=void 0!==e.src&&e.src===E.os.YZ?"s2s":e.bidderCode;return O[i]&&(!1===O[i].SRA&&(r=Math.min(e.bids.length,t)),T[O[i].origin]+r>t&&(n=!1)),!n})),n&&e.run(),n}function c(e,n){void 0===e[n]?e[n]=1:e[n]++}u(a)||((0,i.logWarn)("queueing auction due to limited endpoint capacity"),S.push(a))}return{addBidReceived:function(e){q=q.concat(e)},addNoBid:function(e){D=D.concat(e)},executeCallback:K,callBids:function(){r="started",n=Date.now();var e=y.ZP.makeBidRequests(v,n,Z,N,m,p);(0,i.logInfo)("Bids Requested for Auction with id: ".concat(Z),e),e.length<1?((0,i.logWarn)("No valid bid requests returned for auction"),L()):j.call({dispatch:V,context:this},e)},addWinningBid:function(e){F=F.concat(e),y.ZP.callBidWonBidder(e.adapterCode||e.bidder,e,a)},setBidTargeting:function(e){y.ZP.callSetTargetingBidder(e.adapterCode||e.bidder,e)},getWinningBids:function(){return F},getAuctionStart:function(){return n},getTimeout:function(){return N},getAuctionId:function(){return Z},getAuctionStatus:function(){return r},getAdUnits:function(){return v},getAdUnitCodes:function(){return B},getBidRequests:function(){return _},getBidsReceived:function(){return q},getNoBids:function(){return D},getFPD:function(){return p}}}var k=(0,l.z3)("sync",(function(e,n){this.dispatch.call(null,e,n)}),"addBidResponse"),j=(0,l.z3)("sync",(function(e){this.dispatch.call(this.context,e)}),"addBidderRequests"),U=(0,l.z3)("async",(function(e,n){n&&n()}),"bidsBackCallback");function _(e,n){n.timeToRespond>e.getTimeout()+d.vc.getConfig("timeoutBuffer")&&e.executeCallback(!0)}function R(e,n){!function(e){var n,t=!0===m.S.get(e.bidderCode,"allowZeroCpmBids")?e.cpm>=0:e.cpm>0;e.bidderCode&&(t||e.dealId)&&(n=function(e,n){var t=(arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}).index,r=void 0===t?h.K.index:t;if(!n)return{};var i=r.getBidRequest(n),o={},a=L(n.mediaType,e);H(o,a,n,i),e&&m.S.getOwn(e,E.k2.xn)&&(H(o,m.S.ownSettingsFor(e),n,i),n.sendStandardTargeting=m.S.get(e,"sendStandardTargeting"));n.native&&(o=Object.assign({},o,(0,u.Ur)(n)));return o}(e.bidderCode,e));e.adserverTargeting=Object.assign(e.adserverTargeting||{},n)}(n),b.j8(E.FP.BID_RESPONSE,n),e.addBidReceived(n),_(e,n)}function P(e,n,t){var r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},a=r.index,u=void 0===a?h.K.index:a,c=!0,s=(0,o.Z)(u.getMediaTypes({requestId:n.originalRequestId||n.requestId,transactionId:n.transactionId}),"video"),f=s&&(0,o.Z)(s,"context");d.vc.getConfig("cache.url")&&f!==p.gZ&&(!n.videoCacheKey||d.vc.getConfig("cache.ignoreBidderCacheKey")?(c=!1,N(e,n,t,s)):n.vastUrl||((0,i.logError)("videoCacheKey specified but not required vastUrl for video bid"),c=!1)),c&&(R(e,n),t())}var q,D,Z=function(e){(0,c.h)(e.map((function(e){return e.bidResponse})),(function(n,t){t.forEach((function(t,r){var o=e[r],a=o.auctionInstance,u=o.bidResponse,s=o.afterBidAdded;n?((0,i.logWarn)("Failed to save to the video cache: ".concat(n,". Video bid must be discarded.")),_(a,u)):""===t.uuid?((0,i.logWarn)("Supplied video cache key was already in use by Prebid Cache; caching attempt was rejected. Video bid must be discarded."),_(a,u)):(u.videoCacheKey=t.uuid,u.vastUrl||(u.vastUrl=(0,c.z)(u.videoCacheKey)),R(a,u),s())}))}))};d.vc.getConfig("cache",(function(e){q="number"==typeof e.cache.batchSize&&e.cache.batchSize>0?e.cache.batchSize:1,D="number"==typeof e.cache.batchTimeout&&e.cache.batchTimeout>0?e.cache.batchTimeout:0}));var x=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:setTimeout,n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:Z,t=[[]],r=!1,i=function(e){return e()};return function(o,a,u){var c=D>0?e:i;t[t.length-1].length>=q&&t.push([]),t[t.length-1].push({auctionInstance:o,bidResponse:a,afterBidAdded:u}),r||(r=!0,c((function(){t.forEach(n),t=[[]],r=!1}),D))}}(),N=(0,l.z3)("async",(function(e,n,t,r){x(e,n,t)}),"callPrebidCache");function M(e){var n=e.adUnitCode,t=e.bid,o=e.auctionId,u=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},c=u.index,f=void 0===c?h.K.index:c,l=f.getBidderRequest(t),g=l&&l.start||t.requestTimestamp,p=Object.assign({},t,{auctionId:o,responseTimestamp:(0,i.timestamp)(),requestTimestamp:g,cpm:parseFloat(t.cpm)||0,bidder:t.bidderCode,adUnitCode:n});p.timeToRespond=p.responseTimestamp-p.requestTimestamp,b.j8(E.FP.BID_ADJUSTMENT,p);var v=f.getAdUnit(p).renderer,m=p.mediaType,y=f.getMediaTypes(p),w=y&&y[m],C=w&&w.renderer,A=null;C&&C.url&&C.render&&(!0!==C.backupOnly||!t.renderer)?A=C:v&&v.url&&v.render&&(!0!==v.backupOnly||!t.renderer)&&(A=v),A&&(p.renderer=s.Th.install({url:A.url,config:A.options}),p.renderer.setRender(A.render));var I=F(t.mediaType,y,d.vc.getConfig("mediaTypePriceGranularity")),T=(0,a.D)(p.cpm,"object"===(0,r.Z)(I)?I:d.vc.getConfig("customPriceBucket"),d.vc.getConfig("currency.granularityMultiplier"));return p.pbLg=T.low,p.pbMg=T.med,p.pbHg=T.high,p.pbAg=T.auto,p.pbDg=T.dense,p.pbCg=T.custom,p}function F(e,n,t){if(e&&t){if(e===v.pX){var r=(0,o.Z)(n,"".concat(v.pX,".context"),"instream");if(t["".concat(v.pX,"-").concat(r)])return t["".concat(v.pX,"-").concat(r)]}return t[e]}}var W=function(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.index,r=void 0===t?h.K.index:t,i=F(e.mediaType,r.getMediaTypes(e),d.vc.getConfig("mediaTypePriceGranularity")),o="string"==typeof e.mediaType&&i?"string"==typeof i?i:"custom":d.vc.getConfig("priceGranularity");return o},z=function(e){return function(n){var t=e||W(n);return t===E.Ql.B7?n.pbAg:t===E.Ql.uN?n.pbDg:t===E.Ql.yE?n.pbLg:t===E.Ql.M2?n.pbMg:t===E.Ql.lj?n.pbHg:t===E.Ql.qN?n.pbCg:void 0}};function K(e,n){return{key:e,val:"function"==typeof n?function(e,t){return n(e,t)}:function(e){return(0,i.getValue)(e,n)}}}function L(e,n){var t=E.TD,r=Object.assign({},m.S.settingsFor(null));if(r[E.k2.xn]||(r[E.k2.xn]=function(){var e=E.TD;return[K(e.BIDDER,"bidderCode"),K(e.AD_ID,"adId"),K(e.PRICE_BUCKET,z()),K(e.SIZE,"size"),K(e.DEAL,"dealId"),K(e.SOURCE,"source"),K(e.FORMAT,"mediaType"),K(e.ADOMAIN,(function(e){return e.meta&&e.meta.advertiserDomains&&e.meta.advertiserDomains.length>0?e.meta.advertiserDomains[0]:""}))]}()),"video"===e){var a=r[E.k2.xn].slice();if(r[E.k2.xn]=a,[t.UUID,t.CACHE_ID].forEach((function(e){void 0===(0,g.sE)(a,(function(n){return n.key===e}))&&a.push(K(e,"videoCacheKey"))})),d.vc.getConfig("cache.url")&&(!n||!1!==m.S.get(n,"sendStandardTargeting"))){var u=(0,i.parseUrl)(d.vc.getConfig("cache.url"));void 0===(0,g.sE)(a,(function(e){return e.key===t.CACHE_HOST}))&&a.push(K(t.CACHE_HOST,(function(e){return(0,o.Z)(e,"adserverTargeting.".concat(t.CACHE_HOST))?e.adserverTargeting[t.CACHE_HOST]:u.hostname})))}}return r}function H(e,n,t,r){var o=n[E.k2.xn];return t.size=t.getSize(),(0,i._each)(o,(function(o){var a=o.key,u=o.val;if(e[a]&&(0,i.logWarn)("The key: "+a+" is being overwritten"),(0,i.isFn)(u))try{u=u(t,r)}catch(e){(0,i.logError)("bidmanager","ERROR",e)}(void 0===n.suppressEmptyKeys||!0!==n.suppressEmptyKeys)&&a!==E.TD.DEAL||!(0,i.isEmptyStr)(u)&&null!=u?e[a]=u:(0,i.logInfo)("suppressing empty key '"+a+"' from adserver targeting")})),e}function G(e,n){return e[n.adUnitCode]||(e[n.adUnitCode]={bids:[]}),e[n.adUnitCode].bids.push(n),e}},78653:function(e,n,t){t.d(n,{K:function(){return c}});var r=t(64358),i=t(25686),o=t(34614);function a(e){Object.assign(this,{getAuction:function(n){var t=n.auctionId;if(null!=t)return e().find((function(e){return e.getAuctionId()===t}))},getAdUnit:function(n){var t=n.transactionId;if(null!=t)return e().flatMap((function(e){return e.getAdUnits()})).find((function(e){return e.transactionId===t}))},getMediaTypes:function(e){var n=e.transactionId,t=e.requestId;if(null!=t){var r=this.getBidRequest({requestId:t});if(null!=r&&(null==n||r.transactionId===n))return r.mediaTypes}else if(null!=n){var i=this.getAdUnit({transactionId:n});if(null!=i)return i.mediaTypes}},getBidderRequest:function(n){var t=n.requestId,r=n.bidderRequestId;if(null!=t||null!=r){var i=e().flatMap((function(e){return e.getBidRequests()}));return null!=r&&(i=i.filter((function(e){return e.bidderRequestId===r}))),null==t?i[0]:i.find((function(e){return e.bids&&null!=e.bids.find((function(e){return e.bidId===t}))}))}},getBidRequest:function(n){var t=n.requestId;if(null!=t)return e().flatMap((function(e){return e.getBidRequests()})).flatMap((function(e){return e.bids})).find((function(e){return e&&e.bidId===t}))}})}var u=t(5644);var c=function(){var e=[],n={};return n.addWinningBid=function(n){var t=(0,o.sE)(e,(function(e){return e.getAuctionId()===n.auctionId}));t?(n.status=u.UE.fe,t.addWinningBid(n)):(0,r.logWarn)("Auction not found when adding winning bid")},n.getAllWinningBids=function(){return e.map((function(e){return e.getWinningBids()})).reduce(r.flatten,[])},n.getBidsRequested=function(){return e.map((function(e){return e.getBidRequests()})).reduce(r.flatten,[])},n.getNoBids=function(){return e.map((function(e){return e.getNoBids()})).reduce(r.flatten,[])},n.getBidsReceived=function(){return e.map((function(e){if(e.getAuctionStatus()===i.mv)return e.getBidsReceived()})).reduce(r.flatten,[]).filter((function(e){return e}))},n.getAllBidsForAdUnitCode=function(n){return e.map((function(e){return e.getBidsReceived()})).reduce(r.flatten,[]).filter((function(e){return e&&e.adUnitCode===n}))},n.getAdUnits=function(){return e.map((function(e){return e.getAdUnits()})).reduce(r.flatten,[])},n.getAdUnitCodes=function(){return e.map((function(e){return e.getAdUnitCodes()})).reduce(r.flatten,[]).filter(r.uniques)},n.createAuction=function(n){var t=(0,i.vO)(n);return function(n){e.push(n)}(t),t},n.findBidByAdId=function(n){return(0,o.sE)(e.map((function(e){return e.getBidsReceived()})).reduce(r.flatten,[]),(function(e){return e.adId===n}))},n.getStandardBidderAdServerTargeting=function(){return(0,i.LX)()[u.k2.xn]},n.setStatusForBids=function(t,r){var i=n.findBidByAdId(t);if(i&&(i.status=r),i&&r===u.UE.CK){var a=(0,o.sE)(e,(function(e){return e.getAuctionId()===i.auctionId}));a&&a.setBidTargeting(i)}},n.getLastAuctionId=function(){return e.length&&e[e.length-1].getAuctionId()},n.clearAllAuctions=function(){e.length=0},n.index=new a((function(){return e})),n}()},55975:function(e,n,t){t.d(n,{S:function(){return g}});var r=t(15671),i=t(43144),o=t(20265),a=t(64358),u=t(78640),c=t(5644);function s(e,n){!function(e,n){if(n.has(e))throw new TypeError("Cannot initialize the same private elements twice on an object")}(e,n),n.add(e)}function d(e,n,t){if(!n.has(e))throw new TypeError("attempted to get private field on non-instance");return t}var f=new WeakSet;function l(e){return null==e?this.defaultScope:e}var g=new(function(){function e(n,t){(0,r.Z)(this,e),s(this,f),this.getSettings=n,this.defaultScope=t}return(0,i.Z)(e,[{key:"get",value:function(e,n){var t=this.getOwn(e,n);return void 0===t&&(t=this.getOwn(null,n)),t}},{key:"getOwn",value:function(e,n){return e=d(this,f,l).call(this,e),(0,o.Z)(this.getSettings(),"".concat(e,".").concat(n))}},{key:"getScopes",value:function(){var e=this;return Object.keys(this.getSettings()).filter((function(n){return n!==e.defaultScope}))}},{key:"settingsFor",value:function(e){return(0,a.mergeDeep)({},this.ownSettingsFor(null),this.ownSettingsFor(e))}},{key:"ownSettingsFor",value:function(e){return e=d(this,f,l).call(this,e),this.getSettings()[e]||{}}}]),e}())((function(){return(0,u.R)().bidderSettings||{}}),c.k2.zF)},69626:function(e,n,t){t.d(n,{m:function(){return o}});var r=t(64358);function i(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.src,i=void 0===t?"client":t,o=n.bidder,a=void 0===o?"":o,u=n.bidId,c=n.transactionId,s=n.auctionId,d=i,f=e||0;function l(){switch(f){case 0:return"Pending";case 1:return"Bid available";case 2:return"Bid returned empty or error response";case 3:return"Bid timed out"}}this.bidderCode=a,this.width=0,this.height=0,this.statusMessage=l(),this.adId=(0,r.getUniqueIdentifierStr)(),this.requestId=u,this.transactionId=c,this.auctionId=s,this.mediaType="banner",this.source=d,this.getStatusCode=function(){return f},this.getSize=function(){return this.width+"x"+this.height},this.getIdentifiers=function(){return{src:this.source,bidder:this.bidderCode,bidId:this.requestId,transactionId:this.transactionId,auctionId:this.auctionId}}}function o(e,n){return new i(e,n)}},3193:function(e,n,t){t.d(n,{FD:function(){return g},vc:function(){return b}});var r=t(4942),i=t(71002),o=t(93324),a=t(56463),u=t(34614),c=t(64358),s=t(20265),d=t(5644);function f(e,n){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n&&(r=r.filter((function(n){return Object.getOwnPropertyDescriptor(e,n).enumerable}))),t.push.apply(t,r)}return t}var l="TRUE"===(0,c.getParameterByName)(d.f).toUpperCase(),g="random",p={};p[g]=!0,p.fixed=!0;var v=g,h={LOW:"low",MEDIUM:"medium",HIGH:"high",AUTO:"auto",DENSE:"dense",CUSTOM:"custom"},m="*";var b=function(){var e,n,t,d=[],g=null;function b(){e={};var r={_debug:l,get debug(){return this._debug},set debug(e){this._debug=e},_bidderTimeout:3e3,get bidderTimeout(){return this._bidderTimeout},set bidderTimeout(e){this._bidderTimeout=e},_publisherDomain:null,get publisherDomain(){return this._publisherDomain},set publisherDomain(e){(0,c.logWarn)("publisherDomain is deprecated and has no effect since v7 - use pageUrl instead"),this._publisherDomain=e},_priceGranularity:h.MEDIUM,set priceGranularity(e){o(e)&&("string"==typeof e?this._priceGranularity=i(e)?e:h.MEDIUM:(0,c.isPlainObject)(e)&&(this._customPriceBucket=e,this._priceGranularity=h.CUSTOM,(0,c.logMessage)("Using custom price granularity")))},get priceGranularity(){return this._priceGranularity},_customPriceBucket:{},get customPriceBucket(){return this._customPriceBucket},_mediaTypePriceGranularity:{},get mediaTypePriceGranularity(){return this._mediaTypePriceGranularity},set mediaTypePriceGranularity(e){var n=this;this._mediaTypePriceGranularity=Object.keys(e).reduce((function(t,r){return o(e[r])?"string"==typeof e?t[r]=i(e[r])?e[r]:n._priceGranularity:(0,c.isPlainObject)(e)&&(t[r]=e[r],(0,c.logMessage)("Using custom price granularity for ".concat(r))):(0,c.logWarn)("Invalid price granularity for media type: ".concat(r)),t}),{})},_sendAllBids:true,get enableSendAllBids(){return this._sendAllBids},set enableSendAllBids(e){this._sendAllBids=e},_useBidCache:false,get useBidCache(){return this._useBidCache},set useBidCache(e){this._useBidCache=e},_deviceAccess:true,get deviceAccess(){return this._deviceAccess},set deviceAccess(e){this._deviceAccess=e},_bidderSequence:v,get bidderSequence(){return this._bidderSequence},set bidderSequence(e){p[e]?this._bidderSequence=e:(0,c.logWarn)("Invalid order: ".concat(e,". Bidder Sequence was not set."))},_timeoutBuffer:400,get timeoutBuffer(){return this._timeoutBuffer},set timeoutBuffer(e){this._timeoutBuffer=e},_disableAjaxTimeout:false,get disableAjaxTimeout(){return this._disableAjaxTimeout},set disableAjaxTimeout(e){this._disableAjaxTimeout=e},_maxNestedIframes:10,get maxNestedIframes(){return this._maxNestedIframes},set maxNestedIframes(e){this._maxNestedIframes=e},_auctionOptions:{},get auctionOptions(){return this._auctionOptions},set auctionOptions(e){(function(e){if(!(0,c.isPlainObject)(e))return(0,c.logWarn)("Auction Options must be an object"),!1;for(var n=0,t=Object.keys(e);n<t.length;n++){var r=t[n];if("secondaryBidders"!==r&&"suppressStaleRender"!==r)return(0,c.logWarn)("Auction Options given an incorrect param: ".concat(r)),!1;if("secondaryBidders"===r){if(!(0,c.isArray)(e[r]))return(0,c.logWarn)("Auction Options ".concat(r," must be of type Array")),!1;if(!e[r].every(c.isStr))return(0,c.logWarn)("Auction Options ".concat(r," must be only string")),!1}else if("suppressStaleRender"===r&&!(0,c.isBoolean)(e[r]))return(0,c.logWarn)("Auction Options ".concat(r," must be of type boolean")),!1}return!0})(e)&&(this._auctionOptions=e)}};function i(e){return(0,u.sE)(Object.keys(h),(function(n){return e===h[n]}))}function o(e){if(!e)return(0,c.logError)("Prebid Error: no value passed to `setPriceGranularity()`"),!1;if("string"==typeof e)i(e)||(0,c.logWarn)("Prebid Warning: setPriceGranularity was called with invalid setting, using `medium` as default.");else if((0,c.isPlainObject)(e)&&!(0,a.t)(e))return(0,c.logError)("Invalid custom price value passed to `setPriceGranularity()`"),!1;return!0}n&&j(Object.keys(n).reduce((function(e,t){return n[t]!==r[t]&&(e[t]=r[t]||{}),e}),{})),n=r,t={}}function y(){if(g&&t&&(0,c.isPlainObject)(t[g])){var e=t[g],r=new Set(Object.keys(n).concat(Object.keys(e)));return(0,u.Oc)(r).reduce((function(t,r){return void 0===e[r]?t[r]=n[r]:void 0===n[r]?t[r]=e[r]:(0,c.isPlainObject)(e[r])?t[r]=(0,c.mergeDeep)({},n[r],e[r]):t[r]=e[r],t}),{})}return Object.assign({},n)}var E=[y,function(){var e=y();return Object.defineProperty(e,"ortb2",{get:function(){throw new Error("invalid access to 'orbt2' config - use request parameters instead")}}),e}].map((function(e){return function(){if(arguments.length<=1&&"function"!=typeof(arguments.length<=0?void 0:arguments[0])){var n=arguments.length<=0?void 0:arguments[0];return n?(0,s.Z)(e(),n):y()}return k.apply(void 0,arguments)}})),w=(0,o.Z)(E,2),C=w[0],A=w[1],I=[A,C].map((function(e){return function(){var n=e.apply(void 0,arguments);return n&&"object"===(0,i.Z)(n)&&(n=(0,c.deepClone)(n)),n}})),T=(0,o.Z)(I,2),O=T[0],S=T[1];function B(t){if((0,c.isPlainObject)(t)){var r=Object.keys(t),i={};r.forEach((function(r){var o=t[r];(0,c.isPlainObject)(e[r])&&(0,c.isPlainObject)(o)&&(o=Object.assign({},e[r],o));try{i[r]=n[r]=o}catch(e){(0,c.logWarn)("Cannot set config for property ".concat(r," : "),e)}})),j(i)}else(0,c.logError)("setConfig options must be an object")}function k(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},i=n;if("string"!=typeof e&&(i=e,e=m,t=n||{}),"function"==typeof i){var o={topic:e,callback:i};return d.push(o),t.init&&i(e===m?A():(0,r.Z)({},e,A(e))),function(){d.splice(d.indexOf(o),1)}}(0,c.logError)("listener must be a function")}function j(e){var n=Object.keys(e);d.filter((function(e){return(0,u.q9)(n,e.topic)})).forEach((function(n){n.callback((0,r.Z)({},n.topic,e[n.topic]))})),d.filter((function(e){return e.topic===m})).forEach((function(n){return n.callback(e)}))}function U(e){var n=arguments.length>1&&void 0!==arguments[1]&&arguments[1];try{r(e),e.bidders.forEach((function(r){t[r]||(t[r]={}),Object.keys(e.config).forEach((function(i){var o=e.config[i];if((0,c.isPlainObject)(o)){var a=n?c.mergeDeep:Object.assign;t[r][i]=a({},t[r][i]||{},o)}else t[r][i]=o}))}))}catch(e){(0,c.logError)(e)}function r(e){if(!(0,c.isPlainObject)(e))throw"setBidderConfig bidder options must be an object";if(!Array.isArray(e.bidders)||!e.bidders.length)throw"setBidderConfig bidder options must contain a bidders list with at least 1 bidder";if(!(0,c.isPlainObject)(e.config))throw"setBidderConfig bidder options must contain a config object"}}function _(e,n){g=e;try{return n()}finally{R()}}function R(){g=null}return b(),{getCurrentBidder:function(){return g},resetBidder:R,getConfig:A,getAnyConfig:C,readConfig:O,readAnyConfig:S,setConfig:B,mergeConfig:function(e){if((0,c.isPlainObject)(e)){var n=(0,c.mergeDeep)(y(),e);return B(function(e){for(var n=1;n<arguments.length;n++){var t=null!=arguments[n]?arguments[n]:{};n%2?f(Object(t),!0).forEach((function(n){(0,r.Z)(e,n,t[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):f(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}))}return e}({},n)),n}(0,c.logError)("mergeConfig input must be an object")},setDefaults:function(t){(0,c.isPlainObject)(e)?(Object.assign(e,t),Object.assign(n,t)):(0,c.logError)("defaults must be an object")},resetConfig:b,runWithBidder:_,callbackWithBidder:function(e){return function(n){return function(){if("function"==typeof n){for(var t=arguments.length,r=new Array(t),i=0;i<t;i++)r[i]=arguments[i];return _(e,c.bind.call.apply(c.bind,[n,this].concat(r)))}(0,c.logWarn)("config.callbackWithBidder callback is not a function")}}},setBidderConfig:U,getBidderConfig:function(){return t},mergeBidderConfig:function(e){return U(e,!0)}}}()},56463:function(e,n,t){t.d(n,{D:function(){return d},t:function(){return l}});var r=t(34614),i=t(64358),o={buckets:[{max:5,increment:.5}]},a={buckets:[{max:20,increment:.1}]},u={buckets:[{max:20,increment:.01}]},c={buckets:[{max:3,increment:.01},{max:8,increment:.05},{max:20,increment:.5}]},s={buckets:[{max:5,increment:.05},{max:10,increment:.1},{max:20,increment:.5}]};function d(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1,r=parseFloat(e);return isNaN(r)&&(r=""),{low:""===r?"":f(e,o,t),med:""===r?"":f(e,a,t),high:""===r?"":f(e,u,t),auto:""===r?"":f(e,s,t),dense:""===r?"":f(e,c,t),custom:""===r?"":f(e,n,t)}}function f(e,n,t){var i="";if(!l(n))return i;var o=n.buckets.reduce((function(e,n){return e.max>n.max?e:n}),{max:0}),a=0,u=(0,r.sE)(n.buckets,(function(n){if(e>o.max*t){var r=n.precision;void 0===r&&(r=2),i=(n.max*t).toFixed(r)}else{if(e<=n.max*t&&e>=a*t)return n.min=a,n;a=n.max}}));return u&&(i=function(e,n,t){var r=void 0!==n.precision?n.precision:2,i=n.increment*t,o=n.min*t,a=Math.pow(10,r+2),u=(e*a-o*a)/(i*a),c=Math.floor(u)*i+o;return(c=Number(c.toFixed(10))).toFixed(r)}(e,u,t)),i}function l(e){if((0,i.isEmpty)(e)||!e.buckets||!Array.isArray(e.buckets))return!1;var n=!0;return e.buckets.forEach((function(e){e.max&&e.increment||(n=!1)})),n}},53777:function(e,n,t){t.d(n,{Jc:function(){return d},dF:function(){return v}});var r=t(3193),i=t(92797),o=t(78640),a=t(64358),u=t(69626),c=t(55730),s=t(68792),d="__pbjs_debugging__";function f(){return(0,o.R)().installedModules.includes("debugging")}function l(e){return new s.Z((function(n){(0,c.B)(e,"debugging",n)}))}function g(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.alreadyInstalled,t=void 0===n?f:n,c=e.script,g=void 0===c?l:c,p=null;return function(){return null==p&&(p=new s.Z((function(e,n){setTimeout((function(){if(t())e();else{var c="https://cdn.jsdelivr.net/npm/prebid.js@7.12.0/dist/debugging-standalone.js";(0,a.logMessage)('Debugging module not installed, loading it from "'.concat(c,'"...')),(0,o.R)()._installDebugging=!0,g(c).then((function(){(0,o.R)()._installDebugging({DEBUG_KEY:d,hook:i.z3,config:r.vc,createBid:u.m,logger:(0,a.prefixLog)("DEBUG:")})})).then(e,n)}}))}))),p}}var p=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.load,t=void 0===n?g():n,r=e.hook,o=void 0===r?(0,i.v5)("requestBids"):r,a=null,u=!1;function c(e){for(var n=this,t=arguments.length,r=new Array(t>1?t-1:0),i=1;i<t;i++)r[i-1]=arguments[i];return(a||s.Z.resolve()).then((function(){return e.apply(n,r)}))}function d(){u||(a=t(),o.before(c,99),u=!0)}function f(){o.getHooks({hook:c}).remove(),u=!1}function l(){a=null,f()}return{enable:d,disable:f,reset:l}}();p.reset;function v(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.storage,t=void 0===n?window.sessionStorage:n,r=e.debugging,i=void 0===r?p:r,o=null;try{o=t.getItem(d)}catch(e){}null!=o&&i.enable()}r.vc.getConfig("debugging",(function(e){var n=e.debugging;null!=n&&n.enabled?p.enable():p.disable()}))},52021:function(e,n,t){t.d(n,{S1:function(){return l},j8:function(){return p},on:function(){return f},vw:function(){return g}});var r=t(64358),i=t(5644),o=Array.prototype.slice,a=Array.prototype.push,u=r._map(i.FP,(function(e){return e})),c=i.aI,s=[],d=function(){var e={},n={};function t(n,t){r.logMessage("Emitting event for: "+n);var i=t[0]||{},o=i[c[n]],u=e[n]||{que:[]},d=r._map(u,(function(e,n){return n})),f=[];s.push({eventType:n,args:i,id:o,elapsedTime:r.getPerformanceNow()}),o&&r.contains(d,o)&&a.apply(f,u[o].que),a.apply(f,u.que),r._each(f,(function(e){if(e)try{e.apply(null,t)}catch(e){r.logError("Error executing handler:","events.js",e)}}))}return n.on=function(n,t,i){if(function(e){return r.contains(u,e)}(n)){var o=e[n]||{que:[]};i?(o[i]=o[i]||{que:[]},o[i].que.push(t)):o.que.push(t),e[n]=o}else r.logError("Wrong event name : "+n+" Valid event names :"+u)},n.emit=function(e){var n=o.call(arguments,1);t(e,n)},n.off=function(n,t,i){var o=e[n];r.isEmpty(o)||r.isEmpty(o.que)&&r.isEmpty(o[i])||i&&(r.isEmpty(o[i])||r.isEmpty(o[i].que))||(i?r._each(o[i].que,(function(e){var n=o[i].que;e===t&&n.splice(n.indexOf(e),1)})):r._each(o.que,(function(e){var n=o.que;e===t&&n.splice(n.indexOf(e),1)})),e[n]=o)},n.get=function(){return e},n.getEvents=function(){var e=[];return r._each(s,(function(n){var t=Object.assign({},n);e.push(t)})),e},n}();r._setEventEmitter(d.emit.bind(d));var f=d.on,l=d.off,g=(d.get,d.getEvents),p=d.emit},92797:function(e,n,t){t.d(n,{Bx:function(){return p},Cd:function(){return s},IF:function(){return v},bA:function(){return g},o0:function(){return f},v5:function(){return d},z3:function(){return u}});var r=t(89062),i=t(81432),o=t.n(i),a=t(68792),u=o()({ready:o().SYNC|o().ASYNC|o().QUEUE}),c=(0,a.P)();u.ready=function(){var e=u.ready;return function(){try{return e.apply(u,arguments)}finally{c.resolve()}}}();var s=c.promise,d=u.get;function f(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:15,r=e.getHooks({hook:n});0===r.length&&e.before(n,t)}var l={};function g(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},i=t.postInstallAllowed,o=void 0!==i&&i;u("async",(function(t){t.forEach((function(e){return n.apply(void 0,(0,r.Z)(e))})),o&&(l[e]=n)}),e)([])}function p(e){for(var n=arguments.length,t=new Array(n>1?n-1:0),r=1;r<n;r++)t[r-1]=arguments[r];var i=l[e];if(i)return i.apply(void 0,t);d(e).before((function(e,n){n.push(t),e(n)}))}function v(e,n){return Object.defineProperties(n,Object.fromEntries(["before","after","getHooks","removeAll"].map((function(n){return[n,{get:function(){return e[n]}}]})))),n}},24679:function(e,n,t){t.d(n,{B5:function(){return r},Mk:function(){return o},Oh:function(){return a},pX:function(){return i}});var r="native",i="video",o="banner",a="adpod"},70059:function(e,n,t){t.d(n,{Fb:function(){return B},JL:function(){return Z},Sg:function(){return h},Ur:function(){return R},e6:function(){return _},eK:function(){return D},lY:function(){return F},r4:function(){return j},xc:function(){return m}});var r=t(93324),i=t(71002),o=t(4942),a=t(20265),u=t(64358),c=t(34614),s=t(78653),d=t(5644),f=t(24679);function l(e,n){var t="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(!t){if(Array.isArray(e)||(t=function(e,n){if(!e)return;if("string"==typeof e)return g(e,n);var t=Object.prototype.toString.call(e).slice(8,-1);"Object"===t&&e.constructor&&(t=e.constructor.name);if("Map"===t||"Set"===t)return Array.from(e);if("Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t))return g(e,n)}(e))||n&&e&&"number"==typeof e.length){t&&(e=t);var r=0,i=function(){};return{s:i,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(e){throw e},f:i}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var o,a=!0,u=!1;return{s:function(){t=t.call(e)},n:function(){var e=t.next();return a=e.done,e},e:function(e){u=!0,o=e},f:function(){try{a||null==t.return||t.return()}finally{if(u)throw o}}}}function g(e,n){(null==n||n>e.length)&&(n=e.length);for(var t=0,r=new Array(n);t<n;t++)r[t]=e[t];return r}function p(e,n){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n&&(r=r.filter((function(n){return Object.getOwnPropertyDescriptor(e,n).enumerable}))),t.push.apply(t,r)}return t}function v(e){for(var n=1;n<arguments.length;n++){var t=null!=arguments[n]?arguments[n]:{};n%2?p(Object(t),!0).forEach((function(n){(0,o.Z)(e,n,t[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):p(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}))}return e}var h=[],m=Object.keys(d.FY).map((function(e){return d.FY[e]})),b={image:{ortb:{ver:"1.2",assets:[{required:1,id:1,img:{type:3,wmin:100,hmin:100}},{required:1,id:2,title:{len:140}},{required:1,id:3,data:{type:1}},{required:0,id:4,data:{type:2}},{required:0,id:5,img:{type:1,wmin:20,hmin:20}}]},image:{required:!0},title:{required:!0},sponsoredBy:{required:!0},clickUrl:{required:!0},body:{required:!1},icon:{required:!1}}},y=d.s$,E=d.oF,w=d.V1,C=d.zA,A=L(w),I=L(y),T={img:1,js:2,1:"img",2:"js"},O=1;function S(e){if(e&&e.type&&function(e){if(!e||!(0,c.q9)(Object.keys(b),e))return(0,u.logError)("".concat(e," nativeParam is not supported")),!1;return!0}(e.type)&&(e=b[e.type]),!e||!e.ortb||k(e.ortb))return e}function B(e){e.forEach((function(e){var n=e.nativeParams||(0,a.Z)(e,"mediaTypes.native");n&&(e.nativeParams=S(n)),e.nativeParams&&(e.nativeOrtbRequest=e.nativeParams.ortb||function(e){if(!e&&!(0,u.isPlainObject)(e))return void(0,u.logError)("Native assets object is empty or not an object: ",e);var n={ver:"1.2",assets:[]};for(var t in e)if(!C.includes(t)){var r=e[t],i=0;r.required&&(0,u.isBoolean)(r.required)&&(i=Number(r.required));var o={id:n.assets.length,required:i};if(t in w)o.data={type:y[w[t]]},r.len&&(o.data.len=r.len);else if("icon"===t||"image"===t){if(o.img={type:"icon"===t?E.ICON:E.MAIN},r.aspect_ratios)if((0,u.isArray)(r.aspect_ratios))if(r.aspect_ratios.length){var a=r.aspect_ratios[0],c=a.min_width,s=a.min_height;(0,u.isInteger)(c)&&(0,u.isInteger)(s)?(o.img.wmin=c,o.img.hmin=s):(0,u.logError)("image.aspect_ratios min_width or min_height are invalid: ",c,s);var d=r.aspect_ratios.filter((function(e){return e.ratio_width&&e.ratio_height})).map((function(e){return"".concat(e.ratio_width,":").concat(e.ratio_height)}));d.length>0&&(o.img.ext={aspectratios:d})}else(0,u.logError)("image.aspect_ratios was passed, but it's empty:",r.aspect_ratios);else(0,u.logError)("image.aspect_ratios was passed, but it's not a an array:",r.aspect_ratios);r.sizes&&(2===r.sizes.length&&(0,u.isInteger)(r.sizes[0])&&(0,u.isInteger)(r.sizes[1])?(o.img.w=r.sizes[0],o.img.h=r.sizes[1],delete o.img.hmin,delete o.img.wmin):(0,u.logError)("image.sizes was passed, but its value is not an array of integers:",r.sizes))}else"title"===t?o.title={len:r.len||140}:"ext"===t&&(o.ext=r,delete o.required);n.assets.push(o)}return n}(e.nativeParams))}))}function k(e){var n=e.assets;if(!Array.isArray(n)||0===n.length)return(0,u.logError)("assets in mediaTypes.native.ortb is not an array, or it's empty. Assets: ",n),!1;var t=n.map((function(e){return e.id}));return n.length!==new Set(t).size||t.some((function(e){return e!==parseInt(e,10)}))?((0,u.logError)("each asset object must have 'id' property, it must be unique and it must be an integer"),!1):e.hasOwnProperty("eventtrackers")&&!Array.isArray(e.eventtrackers)?((0,u.logError)("ortb.eventtrackers is not an array. Eventtrackers: ",e.eventtrackers),!1):n.every((function(e){return function(e){if(!(0,u.isPlainObject)(e))return(0,u.logError)("asset must be an object. Provided asset: ",e),!1;if(e.img){if(!(0,u.isNumber)(e.img.w)&&!(0,u.isNumber)(e.img.wmin))return(0,u.logError)("for img asset there must be 'w' or 'wmin' property"),!1;if(!(0,u.isNumber)(e.img.h)&&!(0,u.isNumber)(e.img.hmin))return(0,u.logError)("for img asset there must be 'h' or 'hmin' property"),!1}else if(e.title){if(!(0,u.isNumber)(e.title.len))return(0,u.logError)("for title asset there must be 'len' property defined"),!1}else if(e.data){if(!(0,u.isNumber)(e.data.type))return(0,u.logError)("for data asset 'type' property must be a number"),!1}else if(e.video&&!(Array.isArray(e.video.mimes)&&Array.isArray(e.video.protocols)&&(0,u.isNumber)(e.video.minduration)&&(0,u.isNumber)(e.video.maxduration)))return(0,u.logError)("video asset is not properly configured"),!1;return!0}(e)}))}function j(e){var n,t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=t.index,i=void 0===r?s.K.index:r,o=i.getAdUnit(e);if(!o)return!1;var a=o.nativeOrtbRequest,u=(null===(n=e.native)||void 0===n?void 0:n.ortb)||z(e.native,a);return U(u,a)}function U(e,n){if(!(0,a.Z)(e,"link.url"))return(0,u.logError)("native response doesn't have 'link' property. Ortb response: ",e),!1;var t=n.assets.filter((function(e){return 1===e.required})).map((function(e){return e.id})),r=e.assets.map((function(e){return e.id})),i=t.every((function(e){return(0,c.q9)(r,e)}));return i||(0,u.logError)("didn't receive a bid with all required assets. Required ids: ".concat(t,", but received ids in response: ").concat(r)),i}function _(e,n){var t=n.native.ortb||W(n.native);return"click"===e.action?function(e){var n,t=(arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}).fetchURL,r=void 0===t?u.triggerPixel:t;((null===(n=e.link)||void 0===n?void 0:n.clicktrackers)||[]).forEach((function(e){return r(e)}))}(t):function(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.runMarkup,r=void 0===t?function(e){return(0,u.insertHtmlIntoIframe)(e)}:t,i=n.fetchURL,o=void 0===i?u.triggerPixel:i,a=(e.eventtrackers||[]).filter((function(e){return e.event===O})).reduce((function(e,n){return T.hasOwnProperty(n.method)&&e[T[n.method]].push(n.url),e}),{img:[],js:[]}),c=a.img,s=a.js;e.imptrackers&&(c=c.concat(e.imptrackers));c.forEach((function(e){return o(e)})),s=s.map((function(e){return'<script async src="'.concat(e,'"><\/script>')})),e.jstracker&&(s=s.concat([e.jstracker]));s.length&&r(s.join("\n"))}(t),e.action}function R(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.index,r=void 0===t?s.K.index:t,i={},o=r.getAdUnit(e);(0,a.Z)(o,"nativeParams.rendererUrl")?e.native.rendererUrl=x(o.nativeParams.rendererUrl):(0,a.Z)(o,"nativeParams.adTemplate")&&(e.native.adTemplate=x(o.nativeParams.adTemplate));var u=!1!==(0,a.Z)(o,"nativeParams.sendTargetingKeys"),c=N(o),d=v(v({},e.native),e.native.ext);return delete d.ext,Object.keys(d).forEach((function(n){var t=c[n],r=x(e.native[n])||x((0,a.Z)(e,"native.ext.".concat(n)));if("adTemplate"!==n&&t&&r){var s=(0,a.Z)(o,"nativeParams.".concat(n,".sendId"));if("boolean"!=typeof s&&(s=(0,a.Z)(o,"nativeParams.ext.".concat(n,".sendId"))),s)r="".concat(t,":").concat(e.adId);var d=(0,a.Z)(o,"nativeParams.".concat(n,".sendTargetingKeys"));"boolean"!=typeof d&&(d=(0,a.Z)(o,"nativeParams.ext.".concat(n,".sendTargetingKeys"))),("boolean"==typeof d?d:u)&&(i[t]=r)}})),i}var P=function(e){var n;return null===(n=s.K.index.getAdUnit(e))||void 0===n?void 0:n.nativeOrtbRequest};function q(e,n,t){var r,i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},o=i.getNativeReq,a=void 0===o?P:o,u={message:"assetResponse",adId:e.adId},c=a(n),s=n.native,f=null===(r=n.native)||void 0===r?void 0:r.ortb,l={};return c&&f&&(l=K(f,c),s=v(v({},n.native),l)),n.native.ortb&&(u.ortb=n.native.ortb),u.assets=[],(null==t?Object.keys(s):t).forEach((function(e){if("adTemplate"===e&&s[e])u.adTemplate=x(s[e]);else if("rendererUrl"===e&&s[e])u.rendererUrl=x(s[e]);else if("ext"===e)Object.keys(s[e]).forEach((function(n){if(s[e][n]){var t=x(s[e][n]);u.assets.push({key:n,value:t})}}));else if(s[e]&&d.FY.hasOwnProperty(e)){var n=x(s[e]);u.assets.push({key:e,value:n})}})),u}function D(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=t.getNativeReq,i=void 0===r?P:r,o=e.assets.map((function(e){return(0,u.getKeyByValue)(d.FY,e)}));return q(e,n,o,{getNativeReq:i})}function Z(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=t.getNativeReq,i=void 0===r?P:r;return q(e,n,null,{getNativeReq:i})}function x(e){return"object"===(0,i.Z)(e)&&e.url?e.url:e}function N(e){var n={};return(0,a.Z)(e,"nativeParams.ext")&&Object.keys(e.nativeParams.ext).forEach((function(e){n[e]="hb_native_".concat(e)})),v(v({},d.FY),n)}function M(e){if(k(e)){var n,t={},r=l(e.assets);try{var i=function(){var e=n.value;if(e.title){var r={required:!!e.required&&Boolean(e.required),len:e.title.len};t.title=r}else if(e.img){var i={required:!!e.required&&Boolean(e.required)};e.img.w&&e.img.h?i.sizes=[e.img.w,e.img.h]:e.img.wmin&&e.img.hmin&&(i.aspect_ratios={min_width:e.img.wmin,min_height:e.img.hmin,ratio_width:e.img.wmin,ratio_height:e.img.hmin}),e.img.type===E.MAIN?t.image=i:t.icon=i}else if(e.data){var o=Object.keys(y).find((function(n){return y[n]===e.data.type})),a=Object.keys(w).find((function(e){return w[e]===o}));t[a]={required:!!e.required&&Boolean(e.required)},e.data.len&&(t[a].len=e.data.len)}};for(r.s();!(n=r.n()).done;)i()}catch(e){r.e(e)}finally{r.f()}return t}}function F(e){if(!e||!(0,u.isArray)(e))return e;if(!e.some((function(e){var n;return null===(n=((null==e?void 0:e.mediaTypes)||{})[f.B5])||void 0===n?void 0:n.ortb})))return e;var n,t=(0,u.deepClone)(e),r=l(t);try{for(r.s();!(n=r.n()).done;){var i=n.value;i.mediaTypes&&i.mediaTypes[f.B5]&&i.mediaTypes[f.B5].ortb&&(i.mediaTypes[f.B5]=Object.assign((0,u.pick)(i.mediaTypes[f.B5],C),M(i.mediaTypes[f.B5].ortb)),i.nativeParams=S(i.mediaTypes[f.B5]))}}catch(e){r.e(e)}finally{r.f()}return t}function W(e){var n={link:{},eventtrackers:[]};return Object.entries(e).forEach((function(e){var t=(0,r.Z)(e,2),i=t[0],o=t[1];switch(i){case"clickUrl":n.link.url=o;break;case"clickTrackers":n.link.clicktrackers=Array.isArray(o)?o:[o];break;case"impressionTrackers":(Array.isArray(o)?o:[o]).forEach((function(e){n.eventtrackers.push({event:O,method:T.img,url:e})}));break;case"javascriptTrackers":n.jstracker=Array.isArray(o)?o.join(""):o}})),n}function z(e,n){var t=v(v({},W(e)),{},{assets:[]});function r(e,r){var i=n.assets.find(e);null!=i&&(r(i=(0,u.deepClone)(i)),t.assets.push(i))}return Object.keys(e).filter((function(n){return!!e[n]})).forEach((function(n){var t=e[n];switch(n){case"title":r((function(e){return null!=e.title}),(function(e){e.title={text:t}}));break;case"image":case"icon":var i="image"===n?E.MAIN:E.ICON;r((function(e){return null!=e.img&&e.img.type===i}),(function(e){e.img={url:t}}));break;default:n in w&&r((function(e){return null!=e.data&&e.data.type===y[w[n]]}),(function(e){e.data={value:t}}))}})),t}function K(e,n){var t={},r=(null==n?void 0:n.assets)||[];t.clickUrl=e.link.url,t.privacyLink=e.privacy;var i,o=l((null==e?void 0:e.assets)||[]);try{var a=function(){var e=i.value,n=r.find((function(n){return e.id===n.id}));e.title?t.title=e.title.text:e.img?t[n.img.type===E.MAIN?"image":"icon"]=e.img.url:e.data&&(t[A[I[n.data.type]]]=e.data.value)};for(o.s();!(i=o.n()).done;)a()}catch(e){o.e(e)}finally{o.f()}return t}function L(e){var n={};for(var t in e)n[e[t]]=t;return n}},34614:function(e,n,t){function r(e,n,t){return e&&e.includes(n,t)||!1}function i(){return Array.from.apply(Array,arguments)}function o(e,n,t){return e&&e.find(n,t)}function a(e,n,t){return e&&e.findIndex(n,t)}t.d(n,{Oc:function(){return i},cx:function(){return a},q9:function(){return r},sE:function(){return o}})},23866:function(e,n,t){t.d(n,{zh:function(){return re},O5:function(){return oe},ew:function(){return ce}});var r=t(93324),i=t(4942),o=t(78640),a=t(64358),u=t(20265),c=t(44806),s=t(52021),d=t(70059),f=t(5644),l=t(78653),g=t(34614),p=t(35706),v=t(3193),h=f.FP,m=h.AD_RENDER_FAILED,b=h.AD_RENDER_SUCCEEDED;function y(e){var n=e.reason,t=e.message,r=e.bid,i=e.id,o={reason:n,message:t};r&&(o.bid=r),i&&(o.adId=i),(0,a.logError)(t),s.j8(m,o)}function E(e){var n=e.doc,t=e.bid,r=e.id,i={doc:n};t&&(i.bid=t),r&&(i.adId=r),s.j8(b,i)}var w=f.FP.BID_WON,C=f.FP.STALE_RENDER,A=new WeakSet,I={"Prebid Request":function(e,n,t){if(null==t)return void y({reason:f.q_.CANNOT_FIND_AD,message:"Cannot find ad '".concat(n.adId,"' for cross-origin render request"),id:n.adId});if(t.status===f.UE.fe&&((0,a.logWarn)("Ad id ".concat(t.adId," has been rendered before")),s.j8(C,t),(0,u.Z)(v.vc.getConfig("auctionOptions"),"suppressStaleRender")))return;try{!function(e,n){var t=e.adId,r=e.ad,i=e.adUrl,o=e.width,u=e.height,c=e.renderer,s=e.cpm,d=e.originalCpm;(0,p.Pd)(c)?(0,p._U)(c,e):t&&(O(e),n({message:"Prebid Response",ad:(0,a.replaceAuctionPrice)(r,d||s),adUrl:(0,a.replaceAuctionPrice)(i,d||s),adId:t,width:o,height:u}))}(t,e)}catch(e){return void y({reason:f.q_.EXCEPTION,message:e.message,id:n.adId,bid:t})}l.K.addWinningBid(t),s.j8(w,t)},"Prebid Event":function(e,n,t){if(null==t)return void(0,a.logError)("Cannot find ad '".concat(n.adId,"' for x-origin event request"));if(t.status!==f.UE.fe)return void(0,a.logWarn)("Received x-origin event request without corresponding render request for ad '".concat(n.adId,"'"));switch(n.event){case f.FP.AD_RENDER_FAILED:y({bid:t,id:n.adId,reason:n.info.reason,message:n.info.message});break;case f.FP.AD_RENDER_SUCCEEDED:E({doc:null,bid:t,id:n.adId});break;default:(0,a.logError)("Received x-origin event request for unsupported event: '".concat(n.event,"' (adId: '").concat(n.adId,"')"))}}};function T(e){var n=e.message?"message":"data",t={};try{t=JSON.parse(e[n])}catch(e){return}if(t&&t.adId&&t.message){var r=(0,g.sE)(l.K.getBidsReceived(),(function(e){return e.adId===t.adId}));I.hasOwnProperty(t.message)&&I[t.message](function(e){return null==e.origin&&0===e.ports.length?function(){var e="Cannot post message to a frame with null origin. Please update creatives to use MessageChannel, see https://github.com/prebid/Prebid.js/issues/7870";throw(0,a.logError)(e),new Error(e)}:e.ports.length>0?function(n){e.ports[0].postMessage(JSON.stringify(n))}:function(n){e.source.postMessage(JSON.stringify(n),e.origin)}}(e),t,r)}}function O(e){var n=e.adId,t=e.adUnitCode,r=e.width,i=e.height;["div","iframe"].forEach((function(e){var o=function(e){var r=function(e,n){return(0,a.isGptPubadsDefined)()?function(e){var n=(0,g.sE)(window.googletag.pubads().getSlots(),(function(n){return(0,g.sE)(n.getTargetingKeys(),(function(t){return(0,g.q9)(n.getTargeting(t),e)}))}));return n?n.getSlotElementId():null}(e):(0,a.isApnGetTagDefined)()?function(e){var n=window.apntag.getTag(e);return n&&n.targetId}(n):n}(n,t),i=document.getElementById(r);return i&&i.querySelector(e)}(e+':not([style*="display: none"])');if(o){var u=o.style;u.width=r?r+"px":"100%",u.height=i+"px"}else(0,a.logWarn)("Unable to locate matching page element for adUnitCode ".concat(t,".  Can't resize it to ad's dimensions.  Please review setup."))}))}Object.assign(I,{"Prebid Native":function(e,n,t){if(null==t)return void(0,a.logError)("Cannot find ad '".concat(n.adId,"' for x-origin event request"));A.has(t)||(A.add(t),l.K.addWinningBid(t),s.j8(w,t));switch(n.action){case"assetRequest":e((0,d.eK)(n,t));break;case"allAssetRequest":e((0,d.JL)(n,t));break;case"resizeNativeHeight":t.height=n.height,t.width=n.width,O(t);break;default:(0,d.e6)(n,t)}}});var S=t(11974),B=t(18621),k=t(92797),j=t(53777),U=t(875),_=t(69626),R=t(15164),P=t(9528),q=(0,o.R)(),D=S.k_.triggerUserSyncs,Z=f.FP,x=Z.ADD_AD_UNITS,N=Z.BID_WON,M=Z.REQUEST_BIDS,F=Z.SET_TARGETING,W=Z.STALE_RENDER,z=f.q_,K=z.PREVENT_WRITING_ON_MAIN_DOCUMENT,L=z.NO_AD,H=z.EXCEPTION,G=z.CANNOT_FIND_AD,V=z.MISSING_DOC_OR_ADID,Q={bidWon:function(e){var n=l.K.getBidsRequested().map((function(e){return e.bids.map((function(e){return e.adUnitCode}))})).reduce(a.flatten).filter(a.uniques);if(!(0,a.contains)(n,e))return void(0,a.logError)('The "'+e+'" placement is not defined.');return!0}};function J(e,n,t){e.defaultView&&e.defaultView.frameElement&&(e.defaultView.frameElement.width=n,e.defaultView.frameElement.height=t)}function Y(e,n){var t=[];return(0,a.isArray)(e)&&(n?e.length===n:e.length>0)&&(e.every((function(e){return(0,a.isArrayOfNums)(e,2)}))?t=e:(0,a.isArrayOfNums)(e,2)&&t.push(e)),t}function X(e){var n=(0,a.deepClone)(e),t=n.mediaTypes.banner,r=Y(t.sizes);return r.length>0?(t.sizes=r,n.sizes=r):((0,a.logError)("Detected a mediaTypes.banner object without a proper sizes field.  Please ensure the sizes are listed like: [[300, 250], ...].  Removing invalid mediaTypes.banner object from request."),delete n.mediaTypes.banner),n}function $(e){var n=(0,a.deepClone)(e),t=n.mediaTypes.video;if(t.playerSize){var r="number"==typeof t.playerSize[0]?2:1,i=Y(t.playerSize,r);i.length>0?(2===r&&(0,a.logInfo)("Transforming video.playerSize from [640,480] to [[640,480]] so it's in the proper format."),t.playerSize=i,n.sizes=i):((0,a.logError)("Detected incorrect configuration of mediaTypes.video.playerSize.  Please specify only one set of dimensions in a format like: [[640, 480]]. Removing invalid mediaTypes.video.playerSize property from request."),delete n.mediaTypes.video.playerSize)}return n}function ee(e){var n=(0,a.deepClone)(e),t=n.mediaTypes.native;if(t.ortb){var r=Object.keys(f.FY).filter((function(e){return f.FY[e].includes("hb_native_")})),i=Object.keys(t).filter((function(e){return r.includes(e)}));i.length>0&&((0,a.logError)("when using native OpenRTB format, you cannot use legacy native properties. Deleting ".concat(i," keys from request.")),i.forEach((function(e){return delete n.mediaTypes.native[e]})))}return t.image&&t.image.sizes&&!Array.isArray(t.image.sizes)&&((0,a.logError)("Please use an array of sizes for native.image.sizes field.  Removing invalid mediaTypes.native.image.sizes property from request."),delete n.mediaTypes.native.image.sizes),t.image&&t.image.aspect_ratios&&!Array.isArray(t.image.aspect_ratios)&&((0,a.logError)("Please use an array of sizes for native.image.aspect_ratios field.  Removing invalid mediaTypes.native.image.aspect_ratios property from request."),delete n.mediaTypes.native.image.aspect_ratios),t.icon&&t.icon.sizes&&!Array.isArray(t.icon.sizes)&&((0,a.logError)("Please use an array of sizes for native.icon.sizes field.  Removing invalid mediaTypes.native.icon.sizes property from request."),delete n.mediaTypes.native.icon.sizes),n}function ne(e,n){var t=(0,u.Z)(e,"mediaTypes.".concat(n,".pos"));if(!(0,a.isNumber)(t)||isNaN(t)||!isFinite(t)){var r="Value of property 'pos' on ad unit ".concat(e.code," should be of type: Number");(0,a.logWarn)(r),s.j8(f.FP.AUCTION_DEBUG,{type:"WARNING",arguments:r}),delete e.mediaTypes[n].pos}return e}function te(e){var n=function(n){return"adUnit.code '".concat(e.code,"' ").concat(n)},t=e.mediaTypes,r=e.bids;return null==r||(0,a.isArray)(r)?null==r&&null==e.ortb2Imp?((0,a.logError)(n("has no 'adUnit.bids' and no 'adUnit.ortb2Imp'. Removing adUnit from auction")),null):t&&0!==Object.keys(t).length?(null==e.ortb2Imp||null!=r&&0!==r.length||(e.bids=[{bidder:null}],(0,a.logMessage)(n("defines 'adUnit.ortb2Imp' with no 'adUnit.bids'; it will be seen only by S2S adapters"))),e):((0,a.logError)(n("does not define a 'mediaTypes' object.  This is a required field for the auction, so this adUnit has been removed.")),null):((0,a.logError)(n("defines 'adUnit.bids' that is not an array. Removing adUnit from auction")),null)}(0,j.dF)(),q.bidderSettings=q.bidderSettings||{},q.libLoaded=!0,q.version="v7.12.0",(0,a.logInfo)("Prebid.js v7.12.0 loaded"),q.installedModules=q.installedModules||[],q.adUnits=q.adUnits||[],q.triggerUserSyncs=D;var re={validateAdUnit:te,validateBannerMediaType:X,validateVideoMediaType:$,validateSizes:Y};Object.assign(re,{validateNativeMediaType:ee});var ie,oe=(0,k.z3)("sync",(function(e){var n=[];return e.forEach((function(e){if(null!=(e=te(e))){var t,r,i,o=e.mediaTypes;o.banner&&(t=X(e),o.banner.hasOwnProperty("pos")&&(t=ne(t,"banner"))),o.video&&(r=$(t||e),o.video.hasOwnProperty("pos")&&(r=ne(r,"video"))),o.native&&(i=ee(r||(t||e)));var a=Object.assign({},t,r,i);n.push(a)}})),n}),"checkAdUnitSetup");function ae(e){var n=l.K[e]().filter(a.bind.call(a.adUnitsFilter,this,l.K.getAdUnitCodes())),t=l.K.getLastAuctionId();return n.map((function(e){return e.adUnitCode})).filter(a.uniques).map((function(e){return n.filter((function(n){return n.auctionId===t&&n.adUnitCode===e}))})).filter((function(e){return e&&e[0]&&e[0].adUnitCode})).map((function(e){return(0,i.Z)({},e[0].adUnitCode,{bids:e})})).reduce((function(e,n){return Object.assign(e,n)}),{})}function ue(e,n,t){var r=n.querySelector(t);e.parentNode&&e.parentNode===r||(0,a.insertElement)(e,n,t)}q.getAdserverTargetingForAdUnitCodeStr=function(e){if((0,a.logInfo)("Invoking pbjs.getAdserverTargetingForAdUnitCodeStr",arguments),e){var n=q.getAdserverTargetingForAdUnitCode(e);return(0,a.transformAdServerTargetingObj)(n)}(0,a.logMessage)("Need to call getAdserverTargetingForAdUnitCodeStr with adunitCode")},q.getHighestUnusedBidResponseForAdUnitCode=function(e){if(e){var n=l.K.getAllBidsForAdUnitCode(e).filter(B.u8.isUnusedBid).filter(B.u8.isBidNotExpired);return n.length?n.reduce(a.getHighestCpm):{}}(0,a.logMessage)("Need to call getHighestUnusedBidResponseForAdUnitCode with adunitCode")},q.getAdserverTargetingForAdUnitCode=function(e){return q.getAdserverTargeting(e)[e]},q.getAdserverTargeting=function(e){return(0,a.logInfo)("Invoking pbjs.getAdserverTargeting",arguments),B.q0.getAllTargeting(e)},q.getConsentMetadata=function(){return(0,a.logInfo)("Invoking pbjs.getConsentMetadata"),{gdpr:P.rp.getConsentMeta(),usp:P.nX.getConsentMeta(),coppa:!!v.vc.getConfig("coppa")}},q.getNoBids=function(){return(0,a.logInfo)("Invoking pbjs.getNoBids",arguments),ae("getNoBids")},q.getNoBidsForAdUnitCode=function(e){return{bids:l.K.getNoBids().filter((function(n){return n.adUnitCode===e}))}},q.getBidResponses=function(){return(0,a.logInfo)("Invoking pbjs.getBidResponses",arguments),ae("getBidsReceived")},q.getBidResponsesForAdUnitCode=function(e){return{bids:l.K.getBidsReceived().filter((function(n){return n.adUnitCode===e}))}},q.setTargetingForGPTAsync=function(e,n){if((0,a.logInfo)("Invoking pbjs.setTargetingForGPTAsync",arguments),(0,a.isGptPubadsDefined)()){var t=B.q0.getAllTargeting(e);B.q0.resetPresetTargeting(e,n),B.q0.setTargetingForGPT(t,n),Object.keys(t).forEach((function(e){Object.keys(t[e]).forEach((function(n){"hb_adid"===n&&l.K.setStatusForBids(t[e][n],f.UE.CK)}))})),s.j8(F,t)}else(0,a.logError)("window.googletag is not defined on the page")},q.setTargetingForAst=function(e){(0,a.logInfo)("Invoking pbjs.setTargetingForAn",arguments),B.q0.isApntagDefined()?(B.q0.setTargetingForAst(e),s.j8(F,B.q0.getAllTargeting())):(0,a.logError)("window.apntag is not defined on the page")},q.renderAd=(0,k.z3)("async",(function(e,n,t){if((0,a.logInfo)("Invoking pbjs.renderAd",arguments),(0,a.logMessage)("Calling renderAd with adId :"+n),e&&n)try{var r=l.K.findBidByAdId(n);if(r){var i=!0;if(r&&r.status===f.UE.fe&&((0,a.logWarn)("Ad id ".concat(r.adId," has been rendered before")),s.j8(W,r),(0,u.Z)(v.vc.getConfig("auctionOptions"),"suppressStaleRender")&&(i=!1)),i){if(r.ad=(0,a.replaceAuctionPrice)(r.ad,r.originalCpm||r.cpm),r.adUrl=(0,a.replaceAuctionPrice)(r.adUrl,r.originalCpm||r.cpm),t&&t.clickThrough){var o=t.clickThrough;r.ad=(0,a.replaceClickThrough)(r.ad,o),r.adUrl=(0,a.replaceClickThrough)(r.adUrl,o)}l.K.addWinningBid(r),s.j8(N,r);var c=r.height,d=r.width,g=r.ad,h=r.mediaType,m=r.adUrl,b=r.renderer,w=document.createComment("Creative ".concat(r.creativeId," served by ").concat(r.bidder," Prebid.js Header Bidding"));if((0,a.insertElement)(w,e,"html"),(0,p.Pd)(b))(0,p._U)(b,r,e),ue(w,e,"html"),E({doc:e,bid:r,id:n});else if(e===document&&!(0,a.inIframe)()||"video"===h){var C="Error trying to write ad. Ad render call ad id ".concat(n," was prevented from writing to the main document.");y({reason:K,message:C,bid:r,id:n})}else if(g)e.write(g),e.close(),J(e,d,c),ue(w,e,"html"),(0,a.callBurl)(r),E({doc:e,bid:r,id:n});else if(m){var A=(0,a.createInvisibleIframe)();A.height=c,A.width=d,A.style.display="inline",A.style.overflow="hidden",A.src=m,(0,a.insertElement)(A,e,"body"),J(e,d,c),ue(w,e,"html"),(0,a.callBurl)(r),E({doc:e,bid:r,id:n})}else{var I="Error trying to write ad. No ad for bid response id: ".concat(n);y({reason:L,message:I,bid:r,id:n})}}}else{var T="Error trying to write ad. Cannot find ad by given id : ".concat(n);y({reason:G,message:T,id:n})}}catch(e){var O="Error trying to write ad Id :".concat(n," to the page:").concat(e.message);y({reason:H,message:O,id:n})}else{var S="Error trying to write ad Id :".concat(n," to the page. Missing document or adId");y({reason:V,message:S,id:n})}})),q.removeAdUnit=function(e){((0,a.logInfo)("Invoking pbjs.removeAdUnit",arguments),e)?((0,a.isArray)(e)?e:[e]).forEach((function(e){for(var n=q.adUnits.length-1;n>=0;n--)q.adUnits[n].code===e&&q.adUnits.splice(n,1)})):q.adUnits=[]},q.requestBids=(ie=(0,k.z3)("async",(function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.bidsBackHandler,t=e.timeout,i=e.adUnits,o=e.adUnitCodes,u=e.labels,c=e.auctionId,d=e.ortb2;s.j8(M);var f=t||v.vc.getConfig("bidderTimeout");(0,a.logInfo)("Invoking pbjs.requestBids",arguments);var l={global:(0,a.mergeDeep)({},v.vc.getAnyConfig("ortb2")||{},d||{}),bidder:Object.fromEntries(Object.entries(v.vc.getBidderConfig()).map((function(e){var n=(0,r.Z)(e,2);return[n[0],n[1].ortb2]})).filter((function(e){var n=(0,r.Z)(e,2);return n[0],null!=n[1]})))};return ce({bidsBackHandler:n,timeout:f,adUnits:i,adUnitCodes:o,labels:u,auctionId:c,ortb2Fragments:l})}),"requestBids"),(0,k.IF)(ie,(function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.adUnits||q.adUnits;return e.adUnits=(0,a.isArray)(n)?n.slice():[n],ie.call(this,e)})));var ce=(0,k.z3)("async",(function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.bidsBackHandler,t=e.timeout,r=e.adUnits,i=e.adUnitCodes,o=e.labels,u=e.auctionId,s=e.ortb2Fragments,d=(0,P.uV)(v.vc.getConfig("s2sConfig")||[]);if(r=oe(r),i&&i.length?r=r.filter((function(e){return(0,g.q9)(i,e.code)})):i=r&&r.map((function(e){return e.code})),r.forEach((function(e){var n=Object.keys(e.mediaTypes||{banner:"banner"}),t=e.bids.map((function(e){return e.bidder})),r=P.ZP.bidderRegistry,i=t.filter((function(e){return!d.has(e)}));e.transactionId=(0,a.generateUUID)(),(0,c.Z)(e,"ortb2Imp.ext.tid",e.transactionId),i.forEach((function(t){var i=r[t],o=i&&i.getSpec&&i.getSpec(),u=o&&o.supportedMediaTypes||["banner"];n.some((function(e){return(0,g.q9)(u,e)}))?U.f.incrementBidderRequestsCounter(e.code,t):((0,a.logWarn)((0,a.unsupportedBidderMessage)(e,t)),e.bids=e.bids.filter((function(e){return e.bidder!==t})))})),U.f.incrementRequestsCounter(e.code)})),r&&0!==r.length){var f=l.K.createAuction({adUnits:r,adUnitCodes:i,callback:n,cbTimeout:t,labels:o,auctionId:u,ortb2Fragments:s}),p=r.length;p>15&&(0,a.logInfo)("Current auction ".concat(f.getAuctionId()," contains ").concat(p," adUnits."),r),i.forEach((function(e){return B.q0.setLatestAuctionForAdUnit(e,f.getAuctionId())})),f.callBids()}else if((0,a.logMessage)("No adUnits configured. No bids requested."),"function"==typeof n)try{n()}catch(e){(0,a.logError)("Error executing bidsBackHandler",null,e)}}),"startAuction");q.requestBids.before((function(e,n){function t(e){for(var n;n=e.shift();)n()}t(R.Ld),t(se),e.call(this,n)}),49),q.addAdUnits=function(e){(0,a.logInfo)("Invoking pbjs.addAdUnits",arguments),q.adUnits.push.apply(q.adUnits,(0,a.isArray)(e)?e:[e]),s.j8(x)},q.onEvent=function(e,n,t){(0,a.logInfo)("Invoking pbjs.onEvent",arguments),(0,a.isFn)(n)?!t||Q[e].call(null,t)?s.on(e,n,t):(0,a.logError)('The id provided is not valid for event "'+e+'" and no handler was set.'):(0,a.logError)('The event handler provided is not a function and was not set on event "'+e+'".')},q.offEvent=function(e,n,t){(0,a.logInfo)("Invoking pbjs.offEvent",arguments),t&&!Q[e].call(null,t)||s.S1(e,n,t)},q.getEvents=function(){return(0,a.logInfo)("Invoking pbjs.getEvents"),s.vw()},q.registerBidAdapter=function(e,n){(0,a.logInfo)("Invoking pbjs.registerBidAdapter",arguments);try{P.ZP.registerBidAdapter(e(),n)}catch(e){(0,a.logError)("Error registering bidder adapter : "+e.message)}},q.registerAnalyticsAdapter=function(e){(0,a.logInfo)("Invoking pbjs.registerAnalyticsAdapter",arguments);try{P.ZP.registerAnalyticsAdapter(e)}catch(e){(0,a.logError)("Error registering analytics adapter : "+e.message)}},q.createBid=function(e){return(0,a.logInfo)("Invoking pbjs.createBid",arguments),(0,_.m)(e)};var se=[],de=(0,k.z3)("async",(function(e){e&&!(0,a.isEmpty)(e)?((0,a.logInfo)("Invoking pbjs.enableAnalytics for: ",e),P.ZP.enableAnalytics(e)):(0,a.logError)("pbjs.enableAnalytics should be called with option {}")}),"enableAnalyticsCb");function fe(e){e.forEach((function(e){if(void 0===e.called)try{e.call(),e.called=!0}catch(e){(0,a.logError)("Error processing command :","prebid.js",e)}}))}q.enableAnalytics=function(e){se.push(de.bind(this,e))},q.aliasBidder=function(e,n,t){(0,a.logInfo)("Invoking pbjs.aliasBidder",arguments),e&&n?P.ZP.aliasBidAdapter(e,n,t):(0,a.logError)("bidderCode and alias must be passed as arguments","pbjs.aliasBidder")},q.getAllWinningBids=function(){return l.K.getAllWinningBids()},q.getAllPrebidWinningBids=function(){return l.K.getBidsReceived().filter((function(e){return e.status===f.UE.CK}))},q.getHighestCpmBids=function(e){return B.q0.getWinningBids(e)},q.markWinningBidAsUsed=function(e){var n=[];e.adUnitCode&&e.adId?n=l.K.getBidsReceived().filter((function(n){return n.adId===e.adId&&n.adUnitCode===e.adUnitCode})):e.adUnitCode?n=B.q0.getWinningBids(e.adUnitCode):e.adId?n=l.K.getBidsReceived().filter((function(n){return n.adId===e.adId})):(0,a.logWarn)("Improper use of markWinningBidAsUsed. It needs an adUnitCode or an adId to function."),n.length>0&&(n[0].status=f.UE.fe)},q.getConfig=v.vc.getAnyConfig,q.readConfig=v.vc.readAnyConfig,q.mergeConfig=v.vc.mergeConfig,q.mergeBidderConfig=v.vc.mergeBidderConfig,q.setConfig=v.vc.setConfig,q.setBidderConfig=v.vc.setBidderConfig,q.que.push((function(){window.addEventListener("message",T,!1)})),q.cmd.push=function(e){if("function"==typeof e)try{e.call()}catch(e){(0,a.logError)("Error processing command :",e.message,e.stack)}else(0,a.logError)("Commands written into pbjs.cmd.push must be wrapped in a function")},q.que.push=q.cmd.push,q.processQueue=function(){k.z3.ready(),fe(q.que),fe(q.cmd)}},78640:function(e,n,t){function r(){return window.pbjs}t.d(n,{R:function(){return r}}),window.pbjs=window.pbjs||{},window.pbjs.cmd=window.pbjs.cmd||[],window.pbjs.que=window.pbjs.que||[],window._pbjsGlobals=window._pbjsGlobals||[],window._pbjsGlobals.push("pbjs")},25102:function(e,n,t){t.d(n,{hh:function(){return u},nH:function(){return c}});var r=t(3193),i=t(64358),o=new WeakMap;function a(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:window;if(!e)return e;if(/\w+:\/\//.exec(e))return e;var t=n.location.protocol;try{t=n.top.location.protocol}catch(e){}return/^\/\//.exec(e)?t+e:"".concat(t,"//").concat(e)}function u(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.noLeadingWww,r=void 0!==t&&t,i=n.noPort,o=void 0!==i&&i;try{e=new URL(a(e))}catch(e){return}return e=o?e.hostname:e.host,r&&e.startsWith("www.")&&(e=e.substring(4)),e}var c=function(e){function n(e){try{var n=e.querySelector("link[rel='canonical']");if(null!==n)return n.href}catch(e){}return null}return function(){return o.has(e)||o.set(e,Object.freeze(function(){var t,o,c,s,d=[],f=function(e){try{if(!e.location.ancestorOrigins)return;return e.location.ancestorOrigins}catch(e){}}(e),l=r.vc.getConfig("maxNestedIframes"),g=!1,p=0,v=!1,h=!1,m=!1;do{var b=t,y=h,E=void 0,w=!1,C=null;h=!1,t=t?t.parent:e;try{E=t.location.href||null}catch(e){w=!0}if(w)if(y){var A=b.context;try{o=C=A.sourceUrl,m=!0,v=!0,t===e.top&&(g=!0),A.canonicalUrl&&(c=A.canonicalUrl)}catch(e){}}else{(0,i.logWarn)("Trying to access cross domain iframe. Continuing without referrer and location");try{var I=b.document.referrer;I&&(C=I,t===e.top&&(g=!0))}catch(e){}!C&&f&&f[p-1]&&(C=f[p-1],t===e.top&&(m=!0)),C&&!v&&(o=C)}else{if(E&&(o=C=E,v=!1,t===e.top)){g=!0;var T=n(t.document);T&&(c=T)}t.context&&t.context.sourceUrl&&(h=!0)}d.push(C),p++}while(t!==e.top&&p<l);d.reverse();try{s=e.top.document.referrer}catch(e){}var O=g||m?o:null,S=r.vc.getConfig("pageUrl")||c||null,B=a(S,e)||O;return{reachedTop:g,isAmp:v,numIframes:p-1,stack:d,topmostLocation:o||null,location:O,canonicalUrl:S,page:B,domain:u(B)||null,ref:s||null,legacy:{reachedTop:g,isAmp:v,numIframes:p-1,stack:d,referer:o||null,canonicalUrl:S}}}())),o.get(e)}}(window)},74247:function(e,n,t){t.d(n,{UB:function(){return g},lO:function(){return d}});var r=t(71002),i=t(3193),o=t(64358),a=t(20265),u=t(34614),c=[];function s(e,n){return e.labelAll?{labelAll:!0,labels:e.labelAll,activeLabels:n}:{labelAll:!1,labels:e.labelAny,activeLabels:n}}function d(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:c,t=l(n);return!t.shouldFilter||!!t.sizesSupported[e]}function f(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.labels,t=void 0===n?[]:n,r=e.labelAll,i=void 0!==r&&r,s=e.activeLabels,d=void 0===s?[]:s,f=arguments.length>1?arguments[1]:void 0,g=arguments.length>2?arguments[2]:void 0,p=arguments.length>3&&void 0!==arguments[3]?arguments[3]:c,v=l(p);f=(0,o.isPlainObject)(f)?(0,o.deepClone)(f):g?{banner:{sizes:g}}:{};var h=(0,a.Z)(f,"banner.sizes");v.shouldFilter&&h&&(f.banner.sizes=h.filter((function(e){return v.sizesSupported[e]})));var m=Object.keys(f),b={active:m.every((function(e){return"banner"!==e}))||m.some((function(e){return"banner"===e}))&&(0,a.Z)(f,"banner.sizes.length")>0&&(0===t.length||!i&&(t.some((function(e){return v.labels[e]}))||t.some((function(e){return(0,u.q9)(d,e)})))||i&&t.reduce((function(e,n){return e?v.labels[n]||(0,u.q9)(d,n):e}),!0)),mediaTypes:f};return h&&h.length!==f.banner.sizes.length&&(b.filterResults={before:h,after:f.banner.sizes}),b}function l(e){return e.reduce((function(e,n){if("object"===(0,r.Z)(n)&&"string"==typeof n.mediaQuery&&n.mediaQuery.length>0){var t=!1;try{t=(0,o.getWindowTop)().matchMedia(n.mediaQuery).matches}catch(e){(0,o.logWarn)("Unfriendly iFrame blocks sizeConfig from being correctly evaluated"),t=matchMedia(n.mediaQuery).matches}t&&(Array.isArray(n.sizesSupported)&&(e.shouldFilter=!0),["labels","sizesSupported"].forEach((function(t){return(n[t]||[]).forEach((function(n){return e[t][n]=!0}))})))}else(0,o.logWarn)('sizeConfig rule missing required property "mediaQuery"');return e}),{labels:{},sizesSupported:{},shouldFilter:!1})}function g(e,n){return e.reduce((function(e,t){var r=f(s(t,n),t.mediaTypes,t.sizes),i=r.active,a=r.mediaTypes,u=r.filterResults;return i?(u&&(0,o.logInfo)('Size mapping filtered adUnit "'.concat(t.code,'" banner sizes from '),u.before,"to ",u.after),t.mediaTypes=a,t.bids=t.bids.reduce((function(e,r){var i=f(s(r,n),t.mediaTypes),a=i.active,u=i.mediaTypes,c=i.filterResults;return a?(c&&((0,o.logInfo)('Size mapping filtered adUnit "'.concat(t.code,'" bidder "').concat(r.bidder,'" banner sizes from '),c.before,"to ",c.after),r.mediaTypes=u),e.push(r)):(0,o.logInfo)('Size mapping deactivated adUnit "'.concat(t.code,'" bidder "').concat(r.bidder,'"')),e}),[]),e.push(t)):(0,o.logInfo)('Size mapping disabled adUnit "'.concat(t.code,'"')),e}),[])}i.vc.getConfig("sizeConfig",(function(e){return function(e){c=e}(e.sizeConfig)}))},15164:function(e,n,t){t.d(n,{Ld:function(){return u},S6:function(){return s},df:function(){return f},eA:function(){return d}});var r=t(92797),i=t(64358),o=t(55975),a=["core","prebid-module"],u=[];function c(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.gvlid,t=e.moduleName,r=e.bidderCode,c=e.moduleType,d=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},f=d.bidderSettings,l=void 0===f?o.S:f;function g(){if(null==r)return!0;var e=l.get(r,"storageAllowed");return null!=e&&e}var p=a.includes(c);function v(e){if(g()){var o;return s(p,n,r||t,{hasEnforcementHook:!1},(function(n){if(n&&n.hasEnforcementHook)o=e(n);else{var t={hasEnforcementHook:!1,valid:(0,i.hasDeviceAccess)()};o=e(t)}})),o}(0,i.logInfo)("bidderSettings denied access to device storage for bidder '".concat(r,"'"));return e({valid:!1})}var h=function(e,n,t,r,i,o){var a=function(o){if(o&&o.valid){var a=i&&""!==i?" ;domain=".concat(encodeURIComponent(i)):"",u=t&&""!==t?" ;expires=".concat(t):"",c=null!=r&&"none"==r.toLowerCase()?"; Secure":"";document.cookie="".concat(e,"=").concat(encodeURIComponent(n)).concat(u,"; path=/").concat(a).concat(r?"; SameSite=".concat(r):"").concat(c)}};if(!o||"function"!=typeof o)return v(a);u.push((function(){var e=v(a);o(e)}))},m=function(e,n){var t=function(n){if(n&&n.valid){var t=window.document.cookie.match("(^|;)\\s*"+e+"\\s*=\\s*([^;]*)\\s*(;|$)");return t?decodeURIComponent(t[2]):null}return null};if(!n||"function"!=typeof n)return v(t);u.push((function(){var e=v(t);n(e)}))},b=function(e){var n=function(e){if(e&&e.valid)try{return localStorage.setItem("prebid.cookieTest","1"),"1"===localStorage.getItem("prebid.cookieTest")}catch(e){}finally{try{localStorage.removeItem("prebid.cookieTest")}catch(e){}}return!1};if(!e||"function"!=typeof e)return v(n);u.push((function(){var t=v(n);e(t)}))},y=function(e){var n=function(e){return!(!e||!e.valid)&&(0,i.checkCookieSupport)()};if(!e||"function"!=typeof e)return v(n);u.push((function(){var t=v(n);e(t)}))},E=function(e,n,t){var r=function(t){t&&t.valid&&A()&&window.localStorage.setItem(e,n)};if(!t||"function"!=typeof t)return v(r);u.push((function(){var e=v(r);t(e)}))},w=function(e,n){var t=function(n){return n&&n.valid&&A()?window.localStorage.getItem(e):null};if(!n||"function"!=typeof n)return v(t);u.push((function(){var e=v(t);n(e)}))},C=function(e,n){var t=function(n){n&&n.valid&&A()&&window.localStorage.removeItem(e)};if(!n||"function"!=typeof n)return v(t);u.push((function(){var e=v(t);n(e)}))},A=function(e){var n=function(e){if(e&&e.valid)try{return!!window.localStorage}catch(e){(0,i.logError)("Local storage api disabled")}return!1};if(!e||"function"!=typeof e)return v(n);u.push((function(){var t=v(n);e(t)}))},I=function(e,n){var t=function(n){if(n&&n.valid){var t=[];if((0,i.hasDeviceAccess)())for(var r=document.cookie.split(";");r.length;){var o=r.pop(),a=o.indexOf("=");a=a<0?o.length:a,decodeURIComponent(o.slice(0,a).replace(/^\s+/,"")).indexOf(e)>=0&&t.push(decodeURIComponent(o.slice(a+1)))}return t}};if(!n||"function"!=typeof n)return v(t);u.push((function(){var e=v(t);n(e)}))};return{setCookie:h,getCookie:m,localStorageIsEnabled:b,cookiesAreEnabled:y,setDataInLocalStorage:E,getDataFromLocalStorage:w,removeDataFromLocalStorage:C,hasLocalStorage:A,findSimilarCookies:I}}var s=(0,r.z3)("async",(function(e,n,t,r,i){i(r)}),"validateStorageEnforcement");function d(e){return c({moduleName:e,moduleType:"core"})}function f(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=e.gvlid,t=e.moduleName,r=e.bidderCode;if(arguments.length>1||arguments.length>0&&!(0,i.isPlainObject)(arguments[0]))throw new Error("Invalid invocation for getStorageManager");return c({gvlid:n,moduleName:t,bidderCode:r})}},18621:function(e,n,t){t.d(n,{bP:function(){return A},ol:function(){return C},q0:function(){return I},u8:function(){return w}});var r=t(4942),i=t(89062),o=t(64358),a=t(20265),u=t(3193),c=t(70059),s=t(78653),d=t(74247),f=t(24679),l=t(92797),g=t(55975),p=t(34614),v=t(5644),h=[],m="targetingControls.allowTargetingKeys",b="targetingControls.addTargetingKeys",y='Only one of "'.concat(m,'" or "').concat(b,'" can be set'),E=Object.keys(v.TD).map((function(e){return v.TD[e]})),w={isBidNotExpired:function(e){return e.responseTimestamp+1e3*e.ttl-1e3>(0,o.timestamp)()},isUnusedBid:function(e){return e&&(e.status&&!(0,p.q9)([v.UE.fe],e.status)||!e.status)}},C=(0,l.z3)("sync",(function(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0,r=arguments.length>3&&void 0!==arguments[3]&&arguments[3];if(!r){var a=[],c=u.vc.getConfig("sendBidsControl.dealPrioritization"),s=(0,o.groupBy)(e,"adUnitCode");return Object.keys(s).forEach((function(e){var r=[],u=(0,o.groupBy)(s[e],"bidderCode");Object.keys(u).forEach((function(e){return r.push(u[e].reduce(n))})),t>0?(r=c?r.sort(A(!0)):r.sort((function(e,n){return n.cpm-e.cpm})),a.push.apply(a,(0,i.Z)(r.slice(0,t)))):a.push.apply(a,(0,i.Z)(r))})),a}return e}));function A(){var e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];return function(n,t){return void 0!==n.adserverTargeting.hb_deal&&void 0===t.adserverTargeting.hb_deal?-1:void 0===n.adserverTargeting.hb_deal&&void 0!==t.adserverTargeting.hb_deal?1:e?t.cpm-n.cpm:t.adserverTargeting.hb_pb-n.adserverTargeting.hb_pb}}var I=function(e){var n={},t={};function s(e,n){return e.adserverTargeting&&n&&((0,o.isArray)(n)&&(0,p.q9)(n,e.adUnitCode)||"string"==typeof n&&e.adUnitCode===n)}function l(e,n){if(!0===u.vc.getConfig("targetingControls.alwaysIncludeDeals")){var t=E.concat(c.xc);return C(n,o.getHighestCpm).map((function(n){if(n.dealId&&s(n,e))return(0,r.Z)({},n.adUnitCode,D(n,t.filter((function(e){return void 0!==n.adserverTargeting[e]}))))})).filter((function(e){return e}))}return[]}function I(e,n){var t=Object.assign({},v.TD,v.FY),r=Object.keys(t),i={};(0,o.logInfo)("allowTargetingKeys - allowed keys [ ".concat(n.map((function(e){return t[e]})).join(", ")," ]")),e.map((function(e){var o=Object.keys(e)[0],a=e[o].filter((function(e){var o=Object.keys(e)[0],a=0===r.filter((function(e){return 0===o.indexOf(t[e])})).length||(0,p.sE)(n,(function(e){var n=t[e];return 0===o.indexOf(n)}));return i[o]=!a,a}));e[o]=a}));var a=Object.keys(i).filter((function(e){return i[e]}));return(0,o.logInfo)("allowTargetingKeys - removed keys [ ".concat(a.join(", ")," ]")),e.filter((function(e){return e[Object.keys(e)[0]].length>0}))}function T(e,n){var t=(0,o.deepClone)(e);return Object.keys(t).map((function(e){return{adUnitCode:e,adserverTargeting:t[e]}})).sort(A()).reduce((function(e,r,i,a){var u,c=(u=r.adserverTargeting,Object.keys(u).reduce((function(e,n){return e+"".concat(n,"%3d").concat(encodeURIComponent(u[n]),"%26")}),""));i+1===a.length&&(c=c.slice(0,-3));var s=r.adUnitCode,d=c.length;return d<=n?(n-=d,(0,o.logInfo)("AdUnit '".concat(s,"' auction keys comprised of ").concat(d," characters.  Deducted from running threshold; new limit is ").concat(n),t[s]),e[s]=t[s]):(0,o.logWarn)("The following keys for adUnitCode '".concat(s,"' exceeded the current limit of the 'auctionKeyMaxChars' setting.\nThe key-set size was ").concat(d,", the current allotted amount was ").concat(n,".\n"),t[s]),i+1===a.length&&0===Object.keys(e).length&&(0,o.logError)("No auction targeting keys were permitted due to the setting in setConfig(targetingControls.auctionKeyMaxChars).  Please review setup and consider adjusting."),e}),{})}function O(e){var n=e.map((function(e){return(0,r.Z)({},Object.keys(e)[0],e[Object.keys(e)[0]].map((function(e){return(0,r.Z)({},Object.keys(e)[0],e[Object.keys(e)[0]].join(","))})).reduce((function(e,n){return Object.assign(n,e)}),{}))})).reduce((function(e,n){var t=Object.keys(n)[0];return e[t]=Object.assign({},e[t],n[t]),e}),{});return n}function S(n){return"string"==typeof n?[n]:(0,o.isArray)(n)?n:e.getAdUnitCodes()||[]}function B(){var n=e.getBidsReceived();if(u.vc.getConfig("useBidCache")){var r=u.vc.getConfig("bidCacheFilterFunction");"function"==typeof r&&(n=n.filter((function(e){return t[e.adUnitCode]===e.auctionId||!!r(e)})))}else n=n.filter((function(e){return t[e.adUnitCode]===e.auctionId}));return n=n.filter((function(e){return(0,a.Z)(e,"video.context")!==f.Oh})).filter((function(e){return"banner"!==e.mediaType||(0,d.lO)([e.width,e.height])})).filter(w.isUnusedBid).filter(w.isBidNotExpired),C(n,o.getOldestHighestCpmBid)}function k(e,t){var o=n.getWinningBids(e,t),a=j();return o=o.map((function(e){return(0,r.Z)({},e.adUnitCode,Object.keys(e.adserverTargeting).filter((function(n){return void 0===e.sendStandardTargeting||e.sendStandardTargeting||-1===a.indexOf(n)})).reduce((function(n,t){var o=[e.adserverTargeting[t]],a=(0,r.Z)({},t.substring(0,20),o);if(t===v.TD.DEAL){var u="".concat(t,"_").concat(e.bidderCode).substring(0,20),c=(0,r.Z)({},u,o);return[].concat((0,i.Z)(n),[a,c])}return[].concat((0,i.Z)(n),[a])}),[]))})),o}function j(){return e.getStandardBidderAdServerTargeting().map((function(e){return e.key})).concat(E).filter(o.uniques)}function U(e,n,t,r){return Object.keys(n.adserverTargeting).filter(_()).forEach((function(t){e.length&&e.filter(function(e){return function(t){return t.adUnitCode===n.adUnitCode&&t.adserverTargeting[e]}}(t)).forEach(function(e){return function(t){(0,o.isArray)(t.adserverTargeting[e])||(t.adserverTargeting[e]=[t.adserverTargeting[e]]),t.adserverTargeting[e]=t.adserverTargeting[e].concat(n.adserverTargeting[e]).filter(o.uniques),delete n.adserverTargeting[e]}}(t))})),e.push(n),e}function _(){var e=j();return e=e.concat(c.xc),function(n){return-1===e.indexOf(n)}}function R(e){return(0,r.Z)({},e.adUnitCode,Object.keys(e.adserverTargeting).filter(_()).map((function(n){return(0,r.Z)({},n.substring(0,20),[e.adserverTargeting[n]])})))}function P(e,n){return n.filter((function(n){return(0,p.q9)(e,n.adUnitCode)})).map((function(e){return Object.assign({},e)})).reduce(U,[]).map(R).filter((function(e){return e}))}function q(e,n){var t=E.concat(c.xc),i=u.vc.getConfig("sendBidsControl.bidLimit"),a=C(n,o.getHighestCpm,i),d=u.vc.getConfig("targetingControls.allowSendAllBidsTargetingKeys"),f=d?d.map((function(e){return v.TD[e]})):t;return a.map((function(n){if(s(n,e))return(0,r.Z)({},n.adUnitCode,D(n,t.filter((function(e){return void 0!==n.adserverTargeting[e]&&-1!==f.indexOf(e)}))))})).filter((function(e){return e}))}function D(e,n){return n.map((function(n){return(0,r.Z)({},"".concat(n,"_").concat(e.bidderCode).substring(0,20),[e.adserverTargeting[n]])}))}function Z(n){function t(e){return(0,a.Z)(e,v.k2.xn)}return e.getAdUnits().filter((function(e){return(0,p.q9)(n,e.code)&&t(e)})).map((function(e){return(0,r.Z)({},e.code,function(e){var n=t(e);return Object.keys(n).map((function(e){return(0,o.isStr)(n[e])&&(n[e]=n[e].split(",").map((function(e){return e.trim()}))),(0,o.isArray)(n[e])||(n[e]=[n[e]]),(0,r.Z)({},e,n[e])}))}(e))}))}return n.setLatestAuctionForAdUnit=function(e,n){t[e]=n},n.resetPresetTargeting=function(n,t){if((0,o.isGptPubadsDefined)()){var r=S(n),i=e.getAdUnits().filter((function(e){return(0,p.q9)(r,e.code)})),a=h.reduce((function(e,n){return e[n]=null,e}),{});window.googletag.pubads().getSlots().forEach((function(e){var n=(0,o.isFn)(t)&&t(e);i.forEach((function(t){(t.code===e.getAdUnitPath()||t.code===e.getSlotElementId()||(0,o.isFn)(n)&&n(t.code))&&e.updateTargetingFromMap(a)}))}))}},n.resetPresetTargetingAST=function(e){S(e).forEach((function(e){var n=window.apntag.getTag(e);if(n&&n.keywords){var t=Object.keys(n.keywords),r={};t.forEach((function(e){(0,p.q9)(h,e.toLowerCase())||(r[e]=n.keywords[e])})),window.apntag.modifyTag(e,{keywords:r})}}))},n.getAllTargeting=function(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:B(),t=S(e),r=k(t,n).concat(P(t,n)).concat(u.vc.getConfig("enableSendAllBids")?q(t,n):l(t,n)).concat(Z(t));r.map((function(e){Object.keys(e).map((function(n){e[n].map((function(e){-1===h.indexOf(Object.keys(e)[0])&&(h=Object.keys(e).concat(h))}))}))}));var i=Object.keys(Object.assign({},v.kF,v.FY)),a=u.vc.getConfig(m),c=u.vc.getConfig(b);if(null!=c&&null!=a)throw new Error(y);a=null!=c?i.concat(c):a||i,Array.isArray(a)&&a.length>0&&(r=I(r,a)),r=O(r);var s=u.vc.getConfig("targetingControls.auctionKeyMaxChars");return s&&((0,o.logInfo)("Detected 'targetingControls.auctionKeyMaxChars' was active for this auction; set with a limit of ".concat(s," characters.  Running checks on auction keys...")),r=T(r,s)),t.forEach((function(e){r[e]||(r[e]={})})),r},u.vc.getConfig("targetingControls",(function(e){null!=(0,a.Z)(e,m)&&null!=(0,a.Z)(e,b)&&(0,o.logError)(y)})),n.setTargetingForGPT=function(e,n){window.googletag.pubads().getSlots().forEach((function(t){Object.keys(e).filter(n?n(t):(0,o.isAdUnitCodeMatchingSlot)(t)).forEach((function(n){Object.keys(e[n]).forEach((function(t){var r=e[n][t];"string"==typeof r&&-1!==r.indexOf(",")&&(r=r.split(",")),e[n][t]=r})),(0,o.logMessage)("Attempting to set targeting-map for slot: ".concat(t.getSlotElementId()," with targeting-map:"),e[n]),t.updateTargetingFromMap(e[n])}))}))},n.getWinningBids=function(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:B(),t=S(e);return n.filter((function(e){return(0,p.q9)(t,e.adUnitCode)})).filter((function(e){return!0===g.S.get(e.bidderCode,"allowZeroCpmBids")?e.cpm>=0:e.cpm>0})).map((function(e){return e.adUnitCode})).filter(o.uniques).map((function(e){return n.filter((function(n){return n.adUnitCode===e?n:null})).reduce(o.getHighestCpm)}))},n.setTargetingForAst=function(e){var t=n.getAllTargeting(e);try{n.resetPresetTargetingAST(e)}catch(e){(0,o.logError)("unable to reset targeting for AST"+e)}Object.keys(t).forEach((function(e){return Object.keys(t[e]).forEach((function(n){if((0,o.logMessage)("Attempting to set targeting for targetId: ".concat(e," key: ").concat(n," value: ").concat(t[e][n])),(0,o.isStr)(t[e][n])||(0,o.isArray)(t[e][n])){var r={};n.search(/pt[0-9]/)<0?r[n.toUpperCase()]=t[e][n]:r[n]=t[e][n],window.apntag.setKeywords(e,r,{overrideKeyValue:!0})}}))}))},n.isApntagDefined=function(){if(window.apntag&&(0,o.isFn)(window.apntag.setKeywords))return!0},n}(s.K)},11974:function(e,n,t){t.d(n,{k_:function(){return s}});var r=t(93324),i=t(64358),o=t(3193),a=t(34614),u=t(15164);o.vc.setDefaults({userSync:(0,i.deepClone)({syncEnabled:!0,filterSettings:{image:{bidders:"*",filter:"include"}},syncsPerBidder:5,syncDelay:3e3,auctionDelay:0})});var c=(0,u.eA)("usersync");var s=function(e){var n={},t={image:[],iframe:[]},u=new Set,c={},s={image:!0,iframe:!1},d=e.config;function f(){if(d.syncEnabled&&e.browserSupportsCookies){try{!function(){if(!s.iframe)return;l(t.iframe,(function(e){var n=(0,r.Z)(e,2),o=n[0],a=n[1];(0,i.logMessage)("Invoking iframe user sync for bidder: ".concat(o)),(0,i.insertUserSyncIframe)(a),function(e,n){e.image=e.image.filter((function(e){return e[0]!==n}))}(t,o)}))}(),function(){if(!s.image)return;l(t.image,(function(e){var n=(0,r.Z)(e,2),t=n[0],o=n[1];(0,i.logMessage)("Invoking image pixel user sync for bidder: ".concat(t)),(0,i.triggerPixel)(o)}))}()}catch(e){return(0,i.logError)("Error firing user syncs",e)}t={image:[],iframe:[]}}}function l(e,n){(0,i.shuffle)(e).forEach((function(e){n(e),u.add(e[0])}))}function g(e,n){var t=d.filterSettings;if(function(e,n){if(e.all&&e[n])return(0,i.logWarn)('Detected presence of the "filterSettings.all" and "filterSettings.'.concat(n,'" in userSync config.  You cannot mix "all" with "iframe/image" configs; they are mutually exclusive.')),!1;var t=e.all?e.all:e[n],r=e.all?"all":n;if(!t)return!1;var o=t.filter,a=t.bidders;if(o&&"include"!==o&&"exclude"!==o)return(0,i.logWarn)('UserSync "filterSettings.'.concat(r,".filter\" setting '").concat(o,"' is not a valid option; use either 'include' or 'exclude'.")),!1;if("*"!==a&&!(Array.isArray(a)&&a.length>0&&a.every((function(e){return(0,i.isStr)(e)&&"*"!==e}))))return(0,i.logWarn)('Detected an invalid setup in userSync "filterSettings.'.concat(r,".bidders\"; use either '*' (to represent all bidders) or an array of bidders.")),!1;return!0}(t,e)){s[e]=!0;var r=t.all?t.all:t[e],o="*"===r.bidders?[n]:r.bidders,u={include:function(e,n){return!(0,a.q9)(e,n)},exclude:function(e,n){return(0,a.q9)(e,n)}};return u[r.filter||"include"](o,n)}return!s[e]}return o.vc.getConfig("userSync",(function(e){if(e.userSync){var n=e.userSync.filterSettings;(0,i.isPlainObject)(n)&&(n.image||n.all||(e.userSync.filterSettings.image={bidders:"*",filter:"include"}))}d=Object.assign(d,e.userSync)})),n.registerSync=function(e,r,o){return u.has(r)?(0,i.logMessage)('already fired syncs for "'.concat(r,'", ignoring registerSync call')):d.syncEnabled&&(0,i.isArray)(t[e])?r?0!==d.syncsPerBidder&&Number(c[r])>=d.syncsPerBidder?(0,i.logWarn)('Number of user syncs exceeded for "'.concat(r,'"')):n.canBidderRegisterSync(e,r)?(t[e].push([r,o]),void(c=function(e,n){return e[n]?e[n]+=1:e[n]=1,e}(c,r))):(0,i.logWarn)('Bidder "'.concat(r,'" not permitted to register their "').concat(e,'" userSync pixels.')):(0,i.logWarn)("Bidder is required for registering sync"):(0,i.logWarn)('User sync type "'.concat(e,'" not supported'))},n.syncUsers=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0;if(e)return setTimeout(f,Number(e));f()},n.triggerUserSyncs=function(){d.enableOverride&&n.syncUsers()},n.canBidderRegisterSync=function(e,n){return!d.filterSettings||!g(e,n)},n}(Object.defineProperties({config:o.vc.getConfig("userSync")},{browserSupportsCookies:{get:function(){return!(0,i.isSafariBrowser)()&&c.cookiesAreEnabled()}}}))},64358:function(e,n,t){t.r(n),t.d(n,{_each:function(){return de},_map:function(){return le},_setEventEmitter:function(){return C},adUnitsFilter:function(){return Ze},bind:function(){return k},buildUrl:function(){return En},callBurl:function(){return me},checkCookieSupport:function(){return He},chunk:function(){return gn},cleanObj:function(){return un},compareOn:function(){return hn},contains:function(){return fe},convertCamelToUnderscore:function(){return an},convertTypes:function(){return dn},createInvisibleIframe:function(){return $},createTrackPixelHtml:function(){return Ee},createTrackPixelIframeHtml:function(){return we},cyrb53Hash:function(){return An},debugTurnedOn:function(){return X},deepAccess:function(){return p.Z},deepClone:function(){return xe},deepEqual:function(){return wn},deepSetValue:function(){return v.Z},delayExecution:function(){return Ge},fill:function(){return ln},flatten:function(){return Ie},formatQS:function(){return bn},generateUUID:function(){return _},getAdUnitSizes:function(){return Z},getBidIdParameter:function(){return R},getBidRequest:function(){return Te},getBidderCodes:function(){return ke},getDNT:function(){return Xe},getDefinedParams:function(){return Qe},getGptSlotInfoForAdUnitCode:function(){return tn},getHighestCpm:function(){return _e},getKeyByValue:function(){return Be},getKeys:function(){return Oe},getLatestHighestCpmBid:function(){return Pe},getMaxValueFromArray:function(){return vn},getMinValueFromArray:function(){return pn},getOldestHighestCpmBid:function(){return Re},getParameterByName:function(){return ee},getPerformanceNow:function(){return Ke},getPrebidInternal:function(){return O},getUniqueIdentifierStr:function(){return U},getUserConfiguredParams:function(){return Ye},getValue:function(){return Se},getValueString:function(){return Ce},getWindowFromDocument:function(){return In},getWindowLocation:function(){return K},getWindowSelf:function(){return z},getWindowTop:function(){return W},groupBy:function(){return Ve},hasConsoleLogger:function(){return Y},hasDeviceAccess:function(){return Le},hasOwn:function(){return ge},inIframe:function(){return Ne},insertElement:function(){return pe},insertHtmlIntoIframe:function(){return be},insertUserSyncIframe:function(){return ye},internal:function(){return I},isA:function(){return ne},isAdUnitCodeMatchingSlot:function(){return en},isApnGetTagDefined:function(){return Ue},isArray:function(){return ie},isArrayOfNums:function(){return fn},isBoolean:function(){return ue},isEmpty:function(){return ce},isEmptyStr:function(){return se},isFn:function(){return te},isGptPubadsDefined:function(){return je},isInteger:function(){return on},isNumber:function(){return oe},isPlainObject:function(){return ae},isSafariBrowser:function(){return Me},isSlotMatchingAdUnitCode:function(){return nn},isStr:function(){return re},isValidMediaTypes:function(){return Je},logError:function(){return V},logInfo:function(){return H},logMessage:function(){return L},logWarn:function(){return G},mergeDeep:function(){return Cn},parseGPTSingleSizeArray:function(){return N},parseGPTSingleSizeArrayToRtbSize:function(){return M},parseQS:function(){return mn},parseQueryStringParameters:function(){return q},parseSizesInput:function(){return x},parseUrl:function(){return yn},pick:function(){return cn},prefixLog:function(){return Q},replaceAuctionPrice:function(){return Fe},replaceClickThrough:function(){return We},safeJSONParse:function(){return Tn},setScriptAttributes:function(){return On},shuffle:function(){return De},timestamp:function(){return ze},transformAdServerTargetingObj:function(){return D},transformBidderParamKeywords:function(){return sn},triggerPixel:function(){return he},tryAppendQueryString:function(){return P},uniques:function(){return Ae},unsupportedBidderMessage:function(){return rn},waitForElementToLoad:function(){return ve}});var r,i=t(93324),o=t(89062),a=t(4942),u=t(71002),c=t(3193),s=t(77079),d=t.n(s),f=t(34614),l=t(5644),g=t(68792),p=t(20265),v=t(44806),h=Object.prototype.toString,m=Boolean(window.console),b=Boolean(m&&window.console.log),y=Boolean(m&&window.console.info),E=Boolean(m&&window.console.warn),w=Boolean(m&&window.console.error);function C(e){r=e}function A(){null!=r&&r.apply(void 0,arguments)}var I={checkCookieSupport:He,createTrackPixelIframeHtml:we,getWindowSelf:z,getWindowTop:W,getWindowLocation:K,insertUserSyncIframe:ye,insertElement:pe,isFn:te,triggerPixel:he,logError:V,logWarn:G,logMessage:L,logInfo:H,parseQS:mn,formatQS:bn,deepEqual:wn},T={};function O(){return T}var S,B={},k=function(e,n){return n}.bind(null,1,B)()===B?Function.prototype.bind:function(e){var n=this,t=Array.prototype.slice.call(arguments,1);return function(){return n.apply(e,t.concat(Array.prototype.slice.call(arguments)))}},j=(S=0,function(){return++S});function U(){return j()+Math.random().toString(16).substr(2)}function _(e){return e?(e^(window&&window.crypto&&window.crypto.getRandomValues?crypto.getRandomValues(new Uint8Array(1))[0]%16:16*Math.random())>>e/4).toString(16):([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g,_)}function R(e,n){return n&&n[e]?n[e]:""}function P(e,n,t){return t?e+n+"="+encodeURIComponent(t)+"&":e}function q(e){var n="";for(var t in e)e.hasOwnProperty(t)&&(n+=t+"="+encodeURIComponent(e[t])+"&");return n=n.replace(/&$/,"")}function D(e){return e&&Object.getOwnPropertyNames(e).length>0?Oe(e).map((function(n){return"".concat(n,"=").concat(encodeURIComponent(Se(e,n)))})).join("&"):""}function Z(e){if(e){var n=[];if(e.mediaTypes&&e.mediaTypes.banner&&Array.isArray(e.mediaTypes.banner.sizes)){var t=e.mediaTypes.banner.sizes;Array.isArray(t[0])?n=t:n.push(t)}else Array.isArray(e.sizes)&&(Array.isArray(e.sizes[0])?n=e.sizes:n.push(e.sizes));return n}}function x(e){var n=[];if("string"==typeof e){var t=e.split(","),r=/^(\d)+x(\d)+$/i;if(t)for(var i in t)ge(t,i)&&t[i].match(r)&&n.push(t[i])}else if("object"===(0,u.Z)(e)){var o=e.length;if(o>0)if(2===o&&"number"==typeof e[0]&&"number"==typeof e[1])n.push(N(e));else for(var a=0;a<o;a++)n.push(N(e[a]))}return n}function N(e){if(F(e))return e[0]+"x"+e[1]}function M(e){if(F(e))return{w:e[0],h:e[1]}}function F(e){return ie(e)&&2===e.length&&!isNaN(e[0])&&!isNaN(e[1])}function W(){return window.top}function z(){return window.self}function K(){return window.location}function L(){X()&&b&&console.log.apply(console,J(arguments,"MESSAGE:"))}function H(){X()&&y&&console.info.apply(console,J(arguments,"INFO:"))}function G(){X()&&E&&console.warn.apply(console,J(arguments,"WARNING:")),A(l.FP.AUCTION_DEBUG,{type:"WARNING",arguments:arguments})}function V(){X()&&w&&console.error.apply(console,J(arguments,"ERROR:")),A(l.FP.AUCTION_DEBUG,{type:"ERROR",arguments:arguments})}function Q(e){function n(n){return function(){for(var t=arguments.length,r=new Array(t),i=0;i<t;i++)r[i]=arguments[i];n.apply(void 0,[e].concat(r))}}return{logError:n(V),logWarn:n(G),logMessage:n(L),logInfo:n(H)}}function J(e,n){e=[].slice.call(e);var t=c.vc.getCurrentBidder();return n&&e.unshift(n),t&&e.unshift(r("#aaa")),e.unshift(r("#3b88c3")),e.unshift("%cPrebid"+(t?"%c".concat(t):"")),e;function r(e){return"display: inline-block; color: #fff; background: ".concat(e,"; padding: 1px 4px; border-radius: 3px;")}}function Y(){return b}function X(){return!!c.vc.getConfig("debug")}function $(){var e=document.createElement("iframe");return e.id=U(),e.height=0,e.width=0,e.border="0px",e.hspace="0",e.vspace="0",e.marginWidth="0",e.marginHeight="0",e.style.border="0",e.scrolling="no",e.frameBorder="0",e.src="about:blank",e.style.display="none",e}function ee(e){return mn(K().search)[e]||""}function ne(e,n){return h.call(e)==="[object "+n+"]"}function te(e){return ne(e,"Function")}function re(e){return ne(e,"String")}function ie(e){return ne(e,"Array")}function oe(e){return ne(e,"Number")}function ae(e){return ne(e,"Object")}function ue(e){return ne(e,"Boolean")}function ce(e){if(!e)return!0;if(ie(e)||re(e))return!(e.length>0);for(var n in e)if(hasOwnProperty.call(e,n))return!1;return!0}function se(e){return re(e)&&(!e||0===e.length)}function de(e,n){if(!ce(e)){if(te(e.forEach))return e.forEach(n,this);var t=0,r=e.length;if(r>0)for(;t<r;t++)n(e[t],t,e);else for(t in e)hasOwnProperty.call(e,t)&&n.call(this,e[t],t)}}function fe(e,n){if(ce(e))return!1;if(te(e.indexOf))return-1!==e.indexOf(n);for(var t=e.length;t--;)if(e[t]===n)return!0;return!1}function le(e,n){if(ce(e))return[];if(te(e.map))return e.map(n);var t=[];return de(e,(function(r,i){t.push(n(r,i,e))})),t}function ge(e,n){return e.hasOwnProperty?e.hasOwnProperty(n):void 0!==e[n]&&e.constructor.prototype[n]!==e[n]}function pe(e,n,t,r){var i;n=n||document,i=t?n.getElementsByTagName(t):n.getElementsByTagName("head");try{if((i=i.length?i:n.getElementsByTagName("body")).length){i=i[0];var o=r?null:i.firstChild;return i.insertBefore(e,o)}}catch(e){}}function ve(e,n){var t=null;return new g.Z((function(r){var i=function n(){e.removeEventListener("load",n),e.removeEventListener("error",n),null!=t&&window.clearTimeout(t),r()};e.addEventListener("load",i),e.addEventListener("error",i),null!=n&&(t=window.setTimeout(i,n))}))}function he(e,n,t){var r=new Image;n&&I.isFn(n)&&ve(r,t).then(n),r.src=e}function me(e){var n=e.source,t=e.burl;n===l.os.YZ&&t&&I.triggerPixel(t)}function be(e){if(e){var n=document.createElement("iframe");n.id=U(),n.width=0,n.height=0,n.hspace="0",n.vspace="0",n.marginWidth="0",n.marginHeight="0",n.style.display="none",n.style.height="0px",n.style.width="0px",n.scrolling="no",n.frameBorder="0",n.allowtransparency="true",I.insertElement(n,document,"body"),n.contentWindow.document.open(),n.contentWindow.document.write(e),n.contentWindow.document.close()}}function ye(e,n,t){var r=I.createTrackPixelIframeHtml(e,!1,"allow-scripts allow-same-origin"),i=document.createElement("div");i.innerHTML=r;var o=i.firstChild;n&&I.isFn(n)&&ve(o,t).then(n),I.insertElement(o,document,"html",!0)}function Ee(e){if(!e)return"";var n='<div style="position:absolute;left:0px;top:0px;visibility:hidden;">';return n+='<img src="'+encodeURI(e)+'"></div>'}function we(e){var n=!(arguments.length>1&&void 0!==arguments[1])||arguments[1],t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"";return e?(n&&(e=encodeURI(e)),t&&(t='sandbox="'.concat(t,'"')),"<iframe ".concat(t,' id="').concat(U(),'"\n      frameborder="0"\n      allowtransparency="true"\n      marginheight="0" marginwidth="0"\n      width="0" hspace="0" vspace="0" height="0"\n      style="height:0px;width:0px;display:none;"\n      scrolling="no"\n      src="').concat(e,'">\n    </iframe>')):""}function Ce(e,n,t){return null==n?t:re(n)?n:oe(n)?n.toString():void I.logWarn("Unsuported type for param: "+e+" required type: String")}function Ae(e,n,t){return t.indexOf(e)===n}function Ie(e,n){return e.concat(n)}function Te(e,n){var t;if(e)return n.some((function(n){var r=(0,f.sE)(n.bids,(function(n){return["bidId","adId","bid_id"].some((function(t){return n[t]===e}))}));return r&&(t=r),r})),t}function Oe(e){return Object.keys(e)}function Se(e,n){return e[n]}function Be(e,n){for(var t in e)if(e.hasOwnProperty(t)&&e[t]===n)return t}function ke(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:pbjs.adUnits;return e.map((function(e){return e.bids.map((function(e){return e.bidder})).reduce(Ie,[])})).reduce(Ie,[]).filter(Ae)}function je(){if(window.googletag&&te(window.googletag.pubads)&&te(window.googletag.pubads().getSlots))return!0}function Ue(){if(window.apntag&&te(window.apntag.getTag))return!0}var _e=qe("timeToRespond",(function(e,n){return e>n})),Re=qe("responseTimestamp",(function(e,n){return e>n})),Pe=qe("responseTimestamp",(function(e,n){return e<n}));function qe(e,n){return function(t,r){return t.cpm===r.cpm?n(t[e],r[e])?r:t:t.cpm<r.cpm?r:t}}function De(e){for(var n=e.length;n>0;){var t=Math.floor(Math.random()*n),r=e[--n];e[n]=e[t],e[t]=r}return e}function Ze(e,n){return(0,f.q9)(e,n&&n.adUnitCode)}function xe(e){return d()(e)}function Ne(){try{return I.getWindowSelf()!==I.getWindowTop()}catch(e){return!0}}function Me(){return/^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent)}function Fe(e,n){if(e)return e.replace(/\$\{AUCTION_PRICE\}/g,n)}function We(e,n){if(e&&n&&"string"==typeof n)return e.replace(/\${CLICKTHROUGH}/g,n)}function ze(){return(new Date).getTime()}function Ke(){return window.performance&&window.performance.now&&window.performance.now()||0}function Le(){return!1!==c.vc.getConfig("deviceAccess")}function He(){if(window.navigator.cookieEnabled||document.cookie.length)return!0}function Ge(e,n){if(n<1)throw new Error("numRequiredCalls must be a positive number. Got ".concat(n));var t=0;return function(){++t===n&&e.apply(this,arguments)}}function Ve(e,n){return e.reduce((function(e,t){return(e[t[n]]=e[t[n]]||[]).push(t),e}),{})}function Qe(e,n){return n.filter((function(n){return e[n]})).reduce((function(n,t){return Object.assign(n,(0,a.Z)({},t,e[t]))}),{})}function Je(e){var n=["banner","native","video"];return!!Object.keys(e).every((function(e){return(0,f.q9)(n,e)}))&&(!e.video||!e.video.context||(0,f.q9)(["instream","outstream","adpod"],e.video.context))}function Ye(e,n,t){return e.filter((function(e){return e.code===n})).map((function(e){return e.bids})).reduce(Ie,[]).filter((function(e){return e.bidder===t})).map((function(e){return e.params||{}}))}function Xe(){return"1"===navigator.doNotTrack||"1"===window.doNotTrack||"1"===navigator.msDoNotTrack||"yes"===navigator.doNotTrack}var $e=function(e,n){return e.getAdUnitPath()===n||e.getSlotElementId()===n};function en(e){return function(n){return $e(e,n)}}function nn(e){return function(n){return $e(n,e)}}function tn(e){var n;return je()&&(n=(0,f.sE)(window.googletag.pubads().getSlots(),nn(e))),n?{gptSlot:n.getAdUnitPath(),divId:n.getSlotElementId()}:{}}function rn(e,n){var t=Object.keys(e.mediaTypes||{banner:"banner"}).join(", ");return"\n    ".concat(e.code," is a ").concat(t," ad unit\n    containing bidders that don't support ").concat(t,": ").concat(n,".\n    This bidder won't fetch demand.\n  ")}function on(e){return Number.isInteger?Number.isInteger(e):"number"==typeof e&&isFinite(e)&&Math.floor(e)===e}function an(e){return e.replace(/(?:^|\.?)([A-Z])/g,(function(e,n){return"_"+n.toLowerCase()})).replace(/^_/,"")}function un(e){return Object.keys(e).reduce((function(n,t){return void 0!==e[t]&&(n[t]=e[t]),n}),{})}function cn(e,n){return"object"!==(0,u.Z)(e)?{}:n.reduce((function(t,r,i){if("function"==typeof r)return t;var o=r,a=r.match(/^(.+?)\sas\s(.+?)$/i);a&&(r=a[1],o=a[2]);var u=e[r];return"function"==typeof n[i+1]&&(u=n[i+1](u,t)),void 0!==u&&(t[o]=u),t}),{})}function sn(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"keywords",t=[];return de(e,(function(e,r){if(ie(e)){var i=[];de(e,(function(e){((e=Ce(n+"."+r,e))||""===e)&&i.push(e)})),e=i}else{if(!re(e=Ce(n+"."+r,e)))return;e=[e]}t.push({key:r,value:e})})),t}function dn(e,n){return Object.keys(e).forEach((function(t){var r,i;n[t]&&(te(e[t])?n[t]=e[t](n[t]):n[t]=(r=e[t],i=n[t],"string"===r?i&&i.toString():"number"===r?Number(i):i),isNaN(n[t])&&delete n.key)})),n}function fn(e,n){return ie(e)&&(!n||e.length===n)&&e.every((function(e){return on(e)}))}function ln(e,n){for(var t=[],r=0;r<n;r++){var i=ae(e)?xe(e):e;t.push(i)}return t}function gn(e,n){for(var t=[],r=0;r<Math.ceil(e.length/n);r++){var i=r*n,o=i+n;t.push(e.slice(i,o))}return t}function pn(e){return Math.min.apply(Math,(0,o.Z)(e))}function vn(e){return Math.max.apply(Math,(0,o.Z)(e))}function hn(e){return function(n,t){return n[e]<t[e]?1:n[e]>t[e]?-1:0}}function mn(e){return e?e.replace(/^\?/,"").split("&").reduce((function(e,n){var t=n.split("="),r=(0,i.Z)(t,2),o=r[0],a=r[1];return/\[\]$/.test(o)?(e[o=o.replace("[]","")]=e[o]||[],e[o].push(a)):e[o]=a||"",e}),{}):{}}function bn(e){return Object.keys(e).map((function(n){return Array.isArray(e[n])?e[n].map((function(e){return"".concat(n,"[]=").concat(e)})).join("&"):"".concat(n,"=").concat(e[n])})).join("&")}function yn(e,n){var t=document.createElement("a");n&&"noDecodeWholeURL"in n&&n.noDecodeWholeURL?t.href=e:t.href=decodeURIComponent(e);var r=n&&"decodeSearchAsString"in n&&n.decodeSearchAsString;return{href:t.href,protocol:(t.protocol||"").replace(/:$/,""),hostname:t.hostname,port:+t.port,pathname:t.pathname.replace(/^(?!\/)/,"/"),search:r?t.search:I.parseQS(t.search||""),hash:(t.hash||"").replace(/^#/,""),host:t.host||window.location.host}}function En(e){return(e.protocol||"http")+"://"+(e.host||e.hostname+(e.port?":".concat(e.port):""))+(e.pathname||"")+(e.search?"?".concat(I.formatQS(e.search||"")):"")+(e.hash?"#".concat(e.hash):"")}function wn(e,n){var t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},r=t.checkTypes,i=void 0!==r&&r;if(e===n)return!0;if("object"!==(0,u.Z)(e)||null===e||"object"!==(0,u.Z)(n)||null===n||i&&e.constructor!==n.constructor)return!1;if(Object.keys(e).length!==Object.keys(n).length)return!1;for(var o in e){if(!n.hasOwnProperty(o))return!1;if(!wn(e[o],n[o],{checkTypes:i}))return!1}return!0}function Cn(e){for(var n=arguments.length,t=new Array(n>1?n-1:0),r=1;r<n;r++)t[r-1]=arguments[r];if(!t.length)return e;var i=t.shift();if(ae(e)&&ae(i)){var u=function(n){ae(i[n])?(e[n]||Object.assign(e,(0,a.Z)({},n,{})),Cn(e[n],i[n])):ie(i[n])?e[n]?ie(e[n])&&i[n].forEach((function(t){for(var r=1,i=0;i<e[n].length;i++)if(wn(e[n][i],t)){r=0;break}r&&e[n].push(t)})):Object.assign(e,(0,a.Z)({},n,(0,o.Z)(i[n]))):Object.assign(e,(0,a.Z)({},n,i[n]))};for(var c in i)u(c)}return Cn.apply(void 0,[e].concat(t))}function An(e){for(var n,t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,r=function(e,n){if(te(Math.imul))return Math.imul(e,n);var t=(4194303&e)*(n|=0);return 4290772992&e&&(t+=(4290772992&e)*n|0),0|t},i=3735928559^t,o=1103547991^t,a=0;a<e.length;a++)i=r(i^(n=e.charCodeAt(a)),2654435761),o=r(o^n,1597334677);return i=r(i^i>>>16,2246822507)^r(o^o>>>13,3266489909),(4294967296*(2097151&(o=r(o^o>>>16,2246822507)^r(i^i>>>13,3266489909)))+(i>>>0)).toString()}function In(e){return e?e.defaultView:null}function Tn(e){try{return JSON.parse(e)}catch(e){}}function On(e,n){for(var t in n)n.hasOwnProperty(t)&&e.setAttribute(t,n[t])}},68792:function(e,n,t){t.d(n,{P:function(){return E},Z:function(){return y}});var r=t(93324),i=t(15671),o=t(43144),a=t(97326),u=t(88301),c=t(60136),s=t(82963),d=t(61120),f=t(7112),l=t(18916),g=t(42793);function p(e){var n=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(e){return!1}}();return function(){var t,r=(0,d.Z)(e);if(n){var i=(0,d.Z)(this).constructor;t=Reflect.construct(r,arguments,i)}else t=r.apply(this,arguments);return(0,s.Z)(this,t)}}function v(e,n,t){!function(e,n){if(n.has(e))throw new TypeError("Cannot initialize the same private elements twice on an object")}(e,n),n.set(e,t)}var h=new WeakMap,m=new WeakMap,b=new WeakMap,y=function(e){(0,c.Z)(t,e);var n=p(t);function t(e){var r;(0,i.Z)(this,t);var o=[],u=[];function c(e,n){return function(t){if(!o.length){for(o.push(e,t);u.length;)u.shift()();n(t)}}}return r=n.call(this,"function"!=typeof e?e:function(n,t){var r,i=c(1,t),o=(r=c(0,n),function(e){return"function"==typeof(null==e?void 0:e.then)?e.then(r,i):r(e)});try{e(o,i)}catch(e){i(e)}}),v((0,a.Z)(r),h,{writable:!0,value:void 0}),v((0,a.Z)(r),m,{writable:!0,value:void 0}),v((0,a.Z)(r),b,{writable:!0,value:null}),(0,g.Z)((0,a.Z)(r),h,o),(0,g.Z)((0,a.Z)(r),m,u),r}return(0,o.Z)(t,[{key:"then",value:function(e,n){var i=this;if("function"==typeof n)for(var o=this;o;){(0,u.Z)((0,d.Z)(t.prototype),"then",this).call(o,null,(function(){return null}));var a=(0,l.Z)(o,b);(0,g.Z)(o,b,null),o=a}var c=(0,l.Z)(this,h),s=new t((function(t,o){var a=function(){var i=c[1],a=0===c[0]?[e,t]:[n,o],u=(0,r.Z)(a,2),s=u[0],d=u[1];if("function"==typeof s){try{i=s(i)}catch(e){return void o(e)}d=t}d(i)};c.length?a():(0,l.Z)(i,m).push(a)}));return(0,g.Z)(s,b,this),s}}],[{key:"timeout",value:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0;return new t((function(n){0===e?n():setTimeout(n,e)}))}}]),t}((0,f.Z)(Promise));function E(){var e,n,t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=t.promiseFactory,i=void 0===r?function(e){return new y(e)}:r;function o(e){return function(n){return e(n)}}return{promise:i((function(t,r){e=t,n=r})),resolve:o(e),reject:o(n)}}},90154:function(e,n,t){t.d(n,{Dn:function(){return d},LD:function(){return s},gZ:function(){return c},hD:function(){return f}});var r=t(20265),i=t(64358),o=t(3193),a=t(92797),u=t(78653),c="outstream",s="instream";function d(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.index,i=void 0===t?u.K.index:t,o=(0,r.Z)(i.getMediaTypes(e),"video"),a=o&&(0,r.Z)(o,"context"),c=i.getAdUnit(e);return f(e,c,o,a)}var f=(0,a.z3)("sync",(function(e,n,t,r){return t&&r!==c?o.vc.getConfig("cache.url")||!e.vastXml||e.vastUrl?!(!e.vastUrl&&!e.vastXml):((0,i.logError)('\n        This bid contains only vastXml and will not work when a prebid cache url is not specified.\n        Try enabling prebid cache with pbjs.setConfig({ cache: {url: "..."} });\n      '),!1):r!==c||!!(e.renderer||n&&n.renderer||t.renderer)}),"checkVideoBidSetup")},79885:function(e,n,t){t.d(n,{h:function(){return c},z:function(){return s}});var r=t(48928),i=t(3193),o=t(78653);function a(e,n){var t=n?"<![CDATA[".concat(n,"]]>"):"";return'<VAST version="3.0">\n    <Ad>\n      <Wrapper>\n        <AdSystem>prebid.org wrapper</AdSystem>\n        <VASTAdTagURI><![CDATA['.concat(e,"]]></VASTAdTagURI>\n        <Impression>").concat(t,"</Impression>\n        <Creatives></Creatives>\n      </Wrapper>\n    </Ad>\n  </VAST>")}function u(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=n.index,r=void 0===t?o.K.index:t,u=e.vastXml?e.vastXml:a(e.vastUrl,e.vastImpUrl),c=r.getAuction(e),s=Number(e.ttl)+15,d={type:"xml",value:u,ttlseconds:s};return i.vc.getConfig("cache.vasttrack")&&(d.bidder=e.bidder,d.bidid=e.requestId,d.aid=e.auctionId),null!=c&&(d.timestamp=c.getAuctionStart()),"string"==typeof e.customCacheKey&&""!==e.customCacheKey&&(d.key=e.customCacheKey),d}function c(e,n){var t={puts:e.map(u)};(0,r.h)(i.vc.getConfig("cache.url"),function(e){return{success:function(n){var t;try{t=JSON.parse(n).responses}catch(n){return void e(n,[])}t?e(null,t):e(new Error("The cache server didn't respond with a responses property."),[])},error:function(n,t){e(new Error("Error storing video ad in the cache: ".concat(n,": ").concat(JSON.stringify(t))),[])}}}(n),JSON.stringify(t),{contentType:"text/plain",withCredentials:!0})}function s(e){return"".concat(i.vc.getConfig("cache.url"),"?uuid=").concat(e)}},20265:function(e,n,t){function r(e,n,t,r,i){for(n=n.split?n.split("."):n,r=0;r<n.length;r++)e=e?e[n[r]]:i;return e===i?t:e}t.d(n,{Z:function(){return r}})},44806:function(e,n,t){function r(e,n,t){n.split&&(n=n.split("."));for(var r,i=0,o=n.length,a=e;i<o;++i)r=a[n[i]],a=a[n[i]]=i===o-1?t:null!=r?r:!~n[i+1].indexOf(".")&&+n[i+1]>-1?[]:{}}t.d(n,{Z:function(){return r}})},81432:function(e){
/*
* @license MIT
* Fun Hooks v0.9.10
* (c) @snapwich
*/
a.SYNC=1,a.ASYNC=2,a.QUEUE=4;var n=Object.freeze({useProxy:!0,ready:0}),t=new WeakMap,r="2,1,0"===[1].reduce((function(e,n,t){return[e,n,t]}),2).toString()?Array.prototype.reduce:function(e,n){var t,r=Object(this),i=r.length>>>0,o=0;if(n)t=n;else{for(;o<i&&!(o in r);)o++;t=r[o++]}for(;o<i;)o in r&&(t=e(t,r[o],o,r)),o++;return t};function i(e,n){return Array.prototype.slice.call(e,n)}var o=Object.assign||function(e){return r.call(i(arguments,1),(function(e,n){return n&&Object.keys(n).forEach((function(t){e[t]=n[t]})),e}),e)};function a(e){var u,c={},s=[];function d(e,n){return"function"==typeof e?p.call(null,"sync",e,n):"string"==typeof e&&"function"==typeof n?p.apply(null,arguments):"object"==typeof e?f.apply(null,arguments):void 0}function f(e,n,t){var r=!0;void 0===n&&(n=Object.getOwnPropertyNames(e),r=!1);var i={},o=["constructor"];do{(n=n.filter((function(n){return!("function"!=typeof e[n]||-1!==o.indexOf(n)||n.match(/^_/))}))).forEach((function(n){var r=n.split(":"),o=r[0],a=r[1]||"sync";if(!i[o]){var u=e[o];i[o]=e[o]=p(a,u,t?[t,o]:void 0)}})),e=Object.getPrototypeOf(e)}while(r&&e);return i}function l(e){var n=Array.isArray(e)?e:e.split(".");return r.call(n,(function(t,r,i){var o=t[r],a=!1;return o||(i===n.length-1?(u||s.push((function(){a||console.warn("fun-hooks: referenced '"+e+"' but it was never created")})),t[r]=g((function(e){t[r]=e,a=!0}))):t[r]={})}),c)}function g(e){var n=[],r=[],i=function(){},a={before:function(e,t){return c.call(this,n,"before",e,t)},after:function(e,n){return c.call(this,r,"after",e,n)},getHooks:function(e){var t=n.concat(r);"object"==typeof e&&(t=t.filter((function(n){return Object.keys(e).every((function(t){return n[t]===e[t]}))})));try{o(t,{remove:function(){return t.forEach((function(e){e.remove()})),this}})}catch(e){console.error("error adding `remove` to array, did you modify Array.prototype?")}return t},removeAll:function(){return this.getHooks().remove()}},u={install:function(t,o,a){this.type=t,i=a,a(n,r),e&&e(o)}};return t.set(a.after,u),a;function c(e,t,o,a){var u={hook:o,type:t,priority:a||10,remove:function(){var t=e.indexOf(u);-1!==t&&(e.splice(t,1),i(n,r))}};return e.push(u),e.sort((function(e,n){return n.priority-e.priority})),i(n,r),this}}function p(n,r,c){var d=r.after&&t.get(r.after);if(d){if(d.type!==n)throw"fun-hooks: recreated hookable with different type";return r}var f,p,v=c?l(c):g(),h={get:function(e,n){return v[n]||Reflect.get.apply(Reflect,arguments)}};return u||s.push(m),e.useProxy&&"function"==typeof Proxy&&Proxy.revocable?p=new Proxy(r,h):(p=function(){return h.apply?h.apply(r,this,i(arguments)):r.apply(this,arguments)},o(p,v)),t.get(p.after).install(n,p,(function(e,t){var r,o=[];e.length||t.length?(e.forEach(a),r=o.push(void 0)-1,t.forEach(a),f=function(e,t,a){var u,c=0,s="async"===n&&"function"==typeof a[a.length-1]&&a.pop();function d(e){"sync"===n?u=e:s&&s.apply(null,arguments)}function f(e){if(o[c]){var r=i(arguments);return f.bail=d,r.unshift(f),o[c++].apply(t,r)}"sync"===n?u=e:s&&s.apply(null,arguments)}return o[r]=function(){var r=i(arguments,1);"async"===n&&s&&(delete f.bail,r.push(f));var o=e.apply(t,r);"sync"===n&&f(o)},f.apply(null,a),u}):f=void 0;function a(e){o.push(e.hook)}m()})),p;function m(){!u&&("sync"!==n||e.ready&a.SYNC)&&("async"!==n||e.ready&a.ASYNC)?"sync"!==n&&e.ready&a.QUEUE?h.apply=function(){var e=arguments;s.push((function(){p.apply(e[1],e[2])}))}:h.apply=function(){throw"fun-hooks: hooked function not ready"}:h.apply=f}}return(e=o({},n,e)).ready?d.ready=function(){u=!0,function(e){for(var n;n=e.shift();)n()}(s)}:u=!0,d.get=l,d}e.exports=a},77079:function(e){e.exports=function e(n){var t=Array.isArray(n)?[]:{};for(var r in n){var i=n[r];t[r]=i&&"object"==typeof i?e(i):i}return t}},30907:function(e,n,t){function r(e,n){(null==n||n>e.length)&&(n=e.length);for(var t=0,r=new Array(n);t<n;t++)r[t]=e[t];return r}t.d(n,{Z:function(){return r}})},83878:function(e,n,t){function r(e){if(Array.isArray(e))return e}t.d(n,{Z:function(){return r}})},45057:function(e,n,t){t.d(n,{Z:function(){return i}});var r=t(30907);function i(e){if(Array.isArray(e))return(0,r.Z)(e)}},97326:function(e,n,t){function r(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e}t.d(n,{Z:function(){return r}})},26983:function(e,n,t){function r(e,n){return n.get?n.get.call(e):n.value}t.d(n,{Z:function(){return r}})},86011:function(e,n,t){function r(e,n,t){if(n.set)n.set.call(e,t);else{if(!n.writable)throw new TypeError("attempted to set read only private field");n.value=t}}t.d(n,{Z:function(){return r}})},15671:function(e,n,t){function r(e,n){if(!(e instanceof n))throw new TypeError("Cannot call a class as a function")}t.d(n,{Z:function(){return r}})},1519:function(e,n,t){function r(e,n,t){if(!n.has(e))throw new TypeError("attempted to "+t+" private field on non-instance");return n.get(e)}t.d(n,{Z:function(){return r}})},18916:function(e,n,t){t.d(n,{Z:function(){return o}});var r=t(26983),i=t(1519);function o(e,n){var t=(0,i.Z)(e,n,"get");return(0,r.Z)(e,t)}},42793:function(e,n,t){t.d(n,{Z:function(){return o}});var r=t(86011),i=t(1519);function o(e,n,t){var o=(0,i.Z)(e,n,"set");return(0,r.Z)(e,o,t),t}},5647:function(e,n,t){t.d(n,{Z:function(){return o}});var r=t(89611),i=t(78814);function o(e,n,t){return o=(0,i.Z)()?Reflect.construct.bind():function(e,n,t){var i=[null];i.push.apply(i,n);var o=new(Function.bind.apply(e,i));return t&&(0,r.Z)(o,t.prototype),o},o.apply(null,arguments)}},43144:function(e,n,t){function r(e,n){for(var t=0;t<n.length;t++){var r=n[t];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function i(e,n,t){return n&&r(e.prototype,n),t&&r(e,t),Object.defineProperty(e,"prototype",{writable:!1}),e}t.d(n,{Z:function(){return i}})},4942:function(e,n,t){function r(e,n,t){return n in e?Object.defineProperty(e,n,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[n]=t,e}t.d(n,{Z:function(){return r}})},88301:function(e,n,t){t.d(n,{Z:function(){return i}});var r=t(18415);function i(){return i="undefined"!=typeof Reflect&&Reflect.get?Reflect.get.bind():function(e,n,t){var i=(0,r.Z)(e,n);if(i){var o=Object.getOwnPropertyDescriptor(i,n);return o.get?o.get.call(arguments.length<3?e:t):o.value}},i.apply(this,arguments)}},61120:function(e,n,t){function r(e){return r=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(e){return e.__proto__||Object.getPrototypeOf(e)},r(e)}t.d(n,{Z:function(){return r}})},60136:function(e,n,t){t.d(n,{Z:function(){return i}});var r=t(89611);function i(e,n){if("function"!=typeof n&&null!==n)throw new TypeError("Super expression must either be null or a function");e.prototype=Object.create(n&&n.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),Object.defineProperty(e,"prototype",{writable:!1}),n&&(0,r.Z)(e,n)}},48989:function(e,n,t){function r(e){return-1!==Function.toString.call(e).indexOf("[native code]")}t.d(n,{Z:function(){return r}})},78814:function(e,n,t){function r(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(e){return!1}}t.d(n,{Z:function(){return r}})},59199:function(e,n,t){function r(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}t.d(n,{Z:function(){return r}})},31902:function(e,n,t){function r(e,n){var t=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=t){var r,i,o=[],a=!0,u=!1;try{for(t=t.call(e);!(a=(r=t.next()).done)&&(o.push(r.value),!n||o.length!==n);a=!0);}catch(e){u=!0,i=e}finally{try{a||null==t.return||t.return()}finally{if(u)throw i}}return o}}t.d(n,{Z:function(){return r}})},25267:function(e,n,t){function r(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}t.d(n,{Z:function(){return r}})},42786:function(e,n,t){function r(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}t.d(n,{Z:function(){return r}})},82963:function(e,n,t){t.d(n,{Z:function(){return o}});var r=t(71002),i=t(97326);function o(e,n){if(n&&("object"===(0,r.Z)(n)||"function"==typeof n))return n;if(void 0!==n)throw new TypeError("Derived constructors may only return object or undefined");return(0,i.Z)(e)}},89611:function(e,n,t){function r(e,n){return r=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(e,n){return e.__proto__=n,e},r(e,n)}t.d(n,{Z:function(){return r}})},93324:function(e,n,t){t.d(n,{Z:function(){return u}});var r=t(83878),i=t(31902),o=t(40181),a=t(25267);function u(e,n){return(0,r.Z)(e)||(0,i.Z)(e,n)||(0,o.Z)(e,n)||(0,a.Z)()}},18415:function(e,n,t){t.d(n,{Z:function(){return i}});var r=t(61120);function i(e,n){for(;!Object.prototype.hasOwnProperty.call(e,n)&&null!==(e=(0,r.Z)(e)););return e}},89062:function(e,n,t){t.d(n,{Z:function(){return u}});var r=t(45057),i=t(59199),o=t(40181),a=t(42786);function u(e){return(0,r.Z)(e)||(0,i.Z)(e)||(0,o.Z)(e)||(0,a.Z)()}},71002:function(e,n,t){function r(e){return r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},r(e)}t.d(n,{Z:function(){return r}})},40181:function(e,n,t){t.d(n,{Z:function(){return i}});var r=t(30907);function i(e,n){if(e){if("string"==typeof e)return(0,r.Z)(e,n);var t=Object.prototype.toString.call(e).slice(8,-1);return"Object"===t&&e.constructor&&(t=e.constructor.name),"Map"===t||"Set"===t?Array.from(e):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?(0,r.Z)(e,n):void 0}}},7112:function(e,n,t){t.d(n,{Z:function(){return u}});var r=t(61120),i=t(89611),o=t(48989),a=t(5647);function u(e){var n="function"==typeof Map?new Map:void 0;return u=function(e){if(null===e||!(0,o.Z)(e))return e;if("function"!=typeof e)throw new TypeError("Super expression must either be null or a function");if(void 0!==n){if(n.has(e))return n.get(e);n.set(e,t)}function t(){return(0,a.Z)(e,arguments,(0,r.Z)(this).constructor)}return t.prototype=Object.create(e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),(0,i.Z)(t,e)},u(e)}},5644:function(e){e.exports=JSON.parse('{"k2":{"xn":"adserverTargeting","zF":"standard"},"f":"pbjs_debug","Q_":{"GOOD":1,"NO_BID":2},"FP":{"AUCTION_INIT":"auctionInit","AUCTION_END":"auctionEnd","BID_ADJUSTMENT":"bidAdjustment","BID_TIMEOUT":"bidTimeout","BID_REQUESTED":"bidRequested","BID_RESPONSE":"bidResponse","NO_BID":"noBid","BID_WON":"bidWon","BIDDER_DONE":"bidderDone","BIDDER_ERROR":"bidderError","SET_TARGETING":"setTargeting","BEFORE_REQUEST_BIDS":"beforeRequestBids","BEFORE_BIDDER_HTTP":"beforeBidderHttp","REQUEST_BIDS":"requestBids","ADD_AD_UNITS":"addAdUnits","AD_RENDER_FAILED":"adRenderFailed","AD_RENDER_SUCCEEDED":"adRenderSucceeded","TCF2_ENFORCEMENT":"tcf2Enforcement","AUCTION_DEBUG":"auctionDebug","BID_VIEWABLE":"bidViewable","STALE_RENDER":"staleRender","BILLABLE_EVENT":"billableEvent"},"q_":{"PREVENT_WRITING_ON_MAIN_DOCUMENT":"preventWritingOnMainDocument","NO_AD":"noAd","EXCEPTION":"exception","CANNOT_FIND_AD":"cannotFindAd","MISSING_DOC_OR_ADID":"missingDocOrAdid"},"aI":{"bidWon":"adUnitCode"},"Ql":{"yE":"low","M2":"medium","lj":"high","B7":"auto","uN":"dense","qN":"custom"},"TD":{"BIDDER":"hb_bidder","AD_ID":"hb_adid","PRICE_BUCKET":"hb_pb","SIZE":"hb_size","DEAL":"hb_deal","SOURCE":"hb_source","FORMAT":"hb_format","UUID":"hb_uuid","CACHE_ID":"hb_cache_id","CACHE_HOST":"hb_cache_host","ADOMAIN":"hb_adomain"},"kF":{"BIDDER":"hb_bidder","AD_ID":"hb_adid","PRICE_BUCKET":"hb_pb","SIZE":"hb_size","DEAL":"hb_deal","FORMAT":"hb_format","UUID":"hb_uuid","CACHE_HOST":"hb_cache_host"},"FY":{"title":"hb_native_title","body":"hb_native_body","body2":"hb_native_body2","privacyLink":"hb_native_privacy","privacyIcon":"hb_native_privicon","sponsoredBy":"hb_native_brand","image":"hb_native_image","icon":"hb_native_icon","clickUrl":"hb_native_linkurl","displayUrl":"hb_native_displayurl","cta":"hb_native_cta","rating":"hb_native_rating","address":"hb_native_address","downloads":"hb_native_downloads","likes":"hb_native_likes","phone":"hb_native_phone","price":"hb_native_price","salePrice":"hb_native_saleprice","rendererUrl":"hb_renderer_url","adTemplate":"hb_adTemplate"},"os":{"YZ":"s2s"},"UE":{"CK":"targetingSet","fe":"rendered","G9":"bidRejected"},"V1":{"body":"desc","body2":"desc2","sponsoredBy":"sponsored","cta":"ctatext","rating":"rating","address":"address","downloads":"downloads","likes":"likes","phone":"phone","price":"price","salePrice":"saleprice","displayUrl":"displayurl"},"s$":{"sponsored":1,"desc":2,"rating":3,"likes":4,"downloads":5,"price":6,"saleprice":7,"phone":8,"address":9,"desc2":10,"displayurl":11,"ctatext":12},"oF":{"ICON":1,"MAIN":3},"zA":["sendTargetingKeys","adTemplate","rendererUrl","type"]}')}},t={};function r(e){var i=t[e];if(void 0!==i)return i.exports;var o=t[e]={exports:{}};return n[e].call(o.exports,o,o.exports,r),o.exports}r.m=n,e=[],r.O=function(n,t,i,o){if(!t){var a=1/0;for(d=0;d<e.length;d++){t=e[d][0],i=e[d][1],o=e[d][2];for(var u=!0,c=0;c<t.length;c++)(!1&o||a>=o)&&Object.keys(r.O).every((function(e){return r.O[e](t[c])}))?t.splice(c--,1):(u=!1,o<a&&(a=o));if(u){e.splice(d--,1);var s=i();void 0!==s&&(n=s)}}return n}o=o||0;for(var d=e.length;d>0&&e[d-1][2]>o;d--)e[d]=e[d-1];e[d]=[t,i,o]},r.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(n,{a:n}),n},r.d=function(e,n){for(var t in n)r.o(n,t)&&!r.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:n[t]})},r.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),r.o=function(e,n){return Object.prototype.hasOwnProperty.call(e,n)},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},function(){var e={5602:0};r.O.j=function(n){return 0===e[n]};var n=function(n,t){var i,o,a=t[0],u=t[1],c=t[2],s=0;if(a.some((function(n){return 0!==e[n]}))){for(i in u)r.o(u,i)&&(r.m[i]=u[i]);if(c)var d=c(r)}for(n&&n(t);s<a.length;s++)o=a[s],r.o(e,o)&&e[o]&&e[o][0](),e[o]=0;return r.O(d)},t=self.pbjsChunk=self.pbjsChunk||[];t.forEach(n.bind(null,0)),t.push=n.bind(null,t.push.bind(t))}();var i=r(23866);i=r.O(i)}();
(self.pbjsChunk=self.pbjsChunk||[]).push([[3864],{46319:function(e,r,a){a.d(r,{p:function(){return S}});var n=a(71002),t=a(89062),i=a(64358),s=a(20265),o=a(35706),d=a(3193),p=a(14699),c=a(24679),u=a(78653),m=a(34614),l=a(90154),f=a(15164),v=a(55975),g=a(17673),b=a(70059),y="appnexus",h="https://ib.adnxs.com/ut/v3/prebid",_="https://ib.adnxs-simple.com/ut/v3/prebid",k=["id","minduration","maxduration","skippable","playback_method","frameworks","context","skipoffset"],I=["minduration","maxduration","skip","skipafter","playbackmethod","api"],w=["age","externalUid","segments","gender","dnt","language"],x=["geo","device_id"],C=["enabled","dongle","member_id","debug_timeout"],E={playback_method:{unknown:0,auto_play_sound_on:1,auto_play_sound_off:2,click_to_play:3,mouse_over:4,auto_play_sound_unknown:5},context:{unknown:0,pre_roll:1,mid_roll:2,post_roll:3,outstream:4,"in-banner":5}},A={body:"description",body2:"desc2",cta:"ctatext",image:{serverName:"main_image",requiredParams:{required:!0}},icon:{serverName:"icon",requiredParams:{required:!0}},sponsoredBy:"sponsored_by",privacyLink:"privacy_link",salePrice:"saleprice",displayUrl:"displayurl"},T=/\/\/cdn\.adnxs\.com\/v|\/\/cdn\.adnxs\-simple\.com\/v/,O=(0,f.df)({gvlid:32,bidderCode:y}),S={code:y,gvlid:32,aliases:[{code:"appnexusAst",gvlid:32},{code:"emxdigital",gvlid:183},{code:"pagescience"},{code:"defymedia"},{code:"gourmetads"},{code:"matomy"},{code:"featureforward"},{code:"oftmedia"},{code:"adasta"},{code:"beintoo",gvlid:618}],supportedMediaTypes:[c.Mk,c.pX,c.B5],isBidRequestValid:function(e){return!!(e.params.placementId||e.params.member&&e.params.invCode)},buildRequests:function(e,r){var a=(e=(0,b.lY)(e)).map(q),n=(0,m.sE)(e,B),o={};!0===d.vc.getConfig("coppa")&&(o={coppa:!0}),n&&Object.keys(n.params.user).filter((function(e){return(0,m.q9)(w,e)})).forEach((function(e){var r=(0,i.convertCamelToUnderscore)(e);if("segments"===e&&(0,i.isArray)(n.params.user[e])){var a=[];n.params.user[e].forEach((function(e){(0,i.isNumber)(e)?a.push({id:e}):(0,i.isPlainObject)(e)&&a.push(e)})),o[r]=a}else"segments"!==e&&(o[r]=n.params.user[e])}));var p,c=(0,m.sE)(e,Z);c&&c.params&&c.params.app&&(p={},Object.keys(c.params.app).filter((function(e){return(0,m.q9)(x,e)})).forEach((function(e){return p[e]=c.params.app[e]})));var u,l=(0,m.sE)(e,M);l&&l.params&&c.params.app&&c.params.app.id&&(u={appid:l.params.app.id});var f={},v={},y=O.getCookie("apn_prebid_debug")||null;if(y)try{f=JSON.parse(y)}catch(e){(0,i.logError)("AppNexus Debug Auction Cookie Error:\n\n"+e)}else{var k=(0,m.sE)(e,D);k&&k.debug&&(f=k.debug)}f&&f.enabled&&Object.keys(f).filter((function(e){return(0,m.q9)(C,e)})).forEach((function(e){v[e]=f[e]}));var I=(0,m.sE)(e,N),E=I?parseInt(I.params.member,10):0,A=e[0].schain,T=(0,m.sE)(e,X),S={tags:(0,t.Z)(a),user:o,sdk:{source:"pbjs",version:"7.12.0"},schain:A};T&&(S.iab_support={omidpn:"Appnexus",omidpv:"7.12.0"}),E>0&&(S.member_id=E),c&&(S.device=p),l&&(S.app=u);var j=d.vc.getConfig("appnexusAuctionKeywords");if((0,i.isPlainObject)(j)){var R=(0,i.transformBidderParamKeywords)(j);R.length>0&&R.forEach(P),S.keywords=R}if(d.vc.getConfig("adpod.brandCategoryExclusion")&&(S.brand_category_uniqueness=!0),v.enabled&&(S.debug=v,(0,i.logInfo)("AppNexus Debug Auction Settings:\n\n"+JSON.stringify(v,null,4))),r&&r.gdprConsent&&(S.gdpr_consent={consent_string:r.gdprConsent.consentString,consent_required:r.gdprConsent.gdprApplies},r.gdprConsent.addtlConsent&&-1!==r.gdprConsent.addtlConsent.indexOf("~"))){var U=r.gdprConsent.addtlConsent,K=U.substring(U.indexOf("~")+1);S.gdpr_consent.addtl_consent=K.split(".").map((function(e){return parseInt(e,10)}))}if(r&&r.uspConsent&&(S.us_privacy=r.uspConsent),r&&r.refererInfo){var L={rd_ref:encodeURIComponent(r.refererInfo.topmostLocation),rd_top:r.refererInfo.reachedTop,rd_ifs:r.refererInfo.numIframes,rd_stk:r.refererInfo.stack.map((function(e){return encodeURIComponent(e)})).join(",")},W=r.refererInfo.canonicalUrl;(0,i.isStr)(W)&&""!==W&&(L.rd_can=W),S.referrer_detection=L}if((0,m.sE)(e,z)&&e.filter(z).forEach((function(e){var r=function(e,r){var a=r.mediaTypes.video,n=a.durationRangeSec,s=a.requireExactDuration,o=function(e){var r=e.adPodDurationSec,a=e.durationRangeSec,n=e.requireExactDuration,t=(0,i.getMinValueFromArray)(a),s=Math.floor(r/t);return n?Math.max(s,a.length):s}(r.mediaTypes.video),d=(0,i.getMaxValueFromArray)(n),p=e.filter((function(e){return e.uuid===r.bidId})),c=i.fill.apply(void 0,(0,t.Z)(p).concat([o]));if(s){var u=Math.ceil(o/n.length),m=(0,i.chunk)(c,u);n.forEach((function(e,r){m[r].map((function(r){F(r,"minduration",e),F(r,"maxduration",e)}))}))}else c.map((function(e){return F(e,"maxduration",d)}));return c}(a,e),n=S.tags.filter((function(r){return r.uuid!==e.bidId}));S.tags=[].concat((0,t.Z)(n),(0,t.Z)(r))})),e[0].userId){var J=[];V(J,(0,s.Z)(e[0],"userId.criteoId"),"criteo.com",null),V(J,(0,s.Z)(e[0],"userId.netId"),"netid.de",null),V(J,(0,s.Z)(e[0],"userId.idl_env"),"liveramp.com",null),V(J,(0,s.Z)(e[0],"userId.tdid"),"adserver.org","TDID"),V(J,(0,s.Z)(e[0],"userId.uid2.id"),"uidapi.com","UID2"),e[0].userId.pubProvidedId&&e[0].userId.pubProvidedId.forEach((function(e){e.uids.forEach((function(r){J.push({source:e.source,id:r.id})}))})),J.length&&(S.eids=J)}a[0].publisher_id&&(S.publisher_id=a[0].publisher_id);var H=function(e,r){var a=[],n={withCredentials:!0},t=h;(0,g.h)(null==r?void 0:r.gdprConsent)||(t=_);"TRUE"!==(0,i.getParameterByName)("apn_test").toUpperCase()&&!0!==d.vc.getConfig("apn_test")||(n.customHeaders={"X-Is-Test":1});if(e.tags.length>15){var s=(0,i.deepClone)(e);(0,i.chunk)(e.tags,15).forEach((function(e){s.tags=e;var i=JSON.stringify(s);a.push({method:"POST",url:t,data:i,bidderRequest:r,options:n})}))}else{var o=JSON.stringify(e);a={method:"POST",url:t,data:o,bidderRequest:r,options:n}}return a}(S,r);return H},interpretResponse:function(e,r){var a=this,n=r.bidderRequest;e=e.body;var t=[];if(!e||e.error){var d="in response for ".concat(n.bidderCode," adapter");return e&&e.error&&(d+=": ".concat(e.error)),(0,i.logError)(d),t}if(e.tags&&e.tags.forEach((function(e){var r,d=(r=e)&&r.ads&&r.ads.length&&(0,m.sE)(r.ads,(function(e){return e.rtb}));if(d&&((!0===v.S.get(n.bidderCode,"allowZeroCpmBids")?d.cpm>=0:d.cpm>0)&&(0,m.q9)(a.supportedMediaTypes,d.ad_type))){var u=function(e,r,a){var n=(0,i.getBidRequest)(e.uuid,[a]),t={requestId:e.uuid,cpm:r.cpm,creativeId:r.creative_id,dealId:r.deal_id,currency:"USD",netRevenue:!0,ttl:300,adUnitCode:n.adUnitCode,appnexus:{buyerMemberId:r.buyer_member_id,dealPriority:r.deal_priority,dealCode:r.deal_code}};r.adomain&&(t.meta=Object.assign({},t.meta,{advertiserDomains:[]}));r.advertiser_id&&(t.meta=Object.assign({},t.meta,{advertiserId:r.advertiser_id}));function d(e){return{ver:"1.0",complete:0,nodes:[{bsid:e.buyer_member_id.toString()}]}}r.buyer_member_id&&(t.meta=Object.assign({},t.meta,{dchain:d(r)}));r.brand_id&&(t.meta=Object.assign({},t.meta,{brandId:r.brand_id}));if(r.rtb.video){switch(Object.assign(t,{width:r.rtb.video.player_width,height:r.rtb.video.player_height,vastImpUrl:r.notify_url,ttl:3600}),(0,s.Z)(n,"mediaTypes.video.context")){case c.Oh:var u=(0,p.Q1)(n.bidder,r.brand_category_id);t.meta=Object.assign({},t.meta,{primaryCatId:u});var f=r.deal_priority;t.video={context:c.Oh,durationSeconds:Math.floor(r.rtb.video.duration_ms/1e3),dealTier:f},t.vastUrl=r.rtb.video.asset_url;break;case l.gZ:if(t.adResponse=e,t.adResponse.ad=t.adResponse.ads[0],t.adResponse.ad.video=t.adResponse.ad.rtb.video,t.vastXml=r.rtb.video.content,r.renderer_url){var v=(0,m.sE)(a.bids,(function(r){return r.bidId===e.uuid})),g=(0,s.Z)(v,"mediaTypes.video.renderer.options");g||(g=(0,s.Z)(v,"renderer.options")),t.renderer=function(e,r){var a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},n=o.Th.install({id:r.renderer_id,url:r.renderer_url,config:a,loaded:!1,adUnitCode:e});try{n.setRender(K)}catch(e){(0,i.logWarn)("Prebid Error calling setRender on renderer",e)}return n.setEventHandlers({impression:function(){return(0,i.logMessage)("AppNexus outstream video impression event")},loaded:function(){return(0,i.logMessage)("AppNexus outstream video loaded event")},ended:function(){(0,i.logMessage)("AppNexus outstream renderer video event"),document.querySelector("#".concat(e)).style.display="none"}}),n}(t.adUnitCode,r,g)}break;case l.LD:t.vastUrl=r.notify_url+"&redir="+encodeURIComponent(r.rtb.video.asset_url)}}else if(r.rtb[c.B5]){var b=r.rtb[c.B5],y=r.viewability.config.replace("src=","data-src="),h=b.javascript_trackers;null==h?h=y:(0,i.isStr)(h)?h=[h,y]:h.push(y),t[c.B5]={title:b.title,body:b.desc,body2:b.desc2,cta:b.ctatext,rating:b.rating,sponsoredBy:b.sponsored,privacyLink:b.privacy_link,address:b.address,downloads:b.downloads,likes:b.likes,phone:b.phone,price:b.price,salePrice:b.saleprice,clickUrl:b.link.url,displayUrl:b.displayurl,clickTrackers:b.link.click_trackers,impressionTrackers:b.impression_trackers,javascriptTrackers:h},b.main_img&&(t.native.image={url:b.main_img.url,height:b.main_img.height,width:b.main_img.width}),b.icon&&(t.native.icon={url:b.icon.url,height:b.icon.height,width:b.icon.width})}else{Object.assign(t,{width:r.rtb.banner.width,height:r.rtb.banner.height,ad:r.rtb.banner.content});try{if(r.rtb.trackers)for(var _=0;_<r.rtb.trackers[0].impression_urls.length;_++){var k=r.rtb.trackers[0].impression_urls[_],I=(0,i.createTrackPixelHtml)(k);t.ad+=I}}catch(e){(0,i.logError)("Error appending tracking pixel",e)}}return t}(e,d,n);u.mediaType=function(e){var r=e.ad_type;return r===c.pX?c.pX:r===c.B5?c.B5:c.Mk}(d),t.push(u)}})),e.debug&&e.debug.debug_info){var u="AppNexus Debug Auction for Prebid\n\n"+e.debug.debug_info;u=u.replace(/(<td>|<th>)/gm,"\t").replace(/(<\/td>|<\/th>)/gm,"\n").replace(/^<br>/gm,"").replace(/(<br>\n|<br>)/gm,"\n").replace(/<h1>(.*)<\/h1>/gm,"\n\n===== $1 =====\n\n").replace(/<h[2-6]>(.*)<\/h[2-6]>/gm,"\n\n*** $1 ***\n\n").replace(/(<([^>]+)>)/gim,""),(0,i.logMessage)("https://console.appnexus.com/docs/understanding-the-debug-auction"),(0,i.logMessage)(u)}return t},getMappingFileInfo:function(){return{url:"https://acdn.adnxs-simple.com/prebid/appnexus-mapping/mappings.json",refreshInDays:2}},getUserSyncs:function(e,r,a){if(e.iframeEnabled&&(0,g.h)(a))return[{type:"iframe",url:"https://acdn.adnxs.com/dmp/async_usersync.html"}]},transformBidParams:function(e,r,a,n){var t=i.transformBidderParamKeywords;if(!0===r){var o=null,p=d.vc.getConfig("s2sConfig");(0,i.isPlainObject)(p)?o=(0,s.Z)(p,"endpoint.p1Consent"):(0,i.isArray)(p)&&p.forEach((function(e){(0,m.q9)(e.bidders,a.bids[0].bidder)&&(o=(0,s.Z)(e,"endpoint.p1Consent"))})),o&&o.match("/openrtb2/prebid")&&(t=W)}return e=(0,i.convertTypes)({member:"string",invCode:"string",placementId:"number",keywords:t,publisherId:"number"},e),r&&(e.use_pmt_rule="boolean"==typeof e.usePaymentRule&&e.usePaymentRule,e.usePaymentRule&&delete e.usePaymentRule,j(e.keywords)&&e.keywords.forEach(P),Object.keys(e).forEach((function(r){var a=(0,i.convertCamelToUnderscore)(r);a!==r&&(e[a]=e[r],delete e[r])}))),e},onBidWon:function(e){e.native&&function(e){var r=function(e){var r;if((0,i.isStr)(e)&&R(e))r=e;else if((0,i.isArray)(e))for(var a=0;a<e.length;a++){var n=e[a];R(n)&&(r=n)}return r}(e.native.javascriptTrackers);if(r)for(var a="pbjs_adid="+e.adId+";pbjs_auc="+e.adUnitCode,n=function(e){var r=e.indexOf('src="')+5,a=e.indexOf('"',r);return e.substring(r,a)}(r),t=n.replace("dom_id=%native_dom_id%",a),s=document.getElementsByTagName("iframe"),o=!1,d=0;d<s.length&&!o;d++){var p=s[d];try{var c=p.contentDocument||p.contentWindow.document;if(c)for(var u=c.getElementsByTagName("script"),m=0;m<u.length&&!o;m++){var l=u[m];l.getAttribute("data-src")==n&&(l.setAttribute("src",t),l.setAttribute("data-src",""),l.removeAttribute&&l.removeAttribute("data-src"),o=!0)}}catch(e){if(!(e instanceof DOMException&&"SecurityError"===e.name))throw e}}}(e)}};function j(e){return!!((0,i.isArray)(e)&&e.length>0)}function P(e){j(e.value)&&""===e.value[0]&&delete e.value}function R(e){var r=e.match(T),a=null!=r&&r.length>=1,n=e.match("trk.js"),t=null!=n&&n.length>=1;return e.startsWith("<script")&&t&&a}function q(e){var r={};r.sizes=U(e.sizes),r.primary_size=r.sizes[0],r.ad_types=[],r.uuid=e.bidId,e.params.placementId?r.id=parseInt(e.params.placementId,10):r.code=e.params.invCode,r.allow_smaller_sizes=e.params.allowSmallerSizes||!1,r.use_pmt_rule=e.params.usePaymentRule||!1,r.prebid=!0,r.disable_psa=!0;var a=function(e){if(!(0,i.isFn)(e.getFloor))return e.params.reserve?e.params.reserve:null;var r=e.getFloor({currency:"USD",mediaType:"*",size:"*"});if((0,i.isPlainObject)(r)&&!isNaN(r.floor)&&"USD"===r.currency)return r.floor;return null}(e);if(a&&(r.reserve=a),e.params.position)r.position={above:1,below:2}[e.params.position]||0;else{var n=(0,s.Z)(e,"mediaTypes.banner.pos")||(0,s.Z)(e,"mediaTypes.video.pos");0!==n&&1!==n&&3!==n||(r.position=3===n?2:n)}if(e.params.trafficSourceCode&&(r.traffic_source_code=e.params.trafficSourceCode),e.params.privateSizes&&(r.private_sizes=U(e.params.privateSizes)),e.params.supplyType&&(r.supply_type=e.params.supplyType),e.params.pubClick&&(r.pubclick=e.params.pubClick),e.params.extInvCode&&(r.ext_inv_code=e.params.extInvCode),e.params.publisherId&&(r.publisher_id=parseInt(e.params.publisherId,10)),e.params.externalImpId&&(r.external_imp_id=e.params.externalImpId),!(0,i.isEmpty)(e.params.keywords)){var t=(0,i.transformBidderParamKeywords)(e.params.keywords);t.length>0&&t.forEach(P),r.keywords=t}var o,d,p=(0,s.Z)(e,"ortb2Imp.ext.data.pbadslot");if(p&&(r.gpid=p),(e.mediaType===c.B5||(0,s.Z)(e,"mediaTypes.".concat(c.B5)))&&(r.ad_types.push(c.B5),0===r.sizes.length&&(r.sizes=U([1,1])),e.nativeParams)){var l=(o=e.nativeParams,d={},Object.keys(o).forEach((function(e){var r=A[e]&&A[e].serverName||A[e]||e,a=A[e]&&A[e].requiredParams;if(d[r]=Object.assign({},a,o[e]),(r===A.image.serverName||r===A.icon.serverName)&&d[r].sizes){var n=d[r].sizes;((0,i.isArrayOfNums)(n)||(0,i.isArray)(n)&&n.length>0&&n.every((function(e){return(0,i.isArrayOfNums)(e)})))&&(d[r].sizes=U(d[r].sizes))}r===A.privacyLink&&(d.privacy_supported=!0)})),d);r[c.B5]={layouts:[l]}}var f=(0,s.Z)(e,"mediaTypes.".concat(c.pX)),v=(0,s.Z)(e,"mediaTypes.video.context");r.hb_source=f&&"adpod"===v?7:1,(e.mediaType===c.pX||f)&&r.ad_types.push(c.pX),(e.mediaType===c.pX||f&&"outstream"!==v)&&(r.require_asset_url=!0),e.params.video&&(r.video={},Object.keys(e.params.video).filter((function(e){return(0,m.q9)(k,e)})).forEach((function(a){switch(a){case"context":case"playback_method":var n=e.params.video[a];n=(0,i.isArray)(n)?n[0]:n,r.video[a]=E[a][n];break;case"frameworks":break;default:r.video[a]=e.params.video[a]}})),e.params.video.frameworks&&(0,i.isArray)(e.params.video.frameworks)&&(r.video_frameworks=e.params.video.frameworks)),f&&(r.video=r.video||{},Object.keys(f).filter((function(e){return(0,m.q9)(I,e)})).forEach((function(e){switch(e){case"minduration":case"maxduration":"number"!=typeof r.video[e]&&(r.video[e]=f[e]);break;case"skip":"boolean"!=typeof r.video.skippable&&(r.video.skippable=1===f[e]);break;case"skipafter":"number"!=typeof r.video.skipoffset&&(r.video.skippoffset=f[e]);break;case"playbackmethod":if("number"!=typeof r.video.playback_method){var a=f[e];(a=(0,i.isArray)(a)?a[0]:a)>=1&&a<=4&&(r.video.playback_method=a)}break;case"api":if(!r.video_frameworks&&(0,i.isArray)(f[e])){var n=f[e].map((function(e){var r=4===e?5:5===e?4:e;if(r>=1&&r<=5)return r})).filter((function(e){return e}));r.video_frameworks=n}}}))),e.renderer&&(r.video=Object.assign({},r.video,{custom_renderer_present:!0})),e.params.frameworks&&(0,i.isArray)(e.params.frameworks)&&(r.banner_frameworks=e.params.frameworks);var g=(0,m.sE)(u.K.getAdUnits(),(function(r){return e.transactionId===r.transactionId}));return g&&g.mediaTypes&&g.mediaTypes.banner&&r.ad_types.push(c.Mk),0===r.ad_types.length&&delete r.ad_types,r}function U(e){var r=[],a={};if((0,i.isArray)(e)&&2===e.length&&!(0,i.isArray)(e[0]))a.width=parseInt(e[0],10),a.height=parseInt(e[1],10),r.push(a);else if("object"===(0,n.Z)(e))for(var t=0;t<e.length;t++){var s=e[t];(a={}).width=parseInt(s[0],10),a.height=parseInt(s[1],10),r.push(a)}return r}function B(e){return!!e.params.user}function N(e){return!!parseInt(e.params.member,10)}function Z(e){if(e.params)return!!e.params.app}function M(e){return e.params&&e.params.app?!!e.params.app.id:!!e.params.app}function D(e){return!!e.debug}function z(e){return e.mediaTypes&&e.mediaTypes.video&&e.mediaTypes.video.context===c.Oh}function X(e){var r=!1,a=e.params,n=e.params.video;return a.frameworks&&(0,i.isArray)(a.frameworks)&&(r=(0,m.q9)(e.params.frameworks,6)),!r&&n&&n.frameworks&&(0,i.isArray)(n.frameworks)&&(r=(0,m.q9)(e.params.video.frameworks,6)),r}function F(e,r,a){(0,i.isEmpty)(e.video)&&(e.video={}),e.video[r]=a}function K(e,r){!function(e){try{var r=document.getElementById(e).querySelectorAll("div[id^='google_ads']");r[0]&&r[0].style.setProperty("display","none")}catch(e){}}(e.adUnitCode),function(e){try{var r=document.getElementById(e).querySelectorAll("script[id^='sas_script']");r[0].nextSibling&&"iframe"===r[0].nextSibling.localName&&r[0].nextSibling.style.setProperty("display","none")}catch(e){}}(e.adUnitCode),e.renderer.push((function(){((0,i.getWindowFromDocument)(r)||window).ANOutstreamVideo.renderAd({tagId:e.adResponse.tag_id,sizes:[e.getSize().split("x")],targetId:e.adUnitCode,uuid:e.adResponse.uuid,adResponse:e.adResponse,rendererOptions:e.renderer.getConfig()},L.bind(null,e))}))}function L(e,r,a){e.renderer.handleVideoEvent({id:r,eventName:a})}function V(e,r,a,n){return r&&(n?e.push({source:a,id:r,rti_partner:n}):e.push({source:a,id:r})),e}function W(e){var r="";return Object.keys(e).forEach((function(a){(0,i.isStr)(e[a])?""!==e[a]?r+="".concat(a,"=").concat(e[a],","):r+="".concat(a,","):(0,i.isArray)(e[a])&&(""===e[a][0]?r+="".concat(a,","):e[a].forEach((function(e){r+="".concat(a,"=").concat(e,",")})))})),r=r.substring(0,r.length-1)}(0,p.dX)(S),window.pbjs.installedModules.push("appnexusBidAdapter")},17673:function(e,r,a){a.d(r,{h:function(){return t}});var n=a(20265);function t(e){return null==e||!e.gdprApplies||!0===(0,n.Z)(e,"vendorData.purpose.consents.1")}}},function(e){var r;r=46319,e(e.s=r)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[1266],{55630:function(n,e,t){var o,a,r,i,c,s,l=t(71002),d=t(4942),u=t(64358),f=t(3193),p=t(9528),g=t(34614),m=!1,v={iab:function(n){var e=n.onSuccess,t=n.onError;function o(n,o){(0,u.logInfo)("Received a response from CMP",n),o?!1===n.gdprApplies||"tcloaded"===n.eventStatus||"useractioncomplete"===n.eventStatus?w(n,{onSuccess:e,onError:t}):s=n:t("CMP unable to register callback function.  Please check CMP setup.")}var a={},r=function(){for(var n,e,t=window;;){try{if("function"==typeof t.__tcfapi){e=t.__tcfapi,n=t;break}}catch(n){}try{if(t.frames.__tcfapiLocator){n=t;break}}catch(n){}if(t===window.top)break;t=t.parent}return{cmpFrame:n,cmpFunction:e}}(),i=r.cmpFrame,c=r.cmpFunction;if(!i)return t("CMP not found.");"function"==typeof c?((0,u.logInfo)("Detected CMP API is directly accessible, calling it now..."),c("addEventListener",2,o)):((0,u.logInfo)("Detected CMP is outside the current iframe where Prebid.js is located, calling it now..."),function(n,e,t){var o="__tcfapi",r="".concat(o,"Call");function i(n){var e="".concat(o,"Return"),t="string"==typeof n.data&&(0,g.q9)(n.data,e)?JSON.parse(n.data):n.data;if(t[e]&&t[e].callId){var r=t[e];void 0!==a[r.callId]&&a[r.callId](r.returnValue,r.success)}}window[o]=function(n,t,o,i){var c=Math.random()+"",s=(0,d.Z)({},r,{command:n,version:t,parameter:i,callId:c});a[c]=o,e.postMessage(s,"*")},window.addEventListener("message",i,!1),window[o](n,2,t)}("addEventListener",i,o))},static:function(n){var e=n.onSuccess,t=n.onError;w(i,{onSuccess:e,onError:t})}};function b(n){var e=!1,t=null;function r(o,a,r){if(null!=t&&clearTimeout(t),e=!0,p.rp.setConsentData(o),"function"==typeof n){for(var i=arguments.length,c=new Array(i>3?i-3:0),s=3;s<i;s++)c[s-3]=arguments[s];n.apply(void 0,[a,r].concat(c))}}if((0,g.q9)(Object.keys(v),o)){var i={onSuccess:function(n){return r(n,!1)},onError:function(n){for(var e=arguments.length,t=new Array(e>1?e-1:0),o=1;o<e;o++)t[o-1]=arguments[o];r.apply(void 0,[null,!0,n].concat(t))}};if(v[o](i),!e){var c=function(){var n=function(n){r(n,!1,"CMP did not load, continuing auction...")};w(s,{onSuccess:n,onError:function(){return n(M(void 0))}})};0===a?c():t=setTimeout(c,a)}}else r(null,!1,"CMP framework (".concat(o,") is not a supported framework.  Aborting consentManagement module and resuming auction."))}function y(n,e){var t;t=function(t,o){if(o){var a=u.logWarn;t&&(a=u.logError,o="".concat(o," Canceling auction as per consentManagement config."));for(var r=arguments.length,i=new Array(r>2?r-2:0),c=2;c<r;c++)i[c-2]=arguments[c];a.apply(void 0,[o].concat(i))}t?"function"==typeof e.bidsBackHandler?e.bidsBackHandler():(0,u.logError)("Error executing bidsBackHandler"):n.call(this,e)},c?((0,u.logInfo)("User consent information already known.  Pulling internally stored information..."),t(!1)):b(t)}function w(n,e){var t,a,i=e.onSuccess,c=e.onError;"static"===o&&(n=n.getTCData),t=n&&"boolean"==typeof n.gdprApplies?n.gdprApplies:r,a=n&&n.tcString,"boolean"==typeof t&&(!0!==t||a&&(0,u.isStr)(a))?i(M(n)):c("CMP returned unexpected value during lookup process.",n)}function M(n){return c={consentString:n?n.tcString:void 0,vendorData:n||void 0,gdprApplies:n&&"boolean"==typeof n.gdprApplies?n.gdprApplies:r},n&&n.addtlConsent&&(0,u.isStr)(n.addtlConsent)&&(c.addtlConsent=n.addtlConsent),c.apiVersion=2,c}f.vc.getConfig("consentManagement",(function(n){return function(n){(n=n&&(n.gdpr||n.usp?n.gdpr:n))&&"object"===(0,l.Z)(n)?((0,u.isStr)(n.cmpApi)?o=n.cmpApi:(o="iab",(0,u.logInfo)("consentManagement config did not specify cmp.  Using system default setting (".concat("iab",")."))),(0,u.isNumber)(n.timeout)?a=n.timeout:(a=1e4,(0,u.logInfo)("consentManagement config did not specify timeout.  Using system default setting (".concat(1e4,")."))),r=!0===n.defaultGdprScope,(0,u.logInfo)("consentManagement module has been activated..."),"static"===o&&((0,u.isPlainObject)(n.consentData)?(i=n.consentData,a=0):(0,u.logError)("consentManagement config with cmpApi: 'static' did not specify consentData. No consents will be available to adapters.")),m||pbjs.requestBids.before(y,50),m=!0,p.rp.enable(),b()):(0,u.logWarn)("consentManagement config not defined, exiting consent manager")}(n.consentManagement)})),window.pbjs.installedModules.push("consentManagement")}},function(n){var e;e=55630,n(n.s=e)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[5160],{9099:function(n,t,e){var a,o,i=e(71002),c=e(64358),s=e(3193),r=e(9528),u=e(78640),l="iab",p=l,f=50,d=!1,g={iab:function(n){var t=n.onSuccess,e=n.onError;var a=(u={},{consentDataCallback:function(n,a){a&&n.uspString&&(u.usPrivacy=n.uspString),u.usPrivacy?P(u,{onSuccess:t,onError:e}):e("Unable to get USP consent string.")}}),o={},i=function(){for(var n,t,e=window;;){try{if("function"==typeof e.__uspapi){t=e.__uspapi,n=e;break}}catch(n){}try{if(e.frames.__uspapiLocator){n=e;break}}catch(n){}if(e===window.top)break;e=e.parent}return{uspapiFrame:n,uspapiFunction:t}}(),s=i.uspapiFrame,r=i.uspapiFunction;var u;if(!s)return e("USP CMP not found.");(0,c.isFn)(r)?((0,c.logInfo)("Detected USP CMP is directly accessible, calling it now..."),r("getUSPData",1,a.consentDataCallback)):((0,c.logInfo)("Detected USP CMP is outside the current iframe where Prebid.js is located, calling it now..."),function(n,t,e){function a(n){var t=n&&n.data&&n.data.__uspapiReturn;t&&t.callId&&void 0!==o[t.callId]&&(o[t.callId](t.returnValue,t.success),delete o[t.callId])}window.__uspapi=function(n,e,a){var i=Math.random()+"",c={__uspapiCall:{command:n,version:e,callId:i}};o[i]=a,t.postMessage(c,"*")},window.addEventListener("message",a,!1),window.__uspapi(n,1,e)}("getUSPData",s,a.consentDataCallback))},static:function(n){var t=n.onSuccess,e=n.onError;P(a,{onSuccess:t,onError:e})}};function m(n){var t=null,e=!1;function a(a,o){if(null!=t&&clearTimeout(t),e=!0,r.nX.setConsentData(a),null!=n){for(var i=arguments.length,c=new Array(i>2?i-2:0),s=2;s<i;s++)c[s-2]=arguments[s];n.apply(void 0,[o].concat(c))}}if(g[p]){var o={onSuccess:a,onError:function(n){for(var t=arguments.length,e=new Array(t>1?t-1:0),o=1;o<t;o++)e[o-1]=arguments[o];a.apply(void 0,[null,"".concat(n," Resuming auction without consent data as per consentManagement config.")].concat(e))}};g[p](o),e||(0===f?P(void 0,o):t=setTimeout(o.onError.bind(null,"USPAPI workflow exceeded timeout threshold."),f))}else a(null,"USP framework (".concat(p,") is not a supported framework. Aborting consentManagement module and resuming auction."))}function v(n,t){var e=this;m((function(a){if(null!=a){for(var o=arguments.length,i=new Array(o>1?o-1:0),s=1;s<o;s++)i[s-1]=arguments[s];c.logWarn.apply(void 0,[a].concat(i))}n.call(e,t)}))}function P(n,t){var e=t.onSuccess,a=t.onError;!n||!n.usPrivacy?a("USPAPI returned unexpected value during lookup process.",n):(!function(n){n&&n.usPrivacy&&(o=n.usPrivacy)}(n),e(o))}function b(){var n=arguments.length>0&&void 0!==arguments[0]&&arguments[0];d||((0,c.logInfo)("USPAPI consentManagement module has been activated".concat(n?"":" using default values (api: '".concat(p,"', timeout: ").concat(f,"ms)"))),(0,u.R)().requestBids.before(v,50)),d=!0,r.nX.enable(),m()}s.vc.getConfig("consentManagement",(function(n){return function(n){(n=n&&n.usp)&&"object"===(0,i.Z)(n)||(0,c.logWarn)("consentManagement.usp config not defined, using defaults"),n&&(0,c.isStr)(n.cmpApi)?p=n.cmpApi:(p=l,(0,c.logInfo)("consentManagement.usp config did not specify cmpApi. Using system default setting (".concat(l,")."))),n&&(0,c.isNumber)(n.timeout)?f=n.timeout:(f=50,(0,c.logInfo)("consentManagement.usp config did not specify timeout. Using system default setting (".concat(50,")."))),"static"===p&&((0,c.isPlainObject)(n.consentData)&&(0,c.isPlainObject)(n.consentData.getUSPData)?(n.consentData.getUSPData.uspString&&(a={usPrivacy:n.consentData.getUSPData.uspString}),f=0):(0,c.logError)("consentManagement config with cmpApi: 'static' did not specify consentData. No consents will be available to adapters.")),b(!0)}(n.consentManagement)})),setTimeout((function(){return!d&&b()})),window.pbjs.installedModules.push("consentManagementUsp")}},function(n){var t;t=9099,n(n.s=t)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[8806],{19749:function(e,n,t){var i=t(64358),o=t(92797),d=t(25102),r=t(15164),c={},a=window===window.top?window:window.top,m=(0,r.eA)("enrichmentFpd");function u(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:window.location.hostname;if(!m.cookiesAreEnabled())return e;var n,t,o=e.split(".");if(2==o.length)return e;var d=-2,r="_rdc".concat(Date.now()),c="writeable";do{n=o.slice(d).join(".");var a=new Date((0,i.timestamp)()+1e4).toUTCString();m.setCookie(r,c,a,"Lax",n,void 0);var u=m.getCookie(r,void 0);u===c?(t=!1,m.setCookie(r,"","Thu, 01 Jan 1970 00:00:01 GMT",void 0,n,void 0)):(d+=-1,t=Math.abs(d)<=o.length)}while(t);return n}function w(){var e;return(0,d.nH)().ref&&(0,i.mergeDeep)(c,{site:{ref:(0,d.nH)().ref}}),(0,d.nH)().page&&(0,i.mergeDeep)(c,{site:{page:(0,d.nH)().page}}),(e=(0,d.hh)((0,d.nH)().page,{noLeadingWww:!0}))&&((0,i.mergeDeep)(c,{site:{domain:e}}),(0,i.mergeDeep)(c,{site:{publisher:{domain:u(e)}}})),function(){var e,n;try{e=a.innerWidth||a.document.documentElement.clientWidth||a.document.body.clientWidth,n=a.innerHeight||a.document.documentElement.clientHeight||a.document.body.clientHeight}catch(t){e=window.innerWidth||window.document.documentElement.clientWidth||window.document.body.clientWidth,n=window.innerHeight||window.document.documentElement.clientHeight||window.document.body.clientHeight}(0,i.mergeDeep)(c,{device:{w:e,h:n}})}(),function(){var e;try{e=a.document.querySelector("meta[name='keywords']")}catch(n){e=window.document.querySelector("meta[name='keywords']")}e&&e.content&&(0,i.mergeDeep)(c,{site:{keywords:e.content.replace(/\s/g,"")}})}(),c}var l={name:"enrichments",queue:2,processFpd:function(e,n){var t=n.global;return c={},{global:e.skipEnrichments?t:(0,i.mergeDeep)(w(),t)}}};(0,o.Bx)("firstPartyData",l),window.pbjs.installedModules.push("enrichmentFpdModule")}},function(e){var n;n=19749,e(e.s=n)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[7910],{63410:function(n,r,t){var o=t(3193),e=t(92797),i=t(64358),u=t(68792),a=[];function l(n,r){var t=this;(function(){var n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=n.global,t=void 0===r?{}:r,e=n.bidder,l=void 0===e?{}:e,s=o.vc.getConfig("firstPartyData")||{},d=u.Z.resolve({global:t,bidder:l});return a.sort((function(n,r){return(n.queue||1)-(r.queue||1)})).forEach((function(n){d=d.then((function(r){var t=r.global,o=r.bidder;return u.Z.resolve(n.processFpd(s,{global:t,bidder:o})).catch((function(r){return(0,i.logError)("Error in FPD module ".concat(n.name),r),{}})).then((function(n){return{global:n.global||t,bidder:n.bidder||o}}))}))})),d})(r.ortb2Fragments).then((function(o){Object.assign(r.ortb2Fragments,o),n.call(t,r)}))}(0,e.bA)("firstPartyData",(function(n){a.push(n)})),(0,e.v5)("startAuction").before(l,10),window.pbjs.installedModules.push("fpdModule")}},function(n){var r;r=63410,n(n.s=r)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[7083],{31498:function(e,n,r){var t=r(4942),o=r(71002),a=r(64358),i=r(20265),c=r(3193),s=r(9528),l=r(34614),u=r(14699),d=r(92797),p=r(15164),f=r(52021),v=r(5644);function g(e,n){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var t=Object.getOwnPropertySymbols(e);n&&(t=t.filter((function(n){return Object.getOwnPropertyDescriptor(e,n).enumerable}))),r.push.apply(r,t)}return r}function b(e){for(var n=1;n<arguments.length;n++){var r=null!=arguments[n]?arguments[n]:{};n%2?g(Object(r),!0).forEach((function(n){(0,t.Z)(e,n,r[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):g(Object(r)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(r,n))}))}return e}var h,m,y,A,O=new Set(["sharedId","pubCommonId","pubProvidedId"]),P={purpose1:{id:1,name:"storage"},purpose2:{id:2,name:"basicAds"},purpose7:{id:7,name:"measurement"}},C=[{purpose:"storage",enforcePurpose:!0,enforceVendor:!0,vendorExceptions:[]},{purpose:"basicAds",enforcePurpose:!0,enforceVendor:!0,vendorExceptions:[]}],j=[],E=[],D=[],w=!1,F=!1,k={getGvlidForBidAdapter:function(e){var n=null;if(e=e||c.vc.getCurrentBidder()){var r=s.ZP.getBidAdapter(e);r&&r.getSpec&&(n=r.getSpec().gvlid)}return n},getGvlidForUserIdModule:function(e){return"object"===(0,o.Z)(e)?e.gvlid:null},getGvlidForAnalyticsAdapter:function(e){return s.ZP.getAnalyticsAdapter(e)&&(s.ZP.getAnalyticsAdapter(e).gvlid||null)}};function Z(e){var n=null;if(e){var r=c.vc.getConfig("gvlMapping"),t="string"==typeof e?e:e.name;if(r&&r[t])return n=r[t];n=k.getGvlidForBidAdapter(t)||k.getGvlidForUserIdModule(e)||k.getGvlidForAnalyticsAdapter(t)}return n}function B(e,n,r){return null==e&&s.rp.enabled?((0,a.logWarn)("Attempting operation that requires purpose ".concat(n," consent while consent data is not available").concat(r?" (module: ".concat(r,")"):"",". Assuming no consent was given.")),!0):e&&e.gdprApplies}function I(e,n,r,t){var o=arguments.length>4&&void 0!==arguments[4]?arguments[4]:O.has.bind(O),a=P[Object.keys(P).filter((function(n){return P[n].name===e.purpose}))[0]].id;if((0,l.q9)(e.vendorExceptions||[],r))return!0;var c=(0,i.Z)(n,"vendorData.purpose.consents.".concat(a)),s=(0,i.Z)(n,"vendorData.vendor.consents.".concat(t)),u=(0,i.Z)(n,"vendorData.purpose.legitimateInterests.".concat(a)),d=!1===e.enforcePurpose||!0===c,p=o(r)||!1===e.enforceVendor||!0===s;return 2===a?d&&p||!0===u:d&&p}function W(e,n,r,t,o){var i=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{},l=i.validate,u=void 0===l?I:l;if(o=Object.assign({},{hasEnforcementHook:!0}),(0,a.hasDeviceAccess)())if(n&&!F)o.valid=!0;else{var d=s.rp.getConsentData();if(B(d,1,t)){var p=c.vc.getCurrentBidder();r=p&&p!=t&&s.ZP.aliasRegistry[p]===t?Z(p):Z(t)||r;var f=t||p,v=u(h,d,f,r,n?function(){return!0}:void 0);v?o.valid=!0:(f&&(0,a.logWarn)("TCF2 denied device access for ".concat(f)),o.valid=!1,j.push(f))}else o.valid=!0}else(0,a.logWarn)("Device access is disabled by Publisher"),o.valid=!1;e.call(this,n,r,t,o)}function G(e){for(var n=s.rp.getConsentData(),r=c.vc.getCurrentBidder(),t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];if(B(n,1,r)){var l=Z(r),u=I(h,n,r,l);u?e.call.apply(e,[this].concat(o)):((0,a.logWarn)("User sync not allowed for ".concat(r)),j.push(r))}else e.call.apply(e,[this].concat(o))}function M(e,n,r){if(B(r,1,"User ID")){var t=n.map((function(e){var n=Z(e.submodule),t=e.submodule.name;if(I(h,r,t,n))return e;(0,a.logWarn)("User denied permission to fetch user id for ".concat(t," User id module")),j.push(t)})).filter((function(e){return e}));e.call(this,t,b(b({},r),{},{hasValidated:!0}))}else e.call(this,n,r)}function S(e,n){for(var r=s.rp.getConsentData(),t=arguments.length,o=new Array(t>2?t-2:0),i=2;i<t;i++)o[i-2]=arguments[i];B(r,2)?(n.forEach((function(e){e.bids=e.bids.filter((function(e){var n=e.bidder,t=Z(n);if((0,l.q9)(E,n))return!1;var o=!!I(m,r,n,t);return o||((0,a.logWarn)("TCF2 blocked auction for ".concat(n)),E.push(n)),o}))})),e.call.apply(e,[this,n].concat(o))):e.call.apply(e,[this,n].concat(o))}function T(e,n){var r=s.rp.getConsentData();B(r,7,"Analytics")?((0,a.isArray)(n)||(n=[n]),n=n.filter((function(e){var n=e.provider,t=Z(n),o=!!I(y,r,n,t);return o||(D.push(n),(0,a.logWarn)("TCF2 blocked analytics adapter ".concat(e.provider))),o})),e.call(this,n)):e.call(this,n)}f.on(v.FP.AUCTION_END,(function(){var e=function(e){return e.filter((function(n,r){return null!==n&&e.indexOf(n)===r}))},n={storageBlocked:e(j),biddersBlocked:e(E),analyticsBlocked:e(D)};f.j8(v.FP.TCF2_ENFORCEMENT,n)}));var U=function(e){return e.purpose===P.purpose1.name},q=function(e){return e.purpose===P.purpose2.name},x=function(e){return e.purpose===P.purpose7.name};c.vc.getConfig("consentManagement",(function(e){return function(e){var n=(0,i.Z)(e,"gdpr.rules");n?A=n:((0,a.logWarn)("TCF2: enforcing P1 and P2 by default"),A=C),F=!!(0,i.Z)(e,"strictStorageEnforcement"),h=(0,l.sE)(A,U),m=(0,l.sE)(A,q),y=(0,l.sE)(A,x),h||(h=C[0]),m||(m=C[1]),w||(h&&(w=!0,p.S6.before(W,49),u.Ks.before(G,48),(0,d.v5)("validateGdprEnforcement").before(M,47)),m&&(0,d.v5)("makeBidRequests").before(S),y&&(0,d.v5)("enableAnalyticsCb").before(T))}(e.consentManagement)})),window.pbjs.installedModules.push("gdprEnforcement")}},function(e){var n;n=31498,e(e.s=n)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[5296],{96787:function(t,e,o){var n=o(64358),r=o(20265),a=o(3193),d=o(92797),i=o(34614),u=void 0,c={},s=!1,f=function(t){var e=c.customGptSlotMatching;if((0,n.isGptPubadsDefined)()){var o=t.reduce((function(t,e){return t[e.code]=e,t}),{});window.googletag.pubads().getSlots().forEach((function(t){var r=(0,i.sE)(Object.keys(o),e?e(t):(0,n.isAdUnitCodeMatchingSlot)(t));if(r){var a=o[r];a.ortb2Imp=a.ortb2Imp||{},a.ortb2Imp.ext=a.ortb2Imp.ext||{},a.ortb2Imp.ext.data=a.ortb2Imp.ext.data||{};var d=a.ortb2Imp.ext.data;d.adserver=d.adserver||{},d.adserver.name="gam",d.adserver.adslot=p(t.getAdUnitPath())}}))}},p=function(t){return(a.vc.getConfig("gptPreAuction")||{}).mcmEnabled?t.replace(/(^\/\d*),\d*\//,"$1/"):t},l=function(t,e){var o=t.ortb2Imp.ext.data;if(o.pbadslot)return o.pbadslot;if((0,n.isGptPubadsDefined)()){var r=window.googletag.pubads().getSlots().filter((function(t){return t.getAdUnitPath()===e}));if(0!==r.length)return 1===r.length?e:"".concat(e,"#").concat(t.code)}},b=function(t){var e=t.ortb2Imp.ext.data,o=c.customPbAdSlot;if(!e.pbadslot)if(o)e.pbadslot=o(t.code,(0,r.Z)(e,"adserver.adslot"));else{try{var n=document.getElementById(t.code);if(n.dataset.adslotid)return void(e.pbadslot=n.dataset.adslotid)}catch(t){}if(!(0,r.Z)(e,"adserver.adslot"))return e.pbadslot=t.code,!0;e.pbadslot=e.adserver.adslot}},g=function(t,e){f(e);var o=c,n=o.useDefaultPreAuction,a=o.customPreAuction;e.forEach((function(t){t.ortb2Imp=t.ortb2Imp||{},t.ortb2Imp.ext=t.ortb2Imp.ext||{},t.ortb2Imp.ext.data=t.ortb2Imp.ext.data||{};var e=t.ortb2Imp.ext;if(a||n){var o,d=(0,r.Z)(e,"data.adserver.adslot");a?o=a(t,d):n&&(o=l(t,d)),o&&(e.gpid=e.data.pbadslot=o)}else{var i=b(t);e.gpid||i||(e.gpid=e.data.pbadslot)}}));for(var d=arguments.length,i=new Array(d>2?d-2:0),s=2;s<d;s++)i[s-2]=arguments[s];return t.call.apply(t,[u,e].concat(i))},m=function(t){(c=(0,n.pick)(t,["enabled",function(t){return!1!==t},"customGptSlotMatching",function(t){return"function"==typeof t&&t},"customPbAdSlot",function(t){return"function"==typeof t&&t},"customPreAuction",function(t){return"function"==typeof t&&t},"useDefaultPreAuction",function(t){return!0===t}])).enabled?s||((0,d.v5)("makeBidRequests").before(g),s=!0):((0,n.logInfo)("".concat("GPT Pre-Auction",": Turning off module")),c={},(0,d.v5)("makeBidRequests").getHooks({hook:g}).remove(),s=!1)};a.vc.getConfig("gptPreAuction",(function(t){return m(t.gptPreAuction)})),m({}),window.pbjs.installedModules.push("gptPreAuction")}},function(t){var e;e=96787,t(t.s=e)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[155],{33390:function(e,r,t){var i=t(89062),n=t(71002),a=t(4942),o=t(20265),d=t(64358),s=t(44806),p=t(24679),c=t(3193),u=t(5644),l=t(15164),m=t(52021),f=t(34614),g=t(14699),v=t(90154),y=t(35706);function b(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);r&&(i=i.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,i)}return t}function h(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?b(Object(t),!0).forEach((function(r){(0,a.Z)(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):b(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}function I(e,r){var t="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(!t){if(Array.isArray(e)||(t=function(e,r){if(!e)return;if("string"==typeof e)return x(e,r);var t=Object.prototype.toString.call(e).slice(8,-1);"Object"===t&&e.constructor&&(t=e.constructor.name);if("Map"===t||"Set"===t)return Array.from(e);if("Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t))return x(e,r)}(e))||r&&e&&"number"==typeof e.length){t&&(e=t);var i=0,n=function(){};return{s:n,n:function(){return i>=e.length?{done:!0}:{done:!1,value:e[i++]}},e:function(e){throw e},f:n}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var a,o=!0,d=!1;return{s:function(){t=t.call(e)},n:function(){var e=t.next();return o=e.done,e},e:function(e){d=!0,a=e},f:function(){try{o||null==t.return||t.return()}finally{if(d)throw a}}}}function x(e,r){(null==r||r>e.length)&&(r=e.length);for(var t=0,i=new Array(r);t<r;t++)i[t]=e[t];return i}var O="ix",S="roundel",w=[p.Mk,p.pX,p.B5],Z=8e3,P=[144,144],C={JPY:1},A="p",E="x",k=1,T=2,z=3,j=4,B=5,D=6,R=7,U=8,X=9,F={SITE:["id","name","domain","cat","sectioncat","pagecat","page","ref","search","mobile","privacypolicy","publisher","content","keywords","ext"],USER:["id","buyeruid","yob","gender","keywords","customdata","geo","data","ext"]},_={"liveramp.com":"idl","netid.de":"NETID","neustar.biz":"fabrickId","zeotap.com":"zeotapIdPlus","uidapi.com":"UID2","adserver.org":"TDID","id5-sync.com":"","crwdcntrl.net":"","epsilon.com":"","audigent.com":"","pubcid.org":"","trustpid.com":""},N=["britepoolid","lipbid","criteoId","merkleId","parrableId","connectid","tapadId","quantcastId","pubProvidedId"],q=["mimes","minduration","maxduration"],J=["mimes","minduration","maxduration","protocols","protocol","startdelay","placement","linearity","skip","skipmin","skipafter","sequence","battr","maxextended","minbitrate","maxbitrate","boxingallowed","playbackmethod","playbackend","delivery","pos","companionad","api","companiontype","ext","playerSize","w","h"],M="ixdiag",W=!1,G=(0,l.df)({gvlid:10,bidderCode:O}),L=0,Q="",V="",$=2;function Y(e){var r=H(e),t=(0,o.Z)(e,"mediaTypes.video"),i=(0,o.Z)(e,"params.video");if(ie(t,i).length)return{};for(var n in r.video=i?(0,d.deepClone)(e.params.video):{},r.ext.tid=(0,o.Z)(e,"ortb2Imp.ext.tid"),t)-1===J.indexOf(n)||r.video.hasOwnProperty(n)||(r.video[n]=t[n]);if(r.video.minduration>r.video.maxduration)return(0,d.logError)("IX Bid Adapter: video minduration [".concat(r.video.minduration,"] cannot be greater than video maxduration [").concat(r.video.maxduration,"]"),{bidder:O,code:X}),{};var a=i&&i.context||t&&t.context;if(a&&!r.video.hasOwnProperty("placement")&&(a===v.LD?r.video.placement=1:a===v.gZ?(0,o.Z)(i,"playerConfig.floatOnScroll")?r.video.placement=5:r.video.placement=4:(0,d.logWarn)("IX Bid Adapter: Video context '".concat(a,"' is not supported"))),!r.video.w||!r.video.h){var s=ne((0,o.Z)(r,"video.playerSize"))||ne((0,o.Z)(e,"params.size"));if(!s)return(0,d.logWarn)("IX Bid Adapter: Video size is missing in [mediaTypes.video]"),{};r.video.w=s[0],r.video.h=s[1],(0,o.Z)(r,"ext.sid")||(r.ext.sid=(0,d.parseGPTSingleSizeArray)(s))}return K(e,r,p.pX),r}function H(e){var r={};return r.id=e.bidId,r.ext={},r.ext.siteID=e.params.siteId.toString(),!e.params.hasOwnProperty("id")||"string"!=typeof e.params.id&&"number"!=typeof e.params.id||(r.ext.sid=String(e.params.id)),r}function K(e,r,t){var i=null,n=null;if(e.params.bidFloor&&e.params.bidFloorCur&&(i={floor:e.params.bidFloor,currency:e.params.bidFloorCur}),(0,d.isFn)(e.getFloor)){var a="*",o="*";if(t&&(0,d.contains)(w,t)){var s=r[t];a=t,o=[s.w,s.h]}try{n=e.getFloor({mediaType:a,size:o})}catch(e){(0,d.logWarn)("priceFloors module call getFloor failed, error : ",e)}}n?(r.bidfloor=n.floor,r.bidfloorcur=n.currency,r.ext.fl=A):i&&(r.bidfloor=i.floor,r.bidfloorcur=i.currency,r.ext.fl=E)}function ee(e,r,t){var i={},n=!(!(0,o.Z)(e,"exp")||!(0,d.isInteger)(e.exp)),a=(0,o.Z)(e,"dealid")||(0,o.Z)(e,"ext.dealid");C.hasOwnProperty(r)?i.cpm=e.price/C[r]:i.cpm=e.price/100,i.requestId=e.impid,a&&(i.dealId=a),i.netRevenue=true,i.currency=r,i.creativeId=e.hasOwnProperty("crid")?e.crid:"-",e.mtype==$?i.vastXml=e.adm:e.ext&&e.ext.vasturl&&(i.vastUrl=e.ext.vasturl);var s=null;if("string"==typeof e.adm&&"{"===e.adm[0]&&"}"===e.adm[e.adm.length-1])try{s=JSON.parse(e.adm)}catch(e){(0,d.logWarn)("adm looks like JSON but failed to parse: ",e)}return e.ext&&e.ext.vasturl||e.mtype==$?(i.width=t.video.w,i.height=t.video.h,i.mediaType=p.pX,i.mediaTypes=t.mediaTypes,i.ttl=n?e.exp:3600):s&&s.native?(i.native={ortb:s.native},i.width=e.w?e.w:1,i.height=e.h?e.h:1,i.mediaType=p.B5,i.ttl=n?e.exp:3600):(i.ad=e.adm,i.width=e.w,i.height=e.h,i.mediaType=p.Mk,i.ttl=n?e.exp:300),i.meta={},i.meta.networkId=(0,o.Z)(e,"ext.dspid"),i.meta.brandId=(0,o.Z)(e,"ext.advbrandid"),i.meta.brandName=(0,o.Z)(e,"ext.advbrand"),e.adomain&&e.adomain.length>0&&(i.meta.advertiserDomains=e.adomain),i}function re(e){return Array.isArray(e)&&2===e.length&&(0,d.isInteger)(e[0])&&(0,d.isInteger)(e[1])}function te(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[];if(re(e))return e[0]===r[0]&&e[1]===r[1];for(var t=0;t<e.length;t++)if(e[t][0]===r[0]&&e[t][1]===r[1])return!0;return!1}function ie(e,r){var t=[];e||(0,d.logWarn)("IX Bid Adapter: mediaTypes.video is the preferred location for video params in ad unit");var i,n=I(q);try{for(n.s();!(i=n.n()).done;){var a=i.value,o=e&&e.hasOwnProperty(a),s=r&&r.hasOwnProperty(a);o||s||t.push("IX Bid Adapter: ".concat(a," is not included in either the adunit or params level"))}}catch(e){n.e(e)}finally{n.f()}var p=e&&e.hasOwnProperty("protocol"),c=e&&e.hasOwnProperty("protocols"),u=r&&r.hasOwnProperty("protocol"),l=r&&r.hasOwnProperty("protocols");return p||c||u||l||t.push("IX Bid Adapter: protocol/protcols is not included in either the adunit or params level"),t}function ne(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[];return re(e)?e:!!re(e[0])&&e[0]}function ae(e,r,t){if(e)return h(h({},(0,f.sE)(t,(function(r){return r.bidId===e}))),(0,f.sE)(r,(function(r){return r.id===e})))}function oe(e,r,t,a){var u="https://htlb.casalemedia.com/openrtb/pbjs",l=function(e){var r=[],t={};if((0,d.isArray)(e)){var i,n=I(e);try{for(n.s();!(i=n.n()).done;){var a=i.value;_.hasOwnProperty(a.source)&&(0,o.Z)(a,"uids.0")&&(t[a.source]=!0,""!=_[a.source]&&(a.uids[0].ext={rtiPartner:_[a.source]}),delete a.uids[0].atype,r.push(a))}}catch(e){n.e(e)}finally{n.f()}}return{toSend:r,seenSources:t}}((0,o.Z)(e,"0.userIdAsEids")),m=l.toSend,f=(0,o.Z)(r,"refererInfo.page");if(window.headertag&&"function"==typeof window.headertag.getIdentityInfo){var g=window.headertag.getIdentityInfo();if(g&&"object"===(0,n.Z)(g))for(var v in g)if(g.hasOwnProperty(v)){var y=g[v];!y.responsePending&&y.data&&"object"===(0,n.Z)(y.data)&&Object.keys(y.data).length&&!l.seenSources[y.data.source]&&m.push(y.data)}}if(r&&r.bidderCode===S&&!l.seenSources["liveramp.com"])return[];var b={},x=c.vc.getConfig("bidderTimeout");b.id=e[0].bidderRequestId.toString(),b.site={},b.ext={},b.ext.source="prebid",b.ext.ixdiag={},b.ext.ixdiag.msd=0,b.ext.ixdiag.msi=0,b.imp=[],b.at=1;var w=function(e){for(var r=e.map((function(e){return e.transactionId})).filter((function(e,r,t){return t.indexOf(e)===r})),t={mfu:0,bu:0,iu:0,nu:0,ou:0,allu:0,ren:!1,version:"7.12.0",userIds:de(e[0]),url:window.location.href.split("?")[0]},i=function(i){a=e.filter((function(e){return e.transactionId===r[i]}))[0],(0,o.Z)(a,"mediaTypes")&&(Object.keys(a.mediaTypes).length>1&&t.mfu++,(0,o.Z)(a,"mediaTypes.native")&&t.nu++,(0,o.Z)(a,"mediaTypes.banner")&&t.bu++,"outstream"===(0,o.Z)(a,"mediaTypes.video.context")&&(t.ou++,ve(a)&&(t.ren=!0)),"instream"===(0,o.Z)(a,"mediaTypes.video.context")&&t.iu++,t.allu++)},n=0;n<r.length;n++){var a;i(n)}return t}(e);for(var P in w)b.ext.ixdiag[P]=w[P];x&&(b.ext.ixdiag.tmax=x),c.vc.getConfig("userSync")&&(b.ext.ixdiag.syncsPerBidder=c.vc.getConfig("userSync").syncsPerBidder);var C=function(){if(!G.localStorageIsEnabled())return;var e,r={};try{e=JSON.parse(G.getDataFromLocalStorage(M)||"{}")}catch(e){return(0,d.logError)("ix can not read ixdiag from localStorage."),null}return Object.keys(e).forEach((function(t){Object.keys(e[t]).forEach((function(i){"number"==typeof e[t][i]&&(r[i]=r[i]?r[i]+e[t][i]:e[t][i])}))})),r}();(0,d.isEmpty)(C)||(b.ext.ixdiag.err=C),e[0].schain&&(b.source={ext:{schain:e[0].schain}}),m.length>0&&(b.user={},b.user.eids=m),document.referrer&&""!==document.referrer&&(b.site.ref=document.referrer),r&&(r.gdprConsent&&((Q=r.gdprConsent).hasOwnProperty("gdprApplies")&&(b.regs={ext:{gdpr:Q.gdprApplies?1:0}}),Q.hasOwnProperty("consentString")&&(b.user=b.user||{},b.user.ext={consent:Q.consentString||""},Q.hasOwnProperty("addtlConsent")&&Q.addtlConsent&&(b.user.ext.consented_providers_settings={consented_providers:Q.addtlConsent}))),r.uspConsent&&((0,s.Z)(b,"regs.ext.us_privacy",r.uspConsent),V=r.uspConsent),f&&(b.site.page=f)),c.vc.getConfig("coppa")&&(0,s.Z)(b,"regs.coppa",1);var A={};L=e[0].params.siteId,A.s=L,a&&(A.v=a),A.ac="j",A.sd=1,8.1===a&&(A.nf=1);var E=r&&r.bidderCode||"ix",k=c.vc.getConfig(E),T=[],z=0,j=Object.keys(t),B="".concat(u).concat((0,d.parseQueryStringParameters)(h(h({},A),{},{r:JSON.stringify(b)}))).length;if(B>Z)return(0,d.logError)("IX Bid Adapter: Base request size has exceeded maximum request size.",{bidder:O,code:R}),T;var X=B,N=0,q=!1;if(k){if("object"===(0,n.Z)(k.firstPartyData)){var J=k.firstPartyData,W="?";for(var $ in J)J.hasOwnProperty($)&&(W+="".concat(encodeURIComponent($),"=").concat(encodeURIComponent(J[$]),"&"));W=W.slice(0,-1),(N=encodeURIComponent(W).length)<Z?("page"in b.site?b.site.page+=W:b.site.page=W,X+=N):(0,d.logError)("IX Bid Adapter: IX config FPD request size has exceeded maximum request size.",{bidder:O,code:D})}"number"==typeof k.timeout&&(A.t=k.timeout),"boolean"==typeof k.detectMissingSizes?b.ext.ixdiag.dms=k.detectMissingSizes:b.ext.ixdiag.dms=!0}for(var Y=function(n){if(X>=Z||T.length>=4)return"break";for(var a=t[j[n]],c=a.missingCount,l=void 0===c?0:c,m=a.missingImps,f=void 0===m?[]:m,g=a.ixImps,v=!1,y=Z-X,I={ixImps:void 0===g?[]:g,missingBannerImpressions:f},x=Object.keys(I).map((function(e){return I[e]})).filter((function(e){return Array.isArray(e)})).reduce((function(e,r){return e.concat.apply(e,(0,i.Z)(r))}),[]),S=encodeURIComponent(JSON.stringify({impressionObjects:x})).length;x.length&&S>y;)v=!0,x.pop(),S=encodeURIComponent(JSON.stringify({impressionObjects:x})).length;var w=t[j[n]].gpid,P=t[j[n]].dfp_ad_unit_code,C=t[j[n]].tid,E=t[j[n]].divId;if(!w&&P&&E&&(w="".concat(P,"#").concat(E)),x.length&&p.Mk in x[0]){var k=x[0],D={id:k.id,banner:{topframe:k.banner.topframe,format:x.map((function(e){var r=e.banner;return{w:r.w,h:r.h,ext:e.ext}}))}};(P||w||C)&&(D.ext={},D.ext.dfp_ad_unit_code=P,D.ext.gpid=w,D.ext.tid=C),"bidfloor"in x[0]&&(D.bidfloor=x[0].bidfloor),"bidfloorcur"in x[0]&&(D.bidfloorcur=x[0].bidfloorcur),b.imp.push(D),b.ext.ixdiag.msd+=l,b.ext.ixdiag.msi+=f.length}else{var R;x.forEach((function(e){return(0,s.Z)(e,"ext.gpid",w)})),(R=b.imp).push.apply(R,(0,i.Z)(x))}X+=S;var _=(0,o.Z)(r,"ortb2")||{};if(!(0,d.isEmpty)(_)&&!q){b.ext.ixdiag.fpd=!0;var N=h({},_.site||_.context);Object.keys(N).forEach((function(e){-1===F.SITE.indexOf(e)&&delete N[e]}));var J=h({},_.user);Object.keys(J).forEach((function(e){-1===F.USER.indexOf(e)&&delete J[e]}));var M=(0,d.deepClone)(b);if(M.site=(0,d.mergeDeep)({},M.site,N),M.user=(0,d.mergeDeep)({},M.user,J),"".concat(u).concat((0,d.parseQueryStringParameters)(h(h({},A),{},{r:JSON.stringify(M)}))).length<Z){b.site=(0,d.mergeDeep)({},b.site,N),b.user=(0,d.mergeDeep)({},b.user,J),q=!0;var W=encodeURIComponent(JSON.stringify(h(h({},N),J))).length;X+=W}else(0,d.logError)("IX Bid Adapter: FPD request size has exceeded maximum request size.",{bidder:O,code:U})}var G=t[j[n]].pbadslot,L=t[j[n]].tagId,Q=t[j[n]].adUnitCode;if(G||L||Q||E){var V=(0,d.deepClone)(b);"".concat(u).concat((0,d.parseQueryStringParameters)(h(h({},A),{},{r:JSON.stringify(V)}))).length<Z&&(b.ext.ixdiag.pbadslot=G,b.ext.ixdiag.tagid=L,b.ext.ixdiag.adunitcode=Q,b.ext.ixdiag.divId=E)}var $=n===j.length-1;if(v||$){var Y=(0,d.deepClone)(A);$&&!z||(b.ext.ixdiag.sn=z,Y.sn=z),z++,Y.r=JSON.stringify(b),T.push({method:"GET",url:u,data:Y,validBidRequests:e}),X=B,b.imp=[],b.ext.ixdiag.msd=0,b.ext.ixdiag.msi=0,q=!1}},H=0;H<j.length;H++){if("break"===Y(H))break}return T}function de(e){var r=e.userId||{};return N.filter((function(e){return r[e]}))}function se(e,r){if(r)for(var t=0;t<e.length;t++){var i=e[t];if(r[0]===i[0]&&r[1]===i[1]){e.splice(t,1);break}}}function pe(e,r){var t=function(e){var r=H(e),t=e.nativeOrtbRequest;return t.eventtrackers=[{event:1,methods:[1,2]}],t.privacy=1,r.native={request:JSON.stringify(t),ver:"1.2"},r.ext.tid=(0,o.Z)(e,"ortb2Imp.ext.tid"),K(e,r,p.B5),r}(e);if(0!=Object.keys(t).length){r[e.transactionId]={},r[e.transactionId].ixImps=[],r[e.transactionId].ixImps.push(t),r[e.transactionId].gpid=(0,o.Z)(e,"ortb2Imp.ext.gpid"),r[e.transactionId].dfp_ad_unit_code=(0,o.Z)(e,"ortb2Imp.ext.data.adserver.adslot"),r[e.transactionId].pbadslot=(0,o.Z)(e,"ortb2Imp.ext.data.pbadslot"),r[e.transactionId].tagId=(0,o.Z)(e,"params.tagId");var i=e.adUnitCode,n=document.getElementById(i)?i:(0,d.getGptSlotInfoForAdUnitCode)(i).divId;r[e.transactionId].adUnitCode=i,r[e.transactionId].divId=n}}function ce(e,r){var t=Y(e);if(0!=Object.keys(t).length){r[e.transactionId]={},r[e.transactionId].ixImps=[],r[e.transactionId].ixImps.push(t),r[e.transactionId].gpid=(0,o.Z)(e,"ortb2Imp.ext.gpid"),r[e.transactionId].dfp_ad_unit_code=(0,o.Z)(e,"ortb2Imp.ext.data.adserver.adslot"),r[e.transactionId].pbadslot=(0,o.Z)(e,"ortb2Imp.ext.data.pbadslot"),r[e.transactionId].tagId=(0,o.Z)(e,"params.tagId");var i=e.adUnitCode,n=document.getElementById(i)?i:(0,d.getGptSlotInfoForAdUnitCode)(i).divId;r[e.transactionId].adUnitCode=i,r[e.transactionId].divId=n}}function ue(e,r,t){var i=h(h({},{detectMissingSizes:!0}),c.vc.getConfig("ix")),n=function(e){var r=H(e);r.banner={};var t=(0,o.Z)(e,"params.size");return t&&(r.banner.w=t[0],r.banner.h=t[1],(0,o.Z)(r,"ext.sid")||(r.ext.sid=(0,d.parseGPTSingleSizeArray)(t))),r.banner.topframe=(0,d.inIframe)()?0:1,K(e,r,p.Mk),r}(e),a=te((0,o.Z)(e,"mediaTypes.banner.sizes"),(0,o.Z)(e,"params.size"));t.hasOwnProperty(e.transactionId)||(t[e.transactionId]={}),t[e.transactionId].gpid=(0,o.Z)(e,"ortb2Imp.ext.gpid"),t[e.transactionId].dfp_ad_unit_code=(0,o.Z)(e,"ortb2Imp.ext.data.adserver.adslot"),t[e.transactionId].tid=(0,o.Z)(e,"ortb2Imp.ext.tid"),t[e.transactionId].pbadslot=(0,o.Z)(e,"ortb2Imp.ext.data.pbadslot"),t[e.transactionId].tagId=(0,o.Z)(e,"params.tagId");var s=e.adUnitCode,u=document.getElementById(s)?s:(0,d.getGptSlotInfoForAdUnitCode)(s).divId;t[e.transactionId].adUnitCode=s,t[e.transactionId].divId=u,a&&(t[e.transactionId].hasOwnProperty("ixImps")||(t[e.transactionId].ixImps=[]),t[e.transactionId].ixImps.push(n)),i.hasOwnProperty("detectMissingSizes")&&i.detectMissingSizes&&function(e,r,t){var i=e.transactionId;if(r.hasOwnProperty(i)){var n=[];r[i].hasOwnProperty("missingSizes")&&(n=r[i].missingSizes),se(n,e.params.size),r[i].missingSizes=n}else if((0,o.Z)(e,"mediaTypes.banner.sizes")){var a=(0,d.deepClone)(e.mediaTypes.banner.sizes);se(a,e.params.size);var s={missingSizes:a,impression:t};r[i]=s}}(e,r,n)}function le(e,r,t){var i=(0,d.deepClone)(r);return i.ext.sid=(0,d.parseGPTSingleSizeArray)(t),i.banner.w=t[0],i.banner.h=t[1],K(e,i,p.Mk),i}function me(e){"ERROR"===e.type&&e.arguments&&e.arguments[1]&&e.arguments[1].bidder===O&&function(e){if(G.localStorageIsEnabled()){var r;try{r=JSON.parse(G.getDataFromLocalStorage(M)||"{}")}catch(e){(0,d.logWarn)("ix can not read ixdiag from localStorage.")}var t=new Date;if(Object.keys(r).map((function(e){var i=new Date(e);i.setDate(i.getDate()+7)-t<0&&delete r[e]})),"ERROR"===e.type&&e.arguments&&e.arguments[1]&&e.arguments[1].bidder===O){var i=t.toISOString().slice(0,10),n=e.arguments[1].code;n&&(r[i]=r[i]||{},Number(r[i][n])||(r[i][n]=0),r[i][n]++)}G.setDataInLocalStorage(M,JSON.stringify(r))}}(e)}function fe(e){e.renderer.push((function(){var r=e.adUnitCode,t=document.getElementById(r)?r:(0,d.getGptSlotInfoForAdUnitCode)(r).divId;t?window.createIXPlayer(t,e):(0,d.logWarn)("IX Bid Adapter: adUnitCode: ".concat(t," not found on page."))}))}function ge(e,r){var t=y.Th.install({id:e,url:r,loaded:!1});try{t.setRender(fe)}catch(e){return(0,d.logWarn)("Prebid Error calling setRender on renderer",e),null}return r?t:((0,d.logWarn)("Outstream renderer URL not found"),null)}function ve(e){if("outstream"!==(0,o.Z)(e,"mediaTypes.video.context"))return!1;var r=(0,o.Z)(e,"mediaTypes.video.renderer");return r||(r=(0,o.Z)(e,"renderer")),!!("object"!==(0,n.Z)(r)||!r.url||!r.render)||r.backupOnly}var ye={code:O,gvlid:10,aliases:[{code:S,gvlid:10,skipPbsAliasing:!1}],supportedMediaTypes:w,isBidRequestValid:function(e){W||(m.on(u.FP.AUCTION_DEBUG,me),m.on(u.FP.AD_RENDER_FAILED,me),W=!0);var r,t,i=(0,o.Z)(e,"params.video"),n=(0,o.Z)(e,"params.size"),a=(0,o.Z)(e,"mediaTypes.banner.sizes"),s=(0,o.Z)(e,"mediaTypes.video"),p=(0,o.Z)(e,"mediaTypes.video.playerSize"),c=e.params.hasOwnProperty("bidFloor"),l=e.params.hasOwnProperty("bidFloorCur");if(e.hasOwnProperty("mediaType")&&!(0,d.contains)(w,e.mediaType))return(0,d.logWarn)("IX Bid Adapter: media type is not supported."),!1;if((0,o.Z)(e,"mediaTypes.banner")&&!a)return!1;if(n){var f=ne(n);if(!f)return(0,d.logError)("IX Bid Adapter: size has invalid format.",{bidder:O,code:k}),!1;if(!te(e.sizes,f)&&!te(p,f)&&!te(a,f))return(0,d.logError)("IX Bid Adapter: bid size is not included in ad unit sizes or player size.",{bidder:O,code:T}),!1}if("string"!=typeof e.params.siteId&&"number"!=typeof e.params.siteId)return(0,d.logError)("IX Bid Adapter: siteId must be string or number type.",{bidder:O,code:j}),!1;if("string"!=typeof e.params.siteId&&isNaN(Number(e.params.siteId)))return(0,d.logError)("IX Bid Adapter: siteId must valid value",{bidder:O,code:j}),!1;if((c||l)&&!(c&&l&&(r=e.params.bidFloor,t=e.params.bidFloorCur,Boolean("number"==typeof r&&"string"==typeof t&&t.match(/^[A-Z]{3}$/)))))return(0,d.logError)("IX Bid Adapter: bidFloor / bidFloorCur parameter has invalid format.",{bidder:O,code:B}),!1;if(s&&i){var g=Y(e).video,y=ie(s,i);if((0,o.Z)(e,"mediaTypes.video.context")===v.gZ&&ve(e)&&g){var b=[(0,o.Z)(g,"w"),(0,o.Z)(g,"h")];if(!(b[0]>=P[0]&&b[1]>=P[1]))return(0,d.logError)("IX Bid Adapter: ".concat(b," is an invalid size for IX outstream renderer")),!1}if(y.length)return y.forEach((function(e){(0,d.logError)(e,{bidder:O,code:z})})),!1}return function(e){return void 0===(0,o.Z)(e,"mediaTypes.native")||e.nativeOrtbRequest&&Array.isArray(e.nativeOrtbRequest.assets)&&e.nativeOrtbRequest.assets.length>0}(e)},buildRequests:function(e,r){var t=[],n={},a={},s={},c={};for(var u in e.forEach((function(e){var r=Object.keys((0,o.Z)(e,"mediaTypes",{}));for(var t in r)switch(r[t]){case p.Mk:ue(e,c,n);break;case p.pX:ce(e,a);break;case p.B5:pe(e,s);break;default:(0,d.logWarn)("IX Bid Adapter: ad unit mediaTypes ".concat(t," is not supported"))}})),c)if(c.hasOwnProperty(u)){var l=c[u].missingSizes;n.hasOwnProperty(u)||(n[u]={}),n[u].hasOwnProperty("missingImps")||(n[u].missingImps=[],n[u].missingCount=0);for(var m=c[u].impression,f=0;f<l.length;f++){var g=le(e[0],m,l[f]);n[u].missingImps.push(g),n[u].missingCount++}}return Object.keys(n).length>0&&t.push.apply(t,(0,i.Z)(oe(e,r,n,7.2))),Object.keys(a).length>0&&t.push.apply(t,(0,i.Z)(oe(e,r,a,8.1))),Object.keys(s).length>0&&t.push.apply(t,(0,i.Z)(oe(e,r,s))),t},interpretResponse:function(e,r){var t=[],i=null;if(!e.hasOwnProperty("body")||!e.body.hasOwnProperty("seatbid"))return t;for(var n=e.body,a=n.seatbid,s=0;s<a.length;s++)if(a[s].hasOwnProperty("bid")){for(var c=a[s].bid,u=JSON.parse(r.data.r),l=0;l<c.length;l++){var m=ae(c[l].impid,u.imp,r.validBidRequests);if((i=ee(c[l],n.cur,m)).mediaType===p.pX&&ve(m)){var f=(0,o.Z)(n,"ext.videoplayerurl");if(i.renderer=ge(c[l].bidId,f),!i.renderer)continue}t.push(i)}if((0,o.Z)(u,"ext.ixdiag.err")&&G.localStorageIsEnabled())try{G.removeDataFromLocalStorage(M)}catch(e){(0,d.logError)("ix can not clear ixdiag from localStorage.")}}return t},transformBidParams:function(e,r){return(0,d.convertTypes)({siteID:"number"},e)},getUserSyncs:function(e,r){var t=[],i=null;if(r.length>0&&(i=(0,o.Z)(r[0],"body.ext.publishersyncsperbidderoverride")),void 0!==i&&0==i)return[];if(e.iframeEnabled)t.push({type:"iframe",url:"https://js-sec.indexww.com/um/ixmatch.html"});else{var n=null;c.vc.getConfig("userSync")&&(n=c.vc.getConfig("userSync").syncsPerBidder),0===n&&(n=i),n=i&&(0===n||n)?i>n?n:i:1;for(var a=0;a<n;a++)t.push({type:"image",url:be(n,a)})}return t}};function be(e,r){var t="",i="0";return Q&&Q.hasOwnProperty("gdprApplies")&&(i=Q.gdprApplies?"1":"0"),Q&&Q.hasOwnProperty("consentString")&&(t=Q.consentString||""),"https://dsum.casalemedia.com/pbusermatch?origin=prebid&site_id="+L.toString()+"&p="+e.toString()+"&i="+r.toString()+"&gdpr="+i+"&gdpr_consent="+t+"&us_privacy="+(V||"")}(0,g.dX)(ye),window.pbjs.installedModules.push("ixBidAdapter")}},function(e){var r;r=33390,e(e.s=r)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[618],{49917:function(e,r,n){var i=n(71002),a=n(64358),d=n(20265),t=n(14699),s=n(3193),o=n(24679),c=n(35706),u="",p={code:"richaudience",gvlid:108,aliases:["ra"],supportedMediaTypes:[o.Mk,o.pX],isBidRequestValid:function(e){return!!(e.params&&e.params.pid&&e.params.supplyType)},buildRequests:function(e,r){return e.map((function(e){var n={bidfloor:b(e,s.vc),ifa:e.params.ifa,pid:e.params.pid,supplyType:e.params.supplyType,currencyCode:s.vc.getConfig("currency.adServerCurrency"),auctionId:e.auctionId,bidId:e.bidId,BidRequestsCount:e.bidRequestsCount,bidder:e.bidder,bidderRequestId:e.bidderRequestId,tagId:e.adUnitCode,sizes:l(e),referer:void 0!==r.refererInfo.page?encodeURIComponent(r.refererInfo.page):null,numIframes:void 0!==r.refererInfo.numIframes?r.refererInfo.numIframes:null,transactionId:e.transactionId,timeout:s.vc.getConfig("bidderTimeout"),user:g(e),demand:m(e),videoData:f(e),scr_rsl:h(),cpuc:void 0!==window.navigator?window.navigator.hardwareConcurrency:null,kws:(0,a.isEmpty)(e.params.keywords)?null:e.params.keywords,schain:e.schain};u=void 0!==r.refererInfo.page?encodeURIComponent(r.refererInfo.page):null,n.gdpr_consent="",n.gdpr=!1,r&&r.gdprConsent&&(void 0!==r.gdprConsent.gdprApplies&&(n.gdpr=r.gdprConsent.gdprApplies),void 0!==r.gdprConsent.consentString&&(n.gdpr_consent=r.gdprConsent.consentString));return{method:"POST",url:"https://shb.richaudience.com/hb/",data:JSON.stringify(n)}}))},interpretResponse:function(e,r){var n=[],i=e.body;if(i){var a={requestId:JSON.parse(r.data).bidId,cpm:i.cpm,width:i.width,height:i.height,creativeId:i.creative_id,mediaType:i.media_type,netRevenue:i.netRevenue,currency:i.currency,ttl:i.ttl,meta:i.adomain,dealId:i.dealId};if("video"===i.media_type){a.vastXml=i.vastXML;try{null!=a.vastXml&&("outstream"!=JSON.parse(r.data).videoData.format&&"banner"!=JSON.parse(r.data).videoData.format||(a.renderer=c.Th.install({id:r.bidId,adunitcode:r.tagId,loaded:!1,config:i.media_type,url:"https://cdn3.richaudience.com/prebidVideo/player.js"})),a.renderer.setRender(v))}catch(e){a.ad=i.adm}}else a.ad=i.adm;n.push(a)}return n},getUserSyncs:function(e,r,n){var i,a=[],d=Math.floor(9999999999*Math.random()),t="",o="";return i=function(e){try{var r=null,n={};return null!=e.getConfig("userSync").filterSettings&&void 0!==e.getConfig("userSync").filterSettings&&(null!=(r=e.getConfig("userSync").filterSettings).iframe&&void 0!==r.iframe&&(n.raiIframe="richaudience"==r.iframe.bidders||"*"==r.iframe.bidders?r.iframe.filter:"exclude"),null!=r.image&&void 0!==r.image&&(n.raiImage="richaudience"==r.image.bidders||"*"==r.image.bidders?r.image.filter:"exclude")),n}catch(e){return null}}(s.vc),n&&"string"==typeof n.consentString&&void 0!==n.consentString&&(o="consentString=".concat(n.consentString)),e.iframeEnabled&&"exclude"!=i.raiIframe&&(t="https://sync.richaudience.com/dcf3528a0b8aa83634892d50e91c306e/?ord="+d,""!=o&&(t+="&".concat(o)),a.push({type:"iframe",url:t})),e.pixelEnabled&&null!=u&&0==a.length&&"exclude"!=i.raiImage&&(t="https://sync.richaudience.com/bf7c142f4339da0278e83698a02b0854/?referrer=".concat(u),""!=o&&(t+="&".concat(o)),a.push({type:"image",url:t})),a}};function l(e){var r;if(e.mediaTypes&&e.mediaTypes.banner&&e.mediaTypes.banner.sizes&&(r=e.mediaTypes.banner.sizes),null!=r)return r.map((function(e){return{w:e[0],h:e[1]}}))}function m(e){var r="display";return void 0!==e.sizes&&e.sizes.forEach((function(e){("1800"==e[0]&&"1000"==e[1]||"1"==e[0]&&"1"==e[1])&&(r="skin")})),null!=e.mediaTypes&&null!=e.mediaTypes.video&&(r="video"),r}function f(e){return"video"==m(e)?{format:e.mediaTypes.video.context,playerSize:e.mediaTypes.video.playerSize,mimes:e.mediaTypes.video.mimes}:{format:"banner"}}function g(e){var r=[];return e&&e.userId&&(y(e,r,"id5-sync.com",(0,d.Z)(e,"userId.id5id.uid")),y(e,r,"pubcommon",(0,d.Z)(e,"userId.pubcid")),y(e,r,"criteo.com",(0,d.Z)(e,"userId.criteoId")),y(e,r,"liveramp.com",(0,d.Z)(e,"userId.idl_env")),y(e,r,"liveintent.com",(0,d.Z)(e,"userId.lipb.lipbid")),y(e,r,"adserver.org",(0,d.Z)(e,"userId.tdid"))),r}function y(e,r,n,i){(0,a.isStr)(i)&&r.push({userId:i,source:n})}function v(e){e.renderer.push((function(){!function(e){var r="".concat(e.vastXml),n={config:null!=e.params[0].player?{end:null!=e.params[0].player.end?e.params[0].player.end:"close",init:null!=e.params[0].player.init?e.params[0].player.init:"close",skin:null!=e.params[0].player.skin?e.params[0].player.skin:"light"}:{end:"close",init:"close",skin:"light"},pid:e.params[0].pid,adUnit:e.adUnitCode};window.raParams(n,r,!0)}(e)}))}function h(){var e="";return void 0!==window.screen&&(e=window.screen.width+"x"+window.screen.height),e}function b(e,r){try{var n;if(null!=e.params.bidfloor)n=e.params.bidfloor;else if("function"==typeof e.getFloor){n=e.getFloor({currency:null!=r.getConfig("floors.data.currency")?r.getConfig("floors.data.currency"):"USD",mediaType:"object"==(0,i.Z)(e.mediaTypes.banner)?"banner":"video",size:"*"}).floor}return n}catch(e){return 0}}(0,t.dX)(p),window.pbjs.installedModules.push("richaudienceBidAdapter")}},function(e){var r;r=49917,e(e.s=r)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[2229],{40060:function(e,r,t){var i=t(93324),n=t(4942),o=t(71002),a=t(64358),s=t(20265),c=t(44806),d=t(14699),p=t(3193),u=t(24679),l=t(34614),m=t(35706),v=t(78640);function g(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);r&&(i=i.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,i)}return t}function f(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?g(Object(t),!0).forEach((function(r){(0,n.Z)(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):g(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}var b="https://video-outstream.rubiconproject.com/apex-2.2.1.js",x={};p.vc.getConfig("rubicon",(function(e){(0,a.mergeDeep)(x,e.rubicon)}));var y={1:"468x60",2:"728x90",5:"120x90",7:"125x125",8:"120x600",9:"160x600",10:"300x600",13:"200x200",14:"250x250",15:"300x250",16:"336x280",17:"240x400",19:"300x100",31:"980x120",32:"250x360",33:"180x500",35:"980x150",37:"468x400",38:"930x180",39:"750x100",40:"750x200",41:"750x300",42:"2x4",43:"320x50",44:"300x50",48:"300x300",53:"1024x768",54:"300x1050",55:"970x90",57:"970x250",58:"1000x90",59:"320x80",60:"320x150",61:"1000x1000",64:"580x500",65:"640x480",66:"930x600",67:"320x480",68:"1800x1000",72:"320x320",73:"320x160",78:"980x240",79:"980x300",80:"980x400",83:"480x300",85:"300x120",90:"548x150",94:"970x310",95:"970x100",96:"970x210",101:"480x320",102:"768x1024",103:"480x280",105:"250x800",108:"320x240",113:"1000x300",117:"320x100",125:"800x250",126:"200x600",144:"980x600",145:"980x150",152:"1000x250",156:"640x320",159:"320x250",179:"250x600",195:"600x300",198:"640x360",199:"640x200",213:"1030x590",214:"980x360",221:"1x1",229:"320x180",230:"2000x1400",232:"580x400",234:"6x6",251:"2x2",256:"480x820",257:"400x600",258:"500x200",259:"998x200",264:"970x1000",265:"1920x1080",274:"1800x200",278:"320x500",282:"320x400",288:"640x380",548:"500x1000",550:"980x480",552:"300x200",558:"640x640",562:"300x431",564:"320x431",566:"320x300",568:"300x150",570:"300x125",572:"250x350",574:"620x891",576:"610x877",578:"980x552",580:"505x656"};(0,a._each)(y,(function(e,r){return y[e]=r}));var h={code:"rubicon",gvlid:52,supportedMediaTypes:[u.Mk,u.pX],isBidRequestValid:function(e){if("object"!==(0,o.Z)(e.params))return!1;for(var r=0,t=["accountId","siteId","zoneId"];r<t.length;r++)if(e.params[t[r]]=parseInt(e.params[t[r]]),isNaN(e.params[t[r]]))return(0,a.logError)("Rubicon: wrong format of accountId or siteId or zoneId."),!1;var i=w(e,!0);return!!i&&("video"!==i||function(e){var r=!0,t=Object.prototype.toString.call([]),i=Object.prototype.toString.call(0),n={mimes:t,protocols:t,linearity:i,api:t};return Object.keys(n).forEach((function(t){Object.prototype.toString.call((0,s.Z)(e,"mediaTypes.video."+t))!==n[t]&&(r=!1,(0,a.logError)("Rubicon: mediaTypes.video."+t+" is required and must be of type: "+n[t]))})),r}(e))},buildRequests:function(e,r){var t=[],i=e.filter((function(e){return"video"===w(e)})).map((function(e){e.startTime=(new Date).getTime();var t,i={id:e.transactionId,test:p.vc.getConfig("debug")?1:0,cur:["USD"],source:{tid:e.transactionId},tmax:r.timeout,imp:[{exp:p.vc.getConfig("s2sConfig.defaultTtl"),id:e.adUnitCode,secure:1,ext:(0,n.Z)({},e.bidder,e.params),video:(0,s.Z)(e,"mediaTypes.video")||{}}],ext:{prebid:{channel:{name:"pbjs",version:pbjs.version},cache:{vastxml:{returnCreative:!0===x.returnVast}},targeting:{includewinners:!0,includebidderkeys:!1,pricegranularity:(t=p.vc,{ranges:{low:[{max:5,increment:.5}],medium:[{max:20,increment:.1}],high:[{max:20,increment:.01}],auto:[{max:5,increment:.05},{min:5,max:10,increment:.1},{min:10,max:20,increment:.5}],dense:[{max:3,increment:.01},{min:3,max:8,increment:.05},{min:8,max:20,increment:.5}],custom:t.getConfig("customPriceBucket")&&t.getConfig("customPriceBucket").buckets}[t.getConfig("priceGranularity")]})},bidders:{rubicon:{integration:x.int_type||"pbjs"}}}}};"rubicon"!==e.bidder&&(i.ext.prebid.aliases=(0,n.Z)({},e.bidder,"rubicon"));var d,l,m=(0,v.R)().installedModules;if(!m||m.length&&-1===m.indexOf("rubiconAnalyticsAdapter")||(0,c.Z)(i,"ext.prebid.analytics",{rubicon:{"client-analytics":!0}}),"function"!=typeof e.getFloor||x.disableFloors)d=parseFloat((0,s.Z)(e,"params.floor"));else{var g;try{g=e.getFloor({currency:"USD",mediaType:"video",size:Z(e,"video")})}catch(e){(0,a.logError)("Rubicon: getFloor threw an error: ",e)}d="object"!==(0,o.Z)(g)||"USD"!==g.currency||isNaN(parseInt(g.floor))?void 0:parseFloat(g.floor)}(isNaN(d)||(i.imp[0].bidfloor=d),"object"===(0,o.Z)(e.floorData)&&(i.ext.prebid.floors={enabled:!1}),i.imp[0].ext[e.bidder].video.size_id=function(e){var r=parseInt((0,s.Z)(e,"params.video.size_id"));if(!isNaN(r))return r;return"outstream"===(0,s.Z)(e,"mediaTypes.".concat(u.pX,".context"))?203:201}(e),function(e,r,t){if(!e)return;"object"===(0,o.Z)(p.vc.getConfig("app"))?e.app=p.vc.getConfig("app"):e.site={page:_(r,t)};"object"===(0,o.Z)(p.vc.getConfig("device"))&&(e.device=p.vc.getConfig("device"));r.params.video.language&&["site","device"].forEach((function(t){e[t]&&("site"===t?e[t].content=Object.assign({language:r.params.video.language},e[t].content):e[t]=Object.assign({language:r.params.video.language},e[t]))}))}(i,e,r),function(e,r){"object"===(0,o.Z)(e.imp[0].video)&&void 0===e.imp[0].video.skip&&(e.imp[0].video.skip=r.params.video.skip);"object"===(0,o.Z)(e.imp[0].video)&&void 0===e.imp[0].video.skipafter&&(e.imp[0].video.skipafter=r.params.video.skipdelay);"object"===(0,o.Z)(e.imp[0].video)&&void 0===e.imp[0].video.pos&&("atf"===r.params.position?e.imp[0].video.pos=1:"btf"===r.params.position&&(e.imp[0].video.pos=3));var t=Z(r,"video");e.imp[0].video.w=t[0],e.imp[0].video.h=t[1]}(i,e),r.gdprConsent)&&("boolean"==typeof r.gdprConsent.gdprApplies&&(l=r.gdprConsent.gdprApplies?1:0),(0,c.Z)(i,"regs.ext.gdpr",l),(0,c.Z)(i,"user.ext.consent",r.gdprConsent.consentString));r.uspConsent&&(0,c.Z)(i,"regs.ext.us_privacy",r.uspConsent);var f=(0,s.Z)(r,"bids.0.userIdAsEids");f&&f.length&&(0,c.Z)(i,"user.ext.eids",f);var b=p.vc.getConfig("user.id");b&&(0,c.Z)(i,"user.id",b),!0===p.vc.getConfig("coppa")&&(0,c.Z)(i,"regs.coppa",1),e.schain&&A(e.schain)&&(0,c.Z)(i,"source.ext.schain",e.schain);var y=p.vc.getConfig("multibid");return y&&(0,c.Z)(i,"ext.prebid.multibid",y.reduce((function(e,r){var t={};return Object.keys(r).forEach((function(e){t[e.toLowerCase()]=r[e]})),e.push(t),e}),[])),k(e,u.pX,i),(0,c.Z)(i.imp[0],"ext.prebid.auctiontimestamp",r.auctionStart),i.ext.prebid.storedrequest=void 0,i.imp[0].ext.prebid.storedrequest=void 0,{method:"POST",url:"https://".concat(x.videoHost||"prebid-server",".rubiconproject.com/openrtb2/auction"),data:i,bidRequest:e}}));if(!0!==x.singleRequest)t=i.concat(e.filter((function(e){return"banner"===w(e)})).map((function(e){var t=h.createSlotParams(e,r);return{method:"GET",url:"https://".concat(x.bannerHost||"fastlane",".rubiconproject.com/a/api/fastlane.json"),data:h.getOrderedParams(t).reduce((function(e,r){var i=t[r];return(0,a.isStr)(i)&&""!==i||(0,a.isNumber)(i)?"".concat(e).concat(O(r,i),"&"):e}),"")+"slots=1&rand=".concat(Math.random()),bidRequest:e}})));else{var d=e.filter((function(e){return"banner"===w(e)})).reduce((function(e,r){return(e[r.params.siteId]=e[r.params.siteId]||[]).push(r),e}),{});t=i.concat(Object.keys(d).reduce((function(e,t){var i,n;return(i=d[t],n=10,i.map((function(e,r){return r%n==0?i.slice(r,r+n):null})).filter((function(e){return e}))).forEach((function(t){var i=h.combineSlotUrlParams(t.map((function(e){return h.createSlotParams(e,r)})));e.push({method:"GET",url:"https://".concat(x.bannerHost||"fastlane",".rubiconproject.com/a/api/fastlane.json"),data:h.getOrderedParams(i).reduce((function(e,r){var t=i[r];return(0,a.isStr)(t)&&""!==t||(0,a.isNumber)(t)?"".concat(e).concat(O(r,t),"&"):e}),"")+"slots=".concat(t.length,"&rand=").concat(Math.random()),bidRequest:t})})),e}),[]))}return t},getOrderedParams:function(e){var r=/^tg_v/,t=/^tg_i/,i=/^eid_|^tpid_/,n=["account_id","site_id","zone_id","size_id","alt_size_ids","p_pos","gdpr","gdpr_consent","us_privacy","rp_schain"].concat(Object.keys(e).filter((function(e){return i.test(e)}))).concat(["x_liverampidl","ppuid","rf","p_geo.latitude","p_geo.longitude","kw"]).concat(Object.keys(e).filter((function(e){return r.test(e)}))).concat(Object.keys(e).filter((function(e){return t.test(e)}))).concat(["tk_flint","x_source.tid","l_pb_bid_id","x_source.pchain","p_screen_res","rp_floor","rp_secure","tk_user_key"]);return n.concat(Object.keys(e).filter((function(e){return-1===n.indexOf(e)})))},combineSlotUrlParams:function(e){if(1===e.length)return e[0];var r=e.reduce((function(r,t,i){return Object.keys(t).forEach((function(n){r.hasOwnProperty(n)||(r[n]=new Array(e.length)),r[n].splice(i,1,t[n])})),r}),{}),t=new RegExp("^([^;]*)(;\\1)+$");return Object.keys(r).forEach((function(e){var i=r[e].join(";"),n=i.match(t);r[e]=n?n[1]:i})),r},createSlotParams:function(e,r){e.startTime=(new Date).getTime();var t=e.params,n=Z(e,"banner"),c=t.latLong||[],d=(0,i.Z)(c,2),m=d[0],v=d[1],g={account_id:t.accountId,site_id:t.siteId,zone_id:t.zoneId,size_id:n[0],alt_size_ids:n.slice(1).join(",")||void 0,rp_floor:(t.floor=parseFloat(t.floor))>=.01?t.floor:void 0,rp_secure:"1",tk_flint:"".concat(x.int_type||"pbjs_lite","_v7.12.0"),"x_source.tid":e.transactionId,l_pb_bid_id:e.bidId,"x_source.pchain":t.pchain,p_screen_res:[window.screen.width,window.screen.height].join("x"),tk_user_key:t.userId,"p_geo.latitude":isNaN(parseFloat(m))?void 0:parseFloat(m).toFixed(4),"p_geo.longitude":isNaN(parseFloat(v))?void 0:parseFloat(v).toFixed(4),"tg_fl.eid":e.code,rf:_(e,r)};if("function"==typeof e.getFloor&&!x.disableFloors){var f;try{f=e.getFloor({currency:"USD",mediaType:"banner",size:"*"})}catch(e){(0,a.logError)("Rubicon: getFloor threw an error: ",e)}g.rp_hard_floor="object"!==(0,o.Z)(f)||"USD"!==f.currency||isNaN(parseInt(f.floor))?void 0:f.floor}var b={1:"atf",3:"btf"}[(0,s.Z)(e,"mediaTypes.banner.pos")]||"";g.p_pos="atf"===t.position||"btf"===t.position?t.position:b;var y=p.vc.getConfig("user.id");return y&&(g.ppuid=y),e.userIdAsEids&&e.userIdAsEids.forEach((function(e){try{if("adserver.org"===e.source?(g.tpid_tdid=e.uids[0].id,g["eid_adserver.org"]=e.uids[0].id):"liveintent.com"===e.source?(g["tpid_liveintent.com"]=e.uids[0].id,g["eid_liveintent.com"]=e.uids[0].id,e.ext&&Array.isArray(e.ext.segments)&&e.ext.segments.length&&(g["tg_v.LIseg"]=e.ext.segments.join(","))):"liveramp.com"===e.source?g.x_liverampidl=e.uids[0].id:"id5-sync.com"===e.source?g["eid_id5-sync.com"]="".concat(e.uids[0].id,"^").concat(e.uids[0].atype,"^").concat(e.uids[0].ext&&e.uids[0].ext.linkType||""):g["eid_".concat(e.source)]="".concat(e.uids[0].id,"^").concat(e.uids[0].atype||""),!g.ppuid){var r=(0,l.sE)(e.uids,(function(e){return e.ext&&"ppuid"===e.ext.stype}));r&&r.id&&(g.ppuid=r.id)}}catch(r){(0,a.logWarn)("Rubicon: error reading eid:",e,r)}})),r.gdprConsent&&("boolean"==typeof r.gdprConsent.gdprApplies&&(g.gdpr=Number(r.gdprConsent.gdprApplies)),g.gdpr_consent=r.gdprConsent.consentString),r.uspConsent&&(g.us_privacy=encodeURIComponent(r.uspConsent)),g.rp_maxbids=r.bidLimit||1,k(e,u.Mk,g),!0===p.vc.getConfig("coppa")&&(g.coppa=1),e.schain&&A(e.schain)&&(g.rp_schain=h.serializeSupplyChain(e.schain)),g},serializeSupplyChain:function(e){if(!A(e))return"";var r=e.ver,t=e.complete,i=e.nodes;return"".concat(r,",").concat(t,"!").concat(h.serializeSupplyChainNodes(i))},serializeSupplyChainNodes:function(e){var r=["asi","sid","hp","rid","name","domain"];return e.map((function(e){return r.map((function(r){return encodeURIComponent(e[r]||"")})).join(",")})).join("!")},interpretResponse:function(e,r){var t=r.bidRequest;if(!(e=e.body)||"object"!==(0,o.Z)(e))return[];if(e.seatbid){var n=(0,s.Z)(e,"ext.errors.rubicon");Array.isArray(n)&&n.length>0&&(0,a.logWarn)("Rubicon: Error in video response");var d=[];return e.seatbid.forEach((function(r){(r.bid||[]).forEach((function(i){var n={requestId:t.bidId,currency:e.cur||"USD",creativeId:i.crid,cpm:i.price||0,bidderCode:r.seat,ttl:300,netRevenue:!1!==x.netRevenue,width:i.w||(0,s.Z)(t,"mediaTypes.video.w")||(0,s.Z)(t,"params.video.playerWidth"),height:i.h||(0,s.Z)(t,"mediaTypes.video.h")||(0,s.Z)(t,"params.video.playerHeight")};i.id&&(n.seatBidId=i.id),i.dealid&&(n.dealId=i.dealid),i.adomain&&(0,c.Z)(n,"meta.advertiserDomains",Array.isArray(i.adomain)?i.adomain:[i.adomain]),(0,s.Z)(i,"ext.bidder.rp.advid")&&(0,c.Z)(n,"meta.advertiserId",i.ext.bidder.rp.advid);var p=(0,s.Z)(e,"ext.responsetimemillis.rubicon");if(t&&p&&(t.serverResponseTimeMs=p),(0,s.Z)(i,"ext.prebid.type")===u.pX){n.mediaType=u.pX,(0,c.Z)(n,"meta.mediaType",u.pX);var l=(0,s.Z)(i,"ext.prebid.targeting");l&&"object"===(0,o.Z)(l)&&(n.adserverTargeting=l),i.ext.prebid.cache&&"object"===(0,o.Z)(i.ext.prebid.cache.vastXml)&&i.ext.prebid.cache.vastXml.cacheId&&i.ext.prebid.cache.vastXml.url?(n.videoCacheKey=i.ext.prebid.cache.vastXml.cacheId,n.vastUrl=i.ext.prebid.cache.vastXml.url):l&&l.hb_uuid&&l.hb_cache_host&&l.hb_cache_path&&(n.videoCacheKey=l.hb_uuid,n.vastUrl="https://".concat(l.hb_cache_host).concat(l.hb_cache_path,"?uuid=").concat(l.hb_uuid)),i.adm&&(n.vastXml=i.adm),i.nurl&&(n.vastUrl=i.nurl),!n.vastUrl&&i.nurl&&(n.vastUrl=i.nurl),"outstream"===(0,s.Z)(t,"mediaTypes.video.context").toLowerCase()&&(n.renderer=function(e){var r=m.Th.install({id:e.adId,url:x.rendererUrl||b,config:x.rendererConfig||{},loaded:!1,adUnitCode:e.adUnitCode});try{r.setRender(j)}catch(e){(0,a.logWarn)("Prebid Error calling setRender on renderer",e)}return r}(n))}else(0,a.logWarn)("Rubicon: video response received non-video media type");d.push(n)}))})),d}var p,l=e.ads,v=0;return"object"!==(0,o.Z)(t)||Array.isArray(t)||"video"!==w(t)||"object"!==(0,o.Z)(l)||(l=l[t.adUnitCode]),!Array.isArray(l)||l.length<1?[]:l.reduce((function(r,n,s){if(n.impression_id&&p===n.impression_id?v++:p=n.impression_id,"ok"!==n.status)return r;var c,d,l=Array.isArray(t)?t[s-v]:t;if(l&&"object"===(0,o.Z)(l)){var m={requestId:l.bidId,currency:"USD",creativeId:n.creative_id||"".concat(n.network||"","-").concat(n.advertiser||""),cpm:n.cpm||0,dealId:n.deal,ttl:300,netRevenue:!1!==x.netRevenue,rubicon:{advertiserId:n.advertiser,networkId:n.network},meta:{advertiserId:n.advertiser,networkId:n.network,mediaType:u.Mk}};if(n.creative_type&&(m.mediaType=n.creative_type),n.adomain&&(m.meta.advertiserDomains=Array.isArray(n.adomain)?n.adomain:[n.adomain]),n.creative_type===u.pX)m.width=l.params.video.playerWidth,m.height=l.params.video.playerHeight,m.vastUrl=n.creative_depot_url,m.impression_id=n.impression_id,m.videoCacheKey=n.impression_id;else{m.ad=(c=n.script,d=n.impression_id,"<html>\n<head><script type='text/javascript'>inDapIF=true;<\/script></head>\n<body style='margin : 0; padding: 0;'>\n\x3c!-- Rubicon Project Ad Tag --\x3e\n<div data-rp-impression-id='".concat(d,"'>\n<script type='text/javascript'>").concat(c,"<\/script>\n</div>\n</body>\n</html>"));var g=y[n.size_id].split("x").map((function(e){return Number(e)})),f=(0,i.Z)(g,2);m.width=f[0],m.height=f[1]}m.rubiconTargeting=(Array.isArray(n.targeting)?n.targeting:[]).reduce((function(e,r){return e[r.key]=r.values[0],e}),{rpfl_elemid:l.adUnitCode}),r.push(m)}else(0,a.logError)("Rubicon: bidRequest undefined at index position:".concat(s),t,e);return r}),[]).sort((function(e,r){return(r.cpm||0)-(e.cpm||0)}))},getUserSyncs:function(e,r,t,i){if(!S&&e.iframeEnabled){var n={};return t&&("boolean"==typeof t.gdprApplies&&(n.gdpr=Number(t.gdprApplies)),"string"==typeof t.consentString&&(n.gdpr_consent=t.consentString)),i&&(n.us_privacy=encodeURIComponent(i)),n=Object.keys(n).length?"?".concat((0,a.formatQS)(n)):"",S=!0,{type:"iframe",url:"https://".concat(x.syncHost||"eus",".rubiconproject.com/usync.html")+n}}},transformBidParams:function(e,r){return(0,a.convertTypes)({accountId:"number",siteId:"number",zoneId:"number"},e)}};function _(e,r){var t;return t=e.params.referrer?e.params.referrer:r.refererInfo.page,e.params.secure?t.replace(/^http:/i,"https:"):t}function j(e){var r,t=document.getElementById(e.adUnitCode);(r=t.querySelector("div[id^='google_ads']"))&&r.style.setProperty("display","none"),function(e){var r=e.querySelector("script[id^='sas_script']"),t=r&&r.nextSibling;t&&"iframe"===t.localName&&t.style.setProperty("display","none")}(t);var i=e.renderer.getConfig();e.renderer.push((function(){window.MagniteApex.renderAd({width:e.width,height:e.height,vastUrl:e.vastUrl,placement:{attachTo:t,align:i.align||"center",position:i.position||"append"},closeButton:i.closeButton||!1,label:i.label||void 0,collapse:i.collapse||!0})}))}function Z(e,r){var t=e.params;if("video"===r){var i=[];return t.video&&t.video.playerWidth&&t.video.playerHeight?i=[t.video.playerWidth,t.video.playerHeight]:Array.isArray((0,s.Z)(e,"mediaTypes.video.playerSize"))&&1===e.mediaTypes.video.playerSize.length?i=e.mediaTypes.video.playerSize[0]:Array.isArray(e.sizes)&&e.sizes.length>0&&Array.isArray(e.sizes[0])&&e.sizes[0].length>1&&(i=e.sizes[0]),i}var n=[];return Array.isArray(t.sizes)?n=t.sizes:void 0!==(0,s.Z)(e,"mediaTypes.banner.sizes")?n=I(e.mediaTypes.banner.sizes):Array.isArray(e.sizes)&&e.sizes.length>0?n=I(e.sizes):(0,a.logWarn)("Rubicon: no sizes are setup or found"),function(e){var r=[15,2,9];return e.sort((function(e,t){var i=r.indexOf(e),n=r.indexOf(t);return i>-1||n>-1?-1===i?1:-1===n?-1:i-n:e-t}))}(n)}function k(e,r,t){var i={user:{ext:{data:f({},e.params.visitor)}},site:{ext:{data:f({},e.params.inventory)}}};e.params.keywords&&(i.site.keywords=(0,a.isArray)(e.params.keywords)?e.params.keywords.join(","):e.params.keywords);var n=(0,a.mergeDeep)({},e.ortb2||{},i),c=(0,s.Z)(e.ortb2Imp,"ext")||{},d=(0,s.Z)(e.ortb2Imp,"ext.data")||{},p=(0,s.Z)(e,"ortb2Imp.ext.gpid"),l={user:[4],site:[1,2,5,6]},m={user:"tg_v.",site:"tg_i.",adserver:"tg_i.dfp_ad_unit_code",pbadslot:"tg_i.pbadslot",keywords:"kw"},v=function(e,r,t){return"data"===r&&Array.isArray(e)?e.filter((function(e){return e.segment&&(0,s.Z)(e,"ext.segtax")&&l[t]&&-1!==l[t].indexOf((0,s.Z)(e,"ext.segtax"))})).map((function(e){var r=e.segment.filter((function(e){return e.id})).reduce((function(e,r){return e.push(r.id),e}),[]);if(r.length>0)return r.toString()})).toString():("object"!==(0,o.Z)(e)||Array.isArray(e))&&void 0!==e?Array.isArray(e)?e.filter((function(e){if("object"!==(0,o.Z)(e)&&void 0!==e)return e.toString();(0,a.logWarn)("Rubicon: Filtered value: ",e,"for key",r,": Expected value to be string, integer, or an array of strings/ints")})).toString():e.toString():void 0},g=function(e,r,i){var n=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],o=v(e,i,r),a=m[i]&&n?"".concat(m[i]):"data"===i?"".concat(m[r],"iab"):"".concat(m[r]).concat(i);t[a]=t[a]?t[a].concat(",",o):o};r===u.Mk?(["site","user"].forEach((function(e){Object.keys(n[e]).forEach((function(r){"site"===e&&"content"===r&&n[e][r].data?g(n[e][r].data,e,"data"):"ext"!==r?g(n[e][r],e,r):n[e][r].data&&Object.keys(n[e].ext.data).forEach((function(r){g(n[e].ext.data[r],e,r,!1)}))}))})),Object.keys(d).forEach((function(e){"adserver"!==e?g(d[e],"site",e):"gam"===d[e].name&&g(d[e].adslot,name,e)})),p&&(t.p_gpid=p),t["tg_i.pbadslot"]&&delete t["tg_i.dfp_ad_unit_code"]):(Object.keys(c).length&&(0,a.mergeDeep)(t.imp[0].ext,c),p&&(t.imp[0].ext.gpid=p),(0,a.mergeDeep)(t,n))}function I(e){return(0,a.parseSizesInput)(e).reduce((function(e,r){var t=parseInt(y[r],10);return t&&e.push(t),e}),[])}function C(e){return"object"===(0,o.Z)((0,s.Z)(e,"params.video"))&&void 0!==(0,s.Z)(e,"mediaTypes.".concat(u.pX))}function w(e){var r=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return C(e)?-1===["outstream","instream"].indexOf((0,s.Z)(e,"mediaTypes.".concat(u.pX,".context")))?void(r&&(0,a.logError)("Rubicon: mediaTypes.video.context must be outstream or instream")):Z(e,"video").length<2?void(r&&(0,a.logError)("Rubicon: could not determine the playerSize of the video")):(r&&(0,a.logMessage)("Rubicon: making video request for adUnit",e.adUnitCode),"video"):0===Z(e,"banner").length?void(r&&(0,a.logError)("Rubicon: could not determine the sizes for banner request")):(r&&(0,a.logMessage)("Rubicon: making banner request for adUnit",e.adUnitCode),"banner")}function A(e){var r=!1,t=["asi","sid","hp"];return e.nodes?((r=e.nodes.reduce((function(e,r){return e?t.every((function(e){return r.hasOwnProperty(e)})):e}),!0))||(0,a.logError)("Rubicon: required schain params missing"),r):r}function O(e,r){return"rp_schain"===e?"rp_schain=".concat(r):"".concat(e,"=").concat(encodeURIComponent(r))}var S=!1;(0,d.dX)(h),window.pbjs.installedModules.push("rubiconBidAdapter")}},function(e){var r;r=40060,e(e.s=r)}]);
(self.pbjsChunk=self.pbjsChunk||[]).push([[2599],{70789:function(e,r,t){var n=t(71002),i=t(4942),o=t(89062),a=t(64358),u=t(24679),p=t(14699),d=t(3193),c=t(15164);function s(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);r&&(n=n.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,n)}return t}function l(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?s(Object(t),!0).forEach((function(r){(0,i.Z)(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):s(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}var f="triplelift",m=!0,y=null,g=(0,c.df)({gvlid:28,bidderCode:f}),v={gvlid:28,code:f,supportedMediaTypes:[u.Mk,u.pX],isBidRequestValid:function(e){return void 0!==e.params.inventoryCode},buildRequests:function(e,r){var t="https://tlx.3lift.com/header/auction?",n=function(e,r){var t={},n=e[0].schain,i=function(e){var r={},t={},n={},i=e.ortb2||{},o=function(){var e=g.getDataFromLocalStorage("opecloud_ctx");if(!e)return null;try{return JSON.parse(e)}catch(e){return(0,a.logError)("Triplelift: error parsing JSON: ",e),null}}(),u=Object.assign({},i.site),p=Object.assign({},i.user);if(o){p.data=p.data||[];try{p.data.push({name:"www.1plusx.com",ext:o})}catch(e){(0,a.logError)("Triplelift: error adding 1plusX segments: ",e)}}x(t,u),x(n,p),(0,a.isEmpty)(t)||(r.context=t);(0,a.isEmpty)(n)||(r.user=n);return r}(r);t.imp=e.map((function(e,r){var t={id:r,tagid:e.params.inventoryCode,floor:O(e)};return b(e)&&(t.video=function(e){var r=l(l({},e.params.video),e.mediaTypes.video);try{r.w||(r.w=r.playerSize[0][0]),r.h||(r.h=r.playerSize[0][1])}catch(e){(0,a.logWarn)("Video size not defined",e)}"instream"===r.context&&(r.placement=1);"outstream"===r.context&&(r.placement?-1===[3,4,5].indexOf(r.placement)&&((0,a.logMessage)("video.placement value of ".concat(r.placement," is invalid for outstream context. Setting placement to 3")),r.placement=3):r.placement=3);return delete r.playerSize,r}(e)),e.mediaTypes.banner&&!h(e)&&(t.banner={format:T(e.sizes)}),(0,a.isEmpty)(e.ortb2Imp)||(t.fpd=function(e){var r={},t={};x(t,e.ext),(0,a.isEmpty)(t)||(r.context=t);return r}(e.ortb2Imp)),t}));var u=[].concat((0,o.Z)((p=[e[0]],j(p,"tdid","adserver.org","TDID"))),(0,o.Z)(function(e){return j(e,"idl_env","liveramp.com","idl")}([e[0]])),(0,o.Z)(function(e){return j(e,"criteoId","criteo.com","criteoId")}([e[0]])),(0,o.Z)(function(e){return j(e,"pubcid","pubcid.org","pubcid")}([e[0]])));var p;u.length>0&&(t.user={ext:{eids:u}});var d=function(e,r){var t={};(0,a.isEmpty)(e)||(t.schain=l({},e));(0,a.isEmpty)(r)||(t.fpd=l({},r));return t}(n,i);(0,a.isEmpty)(d)||(t.ext=d);return t}(e,r);if(t=(0,a.tryAppendQueryString)(t,"lib","prebid"),t=(0,a.tryAppendQueryString)(t,"v","7.12.0"),r&&r.refererInfo){var i=r.refererInfo.page;t=(0,a.tryAppendQueryString)(t,"referrer",i)}return r&&r.timeout&&(t=(0,a.tryAppendQueryString)(t,"tmax",r.timeout)),r&&r.gdprConsent&&(void 0!==r.gdprConsent.gdprApplies&&(m=r.gdprConsent.gdprApplies,t=(0,a.tryAppendQueryString)(t,"gdpr",m.toString())),void 0!==r.gdprConsent.consentString&&(y=r.gdprConsent.consentString,t=(0,a.tryAppendQueryString)(t,"cmp_cs",y))),r&&r.uspConsent&&(t=(0,a.tryAppendQueryString)(t,"us_privacy",r.uspConsent)),!0===d.vc.getConfig("coppa")&&(t=(0,a.tryAppendQueryString)(t,"coppa",!0)),t.lastIndexOf("&")===t.length-1&&(t=t.substring(0,t.length-1)),(0,a.logMessage)("tlCall request built: "+t),{method:"POST",url:t,data:n,bidderRequest:r}},interpretResponse:function(e,r){var t=r.bidderRequest;return(e.body.bids||[]).map((function(e){return function(e,r){var t={},n=r.width||1,i=r.height||1,o=r.deal_id||"",a=r.crid||"",u=e.bids[r.imp_id];0!=r.cpm&&r.ad&&(t={requestId:u.bidId,cpm:r.cpm,width:n,height:i,netRevenue:!0,ad:r.ad,creativeId:a,dealId:o,currency:"USD",ttl:300,tl_source:r.tl_source,meta:{}},b(u)&&"video"===r.media_type&&(t.vastXml=r.ad,t.mediaType="video",t.ttl=3600),r.advertiser_name&&(t.meta.advertiserName=r.advertiser_name),r.adomain&&r.adomain.length&&(t.meta.advertiserDomains=r.adomain),r.tl_source&&"hdx"==r.tl_source&&(b(u)&&"video"===r.media_type?t.meta.mediaType="video":t.meta.mediaType="banner"),r.tl_source&&"tlx"==r.tl_source&&(t.meta.mediaType="native"));return t}(t,e)}))},getUserSyncs:function(e,r,t,n){var i=function(e){if(!e)return;if(e.iframeEnabled)return"iframe";if(e.pixelEnabled)return"image"}(e);if(i){var o="https://eb2.3lift.com/sync?";return"image"===i&&(o=(0,a.tryAppendQueryString)(o,"px",1),o=(0,a.tryAppendQueryString)(o,"src","prebid")),null!==y&&(o=(0,a.tryAppendQueryString)(o,"gdpr",m),o=(0,a.tryAppendQueryString)(o,"cmp_cs",y)),n&&(o=(0,a.tryAppendQueryString)(o,"us_privacy",n)),[{type:i,url:o}]}}};function b(e){return S(e)&&(h(e)||function(e){return S(e)&&"outstream"===e.mediaTypes.video.context.toLowerCase()}(e))}function h(e){return S(e)&&"instream"===e.mediaTypes.video.context.toLowerCase()}function S(e){return e.mediaTypes.video&&e.mediaTypes.video.context}function O(e){var r=null;if("function"==typeof e.getFloor)try{var t=e.getFloor({currency:"USD",mediaType:b(e)?"video":"banner",size:"*"});"object"!==(0,n.Z)(t)||"USD"!==t.currency||isNaN(parseFloat(t.floor))||(r=parseFloat(t.floor))}catch(e){(0,a.logError)("Triplelift: getFloor threw an error: ",e)}return null!==r?r:e.params.floor}function x(e,r){(0,a.isEmpty)(r)||Object.keys(r).forEach((function(t){null!=r[t]&&(e[t]=r[t])}))}function j(e,r,t,n){return e.map(function(e){return function(r){return r&&r.userId&&r.userId[e]}}(r)).filter(w(r)).map(function(e,r){return function(t){return{source:e,uids:[{id:t.id?t.id:t,ext:{rtiPartner:r}}]}}}(t,n))}var w=function(e){return function(r,t,n){var i=!!r&&((0,a.isStr)(r)?!!r:(0,a.isPlainObject)(r)&&!(0,a.isArray)(r)&&!(0,a.isEmpty)(r)&&r.id&&(0,a.isStr)(r.id)&&!!r.id);return i||void 0===n[0]||(0,a.logWarn)("Triplelift: invalid ".concat(e," userId format")),i}};function T(e){return e.filter(_).map((function(e){return{w:e[0],h:e[1]}}))}function _(e){return 2===e.length&&"number"==typeof e[0]&&"number"==typeof e[1]}(0,p.dX)(v),window.pbjs.installedModules.push("tripleliftBidAdapter")}},function(e){var r;r=70789,e(e.s=r)}]);
})(),pbjs.processQueue();KL.Modules.movements = new function()
{
  var self = this;
  this.drag = 0;
  this.velocity = 0;
  this.captured = null;
  var draglisteners = {};

  this.adddraglistener = adddraglistener;
  function adddraglistener(id, rules)
  {
    draglisteners[id] = rules;
  }

  this.removedraglistener = removedraglistener;
  function removedraglistener(id)
  {
    delete draglisteners[id];
  }

  function startdrag(node)
  {
    // limpiamos los listeners que ya no funcionan (en caso de recargar la página)
    // buscamos el nodo afin
    for (var i in draglisteners)
    {
      if (draglisteners[i].startleft)
      {
        if (self.dragstartx >= draglisteners[i].startleft[0] && self.dragstartx <= draglisteners[i].startleft[1])
        {
          self.captured = i;
          draglisteners[i].listener('start', buildmetrics());
          break;
        }
      }
      if (draglisteners[i].startright)
      {
        var w = WA.browser.getScreenWidth();
        if (self.dragstartx >= draglisteners[i].startright[0]+w && self.dragstartx <= draglisteners[i].startright[1]+w)
        {
          self.captured = i;
          draglisteners[i].listener('start', buildmetrics());
          break;
        }
      }
      if (draglisteners[i].node)
      {
        var n = WA.toDOM(draglisteners[i].node);
        var p = node;
        while (n != p && p != window && p != null)
          p = p.parentNode;
        if (p == n)
        {
          self.captured = i;
          draglisteners[i].listener('start', buildmetrics());
          break;
        }
      }
    }
  }

  function drag()
  {
    if (self.captured)
      draglisteners[self.captured].listener('drag', buildmetrics());
  }

  function stopdrag()
  {
    if (self.captured)
      draglisteners[self.captured].listener(self.velocity<0?'izquierda':'derecha', buildmetrics());
  }

  function buildmetrics()
  {
    return {startx:self.dragstartx, x:self.dragx, dx:self.dragdx, velocity: self.velocity};
  }

  function touchstart(e)
  {
    self.drag = 1;
    self.dragstartx = WA.browser.getTouchDocumentX(e);
    self.dragstarty = WA.browser.getTouchDocumentY(e);
    self.dragdx = 0;
    self.dragx = self.dragstartx;

    self.velocity = 0;
    self.draglasttime = new Date().getTime();
    self.draglasttimex = self.dragstartx;

    startdrag(e.target);
  }

  function touchmove(e)
  {
    var deltax = self.dragstartx - WA.browser.getTouchDocumentX(e);
    var deltay = self.dragstarty - WA.browser.getTouchDocumentY(e);
    if (self.drag == 1)
    {
      // start drag when Delta move > 10 px
      if (Math.abs(deltax) < 5 && Math.abs(deltay) < 5)
        return;

      if (Math.abs(deltax) > Math.abs(deltay))
        self.drag = 2;   // move horizontaly
    }

    if (self.drag == 2)
    {
      // in cuadrant 2 and 4 (< and >) start drag;
      self.dragx = WA.browser.getTouchDocumentX(e);
      self.dragdx = self.dragx - self.dragstartx;

      var deltat = new Date().getTime() - self.draglasttime;
      if (deltat < 1)
        deltat = 1;
      var deltah = self.dragx - self.draglasttimex;
      self.draglasttime = new Date().getTime();
      self.draglasttimex = self.dragx;
      self.velocity = deltah / deltat * 700;
      drag();
    }
  }

  function touchend(e)
  {
    if (self.drag == 2)
    {
      if (Math.abs(self.velocity) < 50)
        self.velocity = 0;
      if (self.velocity > 1000)
        self.velocity = 1000;
      if (self.velocity < -1000)
        self.velocity = -1000;

      stopdrag();
    }

    self.drag = 0;
    self.captured = null;
  }

  function start()
  {
    WA.Managers.event.on('touchstart', document, touchstart, false);
    WA.Managers.event.on('touchmove', document, touchmove, false);
    WA.Managers.event.on('touchend', document, touchend, false);
  }

  KL.loader.addHookStart('general', start);
}
var flagFB = false;

KL.Modules.facebook = new function () {

    var self = this;
    var cargado = false;
    var FBresponse = null;
    this.facebookok = false;
    var serversent = false;
    var called = null;

    // Facebook asyncronous
    //this.fbAsyncInit = window.fbAsyncInit();
    window.fbAsyncInit = function () {
        //console.log("async fb")
        FB.init({
            appId: KL.fbid,
            cookie: true,  // enable cookies to allow the server to access
            xfbml: true,  // parse social plugins on this page
            version: 'v9.0' // use version 3.0
        });
        //  to send the response of authorization google
        FB.getLoginStatus(function (response) {
            self.FBlistener(response); // th Listener in the new structure is the start function
        });
        FB.Event.subscribe('auth.login', self.FBlistener);
        //FB.Event.subscribe('auth.logout', self.FBlistener);
        FB.Event.subscribe('auth.authResponseChange', self.FBlistener);
    };

    // FBlistener
    this.FBlistener = FBlistener;
    function FBlistener(response) {
//        console.log("fb listener")
//        console.log(response)
        FBresponse = response;
        if (called < new Date().getTime() / 1000 - 1) {
          called = null;
        }
        if (self.facebookok && FBresponse!==undefined && !called) {
            called = new Date().getTime() / 1000;
            loginFacebook();
            return;
        }
    }

    // login facebook
    function loginFacebook() {
        //console.log("fb login")
        if (FBresponse.status === 'connected') { // && flagFB
            let auxAccessToken = FBresponse.authResponse.accessToken;
            let auxSignedRequest = FBresponse.authResponse.signedRequest;
            if (serversent == true)
                return;
            WA.Managers.ajax.createPromiseRequest({ url: KL.identitydomains + '/sociallogin/fb', method: 'POST', send: false })
                .then(function (request) {
                    request.addParameter('language', KL.language); //language=es|en
                    request.addParameter('device', KL.device); //device="pc", "mobile", "ios", "android"
                    request.addParameter('user', "{ \"signedRequest\" : \"" + auxSignedRequest + "\", \"accessToken\" : \"" + auxAccessToken + "\" } "); //language=es|en
                    serversent = true;
                    return request.send(); //
                })
                .then(function (response) {
                    self.facebookok = false;
                    serversent = false;
                    var code = JSON.parse(response);
                    // proceso... mismo para todas las redes sociales...
                    switch (code.status) {
                        case "REGISTER":
                            KL.Modules.stat.registerEvent('loginset', 'loginset/social/fb/register');
                            KL.Modules.client.loadclient();
                            KL.Modules.loginset.forms['enlaza'].fill(code, 'fb');
                            break;
                        case "OK":
                            KL.Modules.stat.registerEvent('loginset', 'loginset/social/fb/login');
                            KL.Modules.client.loadclient();
                            KL.Modules.loginset.Logged();
                            break;
                        case "Error":
                            KL.Modules.stat.registerEvent('loginset', 'loginset/sociallogin/facebook/' + respuesta.code);
                            KL.Modules.loginset.errorlogin('loginset-social-facebook', respuesta.message);
                            break;
                    }
                })
                .catch(function (code, err) {
                    KL.Modules.stat.registerEvent('loginset', 'loginset/sociallogin/' + code);
                });
        } else if (FBresponse.status === 'not_authorized') {
            //console.log("No autorizado");
        }/*
        else {
        } */
    }

    this.show = show;

    function show() { self.node.style.display = 'block'; }

    this.hide = hide;

    function hide() { self.node.style.display = 'none'; }


    this.loadFacebookBtn = loadFacebookBtn;
    function loadFacebookBtn() {
        if (window.FB && FB.XFBML) {
            self.facebookok = true;
            //console.log("FB loaded")
        }
        if (!self.facebookok) {
            //console.log("no carga window.FB")
            setTimeout(function () { loadFacebookBtn(); }, 100);
            return;
        }
        window.fbAsyncInit();
    }

    this.cargasdk = cargasdk;
    function cargasdk() {
      /* Facebook SDK */
      // already loaded ???
      if(cargado) {
        return;
      }
      WA.Managers.externloader.loadexterncode("https://connect.facebook.net/" + KL.locale + "/sdk.js#xfbml=1&version=v3.2&appId=" + KL.fbid);
      cargado=true;
    }


    this.share = share;
    function share(shareQuote, shareUrl) {
        var url = document.location.href;
        var quote = false;

        if (shareUrl && (typeof(shareUrl) === "string"))
            url = shareUrl;

        if (shareQuote && (typeof(shareQuote) === "string") && !(shareQuote === ""))
            quote = shareQuote;

        var params = {href: url, method: "share", display: "popup"};

        if (quote)
            params.quote = quote;

        if (url.indexOf('/quiz/') !== -1)
            ga('send', 'event', 'quiz', 'quiz/share', 'share', 0);

        // second parameter is a callback
        FB.ui(params, null);
    }

    this.start = start;
    function start() {
        self.cargasdk();
    }

    this.load = load;
    function load(){
        if (!WA.toDOM('botonfacebook'))
            return;
        self.loadFacebookBtn();
    }


    //
    KL.loader.addHookStart('facebook', start);
    KL.loader.addHookLoad('facebook', load);
}
/*
function KiwiFBlistener(response) {
    flagFB = true;
    KL.Modules.facebook.FBlistener(response);
}
*/
/* Manejo de los datos del cliente, conectado o no */
/*
  Escrito por: Phil
  Fecha: Julio 2016

  Control de cambios:
  10/07/2016: Phil, Creación
  18/08/2016: Phil, agregar control de notificaciones y tiempo de ultima lectura, depuración de atributos no usados
  15/02/2019: Wilmer, boton para el nuevo menu desplegable
  15/04/2019: Wilmer, manejo de origen
*/

KL.Modules.client = new function()
{
  var self = this;
  this.clientready = false;        // true cuando ya sabemos la info del client (o sin client)
  this.clientlogged = false;       // true si el client esta conectado
  this.clientpro = false;          // true si el client es PRO

  this.node = null;
  this.nodemenu = null;
  this.opened = false;
  this.closecandidate = false;
  this.loaded = false;

  var clientcode = null;           // codigo del client

  var hooksloaded = {};           // llamar cuando recibimos los datos del client (sea conectado o no)
  var hooksconnect = {};          // llamar cuando se conecta un client
  var hooksdisconnect = {};       // llamar cuando se desconecta un client

  this.addHookLoad = addHookLoad;
  function addHookLoad(id, hook)
  {
    hooksloaded[id] = hook;
    // Si ya paso por aqui, tenemos que llamar el hook !
    if (self.clientready)
      hook();
  }

  this.delHookLoad = delHookLoad;
  function delHookLoad(id)
  {
    delete hooksloaded[id];
  }

  function callHooksLoad()
  {
    for (var i in hooksloaded)
    {
      hooksloaded[i]();
    }
  }

  /* Chef conectado*/
  this.addHookConnect = addHookConnect;
  function addHookConnect(id, hook)
  {
    hooksconnect[id] = hook;
    if (self.clientready)
      hook();
  }

  this.callHooksConnect = callHooksConnect;
  function callHooksConnect()
  {
    for (var i in hooksconnect)
    {
      hooksconnect[i]();
    }
  }

  this.delHookConnect = delHookConnect;
  function delHookConnect(id)
  {
    delete hooksconnect[id];
  }
  /* Chef conectado*/

  /* Chef desconectado*/
  this.addHookDisconnect = addHookDisconnect;
  function addHookDisconnect(id, hook)
  {
    hooksdisconnect[id] = hook;
    if (self.clientready)
      hook();
  }

  this.callHooksDisconnect = callHooksDisconnect;
  function callHooksDisconnect()
  {
    for (var i in hooksdisconnect)
    {
      hooksdisconnect[i]();
    }
  }

  function buildClient()
  {
    if (clientcode == null) {
      self.clientready = false;
      return;
    }

    self.clientready = true;
    self.clientlogged = !!clientcode.client;
    self.clientpro = self.clientlogged && clientcode.client && (!!clientcode.client.p);
    
    node = WA.toDOM("header-client");
  
    if (self.clientlogged){
      temp = WA.templates['client_connected'](clientcode);

      if((KL.Modules.client.clientpro) && (KL.rootsite == "kiwi")){
        //WA.toDOM("header-icono-kiwipro").style.display = "block";
        WA.toDOM("header-div-logo-normal").style.display = "none";
        WA.toDOM("header-div-logo-pro").style.display = "block";
        WA.toDOM("header").style.backgroundColor = "var(--azul-kiwipro)";
        //WA.toDOM("header").style.backgroundImage = "url('" + KL.cdn7domains + "/img/static/header-azul-desk-fest.jpg')";
        WA.toDOM("header").style.backgroundRepeat = "repeat-x";
        WA.toDOM("footer-divfooter").style.backgroundColor = "var(--azul-kiwipro)";
        //WA.toDOM("footer-divfooter").style.backgroundImage = "url('" + KL.cdn7domains + "/img/static/footer-azul-desk-fest.jpg')";
        WA.toDOM("footer-divfooter").style.backgroundRepeat = "repeat-x";
        if (KL.device == "pc")
          WA.toDOM("header-search-go").style.backgroundColor = "#9fc7c4";
      }
      if((!KL.Modules.client.clientpro) && (KL.rootsite == "kiwi")){
        WA.toDOM("header-div-logo-normal").style.display = "block";
        WA.toDOM("header-div-logo-pro").style.display = "none";
        WA.toDOM("header").style.backgroundColor = "var(--verde-kiwi)";
        //WA.toDOM("header").style.backgroundImage = "url('" + KL.cdn7domains + "/img/static/header-verde-desk-fest.jpg')";
        WA.toDOM("header").style.backgroundRepeat = "repeat-x";
        //WA.toDOM("footer-divfooter").style.backgroundImage = "url('" + KL.cdn7domains + "/img/static/footer-verde-desk-fest.jpg')";
        WA.toDOM("footer-divfooter").style.backgroundRepeat = "repeat-x";
      }
    }
    else{
      temp = WA.templates['client_notconnected'](clientcode);
  
      if(KL.rootsite == "kiwi"){
        //WA.toDOM("header-icono-kiwipro").style.display = "none";
        WA.toDOM("header-div-logo-normal").style.display = "block";
        WA.toDOM("header-div-logo-pro").style.display = "none";
        WA.toDOM("header").style.backgroundColor = "var(--verde-kiwi)";
        //WA.toDOM("header").style.backgroundImage = "url('" + KL.cdn7domains + "/img/static/header-verde-desk-fest.jpg')";
        WA.toDOM("header").style.backgroundRepeat = "repeat-x";
        //WA.toDOM("footer-divfooter").style.backgroundImage = "url('" + KL.cdn7domains + "/img/static/footer-verde-desk-fest.jpg')";
        WA.toDOM("footer-divfooter").style.backgroundRepeat = "repeat-x";
        //WA.toDOM("header-search-go").style.backgroundColor = "#a8e05c";
      }
    }
  
    node.innerHTML = temp;
      
    if ((self.clientlogged) && (!KL.Modules.client.clientpro) && (KL.rootsite == "kiwi"))
    {
      //WA.toDOM("header-urliconpro").style.display = "block";
      WA.toDOM("header-urliconpro").style.display = "flex";
    }
  
    // Link menus
    self.loaded = false;
    self.node = WA.toDOM("header-client-button");
    self.nodemenu = WA.toDOM("header-client-menu");
  
    if (self.node)
    {
      self.node.onclick=switchmenu;
      self.node.ontouchstart=switchmenu;
      self.node.onmouseover=switchon;
      self.node.onmouseout=tryswitchoff;
    }
  
    if (self.nodemenu)
    {
      self.nodemenu.onmouseover=switchon;
      self.nodemenu.onmouseout=tryswitchoff;
    }
  }

  // MANEJO DEL MENU DEL CLIENTE:
  function switchmenu(event)
  {
    if (!self.opened)
      return switchon(event);
    switchoff();
    return WA.browser.cancelEvent(event);
  }

  function switchon(event)
  {
    self.closecandidate = false;
    if (self.closetimer)
    {
      clearTimeout(self.closetimer);
      self.closetimer = null;
    }
    if (self.opened)
      return;
    KL.Modules.menu.switchoff();
    KL.Modules.language.switchoff();
    KL.Modules.search.switchoff();
    KL.Modules.stat.registerEvent('headclient', 'head/client/open');
    self.opened = true;
    if (KL.device == "mobile")
    {
      self.nodemenu.style.top = "46px";
      if((KL.Modules.client.clientpro) && (KL.rootsite == "kiwi")){
        self.node.className = "anim onpro";
        WA.toDOM('header-client-menu').classList.add("divmenupro");
      }
      else{
        self.node.className = "anim on";
      }
    }
    else
    {
      self.nodemenu.style.top = "60px";
      if((KL.Modules.client.clientpro) && (KL.rootsite == "kiwi")){
        self.node.className = "anim onpro";
        WA.toDOM('header-client-menu').classList.add("divmenupro");
      }
      else{
        self.node.className = "anim on";
      }
    }
    if (!self.loaded)
      load();
    return WA.browser.cancelEvent(event);
  }

  function tryswitchoff()
  {
    self.closecandidate = true;
    self.closetimer = setTimeout(switchoff, 200);
  }

  this.switchoff = switchoff;
  function switchoff(event)
  {
    self.closecandidate = false;
    if (self.closetimer)
    {
      clearTimeout(self.closetimer);
      self.closetimer = null;
    }
    if (!self.opened)
      return;
    KL.Modules.stat.registerEvent('headclient', 'head/client/close');
    self.opened = false;
    // gets height of node
    h = WA.browser.getNodeOuterHeight(self.nodemenu);
    self.nodemenu.style.top = -h + "px";
    self.node.className = "anim";
    return WA.browser.cancelEvent(event);
  }

  function load()
  {
    var request = WA.Managers.ajax.createRequest('/data/menuclient' + (self.clientlogged ? '' : 'nc'), 'POST', null, loaded, true);
  }

  function loaded(request)
  {
    self.nodemenu.innerHTML = request.responseText;
    // Quita la coronita cuando el usuario no es pro
    if ((self.clientlogged) && (KL.Modules.client.clientpro) && (KL.rootsite == "kiwi")) {
      WA.toDOM("menuclient-padlock-planeador").style.display = "none";
    }

    // reajustar top -X si cerrado
    if (self.opened == false)
    {
      h = WA.browser.getNodeOuterHeight(self.nodemenu);
      self.nodemenu.style.top = -h + "px";
    }
    self.loaded = true;
    KL.loader.callHooksPostLoad();
  }

  function start()
  {
    // Start: load the 1rst time client data
    // Toma el objeto del cliente del JS precargado
    // Pone la plantilla correspondiente al client
    clientcode = KL.pagedata.client;
    buildClient();
  }

  this.getClaveChef = getClaveChef;
  function getClaveChef()
  {
    return clientcode.client.c;
  }

  this.getCountry = getCountry;
  function getCountry()
  {
    return clientcode.gep;
  }

  this.loadclient = loadclient;
  function loadclient()
  {
    var request = WA.Managers.ajax.createRequest(KL.identitydomains + '/client', 'POST', 'device=' + KL.device + '&language=' + KL.language, getloadclient, true);
  }

  function getloadclient(request)
  {
    clientcode = JSON.parse(request.responseText);
    buildClient();
  }


  this.disconnect = disconnect;
  function disconnect()
  {
    var request = WA.Managers.ajax.createRequest(KL.identitydomains + '/client', 'DELETE', 'device=' + KL.device+'&language=' + KL.language, loadclient, true);

    //delete cookie?
    var date = new Date();
    date.setTime(date.getTime()+(-24*60*60*1000));
    var expires = "; expires="+date.toGMTString();
    document.cookie = "siteSessionDevel=" + expires + "; domain=" + KL.cookiedomain + "; path=/";
    document.cookie = "siteSession="+expires+"; domain="+KL.cookiedomain+"; path=/";
  }

  // llamado cada 30 segundos para saber si hay notificaciones nuevas del cliente
  function recon()
  {
    var request = WA.Managers.ajax.createRequest(KL.identitydomains + '/notification', 'GET', 'device=' + KL.device + '&language=' + KL.language, getnotif, true);
  }

  // newsletter 
  this.sendnewsletter = sendnewsletter;
  function sendnewsletter() {
    const mail = WA.toDOM('newsletter').value;
    if (mail == "") {
        return;
    }
    WA.Managers.ajax.createPromiseRequest({ url: KL.identitydomains + '/newsletter', method: 'POST', send: false })
      .then(function (request) {
          request.addParameter('language', KL.language);
          request.addParameter('device', KL.device);
          request.addParameter('user', mail);
          return request.send();
      })
      .then(function (response) {
          const resp = JSON.parse(response);
          if (resp.status == "OK") {
              KL.Modules.modal.notifica(resp.message);
          } else {
              switch (resp.code) {
                  case 1504:
                      KL.Modules.modal.notifica(resp.message);
                      break;
                  default:
                      KL.Modules.modal.alerta(resp.message);
                      break;
              }
          }
      })
      .catch(function (code, err) {
          // 
      });
  }

  KL.loader.addHookRecon('client', recon);
  KL.loader.addHookStart('client', start);
}

/* search, main search field */

KL.Modules.search = new function()
{
  var self = this;
  this.node = null;
  this.nodesearch = null;
  this.nodeclose = null;
  this.nodego = null;
  this.nodesugg = null;
  this.opened = false;
  this.trx = 0;
  var flagsearch = false;  // Set to true when searching data from the server. Only 1 search authorize at the same time. If more we ignore them, just get the last one.
  var timer = null;        // timer set to search from server (delay 300ms)

  function hidesuggestion()
  {
    if (!self.nodesugg)
      return;
    self.nodesugg.style.display = "none";
  }

  function showsuggestion()
  {
    if (!self.nodesugg)
    { // No suggestions support
      return;
    }
    KL.Modules.menu.switchoff();
    KL.Modules.language.switchoff();
    KL.Modules.client.switchoff();
    self.nodesugg.style.display = "block";
    KL.Modules.stat.registerEvent('headsearch', 'head/search/suggest');
  }

  // Activated only on mobile
  function hidesearch()
  {
    if (!self.nodesearch)
      return;
    hidesuggestion();
    self.opened = false;
    self.nodesearch.className = "anim";
    self.nodego.className = "icon-k7-search anim";
    self.node.value="";
  }

  // Activated only on mobile
  function showsearch()
  {
    if (!self.nodesearch)
      return;
    KL.Modules.menu.switchoff();
    KL.Modules.language.switchoff();
    KL.Modules.client.switchoff();
    self.opened = true;
    self.nodesearch.className = "anim on";
    
    if((KL.Modules.client.clientpro) && (KL.rootsite == "kiwi"))
      self.nodego.className = "icon-k7-search anim onpro";
    else
      self.nodego.className = "icon-k7-search anim on";
    
    self.node.focus();
  }

  function changeq(event)
  {
    setTimeout(function () {verificaq();}, 0);
  }

   function verificaq()
   {
     if (timer)
     {
       clearTimeout(timer);
       timer = null;
     }
     var numc = self.node.value.trim().length;
     var word = self.node.value.trim();
     if (numc >= 3)
       // Intentamos con timeout a 0: cada caracter es enviado a sugerencias
       timer = setTimeout(function() { gosuggestion(word); }, 0);
     else
       hidesuggestion();
   }

  function gosuggestion(word)
  {
    var request = WA.Managers.ajax.createRequest(KL.graphdomains + '/v6/suggestions', 'POST', null, getsuggestion, false);
    request.addParameter('q', word);
    request.addParameter('language', KL.language);
    request.addParameter('device', KL.device);
    request.addParameter('trx', ++self.trx);
    request.send();
  }

  function getsuggestion(request)
  {
    var resp = JSON.parse(request.responseText);
    if (resp.trx < self.trx)
      return;
    text = "";
    for (var i = 0, l = resp.payload.length; i < l; i++)
    {
      text += '<div class="header-search-suggestions-option" onclick="KL.Modules.search.select(this);">' + resp.payload[i] + '</div>';
    }
    WA.toDOM("header-search-suggestions-result").innerHTML = text;
    showsuggestion();
  }

  function search(event)
  {
    if (KL.device == "mobile")
    {
      // switch on/off barra
      if (!self.nodesearch)
        return;
      if (self.opened)
      {
        hidesearch();
      } else {
        showsearch();
      }
      return;
    }

    KL.Modules.stat.registerEvent('headsearch', 'head/search/go');
    var numc = self.node.value.trim().length;
    var word = self.node.value.trim();
    if (numc < 3)
      return;
    hidesuggestion();
    
    // window.location = "/buscar?q="+word;
    if(KL.rootsite == 'kiwirec')
      window.location = "/search?q="+word;
    else
      window.location = "/buscar?q="+word;

    // KL.loader.loadPage("/buscar?q="+word, null, true);
  }

  this.select = select;
  function select(node)
  {
    KL.Modules.stat.registerEvent('headsearch', 'head/search/gosuggest');
    var word = node.innerHTML;
    self.node.value = word;
    if (KL.device=="mobile")
    {
      // window.location = "/buscar?q="+word;
      if(KL.rootsite == 'kiwirec')
        window.location = "/search?q="+word;
      else
        window.location = "/buscar?q="+word;
      
      return;
    }
    search();
  }

  function clean(event)
  {
    KL.Modules.stat.registerEvent('headsearch', 'head/search/clean');
    if (KL.device == "mobile")
    {
      if (self.node.value.trim().length == 0)
      {
        hidesearch();
        return;
      }
      self.node.value = "";
      hidesuggestion();
      self.node.focus();
      return;
    }
    self.node.value = "";
    hidesuggestion();
  }

  // MENU:
  this.switchoff = switchoff;
  function switchoff(event)
  {
    hidesuggestion();
    hidesearch();
  }

  function start()
  {
    self.nodesearch = WA.toDOM("header-search");
    self.node = WA.toDOM("header-search-q");
    self.nodeclose = WA.toDOM("header-search-close");
    self.nodego = WA.toDOM("header-search-go");
    self.nodesugg = WA.toDOM("header-search-suggestions");
    if (self.node)
    {
      self.node.onkeyup=changeq;
    }
    if (self.nodeclose)
    {
      self.nodeclose.onclick=clean;
    }
    if (self.nodego)
    {
      self.nodego.onclick=search;
    }
  }
  KL.loader.addHookStart('search', start);
}

/* language, menu to change language */

KL.Modules.language = new function()
{
  var self = this;
  this.activated = false;
  this.node1 = null;
  this.node2 = null;
  this.nodemenu = null;
  this.opened = false;

  // MENU:
  function switchmenu(event)
  {
    if (!self.opened)
      return switchon(event);
    setTimeout(switchoff, 100);
    return WA.browser.cancelEvent(event);
  }

  function switchon(event)
  {
    KL.Modules.menu.switchoff();
    KL.Modules.search.switchoff();
    KL.Modules.client.switchoff();
    KL.Modules.stat.registerEvent('headlanguage', 'head/lang/open');
    self.opened = true;
    self.nodemenu.style.display = "block";
  }

  this.switchoff = switchoff;
  function switchoff(event)
  {
    if (!self.activated)
      return;
    KL.Modules.stat.registerEvent('headlanguage', 'head/lang/close');
    self.opened = false;
    self.nodemenu.style.display = "none";
  }

  function click(event)
  {
    if (KL.language == "es" && KL.pagedata.page.pathen)
    {
      KL.Modules.stat.registerEvent('headlanguage', 'head/lang/go-en');
      window.location = KL.pagedata.page.pathen;
    }
    if (KL.language == "en" && KL.pagedata.page.pathes)
    {
      window.location = KL.pagedata.page.pathes;
      KL.Modules.stat.registerEvent('headlanguage', 'head/lang/go-es');
    }
    return false;
  }

  function start()
  {
    self.node1 = WA.toDOM("header-language-button1");
    self.node2 = WA.toDOM("header-language-button2");
    self.nodemenu = WA.toDOM("header-language-menu");
    if (!self.node1 || !self.node2 || !self.nodemenu)
      return;
    self.activated = true;
    self.node1.onclick=switchmenu;
    self.node1.ontouchstart=switchmenu;
    self.node2.onclick=switchmenu;
    self.node2.ontouchstart=switchmenu;
    if (KL.language == "es")
    {
      var n = WA.toDOM("header-language-espanol");
      var m = WA.toDOM("header-language-ingles");
    } else {
      var n = WA.toDOM("header-language-ingles");
      var m = WA.toDOM("header-language-espanol");
    }
    n.className = "icon-k7-paloma on";
    m.parentNode.onclick = click;
  }

  KL.loader.addHookStart('language', start);
}

/* menu, main header menu */

KL.Modules.menu = new function()
{
  var self = this;
  this.node = null;
  this.nodemenu = null;
  this.nodemenupro = null;
  this.nodemenunormal = null;
  this.opened = false;
  this.closecandidate = false;
  this.closetimer = null;
  this.loaded = false;
  var fannode = null;
  var fannum = 0;
  var fanyear = 0;
  var fanmonth = 0;
  var fanday = 0;
  var fanhour = 0;
  var fanperday = 0;
  var fanstart = null;

  function switchmenu(event)
  {
    if (!self.opened)
      return switchon(event);
    switchoff();
    return WA.browser.cancelEvent(event);
  }

  function switchon(event)
  {
    self.closecandidate = false;
    if (self.closetimer)
    {
      clearTimeout(self.closetimer);
      self.closetimer = null;
    }
    if (self.opened)
      return;
    KL.Modules.language.switchoff();
    KL.Modules.search.switchoff();
    KL.Modules.client.switchoff();
    KL.Modules.stat.registerEvent('headmenu', 'head/menu/open');
    self.opened = true;
    if (KL.device == "mobile")
    {
      self.nodemenu.style.top = "46px";
      if((KL.Modules.client.clientpro) && (KL.rootsite == "kiwi"))
        self.node.className = "icon-k7-menu anim onpro";
      else
        self.node.className = "icon-k7-menu anim on";
    }
    else
    {
      self.nodemenu.style.top = "60px";
      if((KL.Modules.client.clientpro) && (KL.rootsite == "kiwi"))
        self.node.className = "icon-k7-menu anim onpro";
      else
        self.node.className = "icon-k7-menu anim on";
    }
    if (!self.loaded)
      load();
    return WA.browser.cancelEvent(event);
  }

  function tryswitchoff()
  {
    // TODO(phil) poner un timer
    self.closecandidate = true;
    self.closetimer = setTimeout(switchoff, 200);
  }

  this.switchoff = switchoff;
  function switchoff(event)
  {
    self.closecandidate = false;
    if (self.closetimer)
    {
      clearTimeout(self.closetimer);
      self.closetimer = null;
    }
    if (!self.opened)
      return;
    KL.Modules.stat.registerEvent('headmenu', 'head/menu/close');
    self.opened = false;
    if (KL.device == "mobile")
    {
      self.nodemenu.style.top = "-500px";
      self.node.className = "icon-k7-menu anim";
    }
    else
    {
      self.nodemenu.style.top = "-320px";
      self.node.className = "icon-k7-menu anim";
    }
    return WA.browser.cancelEvent(event);
  }

  function fancount() {
    fannode = WA.toDOM("header-menu-fans");
    if (!fannode)
      return;
    fannum = fannode.dataset.num;
    fanyear = fannode.dataset.year;
    fanmonth = fannode.dataset.month;
    fanday = fannode.dataset.day;
    fanhour = fannode.dataset.hour;
    fanperday = fannode.dataset.perday;
    fanstart = new Date();
    fanstart.setUTCFullYear(fanyear);
    fanstart.setUTCMonth(parseInt(fanmonth, 10)-1);
    fanstart.setUTCDate(fanday);
    fanstart.setUTCHours(fanhour);
    fanstart.setUTCMinutes(0);
    fanstart.setUTCSeconds(0);
    calcFans();
  }

  function calcFans() {
    var diffTime = Math.abs(new Date() - fanstart) / 1000 / 60 / 60 / 24;
    var newnum = Math.round(parseInt(fannum, 10) * 1.0 + diffTime * parseInt(fanperday, 10));
    fannode.innerHTML = newnum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

    // act each 1 sec
    setTimeout(function() { calcFans(); }, 1000);
  }

  function load()
  {
    var request = WA.Managers.ajax.createRequest('/data/menu', 'POST', null, loaded, true);
  }

  function loaded(request)
  {
    self.nodemenu.innerHTML = request.responseText;
    
    /* para mostrar opciones kiwipro en el menu */
    self.nodemenupro = WA.toDOM("menu-header-kiwipro");
    self.nodemenunormal = WA.toDOM("menu-header-normal");

    if ((KL.rootsite == "kiwi") || (KL.rootsite == "kiwirec")){
      if (KL.Modules.client.clientpro)
      {
        // console.log('chef es pro');
        self.nodemenupro.style.display = 'block';
        self.nodemenunormal.style.display = 'none';
      }
      else
      {
        // console.log('chef no es pro');
        self.nodemenunormal.style.display = 'block';
        self.nodemenupro.style.display = 'none';
      }
    }
    
    self.loaded = true;
    KL.loader.callHooksPostLoad();

    // start fans count
    fancount();
  }

  function start()
  {
    self.node = WA.toDOM("header-button-menu");
    self.nodemenu = WA.toDOM("header-menu");
    if (self.node)
    {
      self.node.onclick=switchmenu;
      self.node.ontouchstart=switchmenu;
      self.node.onmouseover=switchon;
      self.node.onmouseout=tryswitchoff;
    }
    if (self.nodemenu)
    {
      self.nodemenu.onmouseover=switchon;
      self.nodemenu.onmouseout=tryswitchoff;
    }
  }

//  this.container.style.transform = "translate("+this.position+"px,0)";
//  KL.Modules.general.adddraglistener('slider_' + this.node.id, {node: node, listener:listener});
  KL.loader.addHookStart('menu', start);
}

KL.Modules.wall = new function()
{
  var self = this;
  this.node = null;

  function load(wall){
    var request = WA.Managers.ajax.createRequest('/data/' + wall, 'POST', null, loaded, true);
  }

  function loaded(request){

    let auxnode = WA.toDOM("page_container");
    if (!self.node) {
      self.node = WA.createDomNode('div', 'wall', 'wall');
    }
    auxnode.appendChild(self.node);
    self.node.innerHTML = request.responseText;
  }

  this.removeWall = removeWall;
  function removeWall(){
    if (!WA.toDOM('wall'))
      return;
    
    //console.log('remueve wall');
    const wallElement = WA.toDOM('wall');
    //console.log(wallElement);
    
    const parentWall = wallElement.parentElement;
    //console.log(parentWall);
    parentWall.removeChild(wallElement);
  }

  function start(){

    if (!KL.pagedata.page || !KL.pagedata.page.wall) {
      return;
    }
    if (KL.pagedata.page.wall == 'register') {
      load('paywall-registro');
      KL.Modules.stat.registerEvent('wall', 'wall/register/show' + KL.pagedata.page.wallgroup);
//        ga('send', 'event', 'wall', 'wall/register', 'wall/reg/show7', null);
    } else if (KL.pagedata.page.wall == 'pay') {
      load('paywall-suscripcion');
      KL.Modules.stat.registerEvent('wall', 'wall/subscription/show' + KL.pagedata.page.wallgroup);
//        ga('send', 'event', 'wall', 'wall/subscription', 'wall/sub/show7', null);
    }
  }

  KL.loader.addHookStart('wall', start);
  KL.loader.addHookLoad('wall', start);
  //KL.loader.addHookPostLoad('wall', start);
}

KL.device="pc";
KL.language="es";

KL.pagedata={"client":{"client":null,"device":"pc","geo":"LMA","gep":"PE","ip":"161.132.118.202","locallanguage":"es","origin":"kiwi","pay":{"currency":"USD","name":"Dólares americanos","price":1.99,"rate":1,"symbol":"$"},"server":"api7","skin":"","t":1667959292},"page":{"adprefix":"kiwi_","crosslink":[{"cn":"D´Gari  ","i":"52038.jpg","k":39686,"m":1,"mt":"normal","n":"Borrachitos de Sabores","pa":"/receta/postres/dulces/borrachitos-de-sabores","pr":"100.0%","s":1,"t":"recetaslider","v":"","vh":"100.00%","vp":"","vr":"5.0","x":"p|kiwi|crosslink||1|0|1"},{"cn":"Adriana  Sánchez ","date":"2021-04-05T18:53:02Z","i":"2925.jpg","k":2925,"m":1,"ms":"Las recetas al mojo son un verdadero manjar que no te puedes perder, porque además de deliciosas, son sumamente fáciles de preparar. Por eso si eres fan de los platillos al mojo, hemos preparado una...","mt":"normal","n":"5 deliciosas recetas al mojo ","pa":"/tips/tips-de-cocina/tips-de-platillos/5-deliciosas-recetas-al-mojo","pr":"100.0%","s":1,"t":"tipslider","v":"","vh":"100.00%","vp":"","vr":"5.0","x":"p|kiwi|crosslink||1|0|2"},{"cn":"McCormick®  ","i":"52068.jpg","k":39698,"m":2,"mt":"normal","n":"Pasta Alfredo en Microondas","pa":"/receta/pastas/pasta-alfredo-en-microondas","pr":"100.0%","s":1,"t":"recetaslider","v":"372195151486603","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|crosslink||1|0|3"},{"c":2487,"cn":" ","d":"Disfruta de estos tamales mexicanos picositos en el desayuno, el almuerzo o la cena, pues estas 4 recetas de tamales caseros son ideales para cualquier hora del día. Anímate a hacer tamales en casa y consiénte con su sabor picante.","i":"2487.jpg","k":2487,"m":2,"mt":"normal","n":"Tamales mexicanos picositos","pa":"/compilacion/tamales-mexicanos-picositos","rt":"","s":1,"sh":1,"t":"compilacionrecetaslider","v":"357461932542732","vh":"100.00%","vp":"B1xDbuGM","x":"p|kiwi|crosslink||1|0|4"},{"cl":36,"cln":"Consejos de Belleza","cn":"Eloísa Carmona","i":"31114.jpg","ip":"/articuloimagen/31590/th5-320x320-31114.jpg","k":31590,"m":1,"ms":"\nLa gelatina es un postres sencillo, práctico, sabroso, es un básico de la infancia, pero también de la vida adulta porque su componente principal, la grenetina, tiene beneficios digestivos, para l...","mt":"normal","n":"Gelatina: ¿el postre que necesitas para tener cabello fuerte?","pa":"/blog/tips-y-consejos/consejos-de-belleza/gelatina-el-postre-que-necesitas-para-tener-cabello-fuerte","pr":"0.0%","s":"1","t":"articuloslider","vr":null,"x":"p|kiwi|crosslink||1|0|5"},{"cn":"Marilyn Beyda de Dana","date":"2014-02-15T10:00:00Z","i":"190.jpg","k":190,"m":2,"ms":"Esta deliciosa receta de jugo verde para quemar grasa te ayudará a perder esos kilitos de sobra.  Sigue esta receta, complementa con una dieta saludable y baja de peso hoy mismo.  Para mayores result...","mt":"normal","n":"Jugo Verde para quemar grasa","pa":"/tips/tips-de-salud/como-adelgazar/jugo-verde-para-quemar-grasa","pr":"95.1%","s":1,"t":"tipslider","v":"4855845731001","vh":"100.00%","vp":"B1xDbuGM","vr":"4.8","x":"p|kiwi|crosslink||1|0|6"},{"cn":"Brenda Villagomez","i":"52041.jpg","k":39687,"m":2,"mt":"normal","n":"¿Cómo limpiar pescado?","pa":"/receta/pescados-y-mariscos/pescados/como-limpiar-pescado","pr":"100.0%","s":1,"t":"recetaslider","v":"253690322219345","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|crosslink||1|0|7"},{"cn":"Jessica  Alcántara","date":"2019-01-22T10:22:09Z","i":"1825.jpg","k":1825,"m":2,"ms":"So Cute! No creerás lo fácil que es preparar estas Paletas de Cupcake hechas de Galleta con base de mantequilla y decoradas de una forma muy tierna.  Te decimos cómo hacer la masa para estas gallet...","mt":"normal","n":"Paletas de Cupcake hechas de Galleta ","pa":"/tips/tips-de-fiestas/pasteles-y-galletas/paletas-de-cupcake-hechas-de-galleta","pr":"0.0%","s":1,"t":"tipslider","v":"5992134704001","vh":"100.00%","vp":"B1xDbuGM","vr":"0.0","x":"p|kiwi|crosslink||1|0|8"},{"cn":"Eva  ","i":"52129.jpg","k":39726,"m":1,"mt":"normal","n":"Espinacas Cremosas con Pollo y Queso","pa":"/receta/guarniciones-de-exito/espinacas-cremosas-con-pollo-y-queso","pr":"100.0%","s":1,"t":"recetaslider","v":"","vh":"100.00%","vp":"","vr":"5.0","x":"p|kiwi|crosslink||1|0|9"},{"cn":"Bionda  Requesón","i":"52033.jpg","k":39683,"m":2,"mt":"normal","n":"Quesadillas Fritas de Requesón a la Mexicana ","pa":"/receta/platos-fuertes/mexicanos/quesadillas-fritas-de-requeson-a-la-mexicana","pr":"100.0%","s":1,"t":"recetaslider","v":"712068139242750","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|crosslink||1|0|10"}],"device":"pc","keywords":["login","bidmanager.js"],"language":"es","pathen":"https://us.kiwilimon.com","pathes":"https://www.kiwilimon.com","status":"OK","type":"sin-video","wallgroup":0}};
</script>


<script type="text/javascript">
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-11441155-1', 'auto');
ga('send', 'pageview');
</script>


<script async src="https://www.googletagmanager.com/gtag/js?id=G-X0MHE23QYB"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-X0MHE23QYB');
</script>


<script type="text/javascript">
var PREBID_TIMEOUT = 3000;
var FAILSAFE_TIMEOUT = 4000;
var pbjs = pbjs || {};
pbjs.que = pbjs.que || [];
</script>


<script type="text/javascript">
_atrk_opts = { atrk_acct:"M1xzt1Fx9f207i", domain:"kiwilimon.com", dynamic: true};
(function() { as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "//certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<noscript><img src="https://certify.alexametrics.com/atrk.gif?account=M1xzt1Fx9f207i" style="display:none" height="1" width="1" alt="" /></noscript>



<script type="text/javascript">
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
googletag.cmd.push(function() {
  googletag.pubads().disableInitialLoad();
});


pbjs.que.push(function() {
    pbjs.setConfig({
      priceGranularity: "dense",
      enableSendAllBids: true
    });
});

googletag.cmd.push(function() {
  googletag.pubads().collapseEmptyDivs(); // hide ad units when empty.
  googletag.enableServices();
});

heatmap_ext = {
  getTemplates: function(current_url) {
    return [
      // Basica
      { name: 'Basica', value: current_url.match(/\//i) },
      // Receta
      { name: 'Receta', value: current_url.match(/\/receta\//i) },
      // Clasificaciones
      { name: 'Clasificacion', value: current_url.match(/\/recetas|temporada|preferencia|ingrediente|tipo-de-coccion\//i) },
      // tips
      { name: 'Tips', value: current_url.match(/\/tips/i) },
      // blog
      { name: 'Blog', value: current_url.match(/\/blog/i) }
    ];
  }
};
(function(h,e,a,t,m,p) {
m=e.createElement(a);m.async=!0;m.src=t;
p=e.getElementsByTagName(a)[0];p.parentNode.insertBefore(m,p);
})(window,document,'script','https://u.heatmap.it/log.js');
</script>
<script id="Cookiebot" src="https://consent.cookiebot.com/uc.js" data-cbid="4879882a-8e97-4c8c-9eee-288323f00504" data-blockingmode="auto" type="text/javascript"></script>

<style>

/* http://meyerweb.com/eric/tools/css/reset/
   v2.0 | 20110126
   License: none (public domain)
*/

html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
b, u, i, center,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, embed,
figure, figcaption, footer, header, hgroup,
menu, nav, output, ruby, section, summary,
time, mark, audio, video {
  margin: 0;
  padding: 0;
  border: 0;
  font-size: 100%;
  font: inherit;
}

/* HTML5 display-role reset for older browsers */
article, aside, details, figcaption, figure, footer, header, hgroup, menu, nav, section {display: block;}
body {line-height: 1;}
ol, ul {list-style: none;}
blockquote, q {quotes: none;}
blockquote:before, blockquote:after,q:before, q:after {content: '';content: none;}
table {border-collapse: collapse;border-spacing: 0;}

p{line-height: 1.6em;}
img {height: auto;}

:root{
  --verde-kiwi: #8cc63e;
  --color-base-ficha: #8cc63e;
  --azul-kiwipro: #8eb4b1;
  --color-base-ficha-pro: #8eb4b1;
}

body {
  background:#f4f6f4;
  font-family:"Source Sans Pro", "times new roman";
  font-size:13px;
  line-height:1;
  color:#222222;
  position:relative;
  -webkit-font-smoothing:antialiased;
  margin:0;
  width:100%;
}

/* No queremos underline sobre los A en el sitio */
a, a:hover {
  text-decoration: none;
}

.breadcrumbs-link-activo, .feed-recetas-num, .feed-tip-num, .feed-ficha-tip-numrating, .icon-k7-estrellas-v, .icon-k7-estrellas-r, .recipelist-btn-next, .tiplist-btn-next, .feed-btn-vermas, .social-qualification-relleno, .css-color-link, .compilationlist-btn-next{
  /*color: #8cc63e;*/
  color: var(--verde-kiwi);
}

.home_top10pro .feed-recetas-num, .home_top10pro .icon-k7-estrellas-v, .home_top10pro .icon-k7-estrellas-r, .home-top10pro .feed-tip-num, .home-top10pro .icon-k7-estrellas-v, .home-top10pro .icon-k7-estrellas-r, .home-recipelist-pro .recipelist-btn-next, .familiarecetas-top10pro .feed-recetas-num, .familiarecetas-top10pro .icon-k7-estrellas-v, .familiarecetas-top10pro .icon-k7-estrellas-r, .familia-recipelist-pro .recipelist-btn-next, .clasificacionrecetas-top10pro .feed-recetas-num, .clasificacionrecetas-top10pro .icon-k7-estrellas-v, .clasificacionrecetas-top10pro .icon-k7-estrellas-r, .clasificacion-recipelistpro .recipelist-btn-next, .familiatips-top10pro .feed-tip-num, .familiatips-top10pro .feed-ficha-tip-numrating, .familiatips-top10pro .icon-k7-estrellas-v, .familiatips-top10pro .icon-k7-estrellas-r, .clasificaciontips-top10pro .feed-tip-num, .clasificaciontips-top10pro .icon-k7-estrellas-v, .clasificaciontips-top10pro .icon-k7-estrellas-r, .compilaciones-listapro .compilationlist-btn-next, .hometiplist-pro .tiplist-btn-next, .familia-tiplistpro .tiplist-btn-next, .clasificacion-tiplistpro .tiplist-btn-next{
  color: var(--azul-kiwipro);
}





/* para fichas festivas kiwi */
/* color numero rating */
/*
#home_top10 .recetaslider-ficha:nth-child(4n+1) .feed-recetas-num, #home_top10 .recetaslider-ficha:nth-child(4n+1) .icon-k7-estrellas-v, #home_top10 .recetaslider-ficha:nth-child(4n+1) .icon-k7-estrellas-r, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+1) .feed-recetas-num, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+1) .icon-k7-estrellas-v, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+1) .icon-k7-estrellas-r, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+1) .feed-recetas-num, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+1) .icon-k7-estrellas-v, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+1) .icon-k7-estrellas-r{
  color: #eb6f53;
}

#home_top10 .recetaslider-ficha:nth-child(4n+2) .feed-recetas-num, #home_top10 .recetaslider-ficha:nth-child(4n+2) .icon-k7-estrellas-v, #home_top10 .recetaslider-ficha:nth-child(4n+2) .icon-k7-estrellas-r, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+2) .feed-recetas-num, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+2) .icon-k7-estrellas-v, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+2) .icon-k7-estrellas-r, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+2) .feed-recetas-num, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+2) .icon-k7-estrellas-v, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+2) .icon-k7-estrellas-r{
  color: #f1c35e;
}

#home_top10 .recetaslider-ficha:nth-child(4n+3) .feed-recetas-num, #home_top10 .recetaslider-ficha:nth-child(4n+3) .icon-k7-estrellas-v, #home_top10 .recetaslider-ficha:nth-child(4n+3) .icon-k7-estrellas-r, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+3) .feed-recetas-num, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+3) .icon-k7-estrellas-v, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+3) .icon-k7-estrellas-r, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+3) .feed-recetas-num, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+3) .icon-k7-estrellas-v, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+3) .icon-k7-estrellas-r{
  color: #83b4b4;
}

#home_top10 .recetaslider-ficha:nth-child(4n+4) .feed-recetas-num, #home_top10 .recetaslider-ficha:nth-child(4n+4) .icon-k7-estrellas-v, #home_top10 .recetaslider-ficha:nth-child(4n+4) .icon-k7-estrellas-r, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+4) .feed-recetas-num, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+4) .icon-k7-estrellas-v, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+4) .icon-k7-estrellas-r, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+4) .feed-recetas-num, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+4) .icon-k7-estrellas-v, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+4) .icon-k7-estrellas-r{
  color: #9ad14f;
}

#home_top10 .recetaslider-ficha:nth-child(4n+1) .tools-favorites, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+1) .tools-favorites, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+1) .tools-favorites{
  background-color: #eb6f53;
}

#home_top10 .recetaslider-ficha:nth-child(4n+2) .tools-favorites, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+2) .tools-favorites, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+2) .tools-favorites{
  background-color: #f1c35e;
}

#home_top10 .recetaslider-ficha:nth-child(4n+3) .tools-favorites, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+3) .tools-favorites, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+3) .tools-favorites{
  background-color: #83b4b4;
}

#home_top10 .recetaslider-ficha:nth-child(4n+4) .tools-favorites, #familiarecetas_top10 .recetaslider-ficha:nth-child(4n+4) .tools-favorites, #clasificacionrecetas_top10 .recetaslider-ficha:nth-child(4n+4) .tools-favorites{
  background-color: #9ad14f;
}
*/
/* para fichas festivas kiwi */


.css-bgcolor-activado{
  background-color: var(--verde-kiwi);
}

.bgcolor-desactivado, .color-desactivado{
  background-color: #aaaaaa;
}

.css-bgimagen-activado{
  background-image: url('https://cdn7.kiwilimon.com/kiwi5/static/icono-usuario.svg');
}

@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: local('Source Sans Pro ExtraLight'), local('SourceSansPro-ExtraLight'), url('/fonts/source-sans-pro-200.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: local('Source Sans Pro ExtraLight'), local('SourceSansPro-ExtraLight'), url('/fonts/source-sans-pro-400.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: local('Source Sans Pro ExtraLight'), local('SourceSansPro-ExtraLight'), url('/fonts/source-sans-pro-700.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

@font-face {
  font-family: 'museo-sans';
  src: local('museo-sans-500'),
       url('/fonts/museo-sans-500.eot?#iefix') format('embedded-opentype'),
       url('/fonts/museo-sans-500.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'museo-sans-semibold';
  src: local('museo-sans-700'),
       url('/fonts/museo-sans-700.eot?#iefix') format('embedded-opentype'),
       url('/fonts/museo-sans-700.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'museo-sans-bold';
  src: local('museo-sans-900'),
       url('/fonts/museo-sans-900.eot?#iefix') format('embedded-opentype'),
       url('/fonts/museo-sans-900.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-bold';
  src: local('CrimsonPro-Bold'),
       url('/fonts/CrimsonPro-Bold.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-Bold.woff') format('woff'),
       url('/fonts/CrimsonPro-Bold.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-bolditalic';
  src: local('CrimsonPro-BoldItalic'),
       url('/fonts/CrimsonPro-BoldItalic.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-BoldItalic.woff') format('woff'),
       url('/fonts/CrimsonPro-BoldItalic.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-light';
  src: local('CrimsonPro-Light'),
       url('/fonts/CrimsonPro-Light.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-Light.woff') format('woff'),
       url('/fonts/CrimsonPro-Light.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-lightitalic';
  src: local('CrimsonPro-LightItalic'),
       url('/fonts/CrimsonPro-LightItalic.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-LightItalic.woff') format('woff'),
       url('/fonts/CrimsonPro-LightItalic.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-regular';
  src: local('CrimsonPro-Regular'),
       url('/fonts/CrimsonPro-Regular.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-Regular.woff') format('woff'),
       url('/fonts/CrimsonPro-Regular.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-italic';
  src: local('CrimsonPro-Italic'),
       url('/fonts/CrimsonPro-Italic.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-Italic.woff') format('woff'),
       url('/fonts/CrimsonPro-Italic.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-semibold';
  src: local('CrimsonPro-SemiBold'),
       url('/fonts/CrimsonPro-SemiBold.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-SemiBold.woff') format('woff'),
       url('/fonts/CrimsonPro-SemiBold.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'crimsonpro-semibolditalic';
  src: local('CrimsonPro-SemiBoldItalic'),
       url('/fonts/CrimsonPro-SemiBoldItalic.eot?#iefix') format('embedded-opentype'),
       url('/fonts/CrimsonPro-SemiBoldItalic.woff') format('woff'),
       url('/fonts/CrimsonPro-SemiBoldItalic.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'icomoon';
  src:  url('/fonts/icomoon.eot');
  src:  url('/fonts/icomoon.eot') format('embedded-opentype'),
    url('/fonts/icomoon.woff2') format('woff2'),
    url('/fonts/icomoon.ttf') format('truetype'),
    url('/fonts/icomoon.woff') format('woff'),
    url('/fonts/icomoon.svg') format('svg');
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}

.analyzethis {
  background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAEsCAMAAADaaRXwAAAAHWlUWHRDb21tZW50AAAAAABDcmVhdGVkIHdpdGggR0lNUGQuZQcAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAzUExURebn5/Pz8+jp6fz8/Onq6v3+/u/w8P////n5+ezt7evs7Pr7+/b29vT19e7v7/Hy8vf4+GkMZW8AAAXbSURBVHja7d2NdqMqFEBhQAH/9f2fdtrOWvd2pgMJgsk5yd4PMNP0i4hWwUQSleFXIA5kNCSlARBACBBACBBACBBACBBAAAGEAAGEAAGEAAGEAAGEACFAACFAACFAACFAACFACBBACBBACBBACBBACBACBBACBBACBBACBBAChAABhAABhAABhAABhAAhQAAhQAAxpudXCggggAACCCCAECCAECCAECCAAAIIIIAAQoAAQoAAQoAAAggggAACyLW5cbfr8NFiAXk6Rli6+H+APLdwxD8D5KkcXfy7CZCntf3kkPpE8zuA9EOMgAg6PHwERFA2JuoBeUZLyoNZljCPDhBJ41WMByCPb0x7xADI4+syID0gj788z3gMBhBRB0gA5OFNGQ+hc6zXBlkVHiAvDZIZsWYDyMPrMwfICMjj29IeqwFE0lW63AHrpUGSt7F8D8hzPpq6E8h7ggQDiCAQL9vj7UD8ZAARBHI4A4gcEL8ZA8jT2v/msM4AIuYImYNR0QuBuD8/xreb7/7Y1bwmoR5kCvYYvt3X9cNgw9cHGu1X++iMojSDuG1NXo0P62ZUphbE/Xi94OccNwDyKJDtpsbv8WuZAHnEwdHFuxtGQK6+vvCxKF0k6kC2Lha3OEAuqh/imfwGyCUFH092OEDan8yXeL5uAqT1cDXHmnwApO09Eh8rC4CI8tAhogWkhYcKESUgNzzmNYyfBTtrF9EBkvXowvcpbb9nrxxHQFrMd+ccR9G9Fd8D0uKHLHts2g1R5XO9WkBs+S2RVeWT70pA0m+mZZ56C1pPIwpA5hMePx8C0jJoyQexJ7/q6RtfFpCaGZY/+XtNT828A+R8y+k3/yeVh4h0kL5iaYxV4yEiHWSp+JafHu0ASf9Oq77kVuEhIhzEVn3H04dIAORcyRuFrs6TlRzOlXz3f7l+SgBIySn93p84+cTpDsiZfO3iSkHdmCUaZKu+Y+vUjVmiQZJXdlvB52NFuQfMsRrMmxdA2t02KVjActS2xp9kkK3FnY9YdyUDyD3DzVj0AXX94VAyyNDiy70quxKRDJI6p/uSf2RX9rCDZJAmi1KPypa2FgwyNpmx9squ1TWC2CbHGRu6lLa3AfGASJr1ZuZqgAgDYZe2whZAZIEMgAACCCCAAAIIIFyHXACyAqLkwrBsraUOkKtB2txc5G5vaaEJiOPvIa0ar/0D1QJIYVOTwabNcQZIbvQvOh03mhoAYjIvqE9FH5Dtu1t1tHgu17d4dAWQr/YG5+Ne2SRLNEiL53K1ndNlP/3e4OWORdetReEgDV5I03YKkQ2yV58ANmWXhcJB6l+iXdS9qC77pc+58pTs1I1YwkH2ynlWUDdiCQdxlQvwdvqW+RO+tMZSdYjoe0tdPMhYdYh0Che4lr5eVvLeYHf7vba9wZU+IHcfIjdfSesVLs6kYM3F4fT6u4PKdWLFg2SWUXbnBizZKynLX7c3vWr47M7cNImHAaTqWsSfEUlvcOEdIHVtsVxkSysK39JQw+4Ima0O5qnw/CF9cwQVILn9XPw/bjP2ircP0bGhS5/f8egvPpvbYMcB0mTum90TrFv/+wBuy+4G6uVv96lkl7Zwc4/uwdp1uLFHmwIPNfsY3hS5Z/NVDdvhqtnpM7yHxxvthTvr2C5a0W7RU9Vu0Vo2VFe1n/px3mM3BpALTiT+pYcrfSCmP3OQeGsMIFc1dqUeS28AuXTc6l6XQyXIB8m98y2/KuNQCvIxBV7uOL0fwRkDyKPa1tzQ5VVqqAb5/M/C+q8/fczHPhmtqQb5/T+Owdpl+Oywdh/1WrwIyIsFCCAECCAECCCAAAIIIIAAAgggBAggBAgggAACCCCAAAIIIAQIIPR8EAIEEAIEEAKEAAGEAAGEAAGEAAGEACFAACFAACFAACFAACFAAAEEEAIEEAIEEAIEEAIEEEAAIUAAIUAAIUAAIUAAIUAIEEAIEEAIEEAIEEAIEAIEEAIEEAIEEALkbUFIUoAI6xdEqwBEvrbq5gAAAABJRU5ErkJggg==') no-repeat;
  background-position: 50% 50%;
  background-size: cover;
}

[class^="icon-k7-"], [class*=" icon-k7-"] {
  /* use !important to prevent issues with browser extensions that change fonts */
  font-family: 'icomoon' !important;
  speak: none;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.icon-k7-menu:before {content: "\e953";}
.icon-k7-logo:before {content: "\e957";}
.icon-k7-logo-klpro:before {content: "\e964";}
.icon-k7-logo-txtpro:before {content: "\e963";}
.icon-k7-logo-kiwirecipes:before {content: "\e95c";}
.icon-k7-logo-kiwirecipes-kn:before {content: "\e95c";}
.icon-k7-language:before {content: "\e958";}
.icon-k7-langdown:before {content: "\e956";}
.icon-k7-close:before {content: "\e955";}
.icon-k7-search:before {content: "\e954";}
.icon-k7-notlogged:before {content: "\e903";}

.icon-k7-facebook:before {content: "\e94e";}
.icon-k7-twitter:before {content: "\e94d";}
.icon-k7-instagram:before {content: "\e94f";}
.icon-k7-youtube:before {content: "\e951";}
.icon-k7-pinterest:before {content: "\e94a";}
.icon-k7-whatsapp:before {content: "\e952";}
.icon-k7-mail:before {content: "\e920";}
.icon-k7-rss:before {content: "\e94c";}
.icon-k7-tiktok:before {content: "\e95e";}

.icon-k7-collections:before {content: "\e907";}
.icon-k7-favorites:before {content: "\e908";}
.icon-k7-myrecipes:before {content: "\e909";}
.icon-k7-shoppinglist:before {content: "\e90a";}
.icon-k7-uploadrecipe:before {content: "\e90b";}
.icon-k7-menuplanner:before {content: "\e90c";}
.icon-k7-padlock:before {content: "\e906";}

.icon-k7-activity:before {content: "\e90d";}
.icon-k7-followers:before {content: "\e90e";}
.icon-k7-profile:before {content: "\e90f";}
.icon-k7-payments:before {content: "\e910";}
.icon-k7-signout:before {content: "\e911";}

.icon-k7-estrellas-v:before{content: "\e918";}
.icon-k7-estrellas-r:before{content: "\e91e";}

.icon-k7-icon-haciaabajo:before{content: "\e956";}

.icon-k7-sube-receta-footer:before{content: "\e92f";}
.icon-k7-registrate:before{content: "\e932";}
.icon-k7-o-footer:before{content: "\e933";}

.icon-k7-galeria-flecha-izq:before{content: "\e948";}
.icon-k7-galeria-flecha-der:before{content: "\e947";}
.icon-k7-pausa-proceso:before{content: "\e901";}

.icon-k7-play:before{content: "\e923";}
.icon-k7-closevideo:before{content: "\e955";}

.icon-k7-editar-l:before{content: "\e91c";}

.icon-k7-breadcrumbs:before{content: "\e947";}

.icon-k7-check:before{content: "\e91d";}

.icon-k7-cerrar:before{content: "\e955";}

.icon-k7-kiwipro:before{content: "\e95d";}


@keyframes bounce
{
  0% { margin-top: 0; }
  4% { margin-top: -10px; }
  8% { margin-top: 0; }
  10% { margin-top: -5px; }
  12% { margin-top: 0; }
  14% { margin-top: -2px; }
  16% { margin-top: 0; }
  100% { margin-top: 0; }
}

.anim {
    transition: all 0.3s ease 0s;
}

.videoplay{
  border: 2px solid #ffffff;
  border-radius: 100%;
  opacity: 0.8;
  transform: translateX(-50%) translateY(-50%);
  position: absolute;
  top: 50%;
  left: 50%;
  height: 35px;
  width: 43px;
  text-align: center;
  font-size: 20px;
  color: #ffffff;
  padding-top: 13px;
  padding-left: 5px;
}

.videoplay:hover{
  opacity: 1;
}

.wall{
  position: fixed;
  left: 0px;
  top: 0px;
  bottom: 0px;
  right: 0px;
  background-color: rgba(0, 0, 0, 0.75);
  z-index: 50000;
}

#backgroundpopup {
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  background-color: black;
  opacity: 0.75;
  z-index: 50000;
}

#popup {
  position: fixed;
  left: 50%;
  top: 50%;
  width: auto;
  height: auto;
  background-color: white;
  border-radius: 5px;
  border: 1px solid #ccc;
  z-index: 50001;
  padding: 5px;
}

#popup .title {
  height: 20px;
  background-color: #f2f2f2;
  color: var(--verde-kiwi);
  font-size: 1.5em;
  padding: 10px;
  border-radius: 5px 5px 0px 0px;
  margin-bottom: 5px;
  text-transform: uppercase;
}

#popup .button {
  border: 1px solid #ccc;
  border-radius: 2px;
  color: white;
  background-color: var(--verde-kiwi);
  cursor: pointer;
  font-size: 1.2em;
  padding-top: 10px;
  text-align: center;
}

#header-modal em{
  margin: 0px 0px 0px 10px;
}

.modal-1 {
  background-color: #72c096;
}

.modal-2 {
  background-color: #f46a58;
}

.modal-3 {
  background-color:#6ca61e;
}

.modal-buttonok, .modal-buttonconfirma {
  border: 2px solid #ffffff;
  border-radius: 6px;
  box-sizing: border-box;
  cursor: pointer;
  margin: 0px 0px 0px 10px;
  padding: 5px 10px;
}

.modal-buttonok:hover {
  background-color: #ffffff;
  color: #f46a58;
}

.modal-buttonconfirma:hover {
  background-color: #ffffff;
  color: #6ca61e;
}
body {
  min-width:1280px;
}

/* HEADER - Menu principal izquierda */
#header-button-menu.on, #header-client-button.on {
  background-color: #addb45;
}

#header-button-menu.onpro, #header-client-button.onpro {
  background-color: #9fc7c4;
}

/* HEADER - search */
.header-search-suggestions-option {
  padding: 5px;
  cursor: pointer;
}

.header-search-suggestions-option:hover {
  background-color: #8cc63e;
  color: white;
}

/* HEADER - Languge */
.icon-k7-paloma:before {content: "\e91d";}

#header-language-menu div {
  color: #333;
  cursor: pointer;
}

#header-language-menu div span {
 display: inline-block;
 border: 1px solid #999;
 width: 11px;
 height: 11px;
 border-radius: 100%;
 vertical-align: middle;
}

#header-language-menu div span.on {
  border: 0;
  width: 13px;
  height: 13px;
  background-color: #8cc63e;
  color: #fff;
  font-size: 12px;
}

.videoplay{
  border: 3px solid #ffffff;
  font-size: 29px;
  height: 47px;
  width: 63px;
  padding-top: 16px;
}

/* estilos reproductor player video */
.player-divcontenedor-scroll-up{
  position: fixed;
  /* left: 50%; */
  left: calc(100% - 360px);
  width: 50%;
  /* top: 60px; */
  top: 111px;
  height: 200px;
  z-index: 1000;
}

.player-divcontenedor-scroll-down{
  position: fixed;
  /* left: 50%; */
  left: calc(100% - 360px);
  width: 50%;
  bottom: 0px;
  height: 200px;
  z-index: 1000;
}

.player-divcontenedor-noscroll{
  position: absolute;
  left: 0px;
  width: 100%;
  top: 0px;
  bottom: 0px;
  z-index: 10;
}

.player-divcontenedor-scroll-up .player-divcontenedor-video, .player-divcontenedor-scroll-up .player-divcontenedor-video{
  width: 360px !important;
  height: 360px !important;
}
/* fin estilos reproductor player video */

/* estilos crosslink */
#footer-crosslink .recetaslider-ficha, #footer-crosslink .tipslider-ficha, #footer-crosslink .compilacionrecetaslider-ficha, #footer-crosslink .articuloslider-ficha{
  height: auto;
}

/* area nombre ficha */
#footer-crosslink .recetaslider-areanombreficha, #footer-crosslink .tipslider-areanombreficha, #footer-crosslink .compilacionrecetaslider-areanombreficha, #footer-crosslink .articuloslider-areanombreficha{
  height: 42px; 
}

#footer-crosslink .recetasliderpro-areanombreficha, #footer-crosslink .articulosliderpro-areanombreficha{
  height: 42px; 
  display: flex;
  align-items: center;
}

#footer-crosslink .recetaslider-icon-pro, #footer-crosslink .articulosliderpro-icon-pro{
  margin: 0px 0px 0px 10px;
  width: 20px;
  height: 20px;
  font-size: 13px;
}

/* nombre de ficha */
#footer-crosslink .recetaslider-nombreficha, #footer-crosslink .tipslider-nombreficha, #footer-crosslink .compilacionrecetaslider-nombreficha, #footer-crosslink .articuloslider-nombreficha{
  color: #989898;
  font-size: 12px;
  font-weight: normal;
  letter-spacing: 1px;
  max-height: 28px;
}

#footer-crosslink .recetasliderpro-nombreficha, #footer-crosslink .articulosliderpro-nombreficha{
  font-size: 13px;
  max-height: 28px;
  width: calc(100% - 30px);
}

#footer-crosslink .tipsliderpro-nombreficha{
  height: inherit;
}

#footer-crosslink .tipsliderpro-nombreficha .tipsliderpro-icon{
  margin: 0px 0px 0px 10px !important;
  width: 20px !important;
  height: 20px !important;
  font-size: 13px !important;
}

#footer-crosslink .tipsliderpro-nombreficha .tipsliderpro-nombreficha-centrado{
  width: calc(100% - 40px) !important;
  font-size: 13px !important;
  max-height: 28px !important;
}

/* rating */
#footer-crosslink .recetaslider-rating, #footer-crosslink .tipslider-rating{
  display: none;
}

#footer-crosslink .tipslider-rating .tipslider-rating-numero{
  color: #8cc63e;
}
/* fin estilos crosslink */
</style>
  </head>
  <body onload="KL.onLoad();" onscroll="KL.paint();" onresize="KL.paint();" class="user-pending" id="body">
<div style="position: fixed; bottom: 0px; z-index: 2000; left: 50%; transform: translateX(-50%);">
  <div id="footer-adbannersticky" style="max-width: 1280px; margin: 20px auto 0px; position: -webkit-sticky; position: sticky; bottom: 0px; top: calc(100% - 90px); z-index: 390; display: flex; justify-content: center; clear: both;">
    <div id="footer-remueve-sticky" onclick="KL.Modules.ads.removeStickyStyle();" style="position: absolute; top: 0px; right: 50%; background-color: #dddddd; border-radius: 100%; border: 3px solid #ffffff; padding: 5px; box-sizing: border-box; transform: translateX(376px) translateY(-12px); cursor: pointer;">
      <div class="icon-k7-cerrar" style="color: #ffffff; font-size: 8px; font-weight: bold;"></div>
    </div>
    <div class="buildad" data-id="sticky_web" data-position="sticky"></div>
  </div>
</div>

<div class="buildad" data-id="oop" style="height: 0px;"></div>
<div class="buildad" data-id="1x1" style="height: 0px;"></div>

<div id="header" style="color: white; min-width: 1200px; position: fixed; top: 0; left: 0; right: 0; height: 60px; z-index: 400; background-color: var(--verde-kiwi); box-shadow: 0 0 4px rgba(0, 0, 0, 0.4);">
  <div id="header-loading" class="anim" style="background-color: red; position: absolute; top: 0; left: 0; height: 2px; width: 0;"></div>

  <div id="header-button-menu" class="icon-k7-menu" style="font-size:21px; color: white; position: relative; height: 41px; width: 40px; padding-top: 19px; padding-left: 25px; float: left;"></div>

  <div class="header-div-logo" style="padding-top: 16px; padding-left: 10px; width: 155px; height: 32px; position: relative; float: left;" onclick="KL.loader.loadPage('/');">
    <div id="header-div-logo-normal" class="icon-k7-logo" style="display: none; cursor: pointer; font-size:29px; color: white;" onclick="KL.loader.loadPage('/');">
      <a href="/pro"><div id="header-icono-kiwipro" class="icon-k7-kiwipro" alt="Ir a KiwiPro" title="Ir a KiwiPro" style="display: none; position: absolute; top: 9px; right: -23px; color: #ffffff; font-size: 30px;"></div></a>
    </div>
    
    <div id="header-div-logo-pro" style="display: none; cursor: pointer; width: 100%; height: 100%; position: relative;" onclick="KL.loader.loadPage('/');">
      <div id="header-icono-klpro" class="icon-k7-logo-klpro" alt="" title="" style="position: absolute; top: -7px; left: -5px; color: #ffffff; font-size: 40px;"></div>
      <div id="header-icono-kltxtpro" class="icon-k7-logo-txtpro" style="position: absolute; top: -6px; left: 97px; color: #6d938d; font-size: 45px;"></div>
    </div>
  </div>



  <div class="icon-k7-language" style="font-size:21px; color: white; margin-left: 85px; padding-top: 20px; padding-left: 10px; width: 35px; height: 32px; position: relative; float: left;"></div>
  <a href="https://www.kiwilimonrecipes.com/" target="_blank" style="cursor: pointer; font-size:18px; font-weight:bold; color: white; float: left; padding-top: 21px; text-transform: uppercase;">EN</a>
  
  

  <div id="header-client" style="float: right;"></div>

  <div id="header-search" style="/*margin-right: 345px;*/ /*margin-right: 504px;*/ margin-right: 530px; height: 60px; margin-left: 436px; padding-top: 10px; position: relative; width: auto;">
    <div id="header-search-go" class="icon-k7-search" style="cursor: pointer; padding: 8px; color: white; font-size: 21px; float: right; height: 20px; width: 22px; background-color: #a8e05c;"></div>
    <div id="header-search-close" class="icon-k7-close" style="cursor: pointer; padding: 8px; padding-top: 14px; color: #aaa; font-size: 10px; position: absolute; right: 38px; width: 12px; height: 22px;"></div>
    <form method="GET" action="/buscar">
    <input type="text" id="header-search-q" name="q" placeholder="Busca una receta, ingrediente, palabra clave..." style="padding: 6px; padding-left: 12px; height: 24px; border: 0; width: calc(100% - 56px);" autocomplete="off" />
    </form>
    <div id="header-search-suggestions" style="display: none; color: #6a6a6a; position: relative; width: calc(100% - 22px); background-color: white; padding: 10px; font-size: 16px; border: 1px solid #aaa;">
      <div style="font-style: italic; color: #b0b0b0; padding-bottom: 5px;">Sugerencias</div><div id="header-search-suggestions-result"></div>
    </div>
  </div>
</div>
<div id="header-menu" class="anim" style="color: black; position: fixed; z-index: 398; top: -320px; left: 0; /*right: 0;*/ height: 320px; /*min-width: 1200px;*/ min-width: 1100px; box-shadow: rgba(0, 0, 0, 0.6) 0 10px 12px -7px; background-color: #f3f5f4;"></div>
<div id="header-client-menu" class="anim" style="color: black; position: fixed; z-index: 398; top: -400px; width: 300px; right: 0; min-height: 400px; box-shadow: rgba(0, 0, 0, 0.6) -10px 10px 12px -7px; background-color: #f3f5f4;"></div>
<div id="header-language-menu" class="anim" style="display: none; color: black; position: fixed; z-index: 401; top: 55px; left: 280px; width: 100px; height: 50px; box-shadow: rgba(0, 0, 0, 0.6) 0 10px 12px -7px; background-color: #fff; padding: 10px 20px; border-radius: 5px; font-size: 15px;">

  <div style="position: absolute; right: 13px; top: -11px; width: 0; height: 0; border-style: solid; border-width: 0 10px 11px 10px; border-color: transparent transparent #ffffff transparent;"></div>

  <div style="margin-top: 5px; display: block;"><span id="header-language-espanol"></span>&nbsp;&nbsp;ES - Español</div>
  <div style="margin-top: 10px; display: block;"><span id="header-language-ingles"></span>&nbsp;&nbsp;EN - English</div>

</div>
<div id="header-modal" class="anim" style="align-items: center; box-sizing: border-box; color: #ffffff; display: flex; font-size: 17px; font-weight: bold; min-height: 60px; justify-content: center; left: 0; letter-spacing: 1px; margin: 0px auto; max-width: 1280px; min-height: 60px; min-width: 1200px; padding: 10px; position: fixed; right: 0; text-transform: uppercase; top: -10px; z-index: 398;"></div>

<div style="height: 60px;"></div>









<div id="page_container" style="max-width: 1280px; clear: both; margin: 0 auto 0; overflow: hidden; min-height: 600px;">
</div>
<div id="scripts_container"><script>
WA.templates['client_notconnected'] = WA.templater`
<div id="header-client-button" style="float:right; height: 50px; width: 40px; padding-top: 10px; padding-right: 25px; padding-left: 20px; cursor: pointer;">
  <div class="icon-k7-notlogged" style="text-align: center; padding-top: 10px; width: 40px; height: 32px; color: var(--verde-kiwi); font-size: 22px; background-color: white; border-radius: 50%;">
    <div id="notif-salta" style="animation: bounce 5s infinite; color: white; background-color: #d85c45; border-radius: 8px 8px 8px 0; font-size: 10px; height: 15px; padding-top: 2px; position: absolute; text-align: center; width: 15px; right: 15px; top: 5px;">1</div>
  </div>
</div>

<div style="float:right; font-size: 17px; margin-top: 22px; padding: 0px 2px 0px 10px;">
  <a href="/login" style="color: white; text-decoration: none;">CONÉCTATE</a>
</div>

<a id="header-urliconpro" href="/pro/suscripcion-kiwipro" style="text-decoration: none; float: right; box-sizing: border-box; font-size: 17px; margin: 9px 50px 0px; background-color: #8eb4b1; border: 1px solid #ffffff; border-radius: 3px; position: relative; padding: 2px 10px 4px 15px; display: flex; align-items: center; width: -webkit-fit-content; width: -moz-fit-content; width: -o-fit-content; width: -ms-fit-content; width: fit-content;">
  <p style="line-height: 14px; margin: 5px 10px 0px 0px; font-family: 'museo-sans'; font-size: 13px; letter-spacing: 0.5px; color: #fffdfd; text-transform: uppercase;">
    Suscríbete a
  </p>
  <div class="home-secc-pro-mini" style="display: flex; align-items: center; cursor: pointer; position: relative; margin: 5px 0px 0px;">
    <div class="home-secc-icono-klpro icon-k7-logo-klpro" alt="" title="" style="top: -3px; color: #ffffff; font-size: 24px; position: relative;"></div>
    <div class="home-secc-icono-kltxtpro icon-k7-logo-txtpro" style="top: 0px; color: #6d938d; font-size: 29px; position: relative; left: -3px;"></div>
  </div>
</a>
`;
WA.templates['client_connected'] = WA.templater`
<div id="header-client-button" style="float:right; height: 50px; width: 40px; padding-top: 10px; padding-right: 25px; padding-left: 20px; cursor: pointer;"><div style="text-align: center; padding-top: 10px; width: 40px; height: 32px; color: var(--verde-kiwi); font-size: 22px; background-image: url('${'client>i'}'); background-position: center center; background-repeat: no-repeat; background-size: cover;border-radius: 50%; background-color: white;"><div id="notif-salta" style="display: none; animation: bounce 5s infinite; color: white; background-color: #d85c45; border-radius: 8px 8px 8px 0; font-size: 10px; height: 15px; padding-top: 2px; position: absolute; text-align: center; width: 15px; right: 15px; top: 5px;"></div></div></div>
<div style="float:right; font-size: 17px; margin-top: 20px; padding-right: 10px;">${'client>n'}</div>

<a id="header-urliconpro" href="/pro/suscripcion-kiwipro" style="display: none; text-decoration: none; float: right; box-sizing: border-box; font-size: 17px; margin: 9px 50px 0px; background-color: #8eb4b1; border: 1px solid #ffffff; border-radius: 3px; position: relative; padding: 2px 10px 4px 15px; align-items: center; width: -webkit-fit-content; width: -moz-fit-content; width: -o-fit-content; width: -ms-fit-content; width: fit-content;">
  <p style="line-height: 14px; margin: 5px 10px 0px 0px; font-family: 'museo-sans'; font-size: 13px; letter-spacing: 0.5px; color: #fffdfd; text-transform: uppercase;">
    Suscríbete a
  </p>
  <div class="home-secc-pro-mini" style="display: flex; align-items: center; cursor: pointer; position: relative; margin: 5px 0px 0px;">
    <div class="home-secc-icono-klpro icon-k7-logo-klpro" alt="" title="" style="top: -3px; color: #ffffff; font-size: 24px; position: relative;"></div>
    <div class="home-secc-icono-kltxtpro icon-k7-logo-txtpro" style="top: 0px; color: #6d938d; font-size: 29px; position: relative; left: -3px;"></div>
  </div>
</a>
`;
KL.Modules.gallery = new function()
{
  var self = this;
  var galleries = {};
  var counter = 1;

  function load()
  {
    var galleryNodes = document.getElementsByClassName('gallery');
    if (galleryNodes)
    {
      for (var i = 0; i < galleryNodes.length; i++)
      {
        id = galleryNodes[i].id;
        if (!id)
        {
          galleryNodes[i].id = id = "gallery" + counter++;
        }
        galleries[id] = new KL.Modules.onegallery(galleryNodes[i])
      }
    }
  }

  function unload()
  {
    for (var i = 0; i < galleries.length; i++)
      galleries[i].destroy();
    galleries = {};
  }

  KL.loader.addHookLoad('gallery', load);
  KL.loader.addHookPostLoad('gallery', load);
  KL.loader.addHookUnload('gallery', unload);
}

KL.Modules.onegallery = function(node)
{
  var self = this;
  var actual = null;
  var animation = '';
  var gallerynode = node;
  var containernode = null;
  var previousnode = null;
  var nextnode = null;
  var playing = false;
  var playnode = null;
  var withBullets = false;
  var bulletsnode = null;
  var timer = null;
  var timing = null;

  function clickplay(event, noevent)
  {
    if (playing)
    {  // para todo
      clearTimeout(timer);
      timer = null;
      playing = false;
      playnode.firstElementChild.className = 'icon-k7-gallery-pause';
      KL.Modules.stat.registerEvent('gallery', 'gallery/pause');
    }
    else
    {  // lanza
      timer = setTimeout( function() { play(); }, timing);
      playing = true;
      playnode.firstElementChild.className = 'icon-k7-gallery-play';
      if (!noevent)
        KL.Modules.stat.registerEvent('gallery', 'gallery/play');
    }
  }

  function clicknext(clave)
  {
    if (timer)
    {
      clearTimeout(timer);
      timer = setTimeout( function() { play(); }, timing); // todo: timing
    }
    continuousnext(clave);
  }

  function continuousnext(clave)
  {
    if (actual.nextElementSibling)
    {
      setNodeClasses(actual, actual.nextElementSibling);
      actual = actual.nextElementSibling;
    }
    else
    {
      var firstnode = containernode.childNodes[0];
      setNodeClasses(actual, firstnode);
      actual = firstnode;
    }
    updateBullets();
  }

  function clickprevious(clave)
  {
    if (timer)
    {
      clearTimeout(timer);
      timer = setTimeout( function() { play(); }, timing); // todo: timing
    }
    continuousprevious(clave);
  }

  function continuousprevious(clave)
  {
    if (actual.previousElementSibling)
    {
      setNodeClasses(actual, actual.previousElementSibling);
      actual = actual.previousElementSibling;
    }
    else
    {
      var lastindex = containernode.childNodes.length - 1;
      var lastnode = containernode.childNodes[lastindex];

      setNodeClasses(actual, lastnode);
      actual = lastnode;
    }
    updateBullets();
  }

  // onlick bullet, this is the bullet
  function gotoslide(event)
  {
    if (timer)
    {
      clearTimeout(timer);
      timer = setTimeout(play, timing);
    }

    if (this.linked != actual)
    {
      var nextone = this.linked;
      setNodeClasses(actual, nextone);
      actual = this.linked;
      updateBullets();
    }
    KL.Modules.stat.registerEvent('gallery', 'gallery/gotoslide');
  }

  function updateBullets()
  {
    if (!withBullets)
      return;

    for (i = 0, l = bulletsnode.childNodes.length; i < l; i++)
    {
      if (bulletsnode.childNodes[i].linked == actual)
        bulletsnode.childNodes[i].className = 'gallery-bullet on';
      else
        bulletsnode.childNodes[i].className = 'gallery-bullet';
    }
  }

  //current y next son los ids de los nodos
  function setNodeClasses(current, next)
  {
    var lastId = containernode.lastElementChild;
    var firstId = containernode.firstElementChild;
    var before = true;

    for (var i=0, l=containernode.childNodes.length; i<l; i++)
    {
      var node = containernode.childNodes[i];
      if (node == current)
      {
        var transition = '';

        if ((next !== firstId) && (next !== lastId))
          transition = (before?' before':' after');
        else
        {
          if (node === firstId)
            transition = ' after';
          else if (node === lastId)
            transition = ' before';
          else
            transition = (before?' before':' after');
        }
        containernode.childNodes[i].className = 'gallery-slide ' + animation + transition + ' anim';
      }
      else if (containernode.childNodes[i] == next)
      {
        containernode.childNodes[i].className = 'gallery-slide ' + animation + ' anim';
        gallerynode.dataset.current = containernode.childNodes[i].id;
        before = false;
      }
      else
      {
        var transition = '';

        if (node === firstId && (next === lastId))
          transition = ' after';
        else if ((node === lastId) && (next === firstId))
          transition = ' before';
        else if (node === lastId)
          transition = ' after';
        else
          transition = (before?' before':' after');

        containernode.childNodes[i].className = 'gallery-slide ' + animation + transition + '';
      }
    }
  }

  function draglistener(orden)
  {
    // replantear cuando haya mas de un slider principal...
    if (orden == 'izquierda')
    {
      KL.Modules.stat.registerEvent('gallery', 'gallery/dnext');
      clicknext();
    }
    if (orden == 'derecha')
    {
      KL.Modules.stat.registerEvent('gallery', 'gallery/dprevious');
      clickprevious();
    }
  }

  function play()
  {
    if (timer)
      clearTimeout(timer);
    timer = setTimeout(function() { play(); }, timing);

    continuousnext();
  }

  this.destroy = destroy;
  function destroy()
  {
    if (timer)
      clearTimeout(timer)
    timer = null;
    actual = null;
    gallerynode = null;
    containernode = null;
    previousnode = null;
    nextnode = null;
    playnode = null;
    bulletsnode = null;
    self = null;
  }

  // Note: only 1 gallery per page
  if (gallerynode.dataset.scanned)
    return;
  gallerynode.dataset.scanned = true;

  if (!gallerynode.firstElementChild)
    return;

  if (gallerynode.dataset.ratio)
    gallerynode.style.height = (WA.browser.getNodeWidth(gallerynode) / gallerynode.dataset.ratio) + "px";

  containernode = WA.createDomNode('div', gallerynode.id+'_container', 'gallery-container');
  while (gallerynode.hasChildNodes())
  {
    // Solo queremos nodos div
    if (gallerynode.firstChild.nodeType == 1)
    {
      gallerynode.firstChild.className = 'gallery-slide off';
      containernode.appendChild(gallerynode.firstChild);
    }
    else
      gallerynode.removeChild(gallerynode.firstChild);
  }
  containernode.firstChild.style.display = 'block';
  gallerynode.appendChild(containernode);
  actual = containernode.firstChild;

  // 3. boton left
  previousnode = WA.createDomNode('div', null, 'gallery-button left');
  gallerynode.appendChild(previousnode);
  previousnode.onclick = function() {
    KL.Modules.stat.registerEvent('gallery', 'gallery/previous');
    clickprevious();
  };
  n = WA.createDomNode('div', null, 'icon-k7-gallery-previous');
  previousnode.appendChild(n);

  // 4. boton right
  nextnode = WA.createDomNode('div', null, 'gallery-button right');
  gallerynode.appendChild(nextnode);
  nextnode.onclick = function() {
    KL.Modules.stat.registerEvent('gallery', 'gallery/next');
    clicknext();
  };
  n = WA.createDomNode('div', null, 'icon-k7-gallery-next');
  nextnode.appendChild(n);

  // 5. pause on/off
  playnode = WA.createDomNode('div', null, 'gallery-player');
  gallerynode.appendChild(playnode);
  playnode.onclick = clickplay;
  n = WA.createDomNode('div', null, 'icon-k7-gallery-pause');
  playnode.appendChild(n);

  if (gallerynode.dataset.animation)
    animation = gallerynode.dataset.animation;
  if (gallerynode.dataset.time)
  {
    var auxTime = gallerynode.dataset.time;
    timing = ((!isNaN(auxTime) && (auxTime > 0 && auxTime <= 99999)) ? auxTime: 5000);
  }

  if (gallerynode.dataset.bullets == 'yes')
  {
    withBullets = true;
    bulletsnode = WA.createDomNode('div', null, 'gallery-bullets');
    gallerynode.appendChild(bulletsnode);

    for (var i=0, l=containernode.childNodes.length; i<l; i++)
    {
      var auxNode = containernode.childNodes[i];
      var bNode = auxNode.getElementsByClassName('gallery-bullet');
      if (bNode)
      {
        for (var j = 0; j < bNode.length; j++)
        {
          bNode[j].linked = auxNode;
          bNode[j].onclick = gotoslide;
          bulletsnode.appendChild(bNode[j]);
        }
      }
    }
  }
  setNodeClasses(null, actual);
  updateBullets();

  if (gallerynode.dataset.autostart == 'yes' && !timer)
  {
    clickplay(null, true);
  }

  KL.Modules.movements.adddraglistener('gallery_' + gallerynode.id, {node: containernode, listener:draglistener});
}

KL.Modules.tools = new function()
{
  var self = this;
  var tools = {};
  var counter = 1;

  function load()
  {
    var toolsNodes = document.getElementsByClassName('tools');
    if (toolsNodes)
    {
      for (var i = 0; i < toolsNodes.length; i++)
      {
        id = toolsNodes[i].id;
        if (!id)
        {
          toolsNodes[i].id = id = "tools" + counter++;
        }
        // ONLY if not scanned yet

        tools[id] = new KL.Modules.onetoolset(toolsNodes[i]);
      }
    }
  }

  function unload()
  {
    for (var i = 0; i < tools.length; i++)
      tools[i].destroy();
    tools = {};
  }

  KL.loader.addHookLoad('tools', load);
  KL.loader.addHookPostLoad('tools', load);
  KL.loader.addHookUnload('tools', unload);
}

KL.Modules.onetoolset = function(node)
{
  var self = this;
  var containernode = node;
  var toolsshadow = null;
  var toolsnode = null;
  var type = '';
  var key = '';
  var buttons = [];
  var opened = false;

  function open()
  {
    toolsshadow.style.display = 'block';
    pos = 0;
    for (var i = 0, l = buttons.length; i < l; i++)
    {
      buttons[i].style.top = pos + 'px';
      pos += 40;
    }
    opened = true;
  }

  function close()
  {
    toolsshadow.style.display = 'none';
    for (var i = 0, l = buttons.length; i < l; i++)
    {
      buttons[i].style.top = '0px';
    }
    opened = false;
  }

  function clickclose(event)
  {
    close();
    WA.browser.cancelEvent(event);
  }

  function clickfav(event)
  {
    if (!KL.Modules.client.clientlogged)
    {
      KL.Modules.stat.registerEvent('tools', 'tools/gologin');
//      console.log(document.location.pathname);
      KL.loader.loadPage("/login?p="+document.location.pathname+"&o=/fav/"+type+"/"+key);
      return;
    }

    if (!opened)
    {
      open();
      WA.browser.cancelEvent(event);
      return;
    }

    WA.Managers.ajax.createPromiseRequest({ url: KL.graphdomains + '/v6/collection', method: 'post', send: false})
      .then(function(request) {
        request.addParameter('language', KL.language);
        request.addParameter('device', KL.device);
        request.addParameter('service', 'favorite');
        request.addParameter('type', type);
        request.addParameter('key', key);
        return request.send();
      })
      .then(function(response){
        var code = JSON.parse(response);
        if (code.status == 'ok')
        {
          KL.Modules.stat.registerEvent('tools', 'tools/addfav');
          KL.Modules.modal.notifica(KL.i18n.tools_favoritos_ok1+' <em>'+KL.i18n.tools_favoritos_ok2+'</em>');
        }
        else
        {
          KL.Modules.stat.registerEvent('tools', 'tools/errorfav');
          KL.Modules.modal.alerta(code.message);
        }
      })
      .catch(function(code, err) {
        if (code == 401)  // not connected
        {
          KL.Modules.stat.registerEvent('tools', 'tools/gologin');
          KL.loader.loadPage("/login/fav/"+type+"/"+key);
          return;
        }
        // print error modal, send to server error
        KL.Modules.modal.alerta(code, err);
        console.log("Error sending fav:", code, err);
      });
    return WA.browser.cancelEvent(event);
  }

  function clickcollections(event)
  {
    if (!KL.Modules.client.clientlogged)
    {
      KL.Modules.stat.registerEvent('tools', 'tools/gologin');
      KL.loader.loadPage("/login/col/"+type+"/"+key);
      return;
    }

    WA.Managers.ajax.createPromiseRequest({ url: KL.graphdomains + '/v6/collection', method: 'post', send: false})
      .then(function(request) {
        request.addParameter('language', KL.language);
        request.addParameter('device', KL.device);
        request.addParameter('service', 'list');
        return request.send();
      })
      .then(function(response){
        var code = JSON.parse(response);
        KL.Modules.stat.registerEvent('tools', 'tools/opencol');
        data = WA.templates.tools_collectionselect({items:code.payload});
        KL.Modules.modal.buildpopup(data);

        // link clicks
        for (var i = 0, l = code.payload.length; i < l; i++)
        {
          var n = WA.toDOM("tools-collection-" + code.payload[i].clave);
          if (!n)
            continue;
          n.dataset.id = code.payload[i].clave;
          n.onclick = seleccionacoleccion;
        }
        var n = WA.toDOM("tools-collection-create");
        if (n) {
          n.onclick = creacoleccion;
        }
        KL.Modules.modal.showpopup({closeable:true});
      })
      .catch(function(code, err) {
        if (code == 401)  // not connected
        {
          KL.Modules.stat.registerEvent('tools', 'tools/gologin');
          KL.loader.loadPage("/login/createcol");
          return;
        }
        // print error modal, send to server error
        KL.Modules.modal.alerta(code, err);
        console.log("Error sending fav:", code, err);
      });
    return WA.browser.cancelEvent(event);
  }

  function seleccionacoleccion(event)
  {
    if (!KL.Modules.client.clientlogged)
    {
      KL.Modules.stat.registerEvent('tools', 'tools/gologin');
      KL.loader.loadPage("/login/addcol/"+type+"/"+key);
      return;
    }

    var cid = this.dataset.id;
    WA.Managers.ajax.createPromiseRequest({ url: KL.graphdomains + '/v6/collection', method: 'post', send: false})
      .then(function(request) {
        request.addParameter('language', KL.language);
        request.addParameter('device', KL.device);
        request.addParameter('service', 'insert');
        request.addParameter('collection', cid);
        request.addParameter('type', type);
        request.addParameter('key', key);
        return request.send();
      })
      .then(function(response){
        KL.Modules.modal.hidepopup();
        var code = JSON.parse(response);
        if (code.status == 'ok')
        {
          KL.Modules.stat.registerEvent('tools', 'tools/addcol');
          KL.Modules.modal.notifica(KL.i18n.tools_collections_ok1+' <em>'+KL.i18n.tools_collections_ok2+'</em>');
        }
        else
        {
          KL.Modules.stat.registerEvent('tools', 'tools/errorcol');
          KL.Modules.modal.alerta(code.message);
        }
      })
      .catch(function(code, err) {
        if (code == 401)  // not connected
        {
          KL.Modules.stat.registerEvent('tools', 'tools/gologin');
          KL.loader.loadPage("/login/col/"+cid+"/"+type+"/"+key);
          return;
        }
        // print error modal, send to server error
        KL.Modules.modal.alerta(code, err);
        console.log("Error sending col:", code, err);
      });
    return WA.browser.cancelEvent(event);
  }

  function creacoleccion(event)
  {
    var v = WA.toDOM("tools-collection-name").value;

    if (!KL.Modules.client.clientlogged)
    {
      KL.Modules.stat.registerEvent('tools', 'tools/gologin');
      KL.loader.loadPage("/login/createcol/"+KL.fixedEncodeURIComponent(v)+"/"+type+"/"+key);
      return;
    }

    WA.Managers.ajax.createPromiseRequest({ url: KL.graphdomains + '/v6/collection', method: 'post', send: false})
      .then(function(request) {
        request.addParameter('language', KL.language);
        request.addParameter('device', KL.device);
        request.addParameter('service', 'create');
        request.addParameter('name', v);
        request.addParameter('type', type);
        request.addParameter('key', key);
        return request.send();
      })
      .then(function(response) {
        KL.Modules.modal.hidepopup();
        var code = JSON.parse(response);
        if (code.status == 'ok')
        {
          KL.Modules.stat.registerEvent('tools', 'tools/createaddcol');
          KL.Modules.modal.notifica(KL.i18n.tools_collections_ok1+' <em>'+KL.i18n.tools_collections_ok2+'</em>');
        }
        else
        {
          KL.Modules.stat.registerEvent('tools', 'tools/errorcol');
          KL.Modules.modal.alerta(code.message);
        }
      })
      .catch(function(code, err) {
        if (code == 401)  // not connected
        {
          KL.Modules.stat.registerEvent('tools', 'tools/gologin');
          KL.loader.loadPage("/login/col/"+KL.fixedEncodeURIComponent(v)+"/"+type+"/"+key);
          return;
        }
        // print error modal, send to server error
        KL.Modules.modal.alerta(code, err);
        console.log("Error sending col:", code, err);
      });
    return WA.browser.cancelEvent(event);
  }

  function clickshoppinglist(event)
  {
    if (!KL.Modules.client.clientlogged)
    {
      KL.Modules.stat.registerEvent('tools', 'tools/gologin');
      KL.loader.loadPage("/login/shoppinglist/"+key);
      return;
    }

    if (type != 'r')
    {
      KL.Modules.modal.alerta("Error, el objeto no es una receta para agregar a la lista del súper.");
      return;
    }

    WA.Managers.ajax.createPromiseRequest({ url: KL.graphdomains + '/v6/shoppinglist', method: 'post', send: false})
      .then(function(request) {
        request.addParameter('language', KL.language);
        request.addParameter('device', KL.device);
        request.addParameter('service', 'addrecipe');
        request.addParameter('key', key);
        return request.send();
      })
      .then(function(response){
        var code = JSON.parse(response);
        if (code.status == 'ok')
        {
          KL.Modules.stat.registerEvent('tools', 'tools/addshoppinglist');
          KL.Modules.modal.notifica(KL.i18n.tools_listasuper_ok1+' <em>'+KL.i18n.tools_listasuper_ok2+'</em>');
        }
        else
        {
          KL.Modules.stat.registerEvent('tools', 'tools/errorshoppinglist');
          KL.Modules.modal.alerta(code.message);
        }
      })
      .catch(function(code, err) {
        if (code == 401)  // not connected
        {
          KL.Modules.stat.registerEvent('tools', 'tools/gologin');
          KL.loader.loadPage("/login/shoppinglist/"+type+"/"+key);
          return;
        }
        // print error modal, send to server error
        KL.Modules.modal.alerta(code, err);
        console.log("Error sending shoppinglist:", code, err);
      });
    return WA.browser.cancelEvent(event);
  }

  function getlistasuper(request)
  {
    // close tools
    // put heart filled
    var code = JSON.parse(request.responseText);
    if (code.estatus == 'OK')
    {
      KL.Modules.modal.hidepopup();
      KL.Modules.stat.registerEvent('tools', 'tools/addsup');
      KL.Modules.modal.notifica(KL.i18n.tools_listasuper_ok1+' <em>'+KL.i18n.tools_listasuper_ok2+'</em>');
    }
    else
    {
      if (code.code == 1)
      {
        KL.Modules.stat.registerEvent('tools', 'tools/gologin');
        KL.loader.loadPage("/login/sup/"+type+"/"+key);
      }
      else
      {
        KL.Modules.stat.registerEvent('tools', 'tools/errorsup');
        KL.Modules.modal.alerta(code.mensaje);
      }
    }
  }

  function clickmenuplanner(event)
  {
    if (!KL.Modules.client.clientpro)
    {
      KL.Modules.stat.registerEvent('tools', 'tools/gologin');
      KL.loader.loadPage("/pro/"+type+"/"+key);
      return;
    }

    // call PRO MENU PLANNER

    WA.browser.cancelEvent(event);
  }

  this.destroy = destroy;
  function destroy()
  {
    containernode = null;
    toolsshadow = null;
    toolsnode = null;
    buttons = null;
    self = null;
  }

  // Note: only 1 gallery per page
  if (containernode.scanned)
    return;
  containernode.scanned = true;

  toolsshadow = WA.createDomNode('div', null, 'tools-shadow');
  toolsshadow.style.display = 'none';
  containernode.appendChild(toolsshadow);
  toolsnode = WA.createDomNode('div', null, 'tools-container');
  containernode.appendChild(toolsnode);

  // fill with the buttons template
  type = containernode.dataset.type;
  key = containernode.dataset.key;
  code = {t:type,k:key}

  // create buttons
  // close: always here
  var closebutton = WA.createDomNode('div', null, 'anim tools-close icon-k7-tools-close');
  closebutton.onclick = clickclose;
  toolsnode.appendChild(closebutton);
  buttons.push(closebutton);
  if (type == 'r') {
    // menu planner: recipe only
    /*
    var mpbutton = WA.createDomNode('div', null, 'anim tools-menuplanner icon-k7-tools-menuplanner');
    mpbutton.onclick = clickmenuplanner;
    toolsnode.appendChild(mpbutton);
    buttons.push(mpbutton);
    */
    // Shopping list / only recipe
    var slbutton = WA.createDomNode('div', null, 'anim tools-shoppinglist icon-k7-tools-shoppinglist');
    slbutton.onclick = clickshoppinglist;
    toolsnode.appendChild(slbutton);
    buttons.push(slbutton);
  }
  var clbutton = WA.createDomNode('div', null, 'anim tools-collections icon-k7-tools-collections');
  clbutton.onclick = clickcollections;
  toolsnode.appendChild(clbutton);
  buttons.push(clbutton);
  var fvbutton = WA.createDomNode('div', null, 'anim tools-favorites icon-k7-tools-favorites-empty');
  fvbutton.onclick = clickfav;
  toolsnode.appendChild(fvbutton);
  buttons.push(fvbutton);
}

/* Funciones para manejar el feed */
/*
  Escrito por: Phil
  Fecha: Julio 2016

  Control de cambios:
  26/02/2020: Wilmer, Ajuste a feed search/v6
  10/07/2016: Phil, Creación
*/

KL.Modules.feed = new function()
{
  var self = this;

  function load()
  {
  }


  this.unload = unload;
  function unload()
  {
  }

  KL.loader.addHookLoad('feed', load);
  KL.loader.addHookPostLoad('feed', load);
  KL.loader.addHookUnload('feed', unload);
}

KL.Modules.feed.container = function(id, template, datos, q)
{
  var self = this;
}

KL.Modules.slider = new function()
{
  var self = this;
  var sliders = {};
  var counter = 1;

  function load()
  {
    var sliderNodes = document.getElementsByClassName('slider');
    if (sliderNodes)
    {
      for (var i = 0; i < sliderNodes.length; i++)
      {
        id = sliderNodes[i].id;
        if (!id)
        {
          sliderNodes[i].id = id = "slider" + counter++;
        }
        sliders[id] = new KL.Modules.oneslider(sliderNodes[i]);
      }
    }
  }

  function unload()
  {
    for (var i = 0; i < sliders.length; i++)
      sliders[i].destroy();
    sliders = {};
  }

  KL.loader.addHookLoad('slider', load);
 // KL.loader.addHookPostLoad('slider', load);
  KL.loader.addHookUnload('slider', unload);
}

KL.Modules.oneslider = function(node)
{
  var self = this;
  var slidernode = node;
  var containernode = null;
  var position = 0;
  //var percentmove = 0.9;
  var percentmove = 1;

  function clickprevious(event)
  {
    var width = WA.browser.getNodeWidth(slidernode);
    position += Math.round(width*percentmove);
    if (position > 0)
      position = 0;
    containernode.style.left = position + 'px';
    //KL.loader.callHooksPostLoad();
    KL.Modules.stat.registerEvent('slider', 'slider/previous');
    // TODO(phil)
    // considerar enviar los IDs a analizar por la animacion
    // Se env�a a analizar las im�genes DAG 11/08/2022
    KL.Modules.images.analyze();
  }

  function clicknext(event)
  {
    var width = WA.browser.getNodeWidth(slidernode);
    position -= Math.round(width*percentmove);
    var size = getsize();
    var min = -size+width;
    if (min > 0)
      min = 0;
    if (position < min)
      position = min;
    containernode.style.left = position + 'px';
    KL.loader.callHooksPostLoad();
    KL.Modules.stat.registerEvent('slider', 'slider/next');
    //setTimeout(() => { KL.loader.callHooksPostLoad(); }, 900); //600

    // TODO(phil)
    // considerar enviar los IDs a analizar por la animacion
    // Se env�a a analizar las im�genes DAG 11/08/2022
    KL.Modules.images.analyze();
  }

  function getsize()
  {
    var width = 0;
    for (var i=0, l=containernode.childNodes.length; i<l; i++)
    {
      if (containernode.childNodes[i].nodeType != 1)
        continue;
      var x = WA.browser.getNodeNodeLeft(containernode.childNodes[i], containernode) + WA.browser.getNodeOuterWidth(containernode.childNodes[i]);
      if (x > width)
        width = x;
    }
    return width;
  }

  function draglistener(type, metrics)
  {
    if (type == 'start')
    {
      // quitar el anim
      containernode.style.transition = 'none';
    }
    if (type == 'drag')
    {
      // mover a la posicion
      var p = position + metrics.dx;
      var width = WA.browser.getNodeWidth(slidernode);
      if (p > 0)
        p = 0;
      var size = getsize();
      var min = -size+width;
      if (min > 0)
        min = 0;
      if (p < min)
        p = min;
//      containernode.style.transform = "translate("+p+"px,0)";
//      position = p;
      containernode.style.left = p + 'px';
    }
    if (type == 'izquierda' || type == 'derecha')
    {
      // reponer el anim
      containernode.style.transition = '';
      // animar hasta la posicion correspondiente a la velocidad ?
      var p = position + metrics.dx + metrics.velocity/4;
      var width = WA.browser.getNodeWidth(slidernode);
      if (p > 0)
        p = 0;
      var size = getsize();
      var min = -size+width;
      if (min > 0)
        min = 0;
      if (p < min)
        p = min;
      position = p;
      containernode.style.left = position + 'px';
      // TODO(phil)
      // considerar enviar los IDs a analizar por la animacion
    }
    KL.Modules.images.analyze();
    KL.loader.callHooksPostLoad();
  }

  this.destroy = destroy;
  function destroy()
  {
    if (timer)
      clearTimeout(timer)
    timer = null;
    actual = null;
    gallerynode = null;
    containernode = null;
    previousnode = null;
    nextnode = null;
    playnode = null;
    bulletsnode = null;
    self = null;
  }

  // Note: only 1 gallery per page
  if (slidernode.dataset.scanned)
    return;
  slidernode.dataset.scanned = true;

  if (!slidernode.firstElementChild)
    return;

  containernode = WA.createDomNode('div', slidernode.id+'_container', 'slider-container');
  while (slidernode.hasChildNodes())
  {
    // Solo queremos nodos div
    if (slidernode.firstChild.nodeType == 1)
    {
      slidernode.firstChild.className += ' slider-element';
      containernode.appendChild(slidernode.firstChild);
    }
    else
      slidernode.removeChild(slidernode.firstChild);
  }
  slidernode.appendChild(containernode);

  // 3. boton left
  previousnode = WA.createDomNode('div', null, 'slider-button left');
  slidernode.appendChild(previousnode);
  previousnode.onclick = function() {
    KL.Modules.stat.registerEvent('slider', 'slider/previous');
    clickprevious();
  };
  n = WA.createDomNode('div', null, 'icon-k7-slider-previous');
  previousnode.appendChild(n);

  // 4. boton right
  nextnode = WA.createDomNode('div', null, 'slider-button right');
  slidernode.appendChild(nextnode);
  nextnode.onclick = function() {
    KL.Modules.stat.registerEvent('slider', 'slider/next');
    clicknext();
  };
  n = WA.createDomNode('div', null, 'icon-k7-slider-next');
  nextnode.appendChild(n);

  KL.Modules.movements.adddraglistener('slider_' + slidernode.id, {node: containernode, listener:draglistener});
}

KL.Modules.recipelist = new function()
{
  var self = this;
  var node = null;
  var nodemasnuevo = null;
  var noderecomendado = null;
  var nodemaspopular = null;
  var nodenext = null;
  var actual = 1;
  var type = "";
  var key = "";
  var page = 1;
  var quantity = 10;
  var more = false;
  var total = 0;

  function cleandata()
  {
    node.innerHTML = "";
    page = 1;
  }

  function calldata()
  {
    var r = WA.Managers.ajax.createRequest(KL.graphdomains + '/v6/feed', 'POST', null, getdata, false);
    r.addParameter('v', 1 );
    r.addParameter('type', type );
    r.addParameter('key', key );
    r.addParameter('device', KL.device );
    r.addParameter('language', KL.language );
    r.addParameter('quantity', quantity );
    r.addParameter('order', actual );
    r.addParameter('page', page );
    r.addParameter('human', 1 );
    r.send();
  }

  function getdata(request)
  {
    code = JSON.parse(request.responseText);

    // inject into template
    template = WA.templater`${['loop', 'payload','feed_payload']}`;
    text = template(code);
    ndiv = WA.createDomNode('div', null, null);
    ndiv.style = "clear: both;";
    ndiv.innerHTML = text;
    node.appendChild(ndiv);

    // set next, data into
    more = code.more
    nodenext.style.display = more?"block":"none";

    // analyze img and ads and an
    KL.loader.callHooksPostLoad();
  }

  function next()
  {
    if (!more)
      return;
    page++;
    calldata();
  }

  function masnuevo()
  {
    if (actual == 1)
      return;
    actual = 1;
    nodemasnuevo.className = "recipelist-button on";
    noderecomendado.className = "recipelist-button";
    nodemaspopular.className = "recipelist-button";
    // seek new list
    cleandata();
    calldata();
  }

  function recomendado()
  {
    if (actual == 2)
      return;
    actual = 2;
    nodemasnuevo.className = "recipelist-button";
    noderecomendado.className = "recipelist-button on";
    nodemaspopular.className = "recipelist-button";
    // seek new list
    cleandata();
    calldata();
  }

  function maspopular()
  {
    if (actual == 3)
      return;
    actual = 3;
    nodemasnuevo.className = "recipelist-button";
    noderecomendado.className = "recipelist-button";
    nodemaspopular.className = "recipelist-button on";
    // seek new list
    cleandata();
    calldata();
  }

  function load()
  {
    node = WA.toDOM('recipelist');
    if (!node)
      return;
    nodemasnuevo = WA.toDOM('recipelist-masnuevo');
    nodemasnuevo.onclick = masnuevo;
    noderecomendado = WA.toDOM('recipelist-recomendado')
    noderecomendado.onclick = recomendado;
    nodemaspopular = WA.toDOM('recipelist-maspopular')
    nodemaspopular.onclick = maspopular;
    nodenext = WA.toDOM('recipelist-next');
    nodenext.onclick = next;

    type = node.dataset.type;
    key = node.dataset.key;
    quantity = parseInt(node.dataset.quantity, 10);
    page = parseInt(node.dataset.page, 10);
    more = node.dataset.more=="true";
    total = parseInt(node.dataset.total, 10);

    // If more: adds the "get next page" button
    nodenext.style.display = more?"block":"none";
  }

  function unload()
  {
    if (!node)
      return;
    nodemasnuevo.onclick = function() {};
    noderecomendado.onclick = function() {};
    nodemaspopular.onclick = function() {};
    nodenext.onclick = function() {};
    nodemasnuevo = null;
    noderecomendado = null;
    nodemaspopular = null;
    nodenext = null;
    node = null;
  }

  KL.loader.addHookLoad('recipelist', load);
  KL.loader.addHookUnload('recipelist', unload);
}

KL.loader.createCSS(`.gallery{
  margin: 0px;
  width: 100%;
  max-width: inherit;
  height: 100%;
  position: relative;
}

.gallery-slide {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
}

.gallery-slide.slide.anim {
  transition: all 1s ease 0s;
}

.gallery-slide.slide {
  transform: translate3d(0, 0, 0);
}

.gallery-slide.slide.before {
  transform: translate3d(-100%, 0, 0);
}

.gallery-slide.slide.after {
  transform: translate3d(100%, 0, 0);
}

.icon-k7-gallery-previous:before{content: "\\e948";}
.icon-k7-gallery-next:before{content: "\\e947";}
.icon-k7-gallery-play:before{content: "\\e923";}
.icon-k7-gallery-pause:before{content: "\\e922";}

.gallery-button
{
  position: absolute;
  opacity: 1;
  width: 48px;
  top: 0;
  bottom: 0;
  z-index: 14;
  background-color: transparent;
  font-size: 20px;
  cursor: pointer;
}

.gallery-button > div
{
  top: 50%;
  margin-top: -50%;
  position: relative;
  width: 100%;
  text-align: center;
  color: white;
}

.gallery-button:hover > div {
  color: #ccc;
  font-weight: bold;
}

.gallery-button.left{
  left: 0;
}

.gallery-button.right
{
  right: 0;
}

.gallery-player
{
  position: absolute;
  opacity: 1;
  width: 48px;
  left: 0px;
  top: 0px;
  height: 30px;
  width: 20px;
  padding-top: 10px;
  padding-left: 20px;
  z-index: 15;
  background-color: transparent;
  font-size: 20px;
  cursor: pointer;
}

.gallery-player > div
{
  position: relative;
  color: white;
}

.gallery-player:hover > div {
  color: #ccc;
  font-weight: bold;
}

.gallery-bullets {
  position: absolute;
  bottom: 0;
  width: auto;
  left: 50%;
  transform: translateX(-50%);
  text-align: center;
  display: flex;
}

.gallery-bullet {
  cursor: pointer;
  padding: 10px;
  padding-bottom: 20px;
  display: inline-block;
}

.gallery-bullet.on > div {
  background-color: black;
}

.gallery-bullet > div {
  background-color: white;
  border-radius: 100%;
  width: 10px;
  height: 10px;
  box-shadow: 1px 1px 6px rgba(0, 0, 0, 0.5);
}
`);
KL.loader.createCSS(`.gallery {
  overflow: hidden;
}

.gallery-datacontainer{
  float: none;
  /* height: 270px; */
  height: 300px;
  overflow: hidden;
  position: absolute;
  right: 50px;
  top: 50px;
  width: 350px;
}

.gallery-whiteshadow{
  background-color: #ffffff;
  /* height: 280px; */
  height: inherit;
  left: 0px;
  opacity: 0.8;
  position: absolute;
  top: 0px;
  width: 100%;
}

.gallery-content {
  height: auto;
  left: 50%;
  position: absolute;
  text-align: center;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
  width: 100%;
}

.gallery-title {
  color: #333333;
  font-size: 19px;
  font-weight: bold;
  max-height: 43px;
  line-height: 22px;
  margin: 0 40px;
  overflow: hidden;
  padding-bottom: 0;
  position: relative;
  text-align: center;
  text-transform: uppercase;
}

.gallery-description {
  position: relative;
  color: #777777;
  /* padding: 20px 50px; */
  padding: 20px 50px 15px;
  vertical-align: middle;
  font-size: 15px;
  line-height: 1.2em;
  max-height: 74px;
  overflow: hidden;
  text-align: center;
}

.gallery-titlelink, .gallery-titlelinkpro{
  margin-left: auto;
  margin-right: auto;
  padding: 14px;
  position: relative;
  text-align: center;
  width: 250px;
  color: white;
  font-size: 15px;
  font-weight: bold;
  text-transform: uppercase;
}
`);
KL.loader.createCSS(`.tools-shadow {
  position: absolute;
  top: 0px;
  bottom: 0px;
  width: 100%;
  background-color: #222222;
  opacity: 0.2;
  z-index: 1;
}

.tools-container {
  position: absolute;
  right: 10px;
  top: 10px;
  width: 30px;
  height: 30px;
  z-index: 1;
}

.tools-container .icon-k7-tools-close:before {
  content: "\\e946";
  font-size: 16px;
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.tools-container .icon-k7-tools-menuplanner:before {
  content: "\\e90c";
  font-size: 16px;
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.tools-container .icon-k7-tools-shoppinglist:before {
  content: "\\e90a";
  font-size: 15px;
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.tools-container .icon-k7-tools-collections:before {
  content: "\\e907";
  font-size: 15px;
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.tools-container .icon-k7-tools-favorites-empty:before {
  content: "\\e908";
  font-size: 16px;
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.tools-container.icon-k7-tools-favorites-full:before {
  content: "\\e924";
  font-size: 16px;
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.tools-container>div {
  border-radius: 100%;
  position: absolute;
  right: 0px;
  top: 0px;
  cursor: pointer;
  text-align: left;
}

.tools-close, .tools-menuplanner, .tools-shoppinglist, .tools-collections, .tools-favorites{
  background-color: #8cc63e;
  color: #ffffff;
  height: 30px;
  width: 30px;
}

.tools-favorites{
  background-color: #ff0000;
}

.tools-close{
  background-color: #eeeeee;
  color: #888;
}

.tools-coleccionentrada {
  height: 15px;
  cursor: pointer;
  padding: 5px;

}

.tools-coleccionentrada:hover {
  background-color: #ccc;
}
`);
KL.loader.createCSS(`/* generico */
.feed-articulolarge-thumb-titulo-seccion{
  background-color: #8cc63e;
}

/* nutricion */
.feed-articulolarge-thumb-titulo-seccion.id_tema_11{
  background-color: #9ec410;
}

/* bebidas */
.feed-articulolarge-thumb-titulo-seccion.id_tema_30{
  background-color: #f05d7f;
}

/* comida vegana */
.feed-articulolarge-thumb-titulo-seccion.id_tema_1{
  background-color: #28d9ff;
}

/* dieta */
.feed-articulolarge-thumb-titulo-seccion.id_tema_44{
  background-color: #2e94ba;
}

/* reposteria */
.feed-articulolarge-thumb-titulo-seccion.id_tema_20{
  background-color: #efc950;
}

/* tips cocina */
.feed-articulolarge-thumb-titulo-seccion.id_tema_54{
  background-color: #f39041;
}

/* tips consejos */
.feed-articulolarge-thumb-titulo-seccion.id_tema_25{
  background-color: #ca5dde;
}

.feed-divarticulolarge .tools-container, #home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .tools-container{
  left: 225px;
}


/* estilos slider top 10 */
/* estilos slider top 10 para tips kiwi / estilos slider top 10 para tips crafto */
div[id^="familiatips"] div[id^="p|kiwi|tipfamilia"], div[id^="clasificaciontips"] div[id^="p|kiwi|tipclasificacion"], div[id^="home_top10"] div[id^="p|kiwi|tiphome"], div[id^="home_top10"] div[id^="p|crafto|tiphome"], div[id^="familiatips"] div[id^="p|crafto|tipfamilia"], div[id^="clasificaciontips"] div[id^="p|crafto|tipclasificacion"], div[id^="familiatips"] div[id^="p|kiwi|tipclasificaciontop|"], div[id^="familiatips"] div[id^="p|crafto|tipclasificaciontop|"]{
  width: 190px;
  margin: 0px 15px 0px 0px;
  height: 267px;
}

div[id^="familiatips"] div[id^="feed-tip-divimg"], div[id^="clasificaciontips"] div[id^="feed-tip-divimg"], div[id^="home_top10"] div[id^="feed-tip-divimg"]{
  height: 190px;
  width: 190px;
}

div[id^="familiatips"] .feed-tip-nombreficha, div[id^="clasificaciontips"] .feed-tip-nombreficha, div[id^="home_top10"] .feed-tip-nombreficha{
  font-size: 14px;
  max-height: 46px;
  line-height: 15px;
  text-transform: uppercase;
}

div[id^="familiatips"] hr, div[id^="clasificaciontips"] hr, div[id^="familiatips"] .feed-tip-nombrechef, div[id^="clasificaciontips"] .feed-tip-nombrechef, div[id^="home_top10"] div[id^="p|kiwi"] hr, div[id^="home_top10"] div[id^="p|crafto"] hr, div[id^="home_top10"] div[id^="p|kiwi"] .feed-tip-nombrechef, div[id^="home_top10"] div[id^="p|crafto"] .feed-tip-nombrechef{
  display: none;
}

div[id^="familiatips"] div[id^="feed-tip-rating"], div[id^="clasificaciontips"] div[id^="feed-tip-rating"], div[id^="home_top10"] div[id^="p|kiwi|tiphometop"] div[id^="feed-tip-rating"], div[id^="home_top10"] div[id^="p|crafto|tiphometop"] div[id^="feed-tip-rating"]{
  margin: 0px auto;
  padding: 0px;
}
/* fin estilos slider top 10 para tips */

/* area nombre ficha */
#home_top10 .recetaslider-ficha, #familiarecetas_top10 .recetaslider-ficha, #clasificacionrecetas_top10 .recetaslider-ficha, #clasificacionrecetas_top10 .compilacionrecetaslider-ficha, #clasificaciontips_top10 .tipslider-ficha, #home_tecuidalist .feed-articulo-ficha, .pro-slider-fichaspro .feed-receta-ficha{
  height: 267px;
}

#home_top10 .recetaslider-areanombreficha, #familiarecetas_top10 .recetaslider-areanombreficha, #clasificacionrecetas_top10 .recetaslider-areanombreficha, #home_top10 .tipslider-areanombreficha, #home_top10 .articuloslider-areanombreficha{
  height: 52px; 
}

#home_top10 .recetasliderpro-areanombreficha, #familiarecetas_top10 .recetasliderpro-areanombreficha, #clasificacionrecetas_top10 .recetasliderpro-areanombreficha{
  height: 52px; 
  display: flex;
  align-items: center;
}

#home_videos .compilacionrecetaslider-areanombreficha{
  height: 75px; 
}


/* nombre de ficha */
#home_top10 .recetaslider-nombreficha, #familiarecetas_top10 .recetaslider-nombreficha, #clasificacionrecetas_top10 .recetaslider-nombreficha, #home_top10 .tipslider-nombreficha, #home_videos .compilacionrecetaslider-nombreficha, #home_top10 .articuloslider-nombreficha, #home_videos div[id^="p|crafto|tiphomecompilacion"] .feed-compilaciontip-nombreficha, #home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-nombre-articulo{
  font-weight: bold;
  font-size: 14px;
  color: #000000;
  max-height: 46px;
}

#home_top10 .recetaslider-icon-pro, #familiarecetas_top10 .recetaslider-icon-pro, #clasificacionrecetas_top10 .recetaslider-icon-pro{
  width: 30px;
  height: 30px;
  font-size: 20px;
  margin: 0px 0px 0px 10px;
}

#home_top10 .recetasliderpro-nombreficha, #familiarecetas_top10 .recetasliderpro-nombreficha, #clasificacionrecetas_top10 .recetasliderpro-nombreficha{
  font-size: 15px;
  max-height: 31px;
  width: calc(100% - 40px);
}

/* rating */
#home_top10 .recetaslider-rating, #familiarecetas_top10 .recetaslider-rating, #clasificacionrecetas_top10 .recetaslider-rating, #home_top10 .tipslider-rating{
  display: table;
}

#home_top10 div[id^="p|kiwi|"] [class$="-rating"], #home_top10 div[id^="p|crafto|"] [class$="-rating"], #familiarecetas_top10 div[id^="p|kiwi|"] [class$="-rating"], #clasificacionrecetas_top10 div[id^="p|kiwi|"] [class$="-rating"]{
  padding: 0px;
}
/* fin estilos slider top 10 */


/* Estilos feed fichas Normal */
/* Estilo solo para los tips, ya que slider top usa la misma ficha que en feed normal */
div[id^="p|kiwi|home"].feed-tip-ficha, div[id^="tiplist"] div[id^="p|kiwi|tipfamilia"], div[id^="tiplist"] div[id^="p|kiwi|tipclasificacion"], div[id^="tiplist"] div[id^="p|kiwi|tiphome"], div[id^="tiplist"] div[id^="p|crafto|tiphome"], div[id^="tiplist"] div[id^="p|crafto|tipfamilia"], div[id^="tiplist"] div[id^="p|crafto|tipclasificacion"]{
  width: 300px;
  margin: 0px 10px 16px;
  height: 275px;
}

div[id^="tiplist"] div[id^="feed-tip-divimg"]{
  height: 194px;
  width: 300px;
}

div[id^="p|kiwi|home"].feed-tip-ficha .feed-tip-nombreficha, div[id^="tiplist"] .feed-tip-nombreficha{
  font-size: 17px;
  max-height: 38px;
  line-height: 18px;
}

div[id^="p|kiwi|home"].feed-tip-ficha div[id^="feed-tip-rating"], div[id^="tiplist"] div[id^="feed-tip-rating"]{
  margin: 0px 0px 0px 10px;
}
/* fin Estilo solo para los tips */

div[id^="p|kiwi|"][class$="-ficha"], div[id^="p|kiwirec|"][class$="-ficha"], div[id^="p|crafto|tipcompilaciones|"].feed-compilaciontip-ficha{
  height: 275px;
}

div[id^="p|kiwi|client"][class$="-ficha"], div[id^="p|crafto|client"][class$="-ficha"]{
  width: 300px;
  margin: 0px 10px 16px;
}

#prorecipeprolist .feed-producto-ficha{
width: 200px;
margin: 20px 15px;
display: inline-table;
float: none !important;
}

/* div[id^="p|kiwi|probooks|"][class$="-ficha"], div[id^="p|kiwi|prorecipes|"][class$="-ficha"], div[id^="p|kiwi|procollections|"].coleccion-venta-soloportada */
div[id^="p|kiwi|probooks|"][class$="-ficha"], div[id^="p|kiwi|procollections|"].coleccion-venta-soloportada{
  height: 262px;
  margin: 20px 15px;
  width: 200px;
  border-radius: 5px;
  float: none !important;
  display: inline-table;
}

div[id^="p|kiwi|procollections|"].coleccion-venta-ficha{
  float: none !important;
  display: inline-table;
}

div[id^="p|kiwi|procollections|"].coleccion-venta-ficha .coleccionventa-area{
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  vertical-align: top;
  width: 100%;
}

div[id^="p|kiwi|probooks|"] .feed-producto-div-nombreprod, div[id^="p|kiwi|prorecipes|"] .feed-producto-div-nombreprod{
  display: none;
}

/* estilos fichas recetas slider pro*/
.pro-slider-fichaspro div[id^="p|kiwi|probooks|"].feed-producto-ficha{
  width: 200px;
  height: 262px;
  margin: 20px 15px;
  border-radius: 5px;
}

.pro-slider-fichaspro .feed-receta-ficha{
  width: 190px !important;
  margin: 0px 30px 0px 0px !important;
  position: relative;
}

.pro-slider-fichaspro .feed-divimagenficha{
  width: 190px !important;
  height: 190px !important;
}

.pro-slider-fichaspro .feed-receta-ficha img{
  left: 50% !important;
  top: 50% !important;
  transform: translateX(-50%) translateY(-50%) !important;
  height: 100%;
  width: auto !important;
  min-width: 300px;
}

.pro-slider-fichaspro .feed-receta-ficha hr, .pro-slider-fichaspro .feed-receta-nombrechef{
  display: none;
}

.pro-slider-fichaspro .feed-recetapro-icon{
  margin: 0px 0px 0px 10px !important;
}

.pro-slider-fichaspro .feed-receta-nombreficha-centrado{
  max-height: 47px !important;
  width: calc(100% - 40px) !important;
}
/* fin estilos fichas recetas slider pro*/

/* estilos fichas donde vienen cosas revueltas de kiwipro en el home */
.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-producto-ficha{
  width: 200px !important;
  height: 272px;
  /* border-radius: 5px; */
  margin: 0px 20px !important;
  background-color: #ffffff;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-producto-ficha{
  float: left;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-divimagenficha, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha .feed-divimagenficha{
  width: 100% !important;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-divimagenficha img, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha .feed-divimagenficha img{
  height: 100%;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha:first-child, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha:first-child{
  margin: 0px 20px 0px 0px !important;
}

#home-cont-kiwipro.home-cont-sliderpro div[id^="p|kiwi|pro|"] .feed-articulopro-divtextos-articulo, #home-cont-kiwipro.home-cont-sliderpro div[id^="p|kiwi|pro|"] [class$="recetapro-areanombreficha"]{
  height: 62px;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha hr, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha .feed-receta-nombrechef{
  display: none;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-receta-ficha .feed-receta-rating{
  position: relative;
  display: flex !important;
  justify-content: center;
  margin: -3px 0px 0px 0px !important;
  padding: 0px;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulopro-separador, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulopro-nombre-autor{
  display: none !important;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha{
  float: left;
}

/*
.home-cont-sliderpro div[id^="p|kiwi|pro|"] .feed-articulo-divimg-articulo{
  border-radius: 5px;
}
*/

.home-cont-sliderpro div[id^="p|kiwi|pro|"] .feed-recetapro-areanombreficha .feed-recetapro-icon, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulopro-icon{
  margin: 0px 0px 0px 10px !important;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"] .feed-recetapro-areanombreficha .feed-receta-nombreficha-centrado, .home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulopro-nombre-articulo{
  width: calc(100% - 40px) !important;
  max-height: 46px;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"] .feed-recetapro-areanombreficha .feed-receta-nombreficha-centrado{
  max-height: 46px !important;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulopro-nombre-articulo{
  /*max-height: 34px;*/
  font-size: 16px;
  line-height: 15px;
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulopro-area-rating{
  display: none !important;
  padding: 0px;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
}

.home-cont-sliderpro div[id^="p|kiwi|pro|"].feed-articulo-ficha .feed-articulo-clasificacion-articulo{
  display: block !important;
  position: absolute;
  /*bottom: -10px;*/
  bottom: -11px;
  width: 100%;
  text-align: center;
  font-style: italic;
  color: #aaaaaa;
  box-sizing: border-box;
  padding: 0px 10px;
}
/* fin estilos fichas donde vienen cosas revueltas de kiwipro en el home */

.pro-slider-fichaspro .feed-receta-rating{
  margin: 0px auto !important;
  padding: 0px !important;
}

div[id^="p|kiwi|home|"].feed-compilaciontip-ficha, div[id^="p|crafto|tipcompilaciones|"].feed-compilaciontip-ficha{
  margin: 0px 10px 16px;
  overflow: hidden;
  width: 300px;
}

div[id^="p|crafto|tipcompilations|"].feed-compilaciontip-ficha{
  margin: 0px 10px 16px;
  width: 300px;
}

div[id^="p|kiwi|procollections|"].coleccion-venta-soloportada{
  text-align: left;
}

div[id^="p|kiwi|"] [class$="-divimg-articulo"], div[id^="p|kiwirec|"] [class$="-divimg-articulo"]{
  position: relative;
}

div[id^="p|kiwi|"] [class$="-divimg"], div[id^="p|kiwi|home|"] [class$="-divimg"], div[id^="p|kiwirec|"] [class$="-divimg"], div[id^="p|kiwirec|home|"] [class$="-divimg"], div[id^="p|kiwi|"] [class$="-divimg-articulo"], div[id^="p|kiwirec|"] [class$="-divimg-articulo"], div[id^="p|crafto|"] [class$="-divimg"]{
  height: 194px;
  overflow: hidden;
}

div[id^="p|kiwi|"] .feed-compilaciontip-divimg, div[id^="p|crafto|"] .feed-compilaciontip-divimg{
  width: 300px;
}

div[id^="p|kiwi|"] .feed-compilacionreceta-divimg .compilacionreceta-img, div[id^="p|crafto|tipcompilaciones|"].feed-compilaciontip-ficha .compilaciontip-img{
  height: auto;
}

div[id^="p|crafto|"] .feed-compilaciontip-divimg .compilaciontip-img{
  transform: translateY(-50%);
}

#home_videos div[id^="p|crafto|"] .feed-compilaciontip-divimg .compilaciontip-img{
  transform: initial;
}


div[id^="p|kiwi|home|"] [class$="-divimg"] .imgcompilacion{
  transform: translateY(-50%);
}


/* estilos feed normal articulos */
div[id^="p|kiwi|"][class$="feed-articulo-ficha"], div[id^="p|kiwirec|"][class$="feed-articulo-ficha"]{
  background-color: #ffffff;
  float: left;
  margin: 0px 10px 16px;
  overflow: hidden;
  position: relative;
  width: 300px;
}

div[id^="p|kiwi|"] .feed-articulopro-divtextos-articulo, #home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"] .feed-articulopro-divtextos-articulo{
  display: flex;
  align-items: center;
  height: 52px;
  position: relative;
}

div[id^="p|kiwi|"] .feed-articulopro-area-titulo{
  display: flex;
  align-items: center;
  position: relative;
  width: 100%;
  flex: auto;
}

#home_tecuidalist div[id^="p|kiwi|"] .feed-articulopro-icon{
  margin: 0px 0px 0px 10px !important;
}

div[id^="p|kiwi|"] .feed-articulopro-nombre-articulo{
  box-sizing: border-box;
  color: #8eb4b1;
  font-family: crimsonpro-semibold;
  font-size: 19px;
  text-transform: uppercase;
  width: calc(100% - 50px);
  line-height: 17px;
  max-height: 38px;
  overflow: hidden;
  padding: 0px 10px;
  position: absolute;
  right: 0px;
}

#home_tecuidalist div[id^="p|kiwi|"] .feed-articulopro-nombre-articulo{
  font-size: 17px;
  line-height: 15px;
  max-height: 46px;
  width: calc(100% - 40px);
  text-transform: initial;
}

#home_tecuidalist div[id^="p|kiwi|"] .feed-articulopro-separador{
  display: none !important;
}

div[id^="p|kiwi|"] .feed-articulo-nombre-articulo, div[id^="p|kiwirec|"] .feed-articulo-nombre-articulo{
  box-sizing: border-box;
  color: #000000;
  font-size: 17px;
  font-weight: bold;
  line-height: 18px;
  max-height: 38px;
  overflow: hidden;
  padding: 0px 10px;
  position: absolute;
  text-align: center;
  top: 50%;
  transform: translateY(-50%);
  width: 100%;
}

div[id^="p|kiwi|"] .feed-articulopro-desc-articulo, div[id^="p|kiwi|"] .feed-articulo-desc-articulo, div[id^="p|kiwirec|"] .feed-articulo-desc-articulo{
  display: none;
}

div[id^="p|kiwi|"] .feed-articulopro-separador, div[id^="p|kiwi|"] .feed-articulo-separador, div[id^="p|kiwirec|"] .feed-articulo-separador{
  display: block !important;
  bottom: -2px;
}

div[id^="p|kiwi|"] .feed-articulopro-nombre-autor, div[id^="p|kiwi|"] .feed-articulo-nombre-autor, div[id^="p|kiwirec|"] .feed-articulopro-nombre-autor, div[id^="p|kiwirec|"] .feed-articulo-nombre-autor{
  display: block !important;
  position: absolute;
  bottom: -22px;
  right: 10px;
  font-style: italic;
  color: #aaaaaa;
  /*bottom: 7px;*/
}

div[id^="p|kiwi|"] .feed-articulopro-area-rating, div[id^="p|kiwi|"] .feed-articulo-area-rating{
  display: block !important;
  position: absolute;
  bottom: -23px;
  left: 10px;
  /*bottom: 6px;*/
}

div[id^="p|kiwi|"] .feed-articulopro-area-rating .feed-articulo-rating, div[id^="p|kiwi|"] .feed-articulo-area-rating .feed-articulo-rating, div[id^="p|kiwirec|"] .feed-articulo-area-rating .feed-articulo-rating{
  color: #8cc63e;
}
/* fin estilos feed normal articulos */


/* estilos para ficha tips en home principal kiwi */
#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"]{
  width: 600px;
  height: auto;
  margin: 0px 15px 0px 0px;
}

#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-divimg{
    float: left;
    width: 265px;
    height: 265px;
}

#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-areanombreficha{
  float: left;
  width: calc(100% - 265px);
  height: 265px;
}

#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-nombreficha-div{
  color: #333333;
  /*font-size: 18px;*/
  font-size: 20px;
  font-weight: bold;
  /*line-height: 20px;*/
  line-height: 22px;
  margin: 0px 0px 15px;
  /*max-height: 62px;*/
  max-height: 68px;
  padding: 0px 10px;
  overflow: hidden;
  text-transform: uppercase;
  text-align: left;
}


#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-descripcionficha{
  box-sizing: border-box;
  color: #333333;
  font-size: 15px;
  font-weight: normal;
  line-height: 19px;
  max-height: 98px;
  overflow: hidden;
  padding: 0px 10px;
  position: relative;
  width: 100%;
  text-align: left;
  display: block !important;
}

#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-ficha-linkvertip{
  font-size: 16px;
  color: #8cc63e;
  text-align: left;
  margin: 10px 0px 0px;
  padding: 0px 10px;
  line-height: 22px;
  display: block !important;
}

.icon-k7-link-vertip:before{content: "\\e923";}

#home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] hr, #home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-rating, #home_tips div[id^="p|kiwi|tiphome|"][class$="-ficha"] .feed-tip-nombrechef{
  display: none !important;
}
/* estilos para ficha tips en home principal kiwi */


/* estilos home fichas notas blog */
#home_notasblog div[id^="p|kiwi|articlehome|"].feed-articulo-ficha, #home_notasblog div[id^="p|kiwirec|articlehome|"].feed-articulo-ficha{
  background-color: #ffffff;
  width: 190px;
  height: 265px;
  float: left;
  position: relative;
  margin: 0px 15px 0px 0px;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-divimg-articulo, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-divimg-articulo{
  /*height: 190px;*/
  height: 180px;
  position: relative;
  overflow: hidden;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-divtextos-articulo, #home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulopro-divtextos-articulo, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-divtextos-articulo{
  /*height: 75px;*/
  height: 85px;
  position: relative;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-seccion, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-seccion{
  display: none;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-nombre-articulo, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-nombre-articulo{
  box-sizing: border-box;
  line-height: 15px;
  overflow: hidden;
  /*padding: 0px 10px;*/
  padding: 0px 7px;
  position: absolute;
  text-align: center;
  /*text-transform: uppercase;*/
  top: 38%;
  /*transform: translateY(-50%);*/
  transform: translateY(-46%);
  width: 100%;
  font-weight: bold;
  font-size: 14px;
  color: #000000;
  max-height: 46px;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulopro-area-titulo{
  position: absolute;
  top: 38%;
  transform: translateY(-46%);
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulopro-icon{
  margin: 0px 0px 0px 10px !important;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulopro-nombre-articulo{
  font-size: 17px;
  line-height: 15px;
  max-height: 45px;
  width: calc(100% - 40px) !important;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion{
  background-color: #8cc63e;
  box-sizing: border-box;
  color: #ffffff;
  font-size: 11px;
  left: 0px;
  letter-spacing: 1px;
  max-width: 140px;
  padding: 8px 13px;
  position: absolute;
  text-transform: uppercase;
  top: 15px;
  display: block !important;
}


#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_3, #home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_11, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_3, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_11{
  background-color: #9ec410;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_30, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_30{
  background-color: #f05d7f;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_1, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_1{
  background-color: #28d9ff;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_44, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_44{
  background-color: #2e94ba;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_20, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_20{
  background-color: #efc950;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_54, #home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_54{
  background-color: #f39041;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_25, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-titulo-nombreseccion.id_tema_25{
  background-color: #ca5dde;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-nombre-autor, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-nombre-autor{
  display: block !important;
  box-sizing: border-box;
  padding: 0px 10px;
  text-align: center;
  color: #aaaaaa;
  font-family: 'source sans pro';
  font-style: italic;
  font-size: 12px;
  height: 15px;
  overflow: hidden;
  position: absolute;
  bottom: 5px;
  right: 0px;
  width: 100%;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulopro-nombre-autor{
  display: block !important;
  left: 50%;
  transform: translate(-50%);
  bottom: 8px;
  font-size: 12px;
  width: -webkit-fit-content; width: -moz-fit-content; width: -o-fit-content; width: -ms-fit-content; width: fit-content;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-area-rating, #home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulopro-area-rating, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-area-rating, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulopro-area-rating{
  display: none !important;
}

#home_notasblog div[id^="p|kiwi|articlehome|"] .feed-articulo-desc-articulo, #home_notasblog div[id^="p|kiwirec|articlehome|"] .feed-articulo-desc-articulo{
  display: none;
}
/* fin home estilos fichas notas blog */

/* estilos home fichas te cuida */
#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha{
    background-color: #ffffff;
    display: table;
    float: left;
    margin: 0px 15px 0px 0px;
    position: relative;
    width: 190px;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-divcontenido{
  height: inherit;
  position: relative;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-divimg-articulo{
  width: 100%;
  /*height: 190px;*/
  height: 180px;
  position: relative;
  overflow: hidden;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-divimg-articulo img{
  vertical-align: top;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-divtextos-articulo, #home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"] .feed-articulopro-divtextos-articulo{
  height: 62px;
  position: relative;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-nombre-articulo{
  box-sizing: border-box;
  line-height: 15px;
  overflow: hidden;
  /*padding: 0px 10px;*/
  padding: 0px 7px;
  position: absolute;
  text-align: center;
  /*text-transform: uppercase;*/
  top: 50%;
  transform: translateY(-50%);
  width: 100%;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-separador{
  display: none !important;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-area-rating, #home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulopro-area-rating{
  display: block !important;
  color: #8cc63e;
  position: absolute;
  bottom: -16px;
  left: 50%;
  transform: translateX(-50%);
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulopro-area-rating{
  left: 50%;
  transform: translateX(-50%);
  bottom: -16px;
}

#home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-desc-articulo, #home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulo-nombre-autor, #home_tecuidalist div[id^="p|kiwi|articuloclasificacion|"].feed-articulo-ficha .feed-articulopro-nombre-autor{
  display: none !important;
}
/* fin estilos home fichas te cuida */

/* estilos fichas productos feed normal */
div[id^="p|kiwi|"] .feed-producto-divimg, div[id^="p|kiwirec|"] .feed-producto-divimg, div[id^="p|kiwi|home|"] .feed-producto-divimg{
  height: 233px;
}
/* estilos fichas productos feed normal */

div[id^="p|kiwi|probooks|"] .feed-producto-divimg, div[id^="p|kiwi|prorecipes|"] .feed-producto-divimg{
  height: 100%;
}

div[id^="p|kiwi|"] [class$="-areanombreficha"], div[id^="p|kiwirec|"] [class$="-areanombreficha"], div[id^="p|crafto|"] [class$="-areanombreficha"], div[id^="p|kiwi|"] .feed-articulo-divtextos-articulo, div[id^="p|kiwirec|"] .feed-articulo-divtextos-articulo{
  height: 52px;
}

div[id^="p|kiwi|"] .feed-articulo-divtextos-articulo, div[id^="p|kiwirec|"] .feed-articulo-divtextos-articulo{
  position: relative;
}

div[id^="p|kiwi|"] [class$="recetapro-areanombreficha"]{
  height: 52px;
  display: flex;
  align-items: center;
}

div[id^="p|kiwi|"] .feed-compilacionreceta-areanombreficha, div[id^="p|kiwi|"] .feed-compilaciontip-areanombreficha, div[id^="p|crafto|"] .feed-compilaciontip-areanombreficha{
  height: 42px;
}


div[id^="p|kiwi|"] .feed-compilaciontip-areanombreficha .feed-compilaciontip-nombreficha, div[id^="p|crafto|"] .feed-compilaciontip-areanombreficha .feed-compilaciontip-nombreficha{
  color: #000000;
  font-size: 17px;
  font-weight: bold;
  line-height: 18px;
  max-height: 38px;
}

div[id^="p|kiwi|"] [class$="-titulo-seccion"], div[id^="p|kiwirec|"] [class$="-titulo-seccion"], div[id^="p|crafto|"] [class$="-titulo-seccion"]{
  display: none;
}

div[id^="p|kiwi|"] [class$="-rating"], div[id^="p|kiwirec|"] [class$="-rating"], div[id^="p|crafto|"] [class$="-rating"]{
  padding: 8px 0px 0px;
}

div[id^="p|crafto|client|"].feed-tip-ficha{
  height: 275px;
}

div[id^="p|kiwi|client|"] [class$="-rating"], div[id^="p|crafto|client|"] [class$="-rating"]{
  margin: 0px 0px 0px 10px;
  height: 275px;
}


div[id^="p|kiwi|"] [class$="-nombrechef"], div[id^="p|kiwirec|"] [class$="-nombrechef"], div[id^="p|crafto|"] [class$="-nombrechef"]{
  bottom: 5px;
}


/* Estilos feed fichas home videos compilacion craftologia / home tips kiwi */
#home_videos .feed-compilaciontip-ficha{
  height: auto;
  margin: 0px 10px 16px;
  width: 300px;
}

div[id^="p|kiwi|tiphomecompilacion"] .feed-compilaciontip-divimg, div[id^="p|crafto|tiphomecompilacion"] .feed-compilaciontip-divimg{
  height: 222px;
  overflow: hidden;
}

div[id^="p|kiwi|tiphomecompilacion"] .feed-compilaciontip-divimg img, div[id^="p|crafto|tiphomecompilacion"] .feed-compilaciontip-divimg img {
  top: initial !important;
}

div[id^="p|kiwi|tiphomecompilacion"] .feed-compilaciontip-divimg .imgcompilacion, div[id^="p|crafto|tiphomecompilacion"] .feed-compilaciontip-divimg .imgcompilacion, div[id^="p|crafto|crosslink"] .feed-compilaciontip-divimg .compilaciontip-img{
  transform: translateX(-50%) translateY(-50%);
}

div[id^="p|kiwi|tiphomecompilacion"] .feed-linea-separador-compilacion, div[id^="p|kiwi|tiphomecompilacion"] .feed-compilaciontip-descripcion, div[id^="p|crafto|tiphomecompilacion"] .feed-linea-separador-compilacion, div[id^="p|crafto|tiphomecompilacion"] .feed-compilaciontip-descripcion{
  display: none;
}

#home_videos div[id^="p|kiwi|tiphomecompilacion"] .feed-compilaciontip-areanombreficha, #home_videos div[id^="p|crafto|tiphomecompilacion"] .feed-compilaciontip-areanombreficha{
  height: 75px;
}

div[id^="p|crafto|crosslink"] .feed-compilaciontip-divimg .compilaciontip-img{
  height: inherit;
}
/* Fin Estilos feed fichas home videos compilacion craftologia */


/* Estilos caja recomendaciones de tips */
.tip-recomendaciones .feed-tip-ficha .feed-tippro-icon{
  width: 20px !important;
  height: 20px !important;
  font-size: 13px !important;
}

.tip-recomendaciones .feed-tip-ficha .feed-tip-nombrefichapro-centrado{
  width: calc(100% - 30px) !important;
}
/* Fin estilos caja recomendaciones de tips */
/* Fin Estilos feed fichas Normal */


/* Estilos feed fichas Busqueda */
div[id^="p|search|"].feed-tip-ficha{
  width: 300px;
  margin: 0px 10px 16px;
}

#searchlist div[id^="p|search|"][class$="-ficha"], .searchlist-muestra{
  height: 250px;
}

#te-cuida-divcont-consejos-tips #searchlist div[id^="p|search|"][class$="-ficha"]{
  height: auto;
}

#te-cuida-divcont-consejos-tips .feed-articulo-ficha{
  height: auto;
}

div[id^="p|search|"] .feed-tip-divimg, div[id^="p|search|"].feed-compilaciontip-ficha{
  width: 300px;
}

div[id^="p|search|"] [class$="-divimg"]{
  height: 185px;
}

div[id^="p|search|"] .feed-compilacionreceta-divimg, div[id^="p|search|"] .feed-compilaciontip-divimg{
  height: 208px;
}

div[id^="p|search|"] .feed-compilaciontip-divimg .compilaciontip-img{
  transform: translateY(-50%);
}

div[id^="p|search|"] [class$="-areanombreficha"]{
  height: 42px;
}

div[id^="p|search|"] [class$="recetapro-areanombreficha"]{
  height: 42px;
  display: flex;
  align-items: center;
}

div[id^="p|search|"] .feed-compilaciontip-areanombreficha .feed-compilaciontip-nombreficha{
  color: #000000;
  font-size: 17px;
  font-weight: bold;
  line-height: 18px;
  max-height: 38px;
}

div[id^="p|search|"] .feed-tip-nombreficha{
  font-size: 17px;
  max-height: 38px;
  line-height: 18px;
}

div[id^="p|search|"] .feed-linea-separador-compilacion, div[id^="p|search|"] .feed-compilacionreceta-descripcion, div[id^="p|search|"] .feed-compilaciontip-descripcion{
  display: none;
}

div[id^="p|search|"] [class$="-titulo-seccion"]{
  display: block;
}

div[id^="p|search|"] [class$="-rating"]{
  padding: 4px 0px 0px;
}

div[id^="p|search"] div[id^="feed-tip-rating"]{
  margin: 0px 0px 0px 10px;
}

div[id^="p|search|"] [class$="-nombrechef"]{
  bottom: 3px;
}



/* fichas articulo */
div[id^="p|search|"].feed-articulo-ficha{
  background-color: #ffffff;
  float: left;
  margin: 0px 10px 16px;
  overflow: hidden;
  position: relative;
  width: 300px;
  display: flex;
  flex-direction: column;
}

div[id^="p|search|"] .feed-articulo-divcontenido{
  width: 100%
}

div[id^="p|search|"] .feed-articulo-divimg-articulo{
  width: 100%;
  height: 208px;
  overflow: hidden;
  position: relative;
}

div[id^="p|search|"] .feed-articulo-divtextos-articulo, div[id^="p|search|"] .feed-articulopro-divtextos-articulo{
  height: 42px;
  position: relative;
}

div[id^="p|search|"] .feed-articulopro-divtextos-articulo{
  display: flex;
  align-items: center;
}

div[id^="p|search|"] .feed-articulo-nombre-articulo, div[id^="p|search|"] .feed-articulopro-nombre-articulo{
  color: #333333;
  text-decoration: none;
  font-size: 17px;
  font-weight: bold;
  line-height: 18px;
  max-height: 38px;
  overflow: hidden;
  position: absolute;
  text-align: center;
  top: 50%;
  transform: translateY(-50%);
  width: 100%;
  padding: 0px 10px;
  box-sizing: border-box;
}

div[id^="p|search|"] .feed-articulopro-nombre-articulo{
  color: #8eb4b1;
  font-family: crimsonpro-semibold;
  font-size: 16px;
  line-height: 15px;
  right: 0px;
  text-align: left;
  text-transform: uppercase;
  width: calc(100% - 50px);
  max-height: 32px;
}

div[id^="p|search|"] .feed-articulo-desc-articulo, div[id^="p|search|"] .feed-articulopro-desc-articulo{
  display: none;
}
/* fin fichas articulo */

/* estilos fichas productos feed busqueda */
div[id^="p|search|"] .feed-producto-divimg{
  height: 208px;
}
/* estilos fichas productos feed busqueda */
/* Estilos feed fichas Busqueda */


/* Estilo publicidad en feed */
.buildad.feed{
  margin: 0px 10px 16px;
  float: left;
}
/* fin Estilo publicidad en feed */


/* Estilo para ficha newsletter - columna derecha */
.feed-newsletter-ficha{
  margin: 20px auto 10px;
}
/* fin Estilo para ficha newsletter */

/* icono seguir chef */
.icon-k7-seguir-chef:before{content: "\\e918";}
/* */



/* estilos feed recetarios */
div[id^="p|kiwi|recipebooks|"].feed-producto-ficha, div[id^="p|kiwirec|recipebooks|"].feed-producto-ficha{
  width: 300px;
  margin: 0px 10px 16px;
}
/* fin estilos feed recetarios */
`);
KL.loader.createCSS(``);
KL.loader.createCSS(`/* slider */

.slider
{
  position: relative;
  overflow: hidden;
  height: auto;
}

.slider-container
{
  width: 100000px;
  height: auto;
  position: relative;
  left: 0;
  transition: all 1s ease 0s;
}




.slider-container.noanim
{
  transition: none;
}


.slider-container:after
{
  content: "";
  clear: both;
}

.icon-k7-slider-previous:before{content: "\\e948";}
.icon-k7-slider-next:before{content: "\\e947";}

.slider-button
{
  position: absolute;
  width: 17px;
  height: 18px;
  border-radius: 50%;
  cursor: pointer;
  background-color: rgba(255, 255, 255, 0.8);
  z-index: 2;
  padding: 7px;
  padding-left: 8px;
  top: 50%;
  margin-top: -20px;
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.25);
  transition: opacity 0.2s ease 0s;
  opacity: 0.8;
  font-size: 16px;
  font-weight: 700;
  color: #aaa;
}

.slider-button.left
{
  left: 5px;
}

.slider-button.left:hover
{
  color: #333;
}

.slider-button.right
{
  right: 5px;
}

.slider-button.right:hover
{
  color: #333;
}
`);
KL.loader.createCSS(``);
KL.loader.createCSS(`.recipelist-button {
  background-color: #ffffff;
  border-radius: 2px;
  color: #222;
  cursor: pointer;
  float: left;
  font-size: 1.1em;
  font-weight: normal;
  margin: 5px 10px;
  padding: 14px;
  text-align: center;
  width: 29.45%;
}

.home-recipelist-pro .recipelist-button.on, .familia-recipelist-pro .recipelist-button.on, .clasificacion-recipelistpro .recipelist-button.on{
  background-color: var(--azul-kiwipro);
  color: white;
  position: relative;
}

.recipelist-button.on {
  background-color: var(--verde-kiwi);
  color: white;
  position: relative;
}

/*
.recipelist-button.on:after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  margin-left: -15px;
  width: 0;
  height: 0;
  border-top: solid 10px #8CC63E;
  border-left: solid 10px transparent;
  border-right: solid 10px transparent;
}
*/

.icon-k7-recipelist-seemore:before{content: "\\e956";}
`);
KL.loader.createCSS(`.recipelist-button.on:after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  margin-left: -15px;
  width: 0;
  height: 0;
  /*border-top: solid 10px #8CC63E;*/
  border-left: solid 10px transparent;
  border-right: solid 10px transparent;
}

.home-recipelist-pro .recipelist-button.on:after, .familia-recipelist-pro .recipelist-button.on:after, .clasificacion-recipelistpro .recipelist-button.on:after {
  border-top: solid 10px var(--azul-kiwipro);
}

.recipelist-button.on:after {
  border-top: solid 10px var(--verde-kiwi);
}

#recipelist {
  margin-top: 15px;
}
`);
WA.templates['errorpage'] = WA.templater`
<div style="width: 100%; text-align: center;">
  <div class="buildad" data-id="billboard" data-position="top"></div>
</div>
${'message'}
<div style="align-items: center; background-color: #ffffff; box-sizing: border-box; display: flex; justify-content: space-evenly; margin: 20px auto; padding: 40px 125px; position: relative; width: 960px;">
  <img class="analyzethis" data-src="${['eval','KL.cdn7domains']}/img/static/icono-olla-error.svg" data-width="170" data-height="102" data-webp="1" alt="Error 404" title="Error 404" style="background-image: none; width: 170px; background-color: #ffffff;" />

  <div style="box-sizing: border-box; padding: 0px 0px 0px 35px; position: relative; width: calc(100% - 170px);">
    <h1 style="color: #777777; font-size: 22px; font-weight: bold; margin: 0px;">Error 404</h1>

    <h2 style="color: #333333; font-size: 30px; font-weight: bold; line-height: 32px; margin: 0px 210px 10px 0px;">¡Ups! Algo salió mal en la cocina</h2>

    <p style="color: #777777; font-size: 17px; line-height: 22px;">La información que buscas no se encuentra disponible, nuestros chefs ya están trabajando en ello.</p>
  </div>
</div>

<div id="error_categories" style="margin: 30px auto 0px; position: relative; width: 960px;">
  <h2 style="color: #333333; font-size: 17px; font-weight: lighter; letter-spacing: 0.3px; text-transform: uppercase;">Te damos más ideas de qué cocinar hoy</h2>

  <div style="background-color: #ffffff; box-sizing: border-box; display: flex; flex-wrap: wrap; justify-content: space-evenly; margin: 10px 0px 0px; padding: 20px; position: relative; width: 100%;">
    ${['loop', 'categories','error_clasificaciones']}


  </div>
</div>

<div id="error_recipelist" style="margin-top: 30px;">
  <span style="margin-left: 10px; color: #555555; letter-spacing: 0.05em; text-transform: uppercase; font-size: 17px; font-weight: 100;">Ver recetas por:</span>
  ${['call', 'recipelist','recipelist']}
  <div style="clear: both;"></div>
</div>
`;
WA.templates['error_clasificaciones'] = WA.templater`

    <div style="display: flex; flex-direction: column; margin: 20px; min-height: 154px; text-align: center; width: 120px;">
      <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
        <img class="analyzethis" data-src="/clasificacion/${'key'}/${['cond', 'icon','error_clasificaciones_icon']}" data-width="120" data-height="120" data-webp="1" style="height: 120px; margin: 0px 0px 5px; width: 120px;" />
        ${'shorttitle'}
      </a>
    </div>


`;
WA.templates['error_clasificaciones_icon'] = WA.templater`
${'icon'}`;
WA.templates['error_clasificaciones_icon.none'] = WA.templater`
${'image'}`;
WA.templates['recipefamilydata'] = WA.templater`
<div style="float: right;">${['call', 'social-share']}</div>
<h1 style="color: #333333; font-size: 27px; font-weight: bold; text-transform: uppercase;">${'h1title'}</h1>
<div style="color: #777777; font-size: 15px; line-height: 21px; margin: 20px 0px 0px;">${'description'}</div>
`;
WA.templates['gallery'] = WA.templater`
${['cond', 'homechefispro>client>p','gallerypro']}








































































`;
WA.templates['gallerylinkpro5.none'] = WA.templater`
`;
WA.templates['gallerylinkpro4.none'] = WA.templater`
`;
WA.templates['gallerylinkpro2'] = WA.templater`

        <a href="${'link2'}" class="gallery-item-linkpro" style="margin: 3px 0px;">
          ${'titlelink2'}
        </a>
`;
WA.templates['gallerylink'] = WA.templater`

        <a href="${'link1'}">
  ${['cond', 'homechefispro>client>p','linkgallery']}
          
        </a>
`;
WA.templates['gallerylink6'] = WA.templater`

        <a href="${'link6'}" class="gallery-item-link" style="margin: 3px 0px;">
          ${'titlelink6'}
        </a>
`;
WA.templates['gallerylink5'] = WA.templater`

        <a href="${'link5'}" class="gallery-item-link" style="margin: 3px 0px;">
          ${'titlelink5'}
        </a>
`;
WA.templates['gallery-tipo-slide.2'] = WA.templater`

        <hr style="height: 1px; border-top: 1px solid #999999; border-bottom: 0px; border-left: 0px; border-right: 0px; width: 50%; margin: 0px auto;" />
        <div style="position: relative; display: flex; flex-direction: column; padding: 10px 15px 0px; box-sizing: border-box; width: 100%; margin: 0px auto; font-size: 16px;">
          ${['cond', 'homechefispro>client>p','islinkpro']}
          
          
        </div>
`;
WA.templates['islinkpro'] = WA.templater`

            ${['cond', 'link1','gallerylinkpro1']}
            ${['cond', 'link2','gallerylinkpro2']}
            ${['cond', 'link3','gallerylinkpro3']}
            ${['cond', 'link4','gallerylinkpro4']}
            ${['cond', 'link5','gallerylinkpro5']}
          `;
WA.templates['islinkpro.none'] = WA.templater`

            ${['cond', 'link1','gallerylink1']}
            ${['cond', 'link2','gallerylink2']}
            ${['cond', 'link3','gallerylink3']}
            ${['cond', 'link4','gallerylink4']}
            ${['cond', 'link5','gallerylink5']}
          `;
WA.templates['gallerylink2.none'] = WA.templater`
`;
WA.templates['gallerylink1.none'] = WA.templater`
`;
WA.templates['gallerylinkpro1.none'] = WA.templater`
`;
WA.templates['gallery-tipo-slide.1'] = WA.templater`

        ${['cond', 'link1','gallerylink']}
`;
WA.templates['gallery-tipo-slide.none'] = WA.templater`
`;
WA.templates['gallerylink3.none'] = WA.templater`
`;
WA.templates['gallery_slide.none'] = WA.templater`
`;
WA.templates['gallerylink6.none'] = WA.templater`
`;
WA.templates['gallerylink4.none'] = WA.templater`
`;
WA.templates['gallerylinkpro6.none'] = WA.templater`
`;
WA.templates['gallerylink.none'] = WA.templater`
`;
WA.templates['linkgallery'] = WA.templater`

          <div class="gallery-titlelinkpro">
            ${'titlelink1'}
          </div>
`;
WA.templates['gallerylinkpro1'] = WA.templater`

        <a href="${'link1'}" class="gallery-item-linkpro" style="margin: 3px 0px;">
          ${'titlelink1'}
        </a>
`;
WA.templates['gallerylink2'] = WA.templater`

        <a href="${'link2'}" class="gallery-item-link" style="margin: 3px 0px;">
          ${'titlelink2'}
        </a>
`;
WA.templates['gallerylink3'] = WA.templater`

        <a href="${'link3'}" class="gallery-item-link" style="margin: 3px 0px;">
          ${'titlelink3'}
        </a>
`;
WA.templates['gallerylinkpro3'] = WA.templater`

        <a href="${'link3'}" class="gallery-item-linkpro" style="margin: 3px 0px;">
          ${'titlelink3'}
        </a>
`;
WA.templates['gallerylink4'] = WA.templater`

        <a href="${'link4'}" class="gallery-item-link" style="margin: 3px 0px;">
          ${'titlelink4'}
        </a>
`;
WA.templates['gallerypro.none'] = WA.templater`

<div class="gallery" data-autostart="yes" data-bullets="yes" data-keyboard="yes" data-time="15000" data-animation="slide" style="height: 400px;">
  ${['loop', 'slides','gallery_slide']}
</div>
`;
WA.templates['linkgallery.none'] = WA.templater`

          <div class="gallery-titlelink">
            ${'titlelink1'}
          </div>
`;
WA.templates['gallerylink5.none'] = WA.templater`
`;
WA.templates['gallerylinkpro2.none'] = WA.templater`
`;
WA.templates['gallerypro'] = WA.templater`

<div class="gallery gallerypro" data-autostart="yes" data-bullets="yes" data-keyboard="yes" data-time="15000" data-animation="slide" style="height: 400px;">
  ${['loop', 'slides','gallery_slide']}
</div>
`;
WA.templates['gallerylink1'] = WA.templater`

        <a href="${'link1'}" class="gallery-item-link" style="margin: 3px 0px;">
          ${'titlelink1'}
        </a>
`;
WA.templates['gallery_slide'] = WA.templater`

  <div id="gallery-key-${'key'}">
    <div class="gallery-link">
      
      ${['cond', 'container','rutacontainer']}
      
      

      
      
      
      
      
    </div>

    <div class="gallery-datacontainer">
      <div class="gallery-whiteshadow"></div>

      <div class="gallery-content">
        <h1 class="gallery-title">
          <a href="${'link'}" class="gallery-link-principal">${'title'}</a>
        </h1>

        <div class="gallery-description">
          ${'description'}
        </div>

        ${['cond', 'slidetype','gallery-tipo-slide']}
      </div>
      <div style="clear: both;"></div>
      <div class="gallery-bullet">
        <div></div>
      </div>
    </div>
  </div>
`;
WA.templates['rutacontainer.galeriahome'] = WA.templater`

        
        <a href="${'link'}"><img class="analyzethis" data-src="/${'container'}/${'key'}/${'image'}" data-width="1280" data-height="400" data-webp="1" style="width: 100%;" /></a>
      `;
WA.templates['rutacontainer.craftohome'] = WA.templater`

        <a href="${'link'}"><img class="analyzethis" data-src="/${'container'}/${'key'}/${'image'}" data-width="1280" data-height="400" data-webp="1" style="width: 100%;" /></a>
      `;
WA.templates['rutacontainer.galeria'] = WA.templater`

        
        ${['cond', 'sliderhomeblog>key','keygaleria']}
        
      `;
WA.templates['keygaleria.124'] = WA.templater`

          <a href="${'link'}"><img class="analyzethis" data-src="/articuloimagen/${'objectkey'}/${'image'}" data-width="950" data-height="400" data-webp="1" style="width: 100%;" /></a>
        `;
WA.templates['gallerylinkpro4'] = WA.templater`

        <a href="${'link4'}" class="gallery-item-linkpro" style="margin: 3px 0px;">
          ${'titlelink4'}
        </a>
`;
WA.templates['gallerylinkpro3.none'] = WA.templater`
`;
WA.templates['gallerylinkpro5'] = WA.templater`

        <a href="${'link5'}" class="gallery-item-linkpro" style="margin: 3px 0px;">
          ${'titlelink5'}
        </a>
`;
WA.templates['gallerylinkpro6'] = WA.templater`

        <a href="${'link6'}" class="gallery-item-linkpro" style="margin: 3px 0px;">
          ${'titlelink6'}
        </a>
`;
WA.templates['slider'] = WA.templater`
<div class="slider" style="margin: 10px 0px 0px 0px;">
${['loop', 'payload','feed_payload']}
${['loop', 'classifications','slider_classifications']}
${['loop', 'families','slider_families']}
</div>

























`;
WA.templates['slider_families'] = WA.templater`

<div class="slider-family-${'key'}" style="float: left; padding: 0px 7px; text-align: center; width: 108px;">
  <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
    <img class="analyzethis" data-src="${'imagepath'}${['cond', 'icon','slider_icon']}" data-width="108" data-height="108" data-webp="1" style="height: 108px; margin: 0px 0px 8px; width: 108px;" />${'shorttitle'}
  </a>
</div>
`;
WA.templates['tools'] = WA.templater`



`;
WA.templates['tools_collectionitem.none'] = WA.templater`

Aún no hay colecciones
`;
WA.templates['tools_collectionselect'] = WA.templater`

<div class="tools-divcont" style="height: 300px; width: 300px; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%); background-color: #ffffff; border-radius: 5px; padding: 5px; box-sizing: border-box;">
  <div class="title"><span class="icon-k7-collections"></span> Selecciona una colección</div>
  <div style="position: absolute; overflow: auto; top: 60px; bottom: 60px; left: 8px; right: 8px; padding: 5px; border: 1px solid #ccc; border-radius: 3px;">
${['loop', 'items','tools_collectionitem']}
  </div>
  <div style="position: absolute; bottom: 10px; left: 5px; right: 8px; padding: 0px 0px 0px 5px; box-sizing: border-box;">
    <input id="tools-collection-create" type="button" class="button" style="float: right; width: 60px; height: 38px; padding-top: 2px;" value="Crear">
    ó
    <input id="tools-collection-name" type="text" style="vertical-align: middle; height: 20px; margin-left: 10px; width: 190px; height: 30px; padding-top: 2px;" placeholder="Crea una nueva colección">
  </div>
</div>
`;
WA.templates['tools_collectionitem'] = WA.templater`

<div id="tools-collection-${'clave'}" class="tools-coleccionentrada">${'nombre'}</div>
`;
WA.templates['slider_classifications.last'] = WA.templater`

<div class="slider-clasification-${'key'}" style="float: left; padding: 0px 0px 0px 7px; text-align: center; width: 108px;">
  <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
    <img class="analyzethis" data-src="${'imagepath'}${['cond', 'icon','slider_icon']}" data-width="108" data-height="108" data-webp="1" style="height: 108px; margin: 0px 0px 3px; width: 108px;" />${'shorttitle'}
  </a>
</div>
`;
WA.templates['slider_classifications.none'] = WA.templater`
`;
WA.templates['slider_icon.none'] = WA.templater`
${'image'}`;
WA.templates['slider_classifications'] = WA.templater`

<div class="slider-clasification-${'key'}" style="float: left; padding: 0px 7px; text-align: center; width: 108px;">
  <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
    <img class="analyzethis" data-src="${'imagepath'}${['cond', 'icon','slider_icon']}" data-width="108" data-height="108" data-webp="1" style="height: 108px; margin: 0px 0px 8px; width: 108px;" />${'shorttitle'}
  </a>
</div>
`;
WA.templates['slider_families.first'] = WA.templater`

<div class="slider-family-${'key'}" style="float: left; padding: 0px 7px 0px 0px; text-align: center; width: 108px;">
  <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
    <img class="analyzethis" data-src="${'imagepath'}${['cond', 'icon','slider_icon']}" data-width="108" data-height="108" data-webp="1" style="height: 108px; margin: 0px 0px 8px; width: 108px;" />${'shorttitle'}
  </a>
</div>
`;
WA.templates['slider_icon'] = WA.templater`
${'icon'}`;
WA.templates['feed'] = WA.templater`
<div class="feed" style="margin-top: 10px;">
  ${['loop', 'payload','feed_payload']}
</div>



`;
WA.templates['feed_tip'] = WA.templater`


<div id="${'x'}" class="searchlist-muestra tools feed-tip-ficha" data-type="t" data-key="${'k'}" style="background-color: #ffffff; float: left; overflow: hidden; position: relative;">
  <a href="${'pa'}">
    <div class="feed-tip-ficha-horizontal">
      
      <div id="feed-tip-divimg" class="feed-divimagenficha feed-tip-divimg" style="overflow: hidden; position: relative;">
        <img class="analyzethis" data-src="${['cond', 'i','src-tip']}" data-width="320" data-height="320" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" />
        ${['cond', 'v','feed_video']}
        
        <div class="feed-tip-titulo-seccion" style="background-color: #e6007e; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
          Tip
        </div>
      </div>

      
      <div class="feed-tip-areanombreficha" style="/*height: 52px;*/ position: relative;">
        
        <div class="feed-tip-nombreficha" style="box-sizing: border-box; color: #000000; font-weight: bold; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">

          
          ${['cond', 's','estatustip']}
    
          
          
          
          
        
          
          
          <div class="feed-tip-descripcionficha" style="display: none;">
            ${'ms'}
          </div>
          
          
          <div class="feed-tip-ficha-linkvertip" style="display: none; ">
            Ver el tip <div class="icon-k7-link-vertip" style="color: #8cc63e; display: inline-block; vertical-align: middle; font-size: 10px; margin: 0px 0px 0px 5px;"></div>
          </div>
          
        </div>
      </div>

      <hr style="border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%;" />

      
      
      <div id="feed-tip-rating" class="feed-tip-rating" style="display: table; height: 13px; position: relative;">
        <div class="feed-tip-num" style="display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0px 5px 0px 0px; position: relative; vertical-align: middle;">
          ${'vr'}
        </div>
        <div class="feed-ficha icon-k7-estrellas-v" style="display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
          <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: ${'pr'};"></div>
        </div>
      </div>

      
      <div class="feed-tip-nombrechef" style="/*bottom: 5px;*/ box-sizing: border-box; color: #aaaaaa; font-family: 'source sans pro'; font-style: italic; height: 15px; overflow: hidden; padding: 0px 10px 0px 0px; position: absolute; right: 0px; text-align: right; vertical-align: middle; width: calc(100% - 100px);">
        ${'cn'}
      </div>
    </div>
  </a>
</div>







`;
WA.templates['estatustip.10'] = WA.templater`

          <div class="feed-tip-area-nombrefichapro" style="display: flex; align-items: center; justify-content: space-between;">
            <div class="icon-k7-kiwipro feed-tippro-icon" style="box-sizing: border-box; position: relative; width: 30px; height: 30px; background-color: #8eb4b1; border-radius: 100%; color: #ffffff; margin: 0px; display: flex; align-items: center; justify-content: center; font-size: 20px;"></div>
            
            <div class="feed-tip-nombrefichapro-centrado" style="box-sizing: border-box; padding: 0px; width: calc(100% - 40px); position: relative; max-height: 46px; overflow: hidden; color: #8eb4b1; font-family: crimsonpro-semibold; font-size: 16px; letter-spacing: 0.5px; line-height: 15px; text-align: left; text-transform: uppercase;">
              ${'n'}
            </div>
          </div>
          `;
WA.templates['estatustip'] = WA.templater`

          <div class="feed-tip-nombreficha-div">
            ${'n'}
          </div>
          `;
WA.templates['src-tip'] = WA.templater`
/ss_secreto/${'k'}/${'i'}`;
WA.templates['src-tip.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['feed_payload_none'] = WA.templater`
`;
WA.templates['feed_ad'] = WA.templater`

<div class="buildad feed" style="width: 300px; min-height: 250px; position: relative;" data-id="300x250"></div>
`;
WA.templates['feed_chef'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra feed-chef-ficha" data-type="c" data-key="${'k'}" style="background-color: #ffffff; float: left; height: 250px; margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div class="div_imgfeedficha ${['cond', 'bg','bgclassdefault']}" style="${['cond', 'bg','bgpersonalizado']} background-position: right center; background-repeat: no-repeat; background-size: cover; overflow: hidden; position: relative; vertical-align: top; height: 175px;">
      
      <div class="div_cont_fichaavatarchef" style="background-color: ${['cond', 'co','fondocolor']}; position: absolute; height: 100px; left: 50%; top: 50%; width: 100px; z-index: 2; border-radius: 100%; transform: translateX(-50%) translateY(-59%);">
        ${['cond', 'av','avatarchef']}
      </div>
      
      
      <div style="background: rgba(0, 0, 0, 0) linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.4) 100%) repeat scroll 0px 0px; bottom: 0px; height: 44px; position: absolute; width: 100%;">
        <div style="box-sizing: border-box; color: #ffffff; font-size: 14px; font-weight: bold; max-height: 30px; overflow: hidden; padding: 0px 10px 2px; position: absolute; text-align: center; text-decoration: none; top: 50%; transform: translateY(-50%); width: 100%;">
          ${'fn'} ${'ln'}
        </div>
      </div>

      <div class="feed-chef-titulo-seccion" style="box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Perfil
      </div>
    </div>
  </a>
  
  <div style="box-sizing: border-box; display: table; height: 75px; left: 50%; padding: 0px 15px; position: absolute; transform: translateX(-50%); width: 100%;">
    <div style="position: absolute; top: 50%; transform: translateY(-50%);">
      ${['cond', 'qr','numrecetas']}
      ${['cond', 'qt','numtips']}
      ${['cond', 'qc','numcolecciones']}
    </div>
    
    <div style="color: #777777; font-size: 14px; position: absolute; right: 15px; top: 20px;">Seguidores: <span style="font-weight: bold;">${'qs'}</span></div>
    <div style="color: #777777; font-size: 14px; position: absolute; right: 15px; top: 40px;">Siguiendo: <span style="font-weight: bold;">${'qg'}</span></div>
  </div>
</div>


































`;
WA.templates['fondocolor'] = WA.templater`
${'co'}`;
WA.templates['avatarchef.none'] = WA.templater`

<img class="analyzethis" data-src="/kiwilimon/static/icono-usuario.svg" data-srcalt="/kiwilimon/static/icono-usuario.svg" data-width="96" data-height="96" data-webp="1" alt="${'fn'} ${'ln'}" title="${'fn'} ${'ln'}" style="background-color: #ffffff; background-image: none; border-radius: 100%; left: 50%; max-height: 96px; max-width: 96px; position: absolute; top: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" />
`;
WA.templates['bgclassdefault.none'] = WA.templater`
imgfondochefdefault`;
WA.templates['fondocolor.none'] = WA.templater`
#ffffff`;
WA.templates['numrecetas'] = WA.templater`

      <div style="color: #777777; font-size: 15px; line-height: 14px; margin-top: 3px; text-transform: uppercase;">
        Recetas: <span style="color: #555555; font-size: 16px; font-weight: bold;">${'qr'}</span>
      </div>
`;
WA.templates['bgpersonalizado'] = WA.templater`
background-image: url('${'bg'}');`;
WA.templates['avatarchef'] = WA.templater`

<img src="${'av'}" alt="${'fn'} ${'ln'}" title="${'fn'} ${'ln'}" style="background-color: #ffffff; background-image: none; border-radius: 100%; left: 50%; max-height: 94px; max-width: 94px; position: absolute; top: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" />
`;
WA.templates['numcolecciones'] = WA.templater`

      <div style="color: #777777; font-size: 15px; line-height: 14px; margin-top: 3px; text-transform: uppercase;">
        Colecciones: <span style="color: #555555; font-size: 16px; font-weight: bold;">${'qc'}</span>
      </div>
`;
WA.templates['numtips.none'] = WA.templater`
`;
WA.templates['numtips'] = WA.templater`

      <div style="color: #777777; font-size: 15px; line-height: 14px; margin-top: 3px; text-transform: uppercase;">
        Tips: <span style="color: #555555; font-size: 16px; font-weight: bold;">${'qt'}</span>
      </div>
`;
WA.templates['numrecetas.none'] = WA.templater`
`;
WA.templates['numcolecciones.none'] = WA.templater`
`;
WA.templates['bgclassdefault'] = WA.templater`
`;
WA.templates['bgpersonalizado.none'] = WA.templater`
`;
WA.templates['feed_coleccionventa'] = WA.templater`


${['cond', 'i','portadacoleccion']}










`;
WA.templates['portadacoleccion'] = WA.templater`

<div id="${'x'}" class="tools coleccion-venta-soloportada" data-type="cv" data-key="${'k'}" style="float: left; height: 262px; overflow: hidden; position: relative; width: 200px; margin: 20px 15px; border-radius: 5px;">
  <a href="${'pa'}">
    <img class="analyzethis" alt="${'n'}" title="${'n'}" data-src="${['cond', 'i','imgcoleccion']}" data-width="320" data-height="420" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" />
  </a>
</div>




`;
WA.templates['imgcoleccion'] = WA.templater`
/coleccionventa/${'k'}/${'i'}`;
WA.templates['imgcoleccion.none'] = WA.templater`
`;
WA.templates['portadacoleccion.none'] = WA.templater`

<div id="${'x'}" class="tools coleccion-venta-ficha" data-type="cv" data-key="${'k'}" style="height: 262px; background-color: #ffffff; float: left; margin: 20px 15px; overflow: hidden; position: relative; width: 200px; box-shadow: 0px 0px 2px rgb(0, 0, 0, 0.4);">
  <a href="${'pa'}">
    <div class="coleccionventa-area">
    <div style="position: relative; width: 100%; display: flex; flex-wrap: wrap; justify-content: space-between;">
      
      <div style="margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.8%; height: 100px;">
        <img class="analyzethis" data-src="${['cond', 'i1','coleccion1']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" /></div>
      <div style="margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.8%; height: 100px;">
        <img class="analyzethis" data-src="${['cond', 'i2','coleccion2']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" /></div>
      <div style="margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.8%; height: 100px;">
        <img class="analyzethis" data-src="${['cond', 'i3','coleccion3']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" /></div>
      <div style="margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.8%; height: 100px;">
        <img class="analyzethis" data-src="${['cond', 'i4','coleccion4']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" /></div>
    </div>

    
    <div style="clear: both; position: relative; height: 60px;">
      <div style="box-sizing: border-box; color: #333333; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; text-decoration: none; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>
    </div>
  </a>

  <div class="feed-coleccionventa-titulo-seccion" style="background-color: #8cc63e; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
    Colección de Venta
  </div>
</div>














`;
WA.templates['coleccion4.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['coleccion1'] = WA.templater`
/recetaimagen/${'ci1'}/${'i1'}`;
WA.templates['coleccion1.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['coleccion2'] = WA.templater`
/recetaimagen/${'ci2'}/${'i2'}`;
WA.templates['coleccion2.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['coleccion3'] = WA.templater`
/recetaimagen/${'ci3'}/${'i3'}`;
WA.templates['coleccion3.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['coleccion4'] = WA.templater`
/recetaimagen/${'ci4'}/${'i4'}`;
WA.templates['feed_compilaciontip'] = WA.templater`


<div id="${'x'}" class="tools feed-compilaciontip-ficha" data-type="kt" data-key="${'k'}" style="background-color: #ffffff; float: left; /*margin: 0px 10px 16px;*/ overflow: hidden; position: relative; /*width: 300px;*/">
  <a href="${'pa'}">
    <div class="feed-compilaciontip-divimg" style="overflow: hidden; position: relative; /*width: 300px;*/">
      <img class="analyzethis compilaciontip-img" data-src="${['cond', 'i','src-compilaciontip']}" data-width="400" data-height="300" data-webp="1" style="position: absolute; top: 50%; /*height: inherit;*/ /*transform: translateY(-50%);*/ vertical-align: top; width: 100%;" />
      ${['cond', 'v','feed_video']}

      <div class="feed-compilaciontip-titulo-seccion" style="background-color: #e6007e; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Compilación
      </div>
    </div>
    
    
    <div class="feed-compilaciontip-areanombreficha" style="position: relative;">
      <div class="feed-compilaciontip-nombreficha" style="box-sizing: border-box; /*color: #000000;*/ /*font-size: 17px;*/ /*font-weight: bold;*/ /*line-height: 18px;*/ /*max-height: 38px;*/ overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>
    
    <hr class="feed-linea-separador-compilacion" style="border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%;" />
    
    
    <div class="feed-compilaciontip-descripcion" style="height: 38px; position: relative; width: 100%;">
      <div style="box-sizing: border-box; color: #777777; max-height: 27px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">
        
        ${'d'}
      </div>
    </div>
  </a>
</div>







`;
WA.templates['src-compilaciontip.none'] = WA.templater`
/img/static/logo_o-400x300.png`;
WA.templates['src-compilaciontip'] = WA.templater`
/menutip/${'k'}/${'i'}`;
WA.templates['feed_familiatip'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra tools feed-familiatip-ficha" data-type="ft" data-key="${'k'}" style="background-color: #ffffff; float: left; height: 250px; margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div style="display: flex; flex-wrap: wrap; height: 208px; overflow: hidden; justify-content: space-evenly; position: relative; width: 100%; align-content: center;">
      <div class="familiatip-${'ci1'}" style="height: 103px; margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i1','src-familiatip1']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="familiatip-${'ci2'}" style="height: 103px; margin: 0px 0px 1px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i2','src-familiatip2']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="familiatip-${'ci3'}" style="height: 103px; margin: 1px 0px 0px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i3','src-familiatip3']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="familiatip-${'ci1'}" style="height: 103px; margin: 1px 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i4','src-familiatip4']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>

      <div class="feed-familiatip-titulo-seccion" style="background-color: #704a98; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Familia
      </div>
    </div>

    <div style="position: relative; height: 42px;">
      <div style="color: #333333; text-decoration: none; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%; padding: 0px 10px; box-sizing: border-box;">
        ${'n'}
      </div>
    </div>
  </a>
</div>
















`;
WA.templates['src-familiatip2'] = WA.templater`
/ss_secreto/${'ci2'}/${'i2'}`;
WA.templates['src-familiatip2.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiatip3'] = WA.templater`
/ss_secreto/${'ci3'}/${'i3'}`;
WA.templates['src-familiatip3.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiatip4'] = WA.templater`
/ss_secreto/${'ci4'}/${'i4'}`;
WA.templates['src-familiatip4.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiatip1'] = WA.templater`
/ss_secreto/${'ci1'}/${'i1'}`;
WA.templates['src-familiatip1.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['feed_video'] = WA.templater`
<div class="videoplay"><span class="icon-k7-play"></span></div>

`;
WA.templates['feed_video.none'] = WA.templater`
`;
WA.templates['feed_recetaslider'] = WA.templater`

<div id="${'x'}" class="tools recetaslider-ficha" data-type="r" data-key="${'k'}" style="background-color: #ffffff; display: table; float: left; margin: 0px 15px 0px 0px; position: relative; width: 190px;">
  <a href="${'pa'}">
    <div class="feed-receta-ficha-horizontal">
      <div class="feed-recetaslider-divimagenficha" style="width: 190px; height: 190px; position: relative;">
        <img class="analyzethis recetaslider-imgficha" data-src="${['cond', 'i','src-recetaslider']}" data-width="190" data-height="190" data-webp="1" style="width: 190px; height: 190px; vertical-align: top;" />
        ${['cond', 'v','feed_video']}
      </div>

      
      ${['cond', 's','estatusrecetaslider']}
      
      
      
      
      
      

      
      <div class="recetaslider-rating" style="height: 13px; margin: 0px auto; position: relative;">
        <div class="feed-recetas-num" style="display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0 5px 0 0; position: relative; vertical-align: middle;">
          ${'vr'}
        </div>
        <div class="feed-ficha icon-k7-estrellas-v" style="display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
          <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: ${'pr'};"></div>
        </div>
      </div>
    </div>
  </a>
</div>






`;
WA.templates['src-recetaslider'] = WA.templater`
/recetaimagen/${'k'}/${'i'}`;
WA.templates['src-recetaslider.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['estatusrecetaslider.10'] = WA.templater`

      
      <div class="recetasliderpro-areanombreficha" style="position: relative;">
        <div class="icon-k7-kiwipro recetaslider-icon-pro" style="box-sizing: border-box; position: relative; /*width: 20px; height: 20px;*/ background-color: #8eb4b1; border-radius: 100%; color: #ffffff; /*margin: 0px 0px 0px 10px;*/ display: flex; align-items: center; justify-content: center; /*font-size: 13px;*/"></div>
        
        <div class="recetasliderpro-nombreficha" style="box-sizing: border-box; color: #8eb4b1; font-family: crimsonpro-semibold; /*font-size: 13px;*/ letter-spacing: 0.5px; line-height: 15px; /*max-height: 32px;*/ overflow: hidden; padding: 0px 10px; position: absolute; top: 50%; right: 0px; transform: translateY(-50%); text-align: left; text-transform: uppercase; /*width: calc(100% - 30px);*/">
          ${'n'}
        </div>
      </div>
      `;
WA.templates['estatusrecetaslider'] = WA.templater`

      
      <div class="recetaslider-areanombreficha" style="position: relative;">
        <div class="recetaslider-nombreficha" style="box-sizing: border-box; line-height: 15px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; text-transform: uppercase; top: 50%; transform: translateY(-50%); width: 100%;">
          ${'n'}
        </div>
      </div>
      `;
WA.templates['estatusrecetaslider.none'] = WA.templater`
`;
WA.templates['feed_articulo'] = WA.templater`


<div id="${'x'}" class="tools searchlist-muestra feed-articulo-ficha" data-type="a" data-key="${'k'}">
  <a href="${'pa'}" class="feed-articulo-href-articulo" style="text-decoration: none;">
  <div class="feed-articulo-divcontenido">
    <div class="feed-articulo-divimg-articulo">
      <img class="analyzethis" data-src="${['cond', 'i','src-articuloi']}" data-width="320" data-height="320" data-webp="1" alt="${'n'}" title="${'n'}" style="position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" />

      <div class="id_tema_${'cl'} feed-articulo-titulo-seccion" style="background-color: #24b2b3; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Blog
      </div>
      <div class="id_tema_${'cl'} feed-articulo-titulo-nombreseccion" style="display: none;">
        ${'cln'}
      </div>
    </div>
    
    
    ${['cond', 's','estatusarticulo']}
    
    
    
    

    
    
  </div>
  </a>
</div>





















`;
WA.templates['src-articuloi.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['estatusarticulo'] = WA.templater`

    <div class="feed-articulo-divtextos-articulo">
      <div class="feed-articulo-nombre-articulo">
        ${'n'}
      </div>

      <hr class="feed-articulo-separador" style="display: none; border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%; position: absolute; /*bottom: 27px;*/ left: 50%; transform: translateX(-50%);">
      
      <div class="feed-articulo-nombre-autor" style="display: none;">
        ${'cn'}
      </div>
      
      <div class="feed-articulo-desc-articulo">
        ${'ms'}
      </div>
      
      <div class="feed-articulo-area-rating" style="display: none;">
        ${['cond', 'vr','ratingarticulo']}
      </div>
      
      <div class="feed-articulo-cont-lectura" style="display: none;">
        Continuar leyendo
      </div>
    </div>
    `;
WA.templates['estatusarticulo.none'] = WA.templater`
`;
WA.templates['src-articuloi'] = WA.templater`
/articuloimagen/${'k'}/${'i'}`;
WA.templates['src-articulo.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['ratingarticulo.none'] = WA.templater`

<div class="feed-articulo-rating" style="display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0px 5px 0px 0px; position: relative; vertical-align: middle;">
  5.0
</div>
<div class="feed-ficha icon-k7-estrellas-v" style="display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
  <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: 100%;"></div>
</div>
`;
WA.templates['estatusarticulo.10'] = WA.templater`

    <div class="feed-articulopro-divtextos-articulo">
      
      <div class="feed-articulopro-area-titulo">
        <div class="icon-k7-kiwipro feed-articulopro-icon" style="box-sizing: border-box; position: relative; width: 30px; height: 30px; background-color: #8eb4b1; border-radius: 100%; color: #ffffff; margin: 0px 0px 0px 20px; display: flex; align-items: center; justify-content: center; font-size: 20px;"></div>
      
        <div class="feed-articulopro-nombre-articulo">
          ${'n'}
        </div>
      </div>

      <hr class="feed-articulopro-separador" style="display: none; border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%; position: absolute; /*bottom: 27px;*/ left: 50%; transform: translateX(-50%);">
      
      <div class="feed-articulopro-nombre-autor" style="display: none;">
        ${'cn'}
      </div>
      
      <div class="feed-articulopro-desc-articulo">
        ${'ms'}
      </div>
      
      <div class="feed-articulopro-area-rating" style="display: none;">
        ${['cond', 'vr','ratingarticulo']}
      </div>
      
      <div class="feed-articulopro-cont-lectura" style="display: none;">
        Continuar leyendo
      </div>

      <div class="feed-articulo-clasificacion-articulo" style="display: none;">
        <div class="feed-articulo-area-nombre-clasificacion">
          ${'cln'}
        </div>
      </div>
    </div>
    `;
WA.templates['src-articulo'] = WA.templater`
${'ip'}`;
WA.templates['ratingarticulo'] = WA.templater`

<div class="feed-articulo-rating" style="display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0px 5px 0px 0px; position: relative; vertical-align: middle;">
  ${'vr'}
</div>
<div class="feed-ficha icon-k7-estrellas-v" style="display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
  <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: ${'pr'};"></div>
</div>
`;
WA.templates['feed_clasificacionarticulo'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra feed-clasificacionarticulo-ficha" data-type="ca" data-key="${'k'}" style="background-color: #ffffff; float: left; height: 250px; margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div style="display: flex; flex-wrap: wrap; height: 208px; overflow: hidden; justify-content: space-evenly; position: relative; width: 100%; align-content: center;">
      <div style="height: 103px; margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i','src-clasificacionarticulo']}" data-width="150" data-height="150" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div style="height: 103px; margin: 0px 0px 1px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i','src-clasificacionarticulo']}" data-width="150" data-height="150" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div style="height: 103px; margin: 1px 0px 0px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i','src-clasificacionarticulo']}" data-width="150" data-height="150" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div style="height: 103px; margin: 1px 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i','src-clasificacionarticulo']}" data-width="150" data-height="150" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>

      <div class="feed-clasificacionarticulo-titulo-seccion id_tema_${'cl'}" style="background-color: #24b2b3; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Clasificación
      </div>
    </div>

    <div style="position: relative; height: 42px;">
      <div style="color: #333333; text-decoration: none; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%; padding: 0px 10px; box-sizing: border-box;">
        ${'n'}
      </div>
    </div>
  </a>
</div>







`;
WA.templates['src-clasificacionarticulo.none'] = WA.templater`
/img/static/logo-o-150.png`;
WA.templates['src-clasificacionarticulo'] = WA.templater`
/articuloimagen/${'k'}/${'i'}`;
WA.templates['feed_clasificaciontip'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra tools feed-clasificaciontip-ficha" data-type="ct" data-key="${'k'}" style="background-color: #ffffff; float: left; height: 250px; margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div style="display: flex; flex-wrap: wrap; height: 208px; overflow: hidden; justify-content: space-evenly; position: relative; width: 100%; align-content: center;">
      <div class="clasificaciontip-${'ci1'}" style="height: 103px; margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i1','src-clasificaciontip1']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="clasificaciontip-${'ci2'}" style="height: 103px; margin: 0px 0px 1px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i2','src-clasificaciontip2']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="clasificaciontip-${'ci3'}" style="height: 103px; margin: 1px 0px 0px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i3','src-clasificaciontip3']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="clasificaciontip-${'ci4'}" style="height: 103px; margin: 1px 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i4','src-clasificaciontip4']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>

      <div class="feed-clasificaciontip-titulo-seccion" style="background-color: #e6007e; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Clasificación
      </div>
    </div>

    <div style="position: relative; height: 42px;">
      <div style="color: #333333; text-decoration: none; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%; padding: 0px 10px; box-sizing: border-box;">
        ${'n'}
      </div>
    </div>
  </a>
</div>
















`;
WA.templates['src-clasificaciontip2.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificaciontip3'] = WA.templater`
/ss_secreto/${'ci3'}/${'i3'}`;
WA.templates['src-clasificaciontip3.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificaciontip4'] = WA.templater`
/ss_secreto/${'ci4'}/${'i4'}`;
WA.templates['src-clasificaciontip4.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificaciontip1'] = WA.templater`
/ss_secreto/${'ci1'}/${'i1'}`;
WA.templates['src-clasificaciontip1.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificaciontip2'] = WA.templater`
/ss_secreto/${'ci2'}/${'i2'}`;
WA.templates['feed_compilacionreceta'] = WA.templater`

<div id="${'x'}" class="tools feed-compilacionreceta-ficha" data-type="kr" data-key="${'k'}" style="background-color: #ffffff; float: left; /*height: 275px;*/ margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div class="feed-compilacionreceta-divimg" style="/*height: 194px;*/ overflow: hidden; position: relative; width: 300px;">
      <img class="analyzethis compilacionreceta-img" data-src="${['cond', 'i','src-compilacionreceta']}" data-width="400" data-height="300" data-webp="1" style="position: absolute; top: 50%; /*height: inherit;*/ transform: translateY(-50%); vertical-align: top; width: 100%;" />
      ${['cond', 'v','feed_video']}
      
      <div class="feed-compilacionreceta-titulo-seccion" style="background-color: #8cc63e; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Compilación
      </div>
    </div>

    
    <div class="feed-compilacionreceta-areanombreficha" style="/*height: 42px;*/ position: relative;">
      <div class="feed-compilacionreceta-nombreficha" style="box-sizing: border-box; color: #000000; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>

    <hr class="feed-linea-separador-compilacion" style="border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%;" />

    
    <div class="feed-compilacionreceta-descripcion" style="height: 38px; position: relative; width: 100%;">
      <div style="box-sizing: border-box; color: #777777; max-height: 27px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">
        
        ${'d'}
      </div>
    </div>
  </a>
</div>







`;
WA.templates['src-compilacionreceta.none'] = WA.templater`
/img/static/logo_o-400x300.png`;
WA.templates['src-compilacionreceta'] = WA.templater`
/menu/${'k'}/${'i'}`;
WA.templates['feed_articuloslider'] = WA.templater`
<div id="${'x'}" class="tools articuloslider-ficha" data-type="a" data-key="${'k'}" style="float: left; position: relative; background-color: #ffffff; width: 190px; margin: 0px 15px 0px 0px;">
  <a href="${'pa'}">
  <img class="analyzethis" data-src="${['cond', 'i','src-articuloslider']}" data-width="190" data-height="190" data-webp="1" style="width: 190px; height: 190px; vertical-align: top;" />
  
  
  
  ${['cond', 's','estatusarticuloslider']}
  
  
  
  
  
  
  
  </a>
</div>










`;
WA.templates['src-articuloslider'] = WA.templater`
/articuloimagen/${'k'}/${'i'}`;
WA.templates['src-articuloslider.none'] = WA.templater`

  ${['cond', 'ip','src-altarticuloslider']}
  
  
  
`;
WA.templates['src-altarticuloslider'] = WA.templater`
${'ip'}`;
WA.templates['src-altarticuloslider.none'] = WA.templater`
/img/static/logo-o-150.png`;
WA.templates['estatusarticuloslider.10'] = WA.templater`

  <div class="articulosliderpro-areanombreficha" style="position: relative; overflow: hidden;">
    <div class="icon-k7-kiwipro articulosliderpro-icon-pro" style="box-sizing: border-box; position: relative; /*width: 20px; height: 20px;*/ background-color: #8eb4b1; border-radius: 100%; color: #ffffff; /*margin: 0px 0px 0px 10px;*/ display: flex; align-items: center; justify-content: center; /*font-size: 13px;*/"></div>
    
    <div class="articulosliderpro-nombreficha" style="box-sizing: border-box; color: #8eb4b1; font-family: crimsonpro-semibold; /*font-size: 13px;*/ letter-spacing: 0.5px; line-height: 15px; /*max-height: 32px;*/ overflow: hidden; padding: 0px 10px; position: absolute; top: 50%; right: 0px; transform: translateY(-50%); text-align: left; text-transform: uppercase; /*width: calc(100% - 30px);*/">
      ${'n'}
    </div>
  </div>
  `;
WA.templates['estatusarticuloslider'] = WA.templater`

  <div class="articuloslider-areanombreficha" style="position: relative; overflow: hidden;">
    <div class="articuloslider-nombreficha" style="box-sizing: border-box; line-height: 15px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; text-transform: uppercase; top: 50%; transform: translateY(-50%); width: 100%;">
      ${'n'}
    </div>
  </div>
  `;
WA.templates['estatusarticuloslider.none'] = WA.templater`
`;
WA.templates['feed_compilacionrecetaslider'] = WA.templater`

<div id="${'x'}" class="tools compilacionrecetaslider-ficha" data-type="kr" data-key="${'k'}" style="float: left; position: relative; background-color: #ffffff; width: 190px; margin: 0px 15px 0px 0px; ">
  <a href="${'pa'}">
    <div style="position: relative;">
      <img class="analyzethis" data-src="${['cond', 'i','src-compilacionrecetaslider']}" data-width="190" data-height="190" data-webp="1" style="width: 190px; height: 190px; vertical-align: top;" />
      ${['cond', 'v','feed_video']}
    </div>

    <div class="compilacionrecetaslider-areanombreficha" style="position: relative;">
      <div class="compilacionrecetaslider-nombreficha" style="box-sizing: border-box; line-height: 15px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; text-transform: uppercase; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>
  </a>
</div>







`;
WA.templates['src-compilacionrecetaslider.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-compilacionrecetaslider'] = WA.templater`
/menu/${'k'}/${'i'}`;
WA.templates['feed_familiareceta'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra tools feed-familiareceta-ficha" data-type="fr" data-key="${'k'}" style="background-color: #ffffff; float: left; height: 250px; margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div style="display: flex; flex-wrap: wrap; height: 208px; overflow: hidden; justify-content: space-evenly; position: relative; width: 100%; align-content: center;">
      <div class="familiareceta-${'ci1'}" style="height: 103px; margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'ci1','src-familiareceta1']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="familiareceta-${'ci2'}" style="height: 103px; margin: 0px 0px 1px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'ci2','src-familiareceta2']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="familiareceta-${'ci3'}" style="height: 103px; margin: 1px 0px 0px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'ci3','src-familiareceta3']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="familiareceta-${'ci4'}" style="height: 103px; margin: 1px 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'ci4','src-familiareceta4']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>

      <div class="feed-familiareceta-titulo-seccion" style="background-color: #fca032; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Familia
      </div>
    </div>

    <div style="position: relative; height: 42px;">
      <div style="color: #333333; text-decoration: none; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%; padding: 0px 10px; box-sizing: border-box;">
        ${'n'}
      </div>
    </div>
  </a>
</div>
















`;
WA.templates['src-familiareceta4.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiareceta1'] = WA.templater`
/recetaimagen/${'ci1'}/${'i1'}`;
WA.templates['src-familiareceta1.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiareceta2'] = WA.templater`
/recetaimagen/${'ci2'}/${'i2'}`;
WA.templates['src-familiareceta2.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiareceta3'] = WA.templater`
/recetaimagen/${'ci3'}/${'i3'}`;
WA.templates['src-familiareceta3.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-familiareceta4'] = WA.templater`
/recetaimagen/${'ci4'}/${'i4'}`;
WA.templates['feed_receta'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra tools feed-receta-ficha" data-type="r" data-key="${'k'}" style="background-color: #ffffff; float: left; /*height: 275px;*/ margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div class="feed-divimagenficha feed-receta-divimg" style="/*height: 194px;*/ overflow: hidden; position: relative; width: 300px;">
      
      <img class="analyzethis" data-src="${['cond', 'i','src-receta']}" data-width="400" data-height="300" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" />
      ${['cond', 'v','feed_video']}
      
      <div class="feed-receta-titulo-seccion" style="background-color: #8cc63e; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Receta
      </div>
    </div>

    
    ${['cond', 's','estatusreceta']}
    
    
    
    
    
    
    
    <hr style="border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%;" />

    
    <div class="feed-receta-rating" style="display: table; height: 13px; margin: 0px 0px 0px 10px; /*padding: 8px 0px 0px;*/ position: relative;">
      <div style="color: #8cc63e; display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0px 5px 0px 0px; position: relative; vertical-align: middle;">
        ${'vr'}
      </div>
      <div class="feed-ficha icon-k7-estrellas-v" style="color: #8cc63e; display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
        <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: ${'pr'};"></div>
      </div>
    </div>

    
    <div class="feed-receta-nombrechef" style="/*bottom: 5px;*/ box-sizing: border-box; color: #aaaaaa; font-family: 'source sans pro'; font-style: italic; height: 15px; overflow: hidden; padding: 0px 10px 0px 0px; position: absolute; right: 0px; text-align: right; vertical-align: middle; width: calc(100% - 100px);">
      ${'cn'}
    </div>
  </a>
</div>





`;
WA.templates['estatusreceta.10'] = WA.templater`

    
    <div class="feed-recetapro-areanombreficha" style="/*height: 52px;*/ position: relative;">
      <div class="icon-k7-kiwipro feed-recetapro-icon" style="box-sizing: border-box; position: relative; width: 30px; height: 30px; background-color: #8eb4b1; border-radius: 100%; color: #ffffff; margin: 0px 0px 0px 20px; display: flex; align-items: center; justify-content: center; font-size: 20px;"></div>
      
      <div class="feed-receta-nombreficha-centrado" style="box-sizing: border-box; color: #8eb4b1; font-family: crimsonpro-semibold; font-size: 16px; letter-spacing: 0.5px; line-height: 15px; max-height: 32px; overflow: hidden; padding: 0px 10px; position: absolute; top: 50%; right: 0px; transform: translateY(-50%); text-transform: uppercase; width: calc(100% - 50px);">
        ${'n'}
      </div>
    </div>
    `;
WA.templates['estatusreceta'] = WA.templater`

    
    <div class="feed-receta-areanombreficha" style="/*height: 52px;*/ position: relative;">
      <div class="feed-receta-nombreficha-centrado" style="box-sizing: border-box; color: #000000; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>
    `;
WA.templates['estatusreceta.none'] = WA.templater`
`;
WA.templates['src-receta'] = WA.templater`
/recetaimagen/${'k'}/${'i'}`;
WA.templates['src-receta.none'] = WA.templater`
/img/static/logo_o-400x300.png`;
WA.templates['feed_productoslider'] = WA.templater`
${['cond', 'k','claverecetario']}














`;
WA.templates['claverecetario.106'] = WA.templater`
`;
WA.templates['claverecetario'] = WA.templater`

<div id="${'x'}" class="tools productoslider-ficha" data-type="p" data-key="${'k'}" style="float: left; position: relative; width: 250px; margin-right: 15px; display: table; background-color: white;">
  <a href="${'pa'}">
    <img class="analyzethis" data-src="${['cond', 'i','src-productoslider']}" data-width="250" data-height="250" data-webp="1" alt="${'n'}" title="${'n'}" style="width: 250px; height: 250px; vertical-align: top;" />
  </a>
</div>
`;
WA.templates['src-productoslider'] = WA.templater`
/productoventa/${'k'}/${'i'}`;
WA.templates['src-productoslider.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['feed_articulolarge'] = WA.templater`
<div id="${'x'}" class="tools feed-divarticulolarge" data-type="a" data-key="${'k'}" style="float: left; position: relative; background-color: #ffffff; width: 600px; margin: 0px 15px 0px 0px;">
  <a href="${'pa'}">
    <img class="analyzethis" data-src="${['cond', 'ip','src-articulolarge']}" data-width="265" data-height="265" data-webp="1" style="float: left; width: 265px; height: 265px;" />
    <div class="feed-articulolarge-thumb-titulo-seccion id_tema_${'cl'}" style="box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
      ${'cln'}
    </div>
    
    <div style="float: left; height: 265px; position: relative; width: calc(100% - 265px);">
      <div style="box-sizing: border-box; color: #333333; font-size: 15px; line-height: 19px; max-height: 230px; overflow: hidden; padding: 0px 20px; position: absolute; top: 50%; transform: translateY(-50%); width: 100%;">
        <h2 style="color: #333333; font-size: 18px; font-weight: bold; line-height: 20px; margin: 0px 0px 15px; max-height: 62px; overflow: hidden; text-transform: uppercase;">
          ${'n'}
        </h2>
        ${'ms'}<span style="color: #8cc63e;">...continurar leyendo</span>
      </div>
    </div>
  </a>
</div>







`;
WA.templates['src-articulolarge'] = WA.templater`
${'ip'}`;
WA.templates['src-articulolarge.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['feed_quiz'] = WA.templater`



<div id="${'x'}" class="searchlist-muestra feed-quiz-ficha" data-type="q" data-key="${'k'}" style="background-color: #ffffff; float: left; /*height: 275px;*/ margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div class="feed-quiz-divimg" style="/*height: 194px;*/ overflow: hidden; position: relative; width: 300px;">
      
      <img class="analyzethis" data-src="${['cond', 'i','src-quizz']}" data-srcalt="${['cond', 'i','src-altquizz']}" data-width="400" data-height="300" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" />
      
      <div class="feed-quiz-titulo-seccion" style="background-color: #f76d85; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Quiz
      </div>
    </div>

    
    <div class="feed-quiz-areanombreficha" style="/*height: 52px;*/ position: relative;">
      <div style="box-sizing: border-box; color: #000000; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>

    <hr class="feed-linea-separador" style="border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 1px solid #eeeeee; color: #eeeeee; height: 1px; margin: 0px auto; width: 94%;" />

    
    <div class="feed-quiz-rating" style="display: table; height: 13px; margin: 0px 0px 0px 10px; /*padding: 8px 0px 0px;*/ position: relative;">
      <div style="color: #8cc63e; display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0px 5px 0px 0px; position: relative; vertical-align: middle;">
        ${'vr'}
      </div>
      <div class="feed-ficha icon-k7-estrellas-v" style="color: #8cc63e; display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
        <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: ${'pr'};"></div>
      </div>
    </div>

    
    <div class="feed-quiz-nombrechef" style="/*bottom: 5px;*/ box-sizing: border-box; color: #aaaaaa; font-family: 'source sans pro'; font-style: italic; height: 15px; overflow: hidden; padding: 0px 10px 0px 0px; position: absolute; right: 0px; text-align: right; vertical-align: middle; width: calc(100% - 100px);">
       Chef Kiwilimón
    </div>
  </a>
</div>















`;
WA.templates['src-quizz'] = WA.templater`
/quizz/${'k'}/${'i'}`;
WA.templates['src-quizz.none'] = WA.templater`
/img/static/logo_o-400x300.png`;
WA.templates['src-altquizz'] = WA.templater`
/quizz/${'k'}/thumb400x300-${'i'}`;
WA.templates['src-altquizz.none'] = WA.templater`
/img/static/logo_o-400x300.png`;
WA.templates['feed_newsletter'] = WA.templater`
<div id="${'x'}" class="feed-newsletter-ficha" style="width: 100%; /*margin: 5px auto 10px;*/ position: relative; float: left; padding-top: 10px;">
  <div style="width: 94%; min-width: 300px; margin: 0px auto; box-sizing: border-box; position: relative; background-image: url('https://cdn.kiwilimon.com/kiwi5/static/newsletter-bg2.jpg'); background-size: cover; background-repeat: no-repeat; background-position: top right; padding: 20px;">
    <div style=" width: 58%; line-height: 16px; font-size: 12px; font-weight: 200; position: relative; color: #ffffff; text-align: left; text-transform: uppercase;">
      Suscríbete al <span style="font-weight: bold;">news</span> de <span style="font-weight: bold;">kiwi</span> y recibe <span style="font-weight: bold;">recetas originales de temporada, menús</span> y mucho más cada semana en tu <span style="font-weight: bold;">inbox</span>.
    </div>
    
    
    <div style="position: relative; margin: 20px 0px 0px; box-sizing: border-box; width: 100%; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;">
      <input id="newsletter" type="text" name="newsletter" placeholder="e-mail" style="box-sizing: border-box; font-size: 12px; padding: 6px 7px 7px; width: 57%; border: 0px;" value="${'correoParaSuscribir'}" />
      
      <div onclick="KL.Modules.client.sendnewsletter();" style="background-color: #8cc63e; cursor: pointer; color: #ffffff; font-size: 13px; font-weight: normal; padding: 7px 20px; text-align: center; text-transform: uppercase; width: 20%;">
        Enviar
      </div>
    </div>
  </div>
</div>
`;
WA.templates['feed_tipslider'] = WA.templater`

<div id="${'x'}" class="tools tipslider-ficha" data-type="t" data-key="${'k'}" style="background-color: #ffffff; display: table; float: left; margin: 0px 15px 0px 0px; position: relative; width: 190px;">
  <a href="${'pa'}">
    <div style="width: 190px; height: 190px; position: relative;">
      <img class="analyzethis" data-src="${['cond', 'i','src-tipslider']}" data-width="190" data-height="190" data-webp="1" style="width: 190px; height: 190px; vertical-align: top;" />
      ${['cond', 'v','feed_video']}
    </div>

    <div class="tipslider-areanombreficha" style="position: relative;">

      
      
      ${['cond', 's','estatustipslider']}

      
      
      

    </div>

    
    <div class="tipslider-rating" style="height: 13px; margin: 0px auto; position: relative;">
      <div class="tipslider-rating-numero" style="display: table-cell; font-family: 'source sans pro'; font-weight: normal; height: 13px; padding: 0 5px 0 0; position: relative; vertical-align: middle;">
        ${'vr'}
      </div>
      <div class="feed-ficha icon-k7-estrellas-v" style="display: table-cell; height: 13px; position: relative; vertical-align: middle; width: 62px;">
        <div class="feed-ficha icon-k7-estrellas-r" style="height: 13px; left: 0px; overflow: hidden; position: absolute; top: 0px; width: ${'pr'};"></div>
      </div>
    </div>
  </a>
</div>






`;
WA.templates['estatustipslider.10'] = WA.templater`

      <div class="tipsliderpro-nombreficha" style="display: flex; align-items: center; justify-content: space-between;">
        <div class="icon-k7-kiwipro tipsliderpro-icon" style="box-sizing: border-box; position: relative; width: 30px; height: 30px; background-color: #8eb4b1; border-radius: 100%; color: #ffffff; margin: 0px; display: flex; align-items: center; justify-content: center; font-size: 20px;"></div>
        <div class="tipsliderpro-nombreficha-centrado" style="box-sizing: border-box; padding: 0px; width: calc(100% - 40px); position: relative; max-height: 46px; overflow: hidden; color: #8eb4b1; font-family: crimsonpro-semibold; font-size: 16px; letter-spacing: 0.5px; line-height: 15px; text-align: left; text-transform: uppercase;">
          ${'n'}
        </div>
      </div>
      `;
WA.templates['estatustipslider'] = WA.templater`

      <div class="tipslider-nombreficha" style="box-sizing: border-box; line-height: 15px; overflow: hidden; padding: 0px 10px; position: absolute; text-align: center; text-transform: uppercase; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
      `;
WA.templates['src-tipslider'] = WA.templater`
/ss_secreto/${'k'}/${'i'}`;
WA.templates['src-tipslider.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['feed_payload'] = WA.templater`
${['call', '','t','feed_']}`;
WA.templates['feed_clasificacionreceta'] = WA.templater`

<div id="${'x'}" class="searchlist-muestra tools feed-clasificacionreceta-ficha" data-type="cr" data-key="${'k'}" style="background-color: #ffffff; float: left; height: 250px; margin: 0px 10px 16px; overflow: hidden; position: relative; width: 300px; /*margin: 0px 12px 24px;*/">
  <a href="${'pa'}">
    <div style="display: flex; flex-wrap: wrap; height: 208px; overflow: hidden; justify-content: space-evenly; position: relative; width: 100%; align-content: center;">
      <div class="clasificacionreceta-${'ci1'}" style="height: 103px; margin: 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i1','src-clasificacionreceta1']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="clasificacionreceta-${'ci2'}" style="height: 103px; margin: 0px 0px 1px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i2','src-clasificacionreceta2']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="clasificacionreceta-${'ci3'}" style="height: 103px; margin: 1px 0px 0px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i3','src-clasificacionreceta3']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>
      <div class="clasificacionreceta-${'ci4'}" style="height: 103px; margin: 1px 0px 0px 1px; overflow: hidden; position: relative; width: 49.82%;">
        <img class="analyzethis" data-src="${['cond', 'i4','src-clasificacionreceta4']}" data-width="160" data-height="160" data-webp="1" style="position: absolute; top: 50%; transform: translateY(-50%); vertical-align: top; width: 100%;" /></div>

      <div class="feed-clasificacionreceta-titulo-seccion" style="background-color: #fca032; box-sizing: border-box; color: #ffffff; font-size: 11px; left: 0px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; text-transform: uppercase; top: 15px;">
        Clasificación
      </div>
    </div>

    <div style="position: relative; height: 42px;">
      <div style="color: #333333; text-decoration: none; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 100%; padding: 0px 10px; box-sizing: border-box;">
        ${'n'}
      </div>
    </div>
  </a>
</div>
















`;
WA.templates['src-clasificacionreceta4'] = WA.templater`
/recetaimagen/${'ci4'}/${'i4'}`;
WA.templates['src-clasificacionreceta4.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificacionreceta1'] = WA.templater`
/recetaimagen/${'ci1'}/${'i1'}`;
WA.templates['src-clasificacionreceta1.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificacionreceta2'] = WA.templater`
/recetaimagen/${'ci2'}/${'i2'}`;
WA.templates['src-clasificacionreceta2.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-clasificacionreceta3'] = WA.templater`
/recetaimagen/${'ci3'}/${'i3'}`;
WA.templates['src-clasificacionreceta3.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['feed_coleccion'] = WA.templater`

<div id="${'x'}" class="tools coleccion-ficha" data-type="cc" data-key="${'k'}" style="background-color: #ffffff; /* box-shadow: 0 0 4px rgba(0, 0, 0, 0.25); */ cursor: pointer; float: left; height: auto; margin: 0px 15px 25px; position: relative; width: 22%;">
  <a href="${'pa'}">
    <div style="float: left; margin: 0; overflow: hidden; position: relative; width: 49.7%;">
      <img class="analyzethis" data-src="${['cond', 'i','src-coleccion']}" data-width="160" data-height="160" data-webp="1" style="width: 100%; vertical-align: top;" /></div>
    <div style="float: left; margin: 0 0 0 1px; overflow: hidden; position: relative; width: 49.7%;">
      <img class="analyzethis" data-src="${['cond', 'i','src-coleccion']}" data-width="160" data-height="160" data-webp="1" style="width: 100%; vertical-align: top;" /></div>
    <div style="float: left; margin: 1px 0 0; overflow: hidden; position: relative; width: 49.7%;">
      <img class="analyzethis" data-src="${['cond', 'i','src-coleccion']}" data-width="160" data-height="160" data-webp="1" style="width: 100%; vertical-align: top;" /></div>
    <div style="float: left; margin: 1px 0 0 1px; overflow: hidden; position: relative; width: 49.7%;">
      <img class="analyzethis" data-src="${['cond', 'i','src-coleccion']}" data-width="160" data-height="160" data-webp="1" style="width: 100%; vertical-align: top;" /></div>
  </a>
  
  <div onclick="borrarcoleccion(${'k'});" style="background-color: #dddddd; border: 2px solid #ffffff; border-radius: 100%; cursor: pointer; height: 20px; position: absolute; right: -11px; top: -11px; width: 20px; z-index: 100;">
    <span class="icon-k7-close" style="color: #ffffff; font-size: 9px; left: 50%; position: absolute; top: 50%; transform: translateX(-50%) translateY(-50%);"></span></div>
  
  <div id="nombrecoleccion_${'k'}" onclick="vercoleccion(${'k'});" style="align-items: center; box-sizing: border-box; color: #777777; display: flex; flex-wrap: wrap; font-size: 13px; height: 35px; left: 0px; line-height: 14px; overflow: hidden; padding: 4px 7px 5px; position: relative; text-transform: uppercase; width: 85%;">
    comidas
  </div>
  
  <div style="bottom: auto; box-sizing: border-box; font-style: italic; height: 18px; left: 0px; padding: 0px 7px; position: relative; width: 85%;">
    ${'n'}
  </div>
  
  <div onclick="modificarcoleccion(${'k'});" style="border-left: 1px solid #cccccc; bottom: 0px; height: 52px; position: absolute; right: 0px; width: 40px;">
    <span class="icon-k7-editar-l" style="color: #808080; font-size: 18px; left: 50%; position: absolute; top: 50%; transform: translateX(-50%) translateY(-50%);"></span></div>
</div>







`;
WA.templates['src-coleccion.none'] = WA.templater`
/img/static/logo-o-320x320.png`;
WA.templates['src-coleccion'] = WA.templater`
/recetaimagen/${'k'}/${'i'}`;
WA.templates['feed_producto'] = WA.templater`




${['cond', 'productosorigin','origenproducto']}
















${['cond', 'homeorigin','homeorigenproducto']}












`;
WA.templates['origenproducto.none'] = WA.templater`
`;
WA.templates['homeorigenproducto'] = WA.templater`

<div id="${'x'}" class="feed-producto-ficha" data-type="p" data-key="${'k'}" style="box-sizing: border-box; position: relative; display: flex; background-color: #ffffff;">
  <a href="${'pa'}">
    <img class="analyzethis" data-src="/productoventa/${'k'}/${'i'}" data-width="320" data-height="420" data-webp="1" alt="${'n'}" title="${'n'}" style="height: 100%; left: 50%; margin: 0px 0px 10px; position: absolute; top: 50%; transform: translateX(-50%) translateY(-50%); width: 100%;" />
  </a>
${'n'}
</div>
`;
WA.templates['homeorigenproducto.none'] = WA.templater`
`;
WA.templates['src-producto'] = WA.templater`
/productoventa/${'k'}/${'i'}`;
WA.templates['src-producto.none'] = WA.templater`
/img/static/logo-o-500x500.png`;
WA.templates['origenproducto.crafto'] = WA.templater`

<div id="${'x'}" class="feed-producto-ficha manualidades-cont-ficha" data-type="p" data-key="${'k'}" style="box-sizing: border-box; position: relative; width: 100%; display: flex; background-color: #ffffff;">
  
  <div class="manualidades-area-multimedia" style="box-sizing: border-box; position: relative; width: 630px; display: flex;">
    
    
    
    <div class="manualidades-multimedia-principal" style="width: 550px; height: 450px; position: relative; overflow: hidden;">
      
      <img class="analyzethis" data-src="/productoventa/${'k'}/${'i'}" data-width="612" data-height="792" data-webp="1" alt="${'n'}" title="${'n'}" style="left: 50%; margin: 0px 0px 10px; position: absolute; top: 0px; transform: translateX(-50%); width: 100%;" />
    </div>
  </div>

  
  <div class="manualidades-area-txtmanualidad" style="box-sizing: border-box; position: relative; width: calc(100% - 630px); ">
    <div class="manualidades-area-nombre" style="/* height: 62px; */ position: relative; max-height: 94px; overflow: hidden;">
      <h2 class="manualidades-nombre" style="color: #6c52a2; font-size: 32px; font-weight: bold; line-height: 30px; letter-spacing: 1px; margin: 0px; text-transform: uppercase; /*max-height: 61px; overflow: hidden; position: absolute; top: 50%; transform: translateY(-50%);*/">
        ${'n'}
      </h2>
    </div>

    <div class="manualidades-txtdescripcion" style="position: relative; font-size: 20px; line-height: 24px; color: #666666; margin: 30px 0px 0px; max-height: 194px; overflow: hidden;">
      ${'d'}
    </div>
    
    <a href="${'pa'}" class="manualidades-btn-descarga" style="background-color: #e5579a; border-radius: 5px; color: #ffffff; cursor: pointer; display: flex; font-family: 'source sans pro'; font-size: 17px; font-weight: bold; line-height: 25px; letter-spacing: 0.5px; padding: 8px 30px; text-transform: uppercase; min-width: 172px; width: -webkit-fit-content; width: -moz-fit-content; width: -o-fit-content; width: -ms-fit-content; width: fit-content;">
      <div class="icon-k7-flecha-descarga" style="-webkit-transform: rotate(90deg); -moz-transform: rotate(90deg); -o-transform: rotate(90deg); -ms-transform: rotate(90deg); writing-mode: vertical-rl; transform: rotate(90deg) translateY(10px);"></div> <span style="margin: 0px 0px 0px 10px;">Descarga gratis</span>
    </a>
  </div>
</div>
`;
WA.templates['origenproducto'] = WA.templater`

<div id="${'x'}" class="feed-producto-ficha" data-type="p" data-key="${'k'}" style="float: left; /*margin: 0px 10px 16px;*/ overflow: hidden; position: relative; /*width: 300px;*/ background-color: #ffffff;">
  <a href="${'pa'}">

    <div class="searchlist-muestra feed-producto-divimg" style="overflow: hidden; position: relative; width: 100%;">
      ${['cond', 'g','familiaproducto']}
      
      
      
      
      

      <div class="feed-producto-titulo-seccion" style="background-color: #8cc63e; box-sizing: border-box; color: #ffffff; font-size: 11px; letter-spacing: 1px; max-width: 140px; padding: 8px 13px; position: absolute; right: 0px; text-transform: uppercase; top: 15px;">
        Producto
      </div>
    </div>

    <div class="feed-producto-div-nombreprod" style="clear: both; position: relative; height: 42px;">
      <div style="box-sizing: border-box; color: #333333; font-size: 17px; font-weight: bold; line-height: 18px; max-height: 38px; overflow: hidden; padding: 0px 10px 2px; position: absolute; text-align: center; text-decoration: none; top: 50%; transform: translateY(-50%); width: 100%;">
        ${'n'}
      </div>
    </div>
  </a>
</div>
`;
WA.templates['familiaproducto.4'] = WA.templater`

        <img class="analyzethis" alt="${'n'}" title="${'n'}" data-src="${['cond', 'i','src-producto']}" data-width="320" data-height="420" data-webp="1" style="width: 100%; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);" />
      `;
WA.templates['familiaproducto'] = WA.templater`

        <img class="analyzethis" alt="${'n'}" title="${'n'}" data-src="${['cond', 'i','src-producto']}" data-width="500" data-height="500" data-webp="1" style="width: 100%; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);" />
      `;
WA.templates['slider_classifications.first'] = WA.templater`

<div class="slider-clasification-${'key'}" style="float: left; padding: 0px 7px 0px 0px; text-align: center; width: 108px;">
  <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
    <img class="analyzethis" data-src="${'imagepath'}${['cond', 'icon','slider_icon']}" data-width="108" data-height="108" data-webp="1" style="height: 108px; margin: 0px 0px 8px; width: 108px;" />${'shorttitle'}
  </a>
</div>
`;
WA.templates['slider_families.last'] = WA.templater`

<div class="slider-family-${'key'}" style="float: left; padding: 0px 0px 0px 7px; text-align: center; width: 108px;">
  <a href="${'path'}" style="color: #989898; font-size: 12px; letter-spacing: 1px; text-decoration: none; text-transform: uppercase;">
    <img class="analyzethis" data-src="${'imagepath'}${['cond', 'icon','slider_icon']}" data-width="108" data-height="108" data-webp="1" style="height: 108px; margin: 0px 0px 8px; width: 108px;" />${'shorttitle'}
  </a>
</div>
`;
WA.templates['slider_families.none'] = WA.templater`
`;
WA.templates['recipelist'] = WA.templater`
<div class="recipelist-areabotones" style="margin-top: 5px; display: table; position: relative; width: 100%;">
  <div id="recipelist-masnuevo" class="recipelist-button on">Lo más nuevo</div>
  <div id="recipelist-recomendado" class="recipelist-button">Recomendado</div>
  <div id="recipelist-maspopular" class="recipelist-button">Lo más popular</div>
</div>

<div id="recipelist" style="clear: both;" data-type="${'type'}" data-key="${'key'}" data-quantity="${'quantity'}" data-more="${'more'}" data-total="${'total'}" data-page="${'page'}">
  ${['loop', 'payload','feed_payload']}
</div>
<div id="recipelist-next" class="recipelist-btn-next" style="clear: both; margin-top: 15px; cursor: pointer; text-transform: uppercase; text-align: center; line-height: 1.6em; letter-spacing: 0.05em; font-size: 13px;">
Ver más<br />
<span class="icon-k7-recipelist-seemore"></span>
</div>
`;

KL.currentcode={"categories":[{"icon":"i4003.jpg","image":"4003.png","imagepath":"/clasificacion/4003/","key":4003,"link":"faciles","path":"/preferencia/faciles","shorttitle":"Fáciles","virtual":null},{"icon":"i1.jpg","image":"1.jpg","imagepath":"/clasificacion/1/","key":1,"link":"postres","path":"/recetas/postres","shorttitle":"Postres","virtual":null},{"icon":"i48.jpg","image":"48.jpg","imagepath":"/clasificacion/48/","key":48,"link":"carnes-y-aves","path":"/recetas/carnes-y-aves","shorttitle":"Pollo y Carne","virtual":null},{"icon":"i3356.jpg","image":"3356.jpg","imagepath":"/clasificacion/3356/","key":3356,"link":"recetas-a-la-parrilla","path":"/temporada/recetas-a-la-parrilla","shorttitle":"Recetas a la Parrilla","virtual":null},{"icon":"i67.jpg","image":"67.jpg","imagepath":"/clasificacion/67/","key":67,"link":"ensaladas","path":"/recetas/ensaladas","shorttitle":"Ensaladas","virtual":null},{"icon":"i74.jpg","image":"74.jpg","imagepath":"/clasificacion/74/","key":74,"link":"guarniciones","path":"/recetas/guarniciones","shorttitle":"Guarniciones","virtual":null},{"icon":"i93.jpg","image":"93.jpg","imagepath":"/clasificacion/93/","key":93,"link":"pescados-y-mariscos","path":"/recetas/pescados-y-mariscos","shorttitle":"Pescados y Mariscos","virtual":null},{"icon":"i104.jpg","image":"104.jpg","imagepath":"/clasificacion/104/","key":104,"link":"botanas","path":"/recetas/botanas","shorttitle":"Recetas de Botanas Fáciles","virtual":null},{"icon":"i115.jpg","image":"115.jpg","imagepath":"/clasificacion/115/","key":115,"link":"pastas","path":"/recetas/pastas","shorttitle":"Recetas de Pastas","virtual":null},{"icon":"i127.jpg","image":"127.jpg","imagepath":"/clasificacion/127/","key":127,"link":"comida-para-ninos","path":"/recetas/comida-para-ninos","shorttitle":"Comida para Niños","virtual":null},{"icon":"i128.jpg","image":"128.jpg","imagepath":"/clasificacion/128/","key":128,"link":"postres-para-ninos","path":"/recetas/postres-para-ninos","shorttitle":"Postres para Niños","virtual":null},{"icon":"i122.jpg","image":"122.jpg","imagepath":"/clasificacion/122/","key":122,"link":"sopas","path":"/recetas/sopas","shorttitle":"Sopas","virtual":null},{"icon":"i129.jpg","image":"129.jpg","imagepath":"/clasificacion/129/","key":129,"link":"saludables","path":"/recetas/saludables","shorttitle":"Saludables","virtual":null},{"icon":"i130.jpg","image":"130.jpg","imagepath":"/clasificacion/130/","key":130,"link":"desayunos","path":"/recetas/desayunos","shorttitle":"Desayunos","virtual":null},{"icon":"i142.jpg","image":"142.jpg","imagepath":"/clasificacion/142/","key":142,"link":"panes","path":"/recetas/panes","shorttitle":"Panes","virtual":null},{"icon":"i3406.jpg","image":"3406.jpg","imagepath":"/clasificacion/3406/","key":3406,"link":"guarniciones-de-exito","path":"/recetas/guarniciones-de-exito","shorttitle":"Guarniciones de Éxito","virtual":null},{"icon":"i144.jpg","image":"144.jpg","imagepath":"/clasificacion/144/","key":144,"link":"salsas","path":"/recetas/salsas","shorttitle":"Salsas","virtual":null},{"icon":"i1000.jpg","image":"1000.jpg","imagepath":"/clasificacion/1000/","key":1000,"link":"bebidas","path":"/recetas/bebidas","shorttitle":"Bebidas","virtual":null},{"icon":"i3675.jpg","image":"3675.jpg","imagepath":"/clasificacion/3675/","key":3675,"link":"platos-fuertes","path":"/recetas/platos-fuertes","shorttitle":"Platos Fuertes","virtual":null},{"icon":"i3119.jpg","image":"3119.jpg","imagepath":"/clasificacion/3119/","key":3119,"link":"navidad","path":"/temporada/navidad","shorttitle":"Recetas Navideñas","virtual":null}],"recipelist":{"key":"","more":true,"page":1,"payload":[{"cn":"Fresh Gourmet","i":"52270.jpg","k":39777,"m":2,"mt":"normal","n":"Tacos de Lomo a la Parrilla ","pa":"/receta/platos-fuertes/mexicanos/tacos-de-lomo-a-la-parrilla","pr":"100.0%","s":1,"t":"receta","v":"728130359126507","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|1"},{"cn":"Eva  ","i":"52267.jpg","k":39776,"m":2,"mt":"normal","n":"Shawarma de Carne","pa":"/receta/carnes-y-aves/cordero/shawarma-de-carne","pr":"100.0%","s":1,"t":"receta","v":"800826429359982","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|2"},{"cn":"María  Ibarra ","i":"52261.jpg","k":39774,"m":2,"mt":"normal","n":"Receta de Chile Relleno de Queso","pa":"/receta/platos-fuertes/mexicanos/receta-de-chile-relleno-de-queso","pr":"100.0%","s":1,"t":"receta","v":"644823267105263","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|3"},{"cn":"Mundet   ","i":"52241.jpg","k":39767,"m":2,"mt":"normal","n":"Chicharrón en Salsa Ranchera","pa":"/receta/carnes-y-aves/cerdos/chicharron/chicharron-en-salsa-ranchera","pr":"100.0%","s":1,"t":"receta","v":"657274459210390","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|4"},{"class":"adnetwork","formatid":"72089","k":"","mt":"sola","nid":"300x250","num":"p|kiwi|home||1|2|5","placementid":"13081605","preid":"300x250","size":"[[300,250],[336,280]]","t":"ad","x":"p|kiwi|home||1|2|5"},{"cn":"Royal Prestige","i":"52224.jpg","k":39760,"m":2,"mt":"normal","n":"Monster Shake de Café","pa":"/receta/bebidas/sin-alcohol/licuados/monster-shake-de-cafe","pr":"100.0%","s":1,"t":"receta","v":"871862967002066","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|6"},{"cn":"Yamilette González","i":"52234.jpg","k":39764,"m":2,"mt":"normal","n":"Milanesas Napolitanas de Cerdo","pa":"/receta/carnes-y-aves/milanesas-napolitanas-de-cerdo","pr":"100.0%","s":1,"t":"receta","v":"921648502734662","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|7"},{"cn":"Barilla   ","i":"52229.jpg","k":39762,"m":2,"mt":"normal","n":"Pizza Lasaña","pa":"/receta/pastas/lasana/pizza-lasana","pr":"100.0%","s":1,"t":"receta","v":"813194170966020","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|8"},{"cn":"Bionda  Requesón","i":"52227.jpg","k":39761,"m":2,"mt":"normal","n":"Arroz con Leche Ligero","pa":"/receta/postres/los-mejores-postres-sin-horno/arroz-con-leche-ligero","pr":"100.0%","s":1,"t":"receta","v":"197698847946237","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|9"},{"cn":"María  Ibarra ","i":"52214.jpg","k":39757,"m":2,"mt":"normal","n":"Paletas de Carlota de Limón","pa":"/receta/postres/postres-frios/paletas-heladas/paletas-de-carlota-de-limon","pr":"100.0%","s":1,"t":"receta","v":"291317764303189","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|10"},{"cn":"La Moderna  ","i":"52211.jpg","k":39756,"m":2,"mt":"normal","n":"Receta de Spaghetti al Pesto con Camarones","pa":"/receta/pastas/spaghetti/receta-de-spaghetti-al-pesto-con-camarones","pr":"100.0%","s":1,"t":"receta","v":"378875396010294","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|11"},{"cn":"Capullo   ","i":"52208.jpg","k":39755,"m":2,"mt":"normal","n":"Cacerola de Milanesas Alfredo ","pa":"/receta/carnes-y-aves/pollos/pechugas-de-pollo/cacerola-de-milanesas-alfredo","pr":"100.0%","s":1,"t":"receta","v":"232717432448159","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|12"},{"cn":"Huevo San Juan®","i":"52205.jpg","k":39754,"m":2,"mt":"normal","n":"Tiramisú de Calabaza","pa":"/receta/postres/postres-frios/tiramisu/tiramisu-de-calabaza","pr":"100.0%","s":1,"t":"receta","v":"546034798180641","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|13"},{"cn":"Yamilette González","i":"52192.jpg","k":39749,"m":2,"mt":"normal","n":"Vorí Vorí","pa":"/receta/carnes-y-aves/pollos/vori-vori","pr":"100.0%","s":1,"t":"receta","v":"468418683877536","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|14"},{"cn":"María  Ibarra ","i":"52189.jpg","k":39747,"m":2,"mt":"normal","n":"Frijoles con Chorizo y Queso","pa":"/receta/guarniciones/frijoles/frijoles-con-chorizo-y-queso","pr":"100.0%","s":1,"t":"receta","v":"130734187711261","vh":"100.00%","vp":"B1xDbuGM","vr":"5.0","x":"p|kiwi|home||1|2|15"},{"class":"adnetwork","formatid":"72089","k":"","mt":"sola","nid":"300x250","num":"p|kiwi|home||1|2|16","placementid":"13081605","preid":"300x250","size":"[[300,250],[336,280]]","t":"ad","x":"p|kiwi|home||1|2|16"}],"quantity":16,"time":0,"total":5335,"type":"home"}};

KL.LoadedModules.push('errorpage');

KL.currenttemplate=WA.templates['errorpage'];

KL.LoadedModules.push('gallery');


KL.LoadedModules.push('slider');


KL.LoadedModules.push('tools');


KL.LoadedModules.push('feed');


KL.LoadedModules.push('recipelist');

</script></div>
<div style="max-width: 1280px; clear: both; margin: 0 auto 0;">

  <div id="footer-div-crosslink" style="background-color: #ffffff; box-sizing: border-box; color: #aaaaaa; float: left; font-size: 15px; font-weight: 200; letter-spacing: 0.7px; margin: 30px 0px 0px; padding: 17px 30px 5px; text-align: center; width: 880px;">
    También te puede interesar
    
    <div id="footer-crosslink" class="slider" style="margin-top: 10px;"></div>
    <div style="clear: both;"></div>
  </div>
  
  <div id="adbottom" style="float: right; margin-top: 30px; width: 300px; color: #555555; letter-spacing: 0.05em; text-transform: uppercase; font-size: 17px; font-weight: 100; text-align: center; margin-right: 20px;">
    Publicidad
    <div class="buildad" style="margin-top: 10px;" data-id="300x250" data-position="bottom"></div>
  </div>
  <div style="clear: both;"></div>

  <div id="footer-adbanner" style="width: 100%; text-align: center; margin-top: 40px;">
    <div class="buildad" data-id="footer" data-position="bottom"></div>
  </div>
</div>







<div id="footer-divfooter" style="background-color: var(--verde-kiwi); box-sizing: border-box; color: #ffffff; /*padding: 70px 140px;*/ padding: 70px 120px; position: relative; width: 100%; margin-top: 20px;">
  
  <div style="float: left; padding: 40px 85px 0px 0px; position: relative;">
    <a href="/mi-cuenta/receta" style="color: #ffffff;">
      <div class="icon-k7-sube-receta-footer" style="float: left; font-size: 17px; text-align: center; width: 20px;"></div>
      <div style="float: left; font-size: 14px; padding: 1px 11px; text-transform: uppercase; white-space: nowrap;">Subir una receta</div>
    </a>

    <a href="/login" style="color: #ffffff;">
      <div style="clear: both;  padding: 25px 0px 0px;">
        <div class="icon-k7-registrate" style="float: left; font-size: 17px; text-align: center; width: 20px;"></div>
        <div style="float: left; font-size: 14px; padding: 1px 11px; text-transform: uppercase; white-space: nowrap;">Regístrate</div>
      </div>
    </a>

    <a href="/app" style="color: #ffffff;">
      <div style="clear: both;  padding: 25px 0px 0px;">
        <div class="icon-k7-o-footer" style="float: left; font-size: 17px; text-align: center; width: 20px;"></div>
        <div style="float: left; font-size: 14px; padding: 1px 11px; text-transform: uppercase; white-space: nowrap;">Descarga la APP</div>
      </div>
    </a>
  </div>

  
  <div style="border-left: 1px solid #ffffff; float: left; padding: 15px 0px 15px 80px; position: relative;">
    
    <div style="position: relative; float: left;">
      <div class="icon-k7-logo" style="color: #ffffff; font-size: 26px; padding: 0px 0px 20px; position: relative;"></div>
      <a href="https://www.facebook.com/kiwilimon" target="_blank" style="color: #ffffff;"><span class="icon-k7-facebook" style="font-size: 21px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="https://twitter.com/Kiwilimon_LAT" target="_blank" style="color: #ffffff;"><span class="icon-k7-twitter" style="font-size: 20px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="https://instagram.com/kiwilimon" target="_blank" style="color: #ffffff;"><span class="icon-k7-instagram" style="font-size: 21px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="https://www.youtube.com/user/chefkiwilimon?sub_confirmation=1" target="_blank" style="color: #ffffff;"><span class="icon-k7-youtube" style="font-size: 20px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="https://www.pinterest.com/kiwilimon/" target="_blank" style="color: #ffffff;"><span class="icon-k7-pinterest" style="font-size: 21px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="https://www.tiktok.com/@kiwilimonoficial?" target="_blank" style="color: #ffffff;"><span class="icon-k7-tiktok" style="font-size: 20px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="https://feeds.feedburner.com/recetas_kiwilimon" target="_blank" style="color: #ffffff;"><span class="icon-k7-rss" style="font-size: 20px; padding: 0px 20px 0px 0px;"></span></a>
      <a href="/informacion" class="normal_link_footer" style="color: #ffffff;">
        <div style="padding: 70px 0px 0px; position: relative;">kiwilimón® ©2022</div>
      </a>
    </div>

    
    <div style="float: left; padding: 0px 0px 0px 90px; position: relative;">
      <div style="color: #ffffff; font-weight: bold; padding: 0px 0px 20px; text-transform: uppercase;">Enlaces útiles</div>
      <div style="padding: 0px 0px 10px;"><a href="/blog" Style="color: #ffffff;">Blog</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/recetas" Style="color: #ffffff;">Recetas</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/tips" Style="color: #ffffff;">Tips</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/temporada" Style="color: #ffffff;">Temporadas</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/quiz" Style="color: #ffffff;">Quizzes</a></div>
      <div style="padding: 0px 0px 0px;"><a href="/mapa-del-sitio" Style="color: #ffffff;">Mapa del Sitio</a></div>
    </div>

    
    <div style="float: left; padding: 0px 0px 0px 70px; position: relative;">
      <div style="color: #ffffff; font-weight: bold; padding: 0px 0px 20px; text-transform: uppercase;">La Compañía</div>
      <div style="padding: 0px 0px 10px;"><a href="/informacion/aviso-de-privacidad" Style="color: #ffffff;">Aviso de Privacidad</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/informacion/politicas-de-uso" Style="color: #ffffff;">Políticas de Uso del Sitio Web</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/informacion/anunciate" Style="color: #ffffff;">Anúnciate</a></div>
      <div style="padding: 0px 0px 10px;"><a href="/informacion/contacto" Style="color: #ffffff;">Contacto</a></div>
    </div>
  </div>
  <div style="clear: both;"></div>
</div>





    <div id="backgroundpopup" style="display: none;"></div>
    <div id="popup" style="display: none;"></div>
  </body>
</html>
